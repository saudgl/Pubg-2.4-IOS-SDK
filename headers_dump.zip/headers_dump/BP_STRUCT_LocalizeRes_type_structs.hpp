#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_LocalizeRes_type {
	// Fields
	struct FString TextValue_0_4D37165A410D67320AF278A1C1028E4F; // Offset: 0x00 // Size: 0x10
	int TextId_1_20B947934F165858A322E599888F816E; // Offset: 0x10 // Size: 0x04
};

