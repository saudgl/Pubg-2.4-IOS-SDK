#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_RecommendDelete_type.BP_STRUCT_RecommendDelete_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_RecommendDelete_type {
	// Fields
	int ID_0_086B8400728145E4295143780ED1FFD4; // Offset: 0x00 // Size: 0x04
	int nActDay_1_5ED509C054F4D2FD43415E1602979569; // Offset: 0x04 // Size: 0x04
	int nCondition1_2_49EB9240540319512D0C230506E88D41; // Offset: 0x08 // Size: 0x04
	int nCondition2_3_49EC9280540319522D0C230406E88D42; // Offset: 0x0c // Size: 0x04
	int nCycleDay_4_63BF7FC049CBBEC95915A934029D78C9; // Offset: 0x10 // Size: 0x04
	int nDeleteAll_5_10C1974050B4C62B6C0F63D60334B45C; // Offset: 0x14 // Size: 0x04
	int nMapTimeLimte_6_304CA6407A10DBB56A9AA1EC0057C185; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString sDeleteData_7_38EE70C019CC767F190FECBD036EEF91; // Offset: 0x20 // Size: 0x10
};

