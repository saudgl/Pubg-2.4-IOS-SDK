#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LoadedClassManager_BP.LoadedClassManager_BP_C
// Size: 0x398 // Inherited bytes: 0x340
struct ULoadedClassManager_BP_C : UUAELoadedClassManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct TMap<struct FString, struct FString> BPTableName2TableName; // Offset: 0x348 // Size: 0x50

	// Functions

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadBPTableData_Mod
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadBPTableData_Mod(struct FString BPTableName, struct FString tableName); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadBPTableData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadBPTableData(struct FString BPTableName, struct FString tableName); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.Load3DIconBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Load3DIconBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadInFillingBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadInFillingBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehiclePropsBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehiclePropsBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadDecalBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadDecalBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSkillPropsBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadSkillPropsBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitPartternBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehilceRefitPartternBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitColorBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehilceRefitColorBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitParticleBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehilceRefitParticleBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPetAvatarBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadPetAvatarBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehilceRefitBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehilceRefitBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadSeasonMissionBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadSeasonMissionBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarPatternBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadAvatarPatternBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarColorBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadAvatarColorBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadVehicleBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadVehicleBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadPlaneBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadPlaneBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadEmoteBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadEmoteBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadConsumableBPTable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadConsumableBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadGameModeBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadGameModeBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadAvatarBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadAvatarBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.LoadWeaponBPTable
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadWeaponBPTable(struct FString BPTableName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.InitBPTableMap_Mod
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap_Mod(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LoadedClassManager_BP.LoadedClassManager_BP_C.ExecuteUbergraph_LoadedClassManager_BP
	// Flags: [None]
	void ExecuteUbergraph_LoadedClassManager_BP(int EntryPoint); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)
};

