#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GameLogicManagerBase.GameLogicManagerBase_C
// Size: 0x170 // Inherited bytes: 0x170
struct UGameLogicManagerBase_C : UGameBusinessManager {
};

