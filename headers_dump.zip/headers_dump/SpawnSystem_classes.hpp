#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SpawnSystem.SpawnSystemSettings
// Size: 0x50 // Inherited bytes: 0x38
struct USpawnSystemSettings : UDeveloperSettings {
	// Fields
	float TickFrequency; // Offset: 0x38 // Size: 0x04
	int TickingSpawnerThreshold; // Offset: 0x3c // Size: 0x04
	bool bShouldSpawnSystemLogout; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	int MaxWaitSpawnQueSize; // Offset: 0x44 // Size: 0x04
	float VisualDebugRange; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04

	// Functions

	// Object Name: Function SpawnSystem.SpawnSystemSettings.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct USpawnSystemSettings* Get(); // Offset: 0x10227b7d4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STSpawnerBase
// Size: 0x510 // Inherited bytes: 0x3c0
struct ASTSpawnerBase : AActor {
	// Fields
	char pad_0x3C0[0x68]; // Offset: 0x3c0 // Size: 0x68
	struct FString LuaFilePath; // Offset: 0x428 // Size: 0x10
	struct USTStrategyTiming* SpawnTiming; // Offset: 0x438 // Size: 0x08
	struct USTStrategyLocation* SpawnLocation; // Offset: 0x440 // Size: 0x08
	struct USTStrategySpecies* SpawnSpecies; // Offset: 0x448 // Size: 0x08
	struct TArray<struct USTStrategyCond*> SpawnConditions; // Offset: 0x450 // Size: 0x10
	char bUseRegion : 1; // Offset: 0x460 // Size: 0x01
	char pad_0x460_1 : 7; // Offset: 0x460 // Size: 0x01
	char pad_0x461[0x3]; // Offset: 0x461 // Size: 0x03
	int SpawnerCampID; // Offset: 0x464 // Size: 0x04
	enum class ESTSpawnerVolume VolumeType; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x3]; // Offset: 0x469 // Size: 0x03
	float SphereRadius; // Offset: 0x46c // Size: 0x04
	struct FVector BoxHalfExtent; // Offset: 0x470 // Size: 0x0c
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct ASTSpawnSpot* SpawnSpotClass; // Offset: 0x480 // Size: 0x08
	struct FScriptMulticastDelegate OnSpawnUnitSuccessDelegate; // Offset: 0x488 // Size: 0x10
	uint32_t SpawnerID; // Offset: 0x498 // Size: 0x04
	int MaxUnitsCount; // Offset: 0x49c // Size: 0x04
	int MaxAliveCount; // Offset: 0x4a0 // Size: 0x04
	char pad_0x4A4[0x4]; // Offset: 0x4a4 // Size: 0x04
	struct FString SpawnerDescString; // Offset: 0x4a8 // Size: 0x10
	struct FString SpawnerSnapshot; // Offset: 0x4b8 // Size: 0x10
	struct TArray<struct ASTSpawnSpot*> SpawnSpots; // Offset: 0x4c8 // Size: 0x10
	struct TArray<struct AActor*> AlivePawns; // Offset: 0x4d8 // Size: 0x10
	char bActive : 1; // Offset: 0x4e8 // Size: 0x01
	char bInitialized : 1; // Offset: 0x4e8 // Size: 0x01
	char bTimeIsRipe : 1; // Offset: 0x4e8 // Size: 0x01
	char pad_0x4E8_3 : 5; // Offset: 0x4e8 // Size: 0x01
	char pad_0x4E9[0x3]; // Offset: 0x4e9 // Size: 0x03
	int TotalSpawnedUnits; // Offset: 0x4ec // Size: 0x04
	struct USTSpawnSubsystem* SpawnSubsystem; // Offset: 0x4f0 // Size: 0x08
	char pad_0x4F8[0x18]; // Offset: 0x4f8 // Size: 0x18

	// Functions

	// Object Name: Function SpawnSystem.STSpawnerBase.Thinking
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void Thinking(float DeltaTime); // Offset: 0x10227cfc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.Switch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Switch(bool IsSwitchOn); // Offset: 0x10227cf40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnerBase.SetSpawnerID
	// Flags: [Final|Native|Public]
	void SetSpawnerID(uint32_t ID); // Offset: 0x10227cec8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnUnitSpawned
	// Flags: [Native|Public]
	void OnUnitSpawned(uint32_t InSpawnerID, struct APawn* AIPawn, int ConfigId); // Offset: 0x10227cdcc // Return & Params: Num(3) Size(0x14)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnUnitDead
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnUnitDead(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Offset: 0x10227cd14 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnSpawnTimingRipe
	// Flags: [Native|Protected]
	void OnSpawnTimingRipe(bool IsRipe); // Offset: 0x10227cc88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnSpawnerDeactivate
	// Flags: [Event|Protected|BlueprintEvent]
	void OnSpawnerDeactivate(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnSpawnerActivate
	// Flags: [Event|Protected|BlueprintEvent]
	void OnSpawnerActivate(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.OnRep_SpawnerID
	// Flags: [Final|Native|Protected]
	void OnRep_SpawnerID(); // Offset: 0x10227cc74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.Multicast_SpawnerSnapshot
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable]
	void Multicast_SpawnerSnapshot(struct FString Timing, struct FString Species, struct FString Location, struct FString Conditions, struct FString Extra); // Offset: 0x10227ca84 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function SpawnSystem.STSpawnerBase.Multicast_AlivePawnsChange
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable]
	void Multicast_AlivePawnsChange(struct APawn* Unit, bool IsBorn, bool IsAllDead); // Offset: 0x10227c970 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function SpawnSystem.STSpawnerBase.ModifyMaxAlive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyMaxAlive(int NewAlive); // Offset: 0x10227c8f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.IsInitialized
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInitialized(); // Offset: 0x10227c8d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnerBase.IsActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsActive(); // Offset: 0x10227c8b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnerBase.InitSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void InitSpawner(); // Offset: 0x10227c898 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetTotalSpawnedNum
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetTotalSpawnedNum(); // Offset: 0x10227c87c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnSystem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USTSpawnSubsystem* GetSpawnSystem(); // Offset: 0x10227c860 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnSpots
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct ASTSpawnSpot*> GetSpawnSpots(); // Offset: 0x10227c844 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSpawnRadius(); // Offset: 0x10227c828 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FVector GetSpawnLocation(); // Offset: 0x10227c790 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetSpawnExtent(); // Offset: 0x10227c76c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnerSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSpawnerSnapshot(); // Offset: 0x10227c704 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnerID
	// Flags: [Final|Native|Public|Const]
	uint32_t GetSpawnerID(); // Offset: 0x10227c6e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetSpawnerDesc
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSpawnerDesc(); // Offset: 0x10227c680 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetReferencedCount
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	int GetReferencedCount(); // Offset: 0x10227c644 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetMaxUnits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetMaxUnits(); // Offset: 0x10227c628 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetMaxAlive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetMaxAlive(); // Offset: 0x10227c60c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnerBase.GetAliveUnits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct AActor*> GetAliveUnits(); // Offset: 0x10227c57c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnerBase.FindSpot
	// Flags: [Final|Native|Protected]
	struct ASTSpawnSpot* FindSpot(struct FString SpotID); // Offset: 0x10227c4b0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpawnSystem.STSpawnerBase.DeactivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void DeactivateSpawner(); // Offset: 0x10227c494 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.CheckOwnedUnit
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CheckOwnedUnit(struct AActor* InUnit); // Offset: 0x10227c408 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function SpawnSystem.STSpawnerBase.AnalyseConfigData
	// Flags: [Native|Protected|BlueprintCallable]
	void AnalyseConfigData(); // Offset: 0x10227c3ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnerBase.ActivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateSpawner(); // Offset: 0x10227c3d0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class SpawnSystem.STSpawnSpot
// Size: 0x3e0 // Inherited bytes: 0x3c0
struct ASTSpawnSpot : AActor {
	// Fields
	struct FString SpotID; // Offset: 0x3c0 // Size: 0x10
	int SpotWeigh; // Offset: 0x3d0 // Size: 0x04
	enum class ESpawnSpotType SpotType; // Offset: 0x3d4 // Size: 0x01
	char pad_0x3D5[0x3]; // Offset: 0x3d5 // Size: 0x03
	int SquadIndex; // Offset: 0x3d8 // Size: 0x04
	int UnitIndex; // Offset: 0x3dc // Size: 0x04

	// Functions

	// Object Name: Function SpawnSystem.STSpawnSpot.HasModifySpecies
	// Flags: [Final|Native|Public|Const]
	bool HasModifySpecies(); // Offset: 0x10227dba8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnSpot.GetSpotWeigh
	// Flags: [Final|Native|Public|Const]
	int GetSpotWeigh(); // Offset: 0x10227db8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnSpot.GetSpotUnitIndex
	// Flags: [Final|Native|Public|Const]
	int GetSpotUnitIndex(); // Offset: 0x10227db70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnSpot.GetSpotType
	// Flags: [Final|Native|Public|Const]
	enum class ESpawnSpotType GetSpotType(); // Offset: 0x10227db54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnSpot.GetSpotSquadIndex
	// Flags: [Final|Native|Public|Const]
	int GetSpotSquadIndex(); // Offset: 0x10227db38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnSpot.GetSpotID
	// Flags: [Final|Native|Public|Const]
	struct FString GetSpotID(); // Offset: 0x10227dad0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class SpawnSystem.STSpawnSubsystem
// Size: 0x130 // Inherited bytes: 0x30
struct USTSpawnSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
	struct TMap<uint32_t, struct ASTSpawnerBase*> SpawnersMap; // Offset: 0x38 // Size: 0x50
	char pad_0x88[0x28]; // Offset: 0x88 // Size: 0x28
	float TickFrequency; // Offset: 0xb0 // Size: 0x04
	int ThinkTimesPerFrame; // Offset: 0xb4 // Size: 0x04
	int MaxWaitSpawnQueSize; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x74]; // Offset: 0xbc // Size: 0x74

	// Functions

	// Object Name: Function SpawnSystem.STSpawnSubsystem.UnregisterSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void UnregisterSpawner(struct ASTSpawnerBase* Spawner); // Offset: 0x10227e580 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.UnitFindSpawner
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ASTSpawnerBase* UnitFindSpawner(int UnitUID); // Offset: 0x10227e4f4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.SpawnUnit
	// Flags: [Native|Protected|BlueprintCallable]
	struct AActor* SpawnUnit(struct FSTSpawnParam SpawnParam); // Offset: 0x10227e3c4 // Return & Params: Num(2) Size(0xa8)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.RegisterSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterSpawner(struct ASTSpawnerBase* Spawner); // Offset: 0x10227e340 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.RecordProgress
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void RecordProgress(); // Offset: 0x10227e32c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.ReadySpawn
	// Flags: [Native|Protected|BlueprintCallable]
	void ReadySpawn(); // Offset: 0x10227e310 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.PreCheck
	// Flags: [Native|Protected|BlueprintCallable]
	bool PreCheck(); // Offset: 0x10227e2d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.OrderSpawnerThinking
	// Flags: [Native|Protected|BlueprintCallable]
	void OrderSpawnerThinking(float DeltaTime); // Offset: 0x10227e250 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.InitUnit
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	void InitUnit(struct APawn* AIPawn, struct TArray<struct FUnitInitConfig>& Configs); // Offset: 0x10227e164 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.GetUnitConfigID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetUnitConfigID(struct AActor* Unit); // Offset: 0x10227e0d0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.GetAllUnits
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct AActor*> GetAllUnits(); // Offset: 0x10227e06c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.FindSpawner
	// Flags: [Final|Native|Public|Const]
	struct ASTSpawnerBase* FindSpawner(uint32_t SpawnerID); // Offset: 0x10227dfe0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.EnQueue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void EnQueue(struct FSTSpawnParam& SpawnParam, struct ASTSpawnerBase* Spawner); // Offset: 0x10227de90 // Return & Params: Num(2) Size(0xa8)

	// Object Name: Function SpawnSystem.STSpawnSubsystem.CleanQueue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CleanQueue(); // Offset: 0x10227de7c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class SpawnSystem.STSpawnSystemGameplayStatics
// Size: 0x28 // Inherited bytes: 0x28
struct USTSpawnSystemGameplayStatics : UGameplayStatics {
	// Functions

	// Object Name: Function SpawnSystem.STSpawnSystemGameplayStatics.UnitFindSpawner
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ASTSpawnerBase* UnitFindSpawner(struct UObject* WorldContextObject, int UnitUID); // Offset: 0x10227ec84 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function SpawnSystem.STSpawnSystemGameplayStatics.ProjectPointToFloorWithComplexCollisionCheck
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector ProjectPointToFloorWithComplexCollisionCheck(struct UObject* WorldContextObject, struct FVector& Origin, bool& bOutHit, bool bCheckComplex, float OffsetHeight); // Offset: 0x10227eadc // Return & Params: Num(6) Size(0x28)

	// Object Name: Function SpawnSystem.STSpawnSystemGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsEditor(); // Offset: 0x10227eaa8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class SpawnSystem.STSpawnVisualDebug
// Size: 0xe0 // Inherited bytes: 0x28
struct USTSpawnVisualDebug : UObject {
	// Fields
	char pad_0x28[0xb8]; // Offset: 0x28 // Size: 0xb8

	// Functions

	// Object Name: Function SpawnSystem.STSpawnVisualDebug.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct USTSpawnVisualDebug* Get(); // Offset: 0x10227ef34 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STSpeciesDataAsset
// Size: 0x70 // Inherited bytes: 0x30
struct USTSpeciesDataAsset : UDataAsset {
	// Fields
	struct TArray<struct FUnitConfig> UnitConfig; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FSquadConfig> SquadConfig; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FGroupConfig> GroupConfig; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FSpeciesRatioStruct> RatioConfig; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class SpawnSystem.STStrategyBase
// Size: 0xe0 // Inherited bytes: 0x28
struct USTStrategyBase : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
	char bShouldCD : 1; // Offset: 0x98 // Size: 0x01
	char pad_0x98_1 : 7; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x3]; // Offset: 0x99 // Size: 0x03
	float ConfigCDDuration; // Offset: 0x9c // Size: 0x04
	struct ASTSpawnerBase* OwnerSpawner; // Offset: 0xa0 // Size: 0x08
	char bSTActive : 1; // Offset: 0xa8 // Size: 0x01
	char bTickEnable : 1; // Offset: 0xa8 // Size: 0x01
	char pad_0xA8_2 : 6; // Offset: 0xa8 // Size: 0x01
	char pad_0xA9[0x3]; // Offset: 0xa9 // Size: 0x03
	float CDCounter; // Offset: 0xac // Size: 0x04
	struct FString OwnerName; // Offset: 0xb0 // Size: 0x10
	struct FString StrategyName; // Offset: 0xc0 // Size: 0x10
	struct FString StrategySnapshot; // Offset: 0xd0 // Size: 0x10

	// Functions

	// Object Name: Function SpawnSystem.STStrategyBase.UpdateSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSnapshot(struct FString New); // Offset: 0x10227f4e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STStrategyBase.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x10227f464 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyBase.ResetCD
	// Flags: [Native|Protected|BlueprintCallable]
	void ResetCD(); // Offset: 0x10227f448 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyBase.OnStrategyDeactivate
	// Flags: [Event|Protected|BlueprintEvent]
	void OnStrategyDeactivate(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyBase.OnStrategyActivate
	// Flags: [Event|Protected|BlueprintEvent]
	void OnStrategyActivate(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyBase.IsSTActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSTActive(); // Offset: 0x10227f428 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyBase.IsOnCD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOnCD(); // Offset: 0x10227f3f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyBase.GetTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetTickEnable(); // Offset: 0x10227f3d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyBase.GetStrategyDesc
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetStrategyDesc(); // Offset: 0x10227f36c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STStrategyBase.GetSnapshot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSnapshot(); // Offset: 0x10227f304 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STStrategyBase.GetOwnerSpawner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ASTSpawnerBase* GetOwnerSpawner(); // Offset: 0x10227f2e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function SpawnSystem.STStrategyBase.DeactivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void DeactivateStrategy(); // Offset: 0x10227f2cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyBase.CDRemaining
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float CDRemaining(); // Offset: 0x10227f2b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyBase.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x10227f22c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategyCond
// Size: 0xe0 // Inherited bytes: 0xe0
struct USTStrategyCond : USTStrategyBase {
	// Functions

	// Object Name: Function SpawnSystem.STStrategyCond.LuaCheckCondition
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool LuaCheckCondition(); // Offset: 0x10227faf0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyCond.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CheckCondition(); // Offset: 0x10227fab4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class SpawnSystem.STStrategyCond_Hide
// Size: 0x108 // Inherited bytes: 0xe0
struct USTStrategyCond_Hide : USTStrategyCond {
	// Fields
	float Radius; // Offset: 0xe0 // Size: 0x04
	float Height; // Offset: 0xe4 // Size: 0x04
	struct FVector CharacterFOV; // Offset: 0xe8 // Size: 0x0c
	char bUseLineTrace : 1; // Offset: 0xf4 // Size: 0x01
	char pad_0xF4_1 : 7; // Offset: 0xf4 // Size: 0x01
	char pad_0xF5[0x3]; // Offset: 0xf5 // Size: 0x03
	struct ACharacter* ClassFilter; // Offset: 0xf8 // Size: 0x08
	char bUseSpawnerLoc : 1; // Offset: 0x100 // Size: 0x01
	char pad_0x100_1 : 7; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07

	// Functions

	// Object Name: Function SpawnSystem.STStrategyCond_Hide.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CheckCondition(); // Offset: 0x10227fcdc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class SpawnSystem.STStrategyCond_Quantity
// Size: 0xf0 // Inherited bytes: 0xe0
struct USTStrategyCond_Quantity : USTStrategyCond {
	// Fields
	char bLimitAlive : 1; // Offset: 0xe0 // Size: 0x01
	char bCustomQuantity : 1; // Offset: 0xe0 // Size: 0x01
	char pad_0xE0_2 : 6; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x3]; // Offset: 0xe1 // Size: 0x03
	int ThresholdQuantity; // Offset: 0xe4 // Size: 0x04
	int AliveNumberLimit; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04

	// Functions

	// Object Name: Function SpawnSystem.STStrategyCond_Quantity.CheckCondition
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CheckCondition(); // Offset: 0x10227ff1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyCond_Quantity.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x10227fe98 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategyLocation
// Size: 0xe0 // Inherited bytes: 0xe0
struct USTStrategyLocation : USTStrategyBase {
	// Functions

	// Object Name: Function SpawnSystem.STStrategyLocation.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr); // Offset: 0x102280118 // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class SpawnSystem.STStrategyLocation_Root
// Size: 0xe0 // Inherited bytes: 0xe0
struct USTStrategyLocation_Root : USTStrategyLocation {
	// Functions

	// Object Name: Function SpawnSystem.STStrategyLocation_Root.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr); // Offset: 0x1022803b4 // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class SpawnSystem.STStrategyLocation_Spots
// Size: 0xe0 // Inherited bytes: 0xe0
struct USTStrategyLocation_Spots : USTStrategyLocation {
	// Functions

	// Object Name: Function SpawnSystem.STStrategyLocation_Spots.GetSpawnLocation
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetSpawnLocation(struct AActor* Requester, int ReferenceCount, struct TArray<struct FSpawnSpotInfo>& OutArr); // Offset: 0x10228064c // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class SpawnSystem.STStrategySpecies
// Size: 0x110 // Inherited bytes: 0xe0
struct USTStrategySpecies : USTStrategyBase {
	// Fields
	char bUseLuaConfigs : 1; // Offset: 0xe0 // Size: 0x01
	char pad_0xE0_1 : 7; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x7]; // Offset: 0xe1 // Size: 0x07
	struct USTSpeciesDataAsset* SpeciesData; // Offset: 0xe8 // Size: 0x08
	DelegateProperty SupplySpawnSpeciesDelegate; // Offset: 0xf0 // Size: 0x10
	struct TArray<struct FUnitConfig> CacheSpeciesArray; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function SpawnSystem.STStrategySpecies.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x1022809c8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function SpawnSystem.STStrategySpecies.GeAllCacheConfigIDs
	// Flags: [Final|Native|Public]
	struct TArray<int> GeAllCacheConfigIDs(); // Offset: 0x102280964 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpawnSystem.STStrategySpecies.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x1022808e0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategySpecies_SquadRatio
// Size: 0x168 // Inherited bytes: 0x110
struct USTStrategySpecies_SquadRatio : USTStrategySpecies {
	// Fields
	int RatioIndex; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0x54]; // Offset: 0x114 // Size: 0x54

	// Functions

	// Object Name: Function SpawnSystem.STStrategySpecies_SquadRatio.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x102280e3c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function SpawnSystem.STStrategySpecies_SquadRatio.ReadSquadRatios
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ReadSquadRatios(int ReferencedCount, struct TArray<struct FUnitRatio>& RatioConfig); // Offset: 0x102280d58 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpawnSystem.STStrategySpecies_SquadRatio.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x102280cd4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategySpecies_Static
// Size: 0x130 // Inherited bytes: 0x110
struct USTStrategySpecies_Static : USTStrategySpecies {
	// Fields
	enum class EReadSpeciesData HowDataRead; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x3]; // Offset: 0x111 // Size: 0x03
	int GroupIndex; // Offset: 0x114 // Size: 0x04
	int SquadIndex; // Offset: 0x118 // Size: 0x04
	int UnitIndex; // Offset: 0x11c // Size: 0x04
	char pad_0x120[0x10]; // Offset: 0x120 // Size: 0x10

	// Functions

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.WeightedReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void WeightedReadUnit(int ReferencedCount, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281da0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.WeightedReadSquad
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void WeightedReadSquad(int ReferencedCount, struct FSquadConfig& SquadConfig, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281c38 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.WeightedReadGroup
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void WeightedReadGroup(int ReferencedCount, struct FGroupConfig& GroupConfig, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281a70 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x10228194c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.ReadSpotSpecies
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void ReadSpotSpecies(int& ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281774 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.OrderedReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void OrderedReadUnit(int ReferencedCount, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281690 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.OrderedReadSquad
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void OrderedReadSquad(int ReferencedCount, struct FSquadConfig& SquadConfig, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281528 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.OrderedReadGroup
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void OrderedReadGroup(int ReferencedCount, struct FGroupConfig& GroupConfig, struct TArray<struct FSquadConfig>& Squads, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281360 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.ManuallyReadUnit
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void ManuallyReadUnit(int ReferencedCount, int Index, struct TArray<struct FUnitConfig>& Units); // Offset: 0x102281240 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function SpawnSystem.STStrategySpecies_Static.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x1022811bc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategyTiming
// Size: 0xf0 // Inherited bytes: 0xe0
struct USTStrategyTiming : USTStrategyBase {
	// Fields
	struct FScriptMulticastDelegate OnSpawnTimingUp; // Offset: 0xe0 // Size: 0x10

	// Functions

	// Object Name: Function SpawnSystem.STStrategyTiming.TimeIsRipe
	// Flags: [Final|Native|Public]
	void TimeIsRipe(); // Offset: 0x102284f94 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class SpawnSystem.STStrategyTiming_Period
// Size: 0x110 // Inherited bytes: 0xf0
struct USTStrategyTiming_Period : USTStrategyTiming {
	// Fields
	char bFirstDelay : 1; // Offset: 0xf0 // Size: 0x01
	char pad_0xF0_1 : 7; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x3]; // Offset: 0xf1 // Size: 0x03
	float FirstDelayDuration; // Offset: 0xf4 // Size: 0x04
	float PeriodDuration; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x14]; // Offset: 0xfc // Size: 0x14

	// Functions

	// Object Name: Function SpawnSystem.STStrategyTiming_Period.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x1022851cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyTiming_Period.OnReachTimer
	// Flags: [Final|Native|Protected]
	void OnReachTimer(); // Offset: 0x1022851b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyTiming_Period.OnFirstDelay
	// Flags: [Final|Native|Protected]
	void OnFirstDelay(); // Offset: 0x1022851a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyTiming_Period.DeactivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void DeactivateStrategy(); // Offset: 0x102285188 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyTiming_Period.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x102285104 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategyTiming_Trigger
// Size: 0x110 // Inherited bytes: 0xf0
struct USTStrategyTiming_Trigger : USTStrategyTiming {
	// Fields
	enum class ESTSpawnerVolume VolumeType; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x3]; // Offset: 0xf1 // Size: 0x03
	struct FVector CenterLocation; // Offset: 0xf4 // Size: 0x0c
	float SphereRadius; // Offset: 0x100 // Size: 0x04
	struct FVector BoxExtent; // Offset: 0x104 // Size: 0x0c

	// Functions

	// Object Name: Function SpawnSystem.STStrategyTiming_Trigger.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x102285538 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyTiming_Trigger.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x1022854b4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpawnSystem.STStrategyTiming_Wave
// Size: 0x130 // Inherited bytes: 0xf0
struct USTStrategyTiming_Wave : USTStrategyTiming {
	// Fields
	struct TArray<int> ConfigWaveAlive; // Offset: 0xf0 // Size: 0x10
	int WaveInterval; // Offset: 0x100 // Size: 0x04
	char bTriggerToStart : 1; // Offset: 0x104 // Size: 0x01
	char bDelayToStart : 1; // Offset: 0x104 // Size: 0x01
	char pad_0x104_2 : 6; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0x3]; // Offset: 0x105 // Size: 0x03
	int DelayDurationToStart; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct USTStrategyTiming_Trigger* TriggerHelper; // Offset: 0x110 // Size: 0x08
	int CurrentWave; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x14]; // Offset: 0x11c // Size: 0x14

	// Functions

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x10228592c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.ResetCD
	// Flags: [Native|Protected|BlueprintCallable]
	void ResetCD(); // Offset: 0x102285910 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.OnTriggerToStartWave
	// Flags: [Final|Native|Protected]
	void OnTriggerToStartWave(bool IsRipe); // Offset: 0x10228588c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.OnDelayToStartWave
	// Flags: [Final|Native|Protected]
	void OnDelayToStartWave(); // Offset: 0x102285878 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.GetCurrentWave
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetCurrentWave(); // Offset: 0x10228585c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpawnSystem.STStrategyTiming_Wave.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x1022857d8 // Return & Params: Num(1) Size(0x8)
};

