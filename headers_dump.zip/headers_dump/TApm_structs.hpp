#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TApm.TApmSceneInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FTApmSceneInfo {
	// Fields
	int PerfPriority; // Offset: 0x00 // Size: 0x04
	int ReportPriority; // Offset: 0x04 // Size: 0x04
	int ID; // Offset: 0x08 // Size: 0x04
	bool IsFinished; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x13]; // Offset: 0x0d // Size: 0x13
};

