#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ClothingSystemRuntime.ClothingAssetCustomData
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingAssetCustomData : UObject {
};

// Object Name: Class ClothingSystemRuntime.ClothingAsset
// Size: 0x160 // Inherited bytes: 0x48
struct UClothingAsset : UClothingAssetBase {
	// Fields
	struct UPhysicsAsset* PhysicsAsset; // Offset: 0x48 // Size: 0x08
	struct FClothConfig ClothConfig; // Offset: 0x50 // Size: 0xbc
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct TArray<struct FClothLODData> LODData; // Offset: 0x110 // Size: 0x10
	struct TArray<int> LodMap; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FName> UsedBoneNames; // Offset: 0x130 // Size: 0x10
	struct TArray<int> UsedBoneIndices; // Offset: 0x140 // Size: 0x10
	int ReferenceBoneIndex; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x4]; // Offset: 0x154 // Size: 0x04
	struct UClothingAssetCustomData* CustomData; // Offset: 0x158 // Size: 0x08
};

// Object Name: Class ClothingSystemRuntime.ClothingSimulationFactoryNv
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingSimulationFactoryNv : UClothingSimulationFactory {
};

