#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass LobbyChat_QuickChatItem_BP.LobbyChat_QuickChatItem_BP_C
// Size: 0x280 // Inherited bytes: 0x260
struct ULobbyChat_QuickChatItem_BP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x260 // Size: 0x08
	struct UButton* btn_quick_msg; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x270 // Size: 0x08
	struct UTextBlock* txt_quick_msg; // Offset: 0x278 // Size: 0x08
};

