#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class OMobileFBPL.OMobileFBPL
// Size: 0x28 // Inherited bytes: 0x28
struct UOMobileFBPL : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OMobileFBPL.OMobileFBPL.IsRunningOnBattery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRunningOnBattery(); // Offset: 0x101eb8aec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OMobileFBPL.OMobileFBPL.IsBatteryStateCharging
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsBatteryStateCharging(); // Offset: 0x101eb8ab8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetVolumeState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetVolumeState(); // Offset: 0x101eb8a84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceName(); // Offset: 0x101eb8a20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetBatteryTemperature
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetBatteryTemperature(); // Offset: 0x101eb89ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetBatteryLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetBatteryLevel(); // Offset: 0x101eb89b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.AreHeadphonesPluggedIn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool AreHeadphonesPluggedIn(); // Offset: 0x101eb8984 // Return & Params: Num(1) Size(0x1)
};

