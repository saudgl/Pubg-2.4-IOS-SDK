#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GEM.FpsReportActor
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct AFpsReportActor : AActor {
};

