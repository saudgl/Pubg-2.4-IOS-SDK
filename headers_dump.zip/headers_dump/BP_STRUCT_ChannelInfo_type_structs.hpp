#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ChannelInfo_type.BP_STRUCT_ChannelInfo_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_ChannelInfo_type {
	// Fields
	struct FString ChannelID_0_8BFDA3E2401471743F1E119FACCC3838; // Offset: 0x00 // Size: 0x10
	int IsExternal_1_56D0626B4BDDB846A8A3339EC14E4ADA; // Offset: 0x10 // Size: 0x04
};

