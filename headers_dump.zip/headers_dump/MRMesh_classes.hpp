#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MRMesh.MeshReconstructorBase
// Size: 0x28 // Inherited bytes: 0x28
struct UMeshReconstructorBase : UObject {
	// Functions

	// Object Name: Function MRMesh.MeshReconstructorBase.StopReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void StopReconstruction(); // Offset: 0x104aef5ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.StartReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void StartReconstruction(); // Offset: 0x104aef590 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.PauseReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void PauseReconstruction(); // Offset: 0x104aef574 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReconstructionStarted(); // Offset: 0x104aef538 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReconstructionPaused(); // Offset: 0x104aef4fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	// Flags: [Native|Public]
	void DisconnectMRMesh(); // Offset: 0x104aef4e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.ConnectMRMesh
	// Flags: [Native|Public]
	struct FMRMeshConfiguration ConnectMRMesh(struct UMRMeshComponent* Mesh); // Offset: 0x104aef44c // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class MRMesh.MRMeshComponent
// Size: 0x7b0 // Inherited bytes: 0x760
struct UMRMeshComponent : UPrimitiveComponent {
	// Fields
	char pad_0x760[0x8]; // Offset: 0x760 // Size: 0x08
	struct UMaterialInterface* Material; // Offset: 0x768 // Size: 0x08
	struct UMeshReconstructorBase* MeshReconstructor; // Offset: 0x770 // Size: 0x08
	bool bEnableCollision; // Offset: 0x778 // Size: 0x01
	char pad_0x779[0x7]; // Offset: 0x779 // Size: 0x07
	struct TArray<struct UBodySetup*> BodySetups; // Offset: 0x780 // Size: 0x10
	char pad_0x790[0x20]; // Offset: 0x790 // Size: 0x20

	// Functions

	// Object Name: Function MRMesh.MRMeshComponent.GetReconstructor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMeshReconstructorBase* GetReconstructor(); // Offset: 0x104aef930 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MRMesh.MRMeshComponent.ConnectReconstructor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConnectReconstructor(struct UMeshReconstructorBase* Reconstructor); // Offset: 0x104aef8b4 // Return & Params: Num(1) Size(0x8)
};

