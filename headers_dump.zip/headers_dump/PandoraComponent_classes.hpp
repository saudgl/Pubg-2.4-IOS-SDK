#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PandoraComponent.PandoraBpFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraBpFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.Tnm2Test
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Tnm2Test(struct FString errMsg, int iId, int iType, bool bSend); // Offset: 0x101f94cc0 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.SetGameInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGameInstance(struct UGameInstance* Instance); // Offset: 0x101f94c4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickOpenPop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickOpenPop(); // Offset: 0x101f94be8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickInit(); // Offset: 0x101f94b84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickClose
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickClose(); // Offset: 0x101f94b20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.LogoutPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LogoutPandora(); // Offset: 0x101f94b0c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.InitPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitPandora(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion); // Offset: 0x101f94590 // Return & Params: Num(12) Size(0xb1)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.GetHappyMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHappyMessage(); // Offset: 0x101f9452c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class PandoraComponent.PandoraInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraInterface : UObject {
};

// Object Name: Class PandoraComponent.PandoraRichTextBox
// Size: 0x420 // Inherited bytes: 0x100
struct UPandoraRichTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x128 // Size: 0x58
	struct FLinearColor Color; // Offset: 0x180 // Size: 0x10
	enum class ETextJustify Justification; // Offset: 0x190 // Size: 0x01
	bool AutoWrapText; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x2]; // Offset: 0x192 // Size: 0x02
	float WrapTextAt; // Offset: 0x194 // Size: 0x04
	struct FMargin Margin; // Offset: 0x198 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
	struct TArray<struct URichTextBlockDecorator*> Decorators; // Offset: 0x1b0 // Size: 0x10
	char pad_0x1C0[0x260]; // Offset: 0x1c0 // Size: 0x260

	// Functions

	// Object Name: Function PandoraComponent.PandoraRichTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x101f952d4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function PandoraComponent.PandoraRichTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FText GetText(); // Offset: 0x101f95270 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class PandoraComponent.PandoraSceneComponent
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UPandoraSceneComponent : USceneComponent {
};

// Object Name: Class PandoraComponent.PandoraLuaActor
// Size: 0x438 // Inherited bytes: 0x3c0
struct APandoraLuaActor : AActor {
	// Fields
	char pad_0x3C0[0x58]; // Offset: 0x3c0 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x418 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x428 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaActor.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f9562c // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaPawn
// Size: 0x498 // Inherited bytes: 0x420
struct APandoraLuaPawn : APawn {
	// Fields
	char pad_0x420[0x58]; // Offset: 0x420 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x478 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x488 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaPawn.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f959c0 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaCharacter
// Size: 0x880 // Inherited bytes: 0x800
struct APandoraLuaCharacter : ACharacter {
	// Fields
	char pad_0x800[0x58]; // Offset: 0x800 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x858 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x868 // Size: 0x10
	char pad_0x878[0x8]; // Offset: 0x878 // Size: 0x08

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaCharacter.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f95c6c // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaController
// Size: 0x4a0 // Inherited bytes: 0x428
struct APandoraLuaController : AController {
	// Fields
	char pad_0x428[0x58]; // Offset: 0x428 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x480 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x490 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f95f18 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaPlayerController
// Size: 0x7a0 // Inherited bytes: 0x728
struct APandoraLuaPlayerController : APlayerController {
	// Fields
	char pad_0x728[0x58]; // Offset: 0x728 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x780 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x790 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaPlayerController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f961c4 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaGameModeBase
// Size: 0x4c8 // Inherited bytes: 0x450
struct APandoraLuaGameModeBase : AGameModeBase {
	// Fields
	char pad_0x450[0x58]; // Offset: 0x450 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x4a8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x4b8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaGameModeBase.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f96474 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaHUD
// Size: 0x520 // Inherited bytes: 0x4a8
struct APandoraLuaHUD : AHUD {
	// Fields
	char pad_0x4A8[0x58]; // Offset: 0x4a8 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x500 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x510 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaHUD.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f96724 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraLuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetStringFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x101f974f8 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetObjectFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x101f973f8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetNumberFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x101f972f8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIntFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x101f971f8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBoolFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x101f970f8 // Return & Params: Num(3) Size(0x25)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromString(struct FString Value); // Offset: 0x101f97014 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromObject(struct UObject* Value); // Offset: 0x101f96f70 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromNumber(float Value); // Offset: 0x101f96ecc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromInt(int Value); // Offset: 0x101f96e28 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromBool(bool Value); // Offset: 0x101f96d7c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallToLuaWithArgs(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args, struct FString StateName); // Offset: 0x101f96bb0 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CallToLua(struct FString FunctionName, struct FString StateName); // Offset: 0x101f96a54 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaDelegate
// Size: 0x38 // Inherited bytes: 0x28
struct UPandoraLuaDelegate : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x101f97a4c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PandoraComponent.PandoraLuaUserWidget
// Size: 0x310 // Inherited bytes: 0x260
struct UPandoraLuaUserWidget : UUserWidget {
	// Fields
	char pad_0x260[0x58]; // Offset: 0x260 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x2b8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x2c8 // Size: 0x10
	char pad_0x2D8[0x38]; // Offset: 0x2d8 // Size: 0x38

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaUserWidget.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x101f97bac // Return & Params: Num(3) Size(0x40)
};

