#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_EuropeanCountries_type.BP_STRUCT_EuropeanCountries_type
// Size: 0x34 // Inherited bytes: 0x00
struct FBP_STRUCT_EuropeanCountries_type {
	// Fields
	int CountryID_0_4F71D791430F593DC49F7C804FAC3346; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CountryName_1_547BDAD64F027372378DC289A6551233; // Offset: 0x08 // Size: 0x10
	bool isEEU_2_7C32719E4567FA05D6B1F0ABF584AA20; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString CountryCode_3_883C293646DF14E51A2D6C9FCB957783; // Offset: 0x20 // Size: 0x10
	int AreaCode_4_68FEE1401D27555105AC49450CE33C15; // Offset: 0x30 // Size: 0x04
};

