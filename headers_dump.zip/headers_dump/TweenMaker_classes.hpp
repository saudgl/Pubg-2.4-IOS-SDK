#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TweenMaker.BaseTween
// Size: 0x98 // Inherited bytes: 0x28
struct UBaseTween : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct UTweenContainer* mOwningTweenContainer; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x38]; // Offset: 0x60 // Size: 0x38

	// Functions

	// Object Name: Function TweenMaker.BaseTween.TogglePauseTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TogglePauseTween(bool SkipTween); // Offset: 0x101fe9e50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TweenMaker.BaseTween.SetTweenName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTweenName(struct FName TweenName); // Offset: 0x101fe9dd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TweenMaker.BaseTween.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float NewTimeScale); // Offset: 0x101fe9d58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.BaseTween.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelay(float NewDelay); // Offset: 0x101fe9cdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.BaseTween.ResumeTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResumeTween(); // Offset: 0x101fe9cc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TweenMaker.BaseTween.PauseTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PauseTween(bool SkipTween); // Offset: 0x101fe9c44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenWidgetOpacityTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenWidgetOpacityTo(struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe9a80 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenWidgetAngleTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenWidgetAngleTo(struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe98bc // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenShearWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenShearWidgetTo(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe96f8 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenSceneComponentFollowSpline(struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe93c0 // Return & Params: Num(12) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenScaleWidgetTo(struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe91fc // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenScaleWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe9038 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenScaleSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe8de0 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenScaleSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe8b88 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenScaleActorTo(struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe8930 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenScaleActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenScaleActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe86d8 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* JoinTweenRotateSceneComponentTo(struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe8480 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* JoinTweenRotateSceneComponentBy(struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe8228 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* JoinTweenRotateSceneComponentAroundPointByOffset(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe7f58 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* JoinTweenRotateSceneComponentAroundPoint(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe7c0c // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* JoinTweenRotateActorTo(struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe79b4 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* JoinTweenRotateActorBy(struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe775c // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* JoinTweenRotateActorAroundPointByOffset(struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe748c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenRotateActorAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* JoinTweenRotateActorAroundPoint(struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe7140 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenMoveWidgetTo(struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe6f7c // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenMoveWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe6db8 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenMoveSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe6b60 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenMoveSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe6908 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenMoveActorTo(struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe66b0 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMoveActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenMoveActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe6458 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMaterialVectorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* JoinTweenMaterialVectorTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe6254 // Return & Params: Num(8) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMaterialVectorFromTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* JoinTweenMaterialVectorFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe6008 // Return & Params: Num(9) Size(0x48)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMaterialFloatTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenMaterialFloatTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe5e08 // Return & Params: Num(8) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenMaterialFloatFromTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenMaterialFloatFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe5bcc // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenCustomVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* JoinTweenCustomVector2D(struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe59d0 // Return & Params: Num(8) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenCustomVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* JoinTweenCustomVector(struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe57c8 // Return & Params: Num(8) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenCustomFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenCustomFloat(struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101fe55c8 // Return & Params: Num(8) Size(0x28)

	// Object Name: Function TweenMaker.BaseTween.JoinTweenActorFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* JoinTweenActorFollowSpline(struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101fe5290 // Return & Params: Num(12) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.IsTweenPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsTweenPaused(); // Offset: 0x101fe5274 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TweenMaker.BaseTween.IsTweening
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsTweening(); // Offset: 0x101fe5240 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TweenMaker.BaseTween.GetTweenTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UObject* GetTweenTarget(); // Offset: 0x101fe5208 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TweenMaker.BaseTween.GetTweenName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FName GetTweenName(); // Offset: 0x101fe51ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TweenMaker.BaseTween.GetTweenElapsedTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetTweenElapsedTime(); // Offset: 0x101fe51d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.BaseTween.GetTweenDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetTweenDuration(); // Offset: 0x101fe51b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.BaseTween.GetTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UTweenContainer* GetTweenContainer(); // Offset: 0x101fe5198 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TweenMaker.BaseTween.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetTimeScale(); // Offset: 0x101fe517c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.BaseTween.DeleteTween
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteTween(); // Offset: 0x101fe5168 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenWidgetOpacityTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenWidgetOpacityTo(struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe4f2c // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenWidgetAngleTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenWidgetAngleTo(struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe4cf0 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenShearWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenShearWidgetTo(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe4ab4 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenSceneComponentFollowSpline(struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe46fc // Return & Params: Num(14) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenScaleWidgetTo(struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe44c0 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenScaleWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe4284 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenScaleSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe3fb4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenScaleSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe3ce4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenScaleActorTo(struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe3a14 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenScaleActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenScaleActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe3744 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* AppendTweenRotateSceneComponentTo(struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe3474 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* AppendTweenRotateSceneComponentBy(struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe31a4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* AppendTweenRotateSceneComponentAroundPointByOffset(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe2e5c // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* AppendTweenRotateSceneComponentAroundPoint(struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe2a94 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* AppendTweenRotateActorTo(struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe27c4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* AppendTweenRotateActorBy(struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe24f4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* AppendTweenRotateActorAroundPointByOffset(struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe21ac // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenRotateActorAroundPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* AppendTweenRotateActorAroundPoint(struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe1de4 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveWidgetTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenMoveWidgetTo(struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe1ba8 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveWidgetBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenMoveWidgetBy(struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe196c // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveSceneComponentTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenMoveSceneComponentTo(struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe169c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveSceneComponentBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenMoveSceneComponentBy(struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe13cc // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveActorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenMoveActorTo(struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe10fc // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMoveActorBy
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenMoveActorBy(struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fe0e2c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMaterialVectorTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* AppendTweenMaterialVectorTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe0bb0 // Return & Params: Num(10) Size(0x40)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMaterialVectorFromTo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* AppendTweenMaterialVectorFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe08ec // Return & Params: Num(11) Size(0x50)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMaterialFloatTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenMaterialFloatTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe0674 // Return & Params: Num(10) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenMaterialFloatFromTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenMaterialFloatFromTo(struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe03c0 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenCustomVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* AppendTweenCustomVector2D(struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fe014c // Return & Params: Num(10) Size(0x38)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenCustomVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* AppendTweenCustomVector(struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fdfecc // Return & Params: Num(10) Size(0x40)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenCustomFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenCustomFloat(struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, int mNumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fdfc54 // Return & Params: Num(10) Size(0x30)

	// Object Name: Function TweenMaker.BaseTween.AppendTweenActorFollowSpline
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* AppendTweenActorFollowSpline(struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType mLoopType, float Delay, float TimeScale); // Offset: 0x101fdf89c // Return & Params: Num(14) Size(0x38)
};

// Object Name: Class TweenMaker.TweenContainer
// Size: 0x68 // Inherited bytes: 0x28
struct UTweenContainer : UObject {
	// Fields
	struct UTweenManagerComponent* OwningTweenManager; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FParallelTween> mSequences; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x28]; // Offset: 0x40 // Size: 0x28

	// Functions

	// Object Name: Function TweenMaker.TweenContainer.TogglePauseTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TogglePauseTweenContainer(); // Offset: 0x101febe8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TweenMaker.TweenContainer.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float NewTimeScale); // Offset: 0x101febe10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.TweenContainer.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLoop(int NumLoops, enum class ETweenLoopType LoopType); // Offset: 0x101febd58 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function TweenMaker.TweenContainer.ResumeTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResumeTweenContainer(); // Offset: 0x101febd44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TweenMaker.TweenContainer.PauseTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PauseTweenContainer(); // Offset: 0x101febd30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TweenMaker.TweenContainer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsPaused(); // Offset: 0x101febcfc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TweenMaker.TweenContainer.IsObjectTweeningInContainer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool IsObjectTweeningInContainer(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType, struct UBaseTween*& TweenFound); // Offset: 0x101febbd4 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function TweenMaker.TweenContainer.DeleteTweensInContainerByObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteTweensInContainerByObject(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType); // Offset: 0x101febb00 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function TweenMaker.TweenContainer.DeleteTweenContainer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteTweenContainer(); // Offset: 0x101febaec // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class TweenMaker.TweenFloat
// Size: 0x1e8 // Inherited bytes: 0x98
struct UTweenFloat : UBaseTween {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0xb8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorHit; // Offset: 0xc8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // Offset: 0xd8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // Offset: 0xe8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0xe0]; // Offset: 0x108 // Size: 0xe0

	// Functions

	// Object Name: Function TweenMaker.TweenFloat.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult); // Offset: 0x101fecb28 // Return & Params: Num(5) Size(0xb0)

	// Object Name: Function TweenMaker.TweenFloat.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult); // Offset: 0x101fec950 // Return & Params: Num(6) Size(0xa8)

	// Object Name: Function TweenMaker.TweenFloat.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit); // Offset: 0x101fec800 // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function TweenMaker.TweenFloat.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor); // Offset: 0x101fec74c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function TweenMaker.TweenFloat.GetCurrentValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetCurrentValue(); // Offset: 0x101fec730 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class TweenMaker.TweenFloatLatentFactory
// Size: 0x58 // Inherited bytes: 0x28
struct UTweenFloatLatentFactory : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ff4330 // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ff40d0 // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff3d00 // Return & Params: Num(14) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff3994 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff35a4 // Return & Params: Num(15) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff3238 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff2e48 // Return & Params: Num(15) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ff2bac // Return & Params: Num(10) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ff28d4 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ff2638 // Return & Params: Num(10) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_JoinLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_JoinLatentTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x101ff2268 // Return & Params: Num(14) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenWidgetOpacityTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff1f58 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenWidgetAngleTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff1c48 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenSceneComponentFollowSpline(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff17bc // Return & Params: Num(17) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff1398 // Return & Params: Num(16) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateSceneComponentAroundPoint(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff0ef4 // Return & Params: Num(18) Size(0x68)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateActorAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff0ad0 // Return & Params: Num(16) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenRotateActorAroundPoint(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff062c // Return & Params: Num(18) Size(0x68)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenMaterialFloatTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ff02e0 // Return & Params: Num(13) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenMaterialFloatFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101feff58 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenCustomFloat(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fefc0c // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_CreateLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_CreateLatentTweenActorFollowSpline(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenFloat*& OutTween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fef780 // Return & Params: Num(17) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fef4a8 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fef1d0 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101feed80 // Return & Params: Num(16) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fee998 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fee530 // Return & Params: Num(17) Size(0x60)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fee148 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fedce0 // Return & Params: Num(17) Size(0x60)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fed9cc // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fed67c // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fed368 // Return & Params: Num(12) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatLatentFactory.BP_AppendLatentTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloatLatentFactory* BP_AppendLatentTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct UTweenFloat*& OutTween, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101fecf18 // Return & Params: Num(16) Size(0x48)
};

// Object Name: Class TweenMaker.TweenFloatStandardFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UTweenFloatStandardFactory : UObject {
	// Functions

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffce70 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffcc28 // Return & Params: Num(9) Size(0x30)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffc868 // Return & Params: Num(14) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffc514 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffc144 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffbdf0 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffba20 // Return & Params: Num(15) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffb79c // Return & Params: Num(10) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffb4dc // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffb258 // Return & Params: Num(10) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_JoinTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_JoinTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffae98 // Return & Params: Num(14) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenWidgetOpacityTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffab5c // Return & Params: Num(12) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenWidgetAngleTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffa820 // Return & Params: Num(12) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenSceneComponentFollowSpline(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ffa35c // Return & Params: Num(17) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateSceneComponentAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff9f08 // Return & Params: Num(16) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateSceneComponentAroundPoint(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff9a34 // Return & Params: Num(18) Size(0x60)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateActorAroundPointByOffset(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff95e0 // Return & Params: Num(16) Size(0x50)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateActorAroundPoint(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff910c // Return & Params: Num(18) Size(0x60)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenMaterialFloatTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff8d90 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenMaterialFloatFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff89d8 // Return & Params: Num(14) Size(0x4c)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenCustomFloat(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff8660 // Return & Params: Num(13) Size(0x44)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_CreateTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenActorFollowSpline(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenFloat*& Tween, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff819c // Return & Params: Num(17) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenWidgetOpacityTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenWidgetOpacityTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff7edc // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenWidgetAngleTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenWidgetAngleTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff7c1c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenSceneComponentFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenSceneComponentFollowSpline(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff77dc // Return & Params: Num(16) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateSceneComponentAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenRotateSceneComponentAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff740c // Return & Params: Num(15) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateSceneComponentAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenRotateSceneComponentAroundPoint(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff6fc0 // Return & Params: Num(17) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateActorAroundPointByOffset
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenRotateActorAroundPointByOffset(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float OffsetAngle, enum class ETweenReferenceAxis ReferenceAxis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff6bf0 // Return & Params: Num(15) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenRotateActorAroundPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenRotateActorAroundPoint(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector PivotPoint, float StartingAngle, float EndingAngle, float Radius, struct FVector Axis, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff67a4 // Return & Params: Num(17) Size(0x58)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenMaterialFloatTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenMaterialFloatTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff64a8 // Return & Params: Num(12) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenMaterialFloatFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenMaterialFloatFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff6170 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenCustomFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenCustomFloat(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, float from, float to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff5e74 // Return & Params: Num(12) Size(0x40)

	// Object Name: Function TweenMaker.TweenFloatStandardFactory.BP_AppendTweenActorFollowSpline
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTweenFloat* BP_AppendTweenActorFollowSpline(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct USplineComponent* Spline, float Duration, bool ApplyRotation, bool ApplyScale, bool UseConstantSpeed, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101ff5a34 // Return & Params: Num(16) Size(0x40)
};

// Object Name: Class TweenMaker.TweenLinearColor
// Size: 0x168 // Inherited bytes: 0x98
struct UTweenLinearColor : UBaseTween {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0xa0]; // Offset: 0xc8 // Size: 0xa0

	// Functions

	// Object Name: Function TweenMaker.TweenLinearColor.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FLinearColor GetCurrentValue(); // Offset: 0x101ffdc8c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class TweenMaker.TweenLinearColorLatentFactory
// Size: 0x58 // Inherited bytes: 0x28
struct UTweenLinearColorLatentFactory : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_JoinLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_JoinLatentTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ffee64 // Return & Params: Num(10) Size(0x48)

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_JoinLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_JoinLatentTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x101ffeb80 // Return & Params: Num(11) Size(0x58)

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_CreateLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_CreateLatentTweenMaterialVectorTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenLinearColor*& OutTween, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ffe830 // Return & Params: Num(13) Size(0x58)

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_CreateLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_CreateLatentTweenMaterialVectorFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenLinearColor*& OutTween, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ffe498 // Return & Params: Num(14) Size(0x68)

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_AppendLatentTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_AppendLatentTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ffe180 // Return & Params: Num(12) Size(0x50)

	// Object Name: Function TweenMaker.TweenLinearColorLatentFactory.BP_AppendLatentTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColorLatentFactory* BP_AppendLatentTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& OutTween, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x101ffde24 // Return & Params: Num(13) Size(0x60)
};

// Object Name: Class TweenMaker.TweenLinearColorStandardFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UTweenLinearColorStandardFactory : UObject {
	// Functions

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_JoinTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* BP_JoinTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020007e0 // Return & Params: Num(10) Size(0x48)

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_JoinTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* BP_JoinTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102000510 // Return & Params: Num(11) Size(0x58)

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_CreateTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMaterialVectorTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& Tween, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102000190 // Return & Params: Num(13) Size(0x54)

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_CreateTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMaterialVectorFromTo(struct UTweenManagerComponent* TweenManager, struct UMaterialInstanceDynamic*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenLinearColor*& Tween, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101fffdc8 // Return & Params: Num(14) Size(0x64)

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_AppendTweenMaterialVectorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* BP_AppendTweenMaterialVectorTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101fffac8 // Return & Params: Num(12) Size(0x50)

	// Object Name: Function TweenMaker.TweenLinearColorStandardFactory.BP_AppendTweenMaterialVectorFromTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenLinearColor* BP_AppendTweenMaterialVectorFromTo(struct UTweenContainer*& TweenContainer, struct UMaterialInstanceDynamic*& TweenTarget, struct FName ParameterName, struct FLinearColor from, struct FLinearColor to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x101fff780 // Return & Params: Num(13) Size(0x60)
};

// Object Name: Class TweenMaker.TweenManagerActor
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct ATweenManagerActor : AActor {
	// Functions

	// Object Name: Function TweenMaker.TweenManagerActor.IsObjectTweening
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsObjectTweening(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType, struct UBaseTween*& TweenFound); // Offset: 0x1020014bc // Return & Params: Num(4) Size(0x19)

	// Object Name: Function TweenMaker.TweenManagerActor.FindTweenByName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool FindTweenByName(struct FName TweenName, enum class ETweenGenericType TweenType, struct UBaseTween*& TweenFound); // Offset: 0x1020013b8 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function TweenMaker.TweenManagerActor.DeleteAllTweensByObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool DeleteAllTweensByObject(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType); // Offset: 0x1020012e4 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function TweenMaker.TweenManagerActor.DeleteAllTweens
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int DeleteAllTweens(); // Offset: 0x1020012b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.TweenManagerActor.BP_CreateTweenContainerStatic
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenContainerStatic(struct UTweenContainer*& TweenContainer, int NumLoops, enum class ETweenLoopType LoopType, float TimeScale); // Offset: 0x102001178 // Return & Params: Num(4) Size(0x14)
};

// Object Name: Class TweenMaker.TweenManagerComponent
// Size: 0x1c0 // Inherited bytes: 0x110
struct UTweenManagerComponent : UActorComponent {
	// Fields
	struct TArray<struct UTweenContainer*> mTweenContainers; // Offset: 0x110 // Size: 0x10
	char pad_0x120[0xa0]; // Offset: 0x120 // Size: 0xa0

	// Functions

	// Object Name: Function TweenMaker.TweenManagerComponent.UpdateNameMap
	// Flags: [Final|Native|Private|HasOutParms]
	void UpdateNameMap(struct UBaseTween* pTween, struct FName& pPreviousName, struct FName& pNewName); // Offset: 0x102001d68 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function TweenMaker.TweenManagerComponent.TweenDestroyed
	// Flags: [Final|Native|Private]
	void TweenDestroyed(struct UBaseTween* pTween); // Offset: 0x102001cec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TweenMaker.TweenManagerComponent.IsObjectTweening
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool IsObjectTweening(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType, struct UBaseTween*& TweenFound); // Offset: 0x102001bc4 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function TweenMaker.TweenManagerComponent.FindTweenByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool FindTweenByName(struct FName TweenName, enum class ETweenGenericType TweenType, struct UBaseTween*& TweenFound); // Offset: 0x102001ab0 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function TweenMaker.TweenManagerComponent.DeleteAllTweensByObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool DeleteAllTweensByObject(struct UObject*& TweenTarget, enum class ETweenGenericType TweensType); // Offset: 0x1020019d4 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function TweenMaker.TweenManagerComponent.DeleteAllTweens
	// Flags: [Final|Native|Public|BlueprintCallable]
	int DeleteAllTweens(); // Offset: 0x1020019a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function TweenMaker.TweenManagerComponent.BP_CreateTweenContainer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BP_CreateTweenContainer(struct UTweenContainer*& TweenContainer, int NumLoops, enum class ETweenLoopType LoopType, float TimeScale); // Offset: 0x102001858 // Return & Params: Num(4) Size(0x14)
};

// Object Name: Class TweenMaker.TweenRotator
// Size: 0x200 // Inherited bytes: 0x98
struct UTweenRotator : UBaseTween {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0xb8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorHit; // Offset: 0xc8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // Offset: 0xd8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // Offset: 0xe8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0xf8]; // Offset: 0x108 // Size: 0xf8

	// Functions

	// Object Name: Function TweenMaker.TweenRotator.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult); // Offset: 0x102002594 // Return & Params: Num(5) Size(0xb0)

	// Object Name: Function TweenMaker.TweenRotator.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult); // Offset: 0x1020023bc // Return & Params: Num(6) Size(0xa8)

	// Object Name: Function TweenMaker.TweenRotator.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit); // Offset: 0x10200226c // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function TweenMaker.TweenRotator.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor); // Offset: 0x1020021b8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function TweenMaker.TweenRotator.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FRotator GetCurrentValue(); // Offset: 0x10200217c // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class TweenMaker.TweenRotatorLatentFactory
// Size: 0x58 // Inherited bytes: 0x28
struct UTweenRotatorLatentFactory : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102004eac // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102004bb8 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x1020048c4 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_JoinLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_JoinLatentTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x1020045d0 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102004228 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102003e80 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102003ad8 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_CreateLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_CreateLatentTweenRotateActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenRotator*& OutTween, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102003730 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020033c4 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102003058 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102002cec // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorLatentFactory.BP_AppendLatentTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotatorLatentFactory* BP_AppendLatentTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct UTweenRotator*& OutTween, struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102002980 // Return & Params: Num(13) Size(0x48)
};

// Object Name: Class TweenMaker.TweenRotatorStandardFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UTweenRotatorStandardFactory : UObject {
	// Functions

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_JoinTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102007c1c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_JoinTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102007940 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_JoinTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102007664 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_JoinTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_JoinTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102007388 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102006fb0 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102006bd8 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102006800 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_CreateTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenRotateActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenRotator*& Tween, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102006428 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_AppendTweenRotateSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020060d4 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_AppendTweenRotateSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102005d80 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_AppendTweenRotateActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102005a2c // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenRotatorStandardFactory.BP_AppendTweenRotateActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenRotator* BP_AppendTweenRotateActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FRotator bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020056d8 // Return & Params: Num(13) Size(0x40)
};

// Object Name: Class TweenMaker.TweenVector
// Size: 0x1c0 // Inherited bytes: 0x98
struct UTweenVector : UBaseTween {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0xb8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorHit; // Offset: 0xc8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenActorBeginOverlap; // Offset: 0xd8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentHit; // Offset: 0xe8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenPrimitiveComponentBeginOverlap; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0xb8]; // Offset: 0x108 // Size: 0xb8

	// Functions

	// Object Name: Function TweenMaker.TweenVector.OnPrimitiveComponentHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnPrimitiveComponentHit(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, struct FVector pNormalImpulse, struct FHitResult& pHitResult); // Offset: 0x102008f90 // Return & Params: Num(5) Size(0xb0)

	// Object Name: Function TweenMaker.TweenVector.OnPrimitiveComponentBeginOverlap
	// Flags: [Final|Native|Private|HasOutParms]
	void OnPrimitiveComponentBeginOverlap(struct UPrimitiveComponent* pThisComponent, struct AActor* pOtherActor, struct UPrimitiveComponent* pOtherComp, int pOtherBodyIndex, bool bFromSweep, struct FHitResult& pSweepResult); // Offset: 0x102008db8 // Return & Params: Num(6) Size(0xa8)

	// Object Name: Function TweenMaker.TweenVector.OnActorHit
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnActorHit(struct AActor* pThisActor, struct AActor* pOtherActor, struct FVector pNormalImpulse, struct FHitResult& pHit); // Offset: 0x102008c68 // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function TweenMaker.TweenVector.OnActorBeginOverlap
	// Flags: [Final|Native|Private]
	void OnActorBeginOverlap(struct AActor* pThisActor, struct AActor* pOtherActor); // Offset: 0x102008bb4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function TweenMaker.TweenVector.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector GetCurrentValue(); // Offset: 0x102008b90 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class TweenMaker.TweenVector2D
// Size: 0x128 // Inherited bytes: 0x98
struct UTweenVector2D : UBaseTween {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0x60]; // Offset: 0xc8 // Size: 0x60

	// Functions

	// Object Name: Function TweenMaker.TweenVector2D.GetCurrentValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetCurrentValue(); // Offset: 0x102009380 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class TweenMaker.TweenVector2DLatentFactory
// Size: 0x58 // Inherited bytes: 0x28
struct UTweenVector2DLatentFactory : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200c4ec // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200c28c // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200c02c // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200bdcc // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200bb6c // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_JoinLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_JoinLatentTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x10200b8d4 // Return & Params: Num(10) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenShearWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200b5c4 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenScaleWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200b2b4 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenScaleWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200afa4 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenMoveWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200ac94 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenMoveWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200a984 // Return & Params: Num(12) Size(0x48)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_CreateLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_CreateLatentTweenCustomVector2D(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector2D*& OutTween, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200a63c // Return & Params: Num(13) Size(0x50)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200a364 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10200a08c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102009db4 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102009adc // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102009804 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DLatentFactory.BP_AppendLatentTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2DLatentFactory* BP_AppendLatentTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& OutTween, struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020094f4 // Return & Params: Num(12) Size(0x48)
};

// Object Name: Class TweenMaker.TweenVector2DStandardFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UTweenVector2DStandardFactory : UObject {
	// Functions

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200fcdc // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200fa94 // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200f84c // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200f604 // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200f3bc // Return & Params: Num(9) Size(0x38)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_JoinTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_JoinTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200f13c // Return & Params: Num(10) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenShearWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200ee00 // Return & Params: Num(12) Size(0x44)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200eac4 // Return & Params: Num(12) Size(0x44)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200e788 // Return & Params: Num(12) Size(0x44)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveWidgetTo(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200e44c // Return & Params: Num(12) Size(0x44)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveWidgetBy(struct UTweenManagerComponent* TweenManager, struct UWidget*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200e110 // Return & Params: Num(12) Size(0x44)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_CreateTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenCustomVector2D(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector2D*& Tween, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200dd9c // Return & Params: Num(13) Size(0x4c)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenShearWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenShearWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200dadc // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenScaleWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenScaleWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200d81c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenScaleWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenScaleWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200d55c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenMoveWidgetTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenMoveWidgetTo(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200d29c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenMoveWidgetBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenMoveWidgetBy(struct UTweenContainer*& TweenContainer, struct UWidget*& TweenTarget, struct FVector2D bY, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200cfdc // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVector2DStandardFactory.BP_AppendTweenCustomVector2D
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector2D* BP_AppendTweenCustomVector2D(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector2D from, struct FVector2D to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10200cce4 // Return & Params: Num(12) Size(0x48)
};

// Object Name: Class TweenMaker.TweenVectorLatentFactory
// Size: 0x58 // Inherited bytes: 0x28
struct UTweenVectorLatentFactory : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate OnTweenStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenUpdate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnTweenEnd; // Offset: 0x48 // Size: 0x10

	// Functions

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102015b10 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x10201581c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102015528 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102015234 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102014f40 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102014c4c // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102014958 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale); // Offset: 0x102014664 // Return & Params: Num(11) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_JoinLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_JoinLatentTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale); // Offset: 0x1020143c0 // Return & Params: Num(10) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102014018 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102013c70 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020138c8 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenScaleActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102013520 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102013178 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102012dd0 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102012a28 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenMoveActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102012680 // Return & Params: Num(14) Size(0x50)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_CreateLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_CreateLatentTweenCustomVector(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& OutTweenContainer, struct UTweenVector*& OutTween, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10201232c // Return & Params: Num(13) Size(0x58)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102011fc0 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102011c54 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020118e8 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x10201157c // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102011210 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102010ea4 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x102010b38 // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020107cc // Return & Params: Num(13) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorLatentFactory.BP_AppendLatentTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVectorLatentFactory* BP_AppendLatentTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UTweenVector*& OutTween, struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale); // Offset: 0x1020104b0 // Return & Params: Num(12) Size(0x50)
};

// Object Name: Class TweenMaker.TweenVectorStandardFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UTweenVectorStandardFactory : UObject {
	// Functions

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201c3a0 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201c0c4 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201bde8 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201bb0c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201b830 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201b554 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201b278 // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201af9c // Return & Params: Num(11) Size(0x38)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_JoinTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_JoinTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201ad10 // Return & Params: Num(10) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201a938 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201a560 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201a188 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenScaleActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102019db0 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveSceneComponentTo(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020199d8 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveSceneComponentBy(struct UTweenManagerComponent* TweenManager, struct USceneComponent*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102019600 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveActorTo(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102019228 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenMoveActorBy(struct UTweenManagerComponent* TweenManager, struct AActor*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102018e50 // Return & Params: Num(14) Size(0x48)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_CreateTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void BP_CreateTweenCustomVector(struct UTweenManagerComponent* TweenManager, struct UObject*& TweenTarget, struct UTweenContainer*& TweenContainer, struct UTweenVector*& Tween, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102018ad0 // Return & Params: Num(13) Size(0x54)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenScaleSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x10201877c // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenScaleSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102018428 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenScaleActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020180d4 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenScaleActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenScaleActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102017d80 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveSceneComponentTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenMoveSceneComponentTo(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102017a2c // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveSceneComponentBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenMoveSceneComponentBy(struct UTweenContainer*& TweenContainer, struct USceneComponent*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x1020176d8 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveActorTo
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenMoveActorTo(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector to, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102017384 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenMoveActorBy
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenMoveActorBy(struct UTweenContainer*& TweenContainer, struct AActor*& TweenTarget, struct FVector bY, float Duration, enum class ETweenEaseType EaseType, bool DeleteTweenOnHit, bool DeleteTweenOnOverlap, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102017030 // Return & Params: Num(13) Size(0x40)

	// Object Name: Function TweenMaker.TweenVectorStandardFactory.BP_AppendTweenCustomVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UTweenVector* BP_AppendTweenCustomVector(struct UTweenContainer*& TweenContainer, struct UObject*& TweenTarget, struct FVector from, struct FVector to, float Duration, enum class ETweenEaseType EaseType, int NumLoops, enum class ETweenLoopType LoopType, float Delay, float TimeScale, int SequenceIndex); // Offset: 0x102016d2c // Return & Params: Num(12) Size(0x50)
};

