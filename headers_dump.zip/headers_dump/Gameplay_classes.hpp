#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Gameplay.UAEPlayerController
// Size: 0x1198 // Inherited bytes: 0x7e8
struct AUAEPlayerController : ALuaPlayerController {
	// Fields
	char pad_0x7E8[0x10]; // Offset: 0x7e8 // Size: 0x10
	struct FName PlayerType; // Offset: 0x7f8 // Size: 0x08
	struct FString PlayerName; // Offset: 0x800 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x810 // Size: 0x04
	char pad_0x814[0x4]; // Offset: 0x814 // Size: 0x04
	uint64 UId; // Offset: 0x818 // Size: 0x08
	struct FString PlayerOpenID; // Offset: 0x820 // Size: 0x10
	int TeamID; // Offset: 0x830 // Size: 0x04
	char pad_0x834[0x4]; // Offset: 0x834 // Size: 0x04
	int64_t IdxInTeam; // Offset: 0x838 // Size: 0x08
	int CampID; // Offset: 0x840 // Size: 0x04
	struct FVector CharacterLocation; // Offset: 0x844 // Size: 0x0c
	int RoomMode; // Offset: 0x850 // Size: 0x04
	char pad_0x854[0x4]; // Offset: 0x854 // Size: 0x04
	struct FWeatherInfo WeatherInfo; // Offset: 0x858 // Size: 0x18
	int planeAvatarId; // Offset: 0x870 // Size: 0x04
	int DyeDebugFlag; // Offset: 0x874 // Size: 0x04
	int PlayerStartID; // Offset: 0x878 // Size: 0x04
	bool bUsedSimulation; // Offset: 0x87c // Size: 0x01
	char pad_0x87D[0x3]; // Offset: 0x87d // Size: 0x03
	struct FPlayerNetStats NetStats; // Offset: 0x880 // Size: 0x40
	bool bEnablePlaneBanner; // Offset: 0x8c0 // Size: 0x01
	char pad_0x8C1[0x7]; // Offset: 0x8c1 // Size: 0x07
	struct FString PlanetailResLink; // Offset: 0x8c8 // Size: 0x10
	int InPacketLossRate; // Offset: 0x8d8 // Size: 0x04
	int OutPacketLossRate; // Offset: 0x8dc // Size: 0x04
	int ClientNetworkType; // Offset: 0x8e0 // Size: 0x04
	char pad_0x8E4[0x24]; // Offset: 0x8e4 // Size: 0x24
	bool bIsForReplay; // Offset: 0x908 // Size: 0x01
	bool bIsGlobalObserverForReplay; // Offset: 0x909 // Size: 0x01
	char pad_0x90A[0x2]; // Offset: 0x90a // Size: 0x02
	int GameReplayType; // Offset: 0x90c // Size: 0x04
	struct FGameModePlayerUpassInfo InitialUpassInfo; // Offset: 0x910 // Size: 0x30
	struct TArray<struct FGameModePlayerUpassInfo> InitialUpassInfoList; // Offset: 0x940 // Size: 0x10
	struct TArray<struct FPlayerOBInfo> PlayerOBInfoList; // Offset: 0x950 // Size: 0x10
	int LobbyShowWeaponID; // Offset: 0x960 // Size: 0x04
	bool bIsGM; // Offset: 0x964 // Size: 0x01
	char pad_0x965[0x3]; // Offset: 0x965 // Size: 0x03
	struct FString Nation; // Offset: 0x968 // Size: 0x10
	bool bIsTeammateEscaped; // Offset: 0x978 // Size: 0x01
	char pad_0x979[0x7]; // Offset: 0x979 // Size: 0x07
	enum class ECharacterGender DefaultCharacterGender; // Offset: 0x980 // Size: 0x01
	char pad_0x981[0x3]; // Offset: 0x981 // Size: 0x03
	int DefaultCharacterHeadID; // Offset: 0x984 // Size: 0x04
	struct TArray<struct FGameModePlayerItem> InitialItemList; // Offset: 0x988 // Size: 0x10
	struct TArray<struct FGameModePlayerRolewearInfo> InitialAllWear; // Offset: 0x998 // Size: 0x10
	int RolewearIndex; // Offset: 0x9a8 // Size: 0x04
	char pad_0x9AC[0x4]; // Offset: 0x9ac // Size: 0x04
	struct TArray<int> equip_plating_list; // Offset: 0x9b0 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> InitialSharedSkin; // Offset: 0x9c0 // Size: 0x10
	struct FGameModePlayerKnapsackSingleInfo InitialSharedKnapsack; // Offset: 0x9d0 // Size: 0x60
	bool bSharedSkinOpened; // Offset: 0xa30 // Size: 0x01
	bool bUsingSharedSkin; // Offset: 0xa31 // Size: 0x01
	char pad_0xA32[0x2]; // Offset: 0xa32 // Size: 0x02
	int VehicleSkinInReady; // Offset: 0xa34 // Size: 0x04
	bool bSpwanInVehiclePlayerStart; // Offset: 0xa38 // Size: 0x01
	char pad_0xA39[0x7]; // Offset: 0xa39 // Size: 0x07
	struct TArray<struct FGameModePlayerItem> InitialWeaponAvatarList; // Offset: 0xa40 // Size: 0x10
	struct FGameModePlayerPetInfo InitialPetInfo; // Offset: 0xa50 // Size: 0x20
	struct TArray<struct FGameModePlayerKnapsackExtInfo> InitialKnapsackExtInfo; // Offset: 0xa70 // Size: 0x10
	struct TArray<struct FGameModePlayeWeaponSchemeInfo> InitialWeaponSchemeInfo; // Offset: 0xa80 // Size: 0x10
	struct FScriptMulticastDelegate OnInitialWeaponScheme; // Offset: 0xa90 // Size: 0x10
	int CurWeaponSchemeIndex; // Offset: 0xaa0 // Size: 0x04
	int PveLevel; // Offset: 0xaa4 // Size: 0x04
	struct TArray<int> InitialCharSkillList; // Offset: 0xaa8 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> InitialVehicleAvatarList; // Offset: 0xab8 // Size: 0x10
	struct TArray<struct FGameModePlayerItems> InitialVehicleAvatarSkinList; // Offset: 0xac8 // Size: 0x10
	int ShowVehicleSkin; // Offset: 0xad8 // Size: 0x04
	char pad_0xADC[0x4]; // Offset: 0xadc // Size: 0x04
	struct TArray<int> HolographyList; // Offset: 0xae0 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> InitialBackPackPendantList; // Offset: 0xaf0 // Size: 0x10
	struct TArray<struct FVehicleAvatarData> InitialVehicleAdvanceAvatarList; // Offset: 0xb00 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> InitialVehicleMusicList; // Offset: 0xb10 // Size: 0x10
	struct FGameModePlayerConsumableAvatar InitialConsumableAvatar; // Offset: 0xb20 // Size: 0x10
	struct FGameModePlayerEquipmentAvatar InitialEquipmentAvatar; // Offset: 0xb30 // Size: 0x0c
	char pad_0xB3C[0x4]; // Offset: 0xb3c // Size: 0x04
	struct TMap<int, int> WeaponAvatarItemList; // Offset: 0xb40 // Size: 0x50
	char pad_0xB90[0x50]; // Offset: 0xb90 // Size: 0x50
	struct TMap<int, int> GrenadeAvatarItemList; // Offset: 0xbe0 // Size: 0x50
	struct TArray<struct FGameModeWeaponAvatarData> WeaponAvatarDataList; // Offset: 0xc30 // Size: 0x10
	struct TMap<int, int> VehicleAvatarList; // Offset: 0xc40 // Size: 0x50
	struct TMap<int, struct FVehicleAvatarData> VehicleAdvanceAvatarList; // Offset: 0xc90 // Size: 0x50
	struct TMap<int, struct FVehicleAvatarSkinList> VehicleAvatarSkinList; // Offset: 0xce0 // Size: 0x50
	struct TArray<int> VehicleMusicList; // Offset: 0xd30 // Size: 0x10
	struct TArray<int> DefaultVehicleMusic; // Offset: 0xd40 // Size: 0x10
	struct TArray<struct FGameModePlayerExpressionItem> InitialExpressionItemList; // Offset: 0xd50 // Size: 0x10
	struct TArray<struct FGameModeWeaponDIYPlanData> InitialWeaponDIYPlanData; // Offset: 0xd60 // Size: 0x10
	struct TMap<int, int> WeaponDIYPlanDataMap; // Offset: 0xd70 // Size: 0x50
	struct TMap<int, int> InitialWeaponPendantList; // Offset: 0xdc0 // Size: 0x50
	struct TArray<struct FGameModePlayerTaskData> InitialTaskDataList; // Offset: 0xe10 // Size: 0x10
	struct TArray<struct FSpecialPickItem> InitialSpecialPickItemList; // Offset: 0xe20 // Size: 0x10
	struct TArray<struct FDailyTaskStoreInfo> DailyTaskStoreList; // Offset: 0xe30 // Size: 0x10
	uint32_t TaskSyncToDsTs; // Offset: 0xe40 // Size: 0x04
	int AnchorPlatResID; // Offset: 0xe44 // Size: 0x04
	int AnchorPlatColorID; // Offset: 0xe48 // Size: 0x04
	char pad_0xE4C[0x24]; // Offset: 0xe4c // Size: 0x24
	struct FScriptMulticastDelegate OnReceiveUIMessage; // Offset: 0xe70 // Size: 0x10
	int64_t LastGameResultTime; // Offset: 0xe80 // Size: 0x08
	bool bRoomCanKickPlayer; // Offset: 0xe88 // Size: 0x01
	bool bCanDownloadInBattle; // Offset: 0xe89 // Size: 0x01
	char pad_0xE8A[0x6]; // Offset: 0xe8a // Size: 0x06
	struct FString IpCountryStr; // Offset: 0xe90 // Size: 0x10
	bool bRoomOwner; // Offset: 0xea0 // Size: 0x01
	bool bOpenChangeWearing; // Offset: 0xea1 // Size: 0x01
	char pad_0xEA2[0x2]; // Offset: 0xea2 // Size: 0x02
	uint32_t ObserverFlags; // Offset: 0xea4 // Size: 0x04
	bool bIsSpectating; // Offset: 0xea8 // Size: 0x01
	char pad_0xEA9[0x3]; // Offset: 0xea9 // Size: 0x03
	struct FLobbyWatchInfo LobbyWatchInfo; // Offset: 0xeac // Size: 0x08
	int HawkEyeSpectateMaxMatchCount; // Offset: 0xeb4 // Size: 0x04
	int HawkEyeSpectateUsedMatchCount; // Offset: 0xeb8 // Size: 0x04
	bool bIsWatchEnd; // Offset: 0xebc // Size: 0x01
	char pad_0xEBD[0x3]; // Offset: 0xebd // Size: 0x03
	float UpdateOBCircleCounter; // Offset: 0xec0 // Size: 0x04
	float UpdateOBCircleInterval; // Offset: 0xec4 // Size: 0x04
	bool bAllowAutoSelectTeamMate; // Offset: 0xec8 // Size: 0x01
	bool bWaitRetryGotoSpectating; // Offset: 0xec9 // Size: 0x01
	char pad_0xECA[0x6]; // Offset: 0xeca // Size: 0x06
	struct TArray<struct FString> FriendObservers; // Offset: 0xed0 // Size: 0x10
	bool bCanLedgeGrab; // Offset: 0xee0 // Size: 0x01
	char pad_0xEE1[0x7]; // Offset: 0xee1 // Size: 0x07
	bool bIsSpectatingEnemy; // Offset: 0xee8 // Size: 0x01
	char pad_0xEE9[0x5f]; // Offset: 0xee9 // Size: 0x5f
	struct TWeakObjectPtr<struct UUAEUserWidget> InGameUIRoot; // Offset: 0xf48 // Size: 0x08
	char pad_0xF50[0x4]; // Offset: 0xf50 // Size: 0x04
	bool bReconnected; // Offset: 0xf54 // Size: 0x01
	bool bReconnecting; // Offset: 0xf55 // Size: 0x01
	char pad_0xF56[0x12]; // Offset: 0xf56 // Size: 0x12
	struct FScriptMulticastDelegate PlayerControllerLostDelegate; // Offset: 0xf68 // Size: 0x10
	struct FScriptMulticastDelegate SyncDailyTaskInfoDelegate; // Offset: 0xf78 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerRecoveredDelegate; // Offset: 0xf88 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerAboutToReconnectDelegate; // Offset: 0xf98 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerReconnectedDelegate; // Offset: 0xfa8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerAboutToRespawnDelegate; // Offset: 0xfb8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerRespawnedDelegate; // Offset: 0xfc8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerControllerAboutToExitDelegate; // Offset: 0xfd8 // Size: 0x10
	struct FScriptMulticastDelegate OnPlayerQuitSpectatingForClient; // Offset: 0xfe8 // Size: 0x10
	struct FScriptMulticastDelegate OnPlayerControllerBattleBeginPlay; // Offset: 0xff8 // Size: 0x10
	char pad_0x1008[0x20]; // Offset: 0x1008 // Size: 0x20
	bool bCanWatchEnemyInRoomMode; // Offset: 0x1028 // Size: 0x01
	char pad_0x1029[0xb7]; // Offset: 0x1029 // Size: 0xb7
	struct TArray<int> BuffEffectDisplayIDArray; // Offset: 0x10e0 // Size: 0x10
	bool IsDelayNotifyEnterBattleUntilLevelLoad; // Offset: 0x10f0 // Size: 0x01
	char pad_0x10F1[0x3]; // Offset: 0x10f1 // Size: 0x03
	float NotifyTimeOut; // Offset: 0x10f4 // Size: 0x04
	float DelayCloseLoadingTime; // Offset: 0x10f8 // Size: 0x04
	char pad_0x10FC[0x4]; // Offset: 0x10fc // Size: 0x04
	struct FString NeedLoadLevelName; // Offset: 0x1100 // Size: 0x10
	struct FString NeedLoadedLevelFullName; // Offset: 0x1110 // Size: 0x10
	bool IsTickHouse; // Offset: 0x1120 // Size: 0x01
	char pad_0x1121[0xf]; // Offset: 0x1121 // Size: 0x0f
	int AntiDataCD; // Offset: 0x1130 // Size: 0x04
	int ModeID; // Offset: 0x1134 // Size: 0x04
	bool bOpenReconnectUseCharViewPoint; // Offset: 0x1138 // Size: 0x01
	char pad_0x1139[0x27]; // Offset: 0x1139 // Size: 0x27
	float ClientToDSFlowLimitTime; // Offset: 0x1160 // Size: 0x04
	float ClientToDSFlowLimit; // Offset: 0x1164 // Size: 0x04
	char pad_0x1168[0x20]; // Offset: 0x1168 // Size: 0x20
	struct FString UsingNetObjectPathNameMappingCSV; // Offset: 0x1188 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.UAEPlayerController.UseingWeaponScheme
	// Flags: [Final|Native|Public]
	bool UseingWeaponScheme(); // Offset: 0x103aa3eb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.TestShowLongTimeNoOperation
	// Flags: [Final|Exec|Native|Public]
	void TestShowLongTimeNoOperation(); // Offset: 0x103aa3e70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.TestShowConfirmDialogOfMisKill
	// Flags: [Final|Exec|Native|Public]
	void TestShowConfirmDialogOfMisKill(); // Offset: 0x103aa3e5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.TestRespawn
	// Flags: [Final|Exec|Native|Public]
	void TestRespawn(); // Offset: 0x103aa3e48 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.TestLogout
	// Flags: [Final|Exec|Native|Public]
	void TestLogout(); // Offset: 0x103aa3e34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.TestCastUIMsgWithPara
	// Flags: [Final|Exec|Native|Public]
	void TestCastUIMsgWithPara(struct FString strMsg, struct FString module, int TestID); // Offset: 0x103aa3d08 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Gameplay.UAEPlayerController.SyncDailyTaskStoreInfo
	// Flags: [Final|Native|Public]
	void SyncDailyTaskStoreInfo(struct TArray<struct FDailyTaskStoreInfo> NewDailyTaskStoreList); // Offset: 0x103aa3c24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.SetUsedSimulationCVar
	// Flags: [Final|Native|Public]
	void SetUsedSimulationCVar(bool Value); // Offset: 0x103aa3ba0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.SetTargetMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	void SetTargetMsgReceiveDelegate(struct UGameInstance* InGameInstance, DelegateProperty InDelegate); // Offset: 0x103aa3adc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.SetPanels
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetPanels(struct TArray<struct UUAEUserWidget*>& panels); // Offset: 0x103aa3a2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.SetDSMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	void SetDSMsgReceiveDelegate(DelegateProperty InDelegate); // Offset: 0x103aa39a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.SetClientMsgReceiveDelegate
	// Flags: [Final|Native|Static|Public]
	void SetClientMsgReceiveDelegate(struct UGameInstance* InGameInstance, DelegateProperty InDelegate); // Offset: 0x103aa38e0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.ServerTestLogout
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTestLogout(); // Offset: 0x103aa3884 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ServerSetVoiceId
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerSetVoiceId(int VoiceID); // Offset: 0x103aa37d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.ServerKickSelf
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerKickSelf(); // Offset: 0x103aa377c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ServerGotoSpectating
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerGotoSpectating(struct APawn* ViewTarget); // Offset: 0x103aa36d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerController.ServerExitGame
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerExitGame(); // Offset: 0x103aa3674 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ServerAcknowledgeReconnection_2
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerAcknowledgeReconnection_2(uint32_t Token); // Offset: 0x103aa35c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.SendNetObjectPathNameMappingHashToServer
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void SendNetObjectPathNameMappingHashToServer(uint32_t VersionHash); // Offset: 0x103aa351c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	void SendLuaDSToClient(int ID, struct TArray<char>& Content); // Offset: 0x103aa3438 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.SendLuaClientToDS
	// Flags: [Final|Native|Public|HasOutParms]
	void SendLuaClientToDS(int ID, struct TArray<char>& Content); // Offset: 0x103aa3354 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.RPC_Server_SyncClientNetInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_Server_SyncClientNetInfo(int InLoss, int OutLoss, int InNetworkType); // Offset: 0x103aa3230 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Gameplay.UAEPlayerController.RPC_Server_ReportClientNetInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_Server_ReportClientNetInfo(int AvgPing, int MaxPing, int MinPing, int LostPackRate, int AvgNoOutlier, int StdNoOutlier, int NumNoOutlier, int InLoss, int OutLoss); // Offset: 0x103aa2f9c // Return & Params: Num(9) Size(0x24)

	// Object Name: Function Gameplay.UAEPlayerController.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_LuaDSToClient(int ID, struct TArray<char> Content); // Offset: 0x103aa2e94 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.RPC_LuaClientToDS
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_LuaClientToDS(int ID, struct TArray<char> Content); // Offset: 0x103aa2d8c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.Respawn
	// Flags: [Native|Public|BlueprintCallable]
	void Respawn(); // Offset: 0x103aa2d70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ResetUsedSimulationCVar
	// Flags: [Final|Native|Public]
	void ResetUsedSimulationCVar(); // Offset: 0x103aa2d5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ReleaseInGameUI
	// Flags: [Native|Public|BlueprintCallable]
	void ReleaseInGameUI(); // Offset: 0x103aa2d40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ReceivePostLoginInit
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostLoginInit(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.PrintStatistics
	// Flags: [Final|Exec|Native|Public]
	void PrintStatistics(); // Offset: 0x103aa2d2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.PlayerStartIDReceived
	// Flags: [Final|Native|Protected]
	void PlayerStartIDReceived(); // Offset: 0x103aa2d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_WeaponAvatarDataList
	// Flags: [Native|Public]
	void OnRep_WeaponAvatarDataList(); // Offset: 0x103aa2cfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_UsingNetObjectPathNameMappingCSV
	// Flags: [Final|Native|Public]
	void OnRep_UsingNetObjectPathNameMappingCSV(); // Offset: 0x103aa2ce8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_UsedSimulation
	// Flags: [Native|Public]
	void OnRep_UsedSimulation(); // Offset: 0x103aa2ccc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_PveLevel
	// Flags: [Native|Public]
	void OnRep_PveLevel(); // Offset: 0x103aa2cb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_PlayerOBInfoList
	// Flags: [Final|Native|Public]
	void OnRep_PlayerOBInfoList(); // Offset: 0x103aa2c9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_LobbyWatchInfo
	// Flags: [Native|Public]
	void OnRep_LobbyWatchInfo(); // Offset: 0x103aa2c80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_LastGameResultTime
	// Flags: [Native|Public]
	void OnRep_LastGameResultTime(); // Offset: 0x103aa2c64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_IsSpectatingEnemy
	// Flags: [Native|Protected]
	void OnRep_IsSpectatingEnemy(); // Offset: 0x103aa2c48 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_IsSpectating
	// Flags: [Native|Public]
	void OnRep_IsSpectating(); // Offset: 0x103aa2c2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_IsObserver
	// Flags: [Native|Public]
	void OnRep_IsObserver(); // Offset: 0x103aa2c10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_InitialWeaponSchemeInfo
	// Flags: [Final|Native|Public]
	void OnRep_InitialWeaponSchemeInfo(); // Offset: 0x103aa2bfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_InitialEquipmentAvatar
	// Flags: [Native|Public]
	void OnRep_InitialEquipmentAvatar(); // Offset: 0x103aa2be0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_InitialConsumableAvatar
	// Flags: [Native|Public]
	void OnRep_InitialConsumableAvatar(); // Offset: 0x103aa2bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_FriendObservers
	// Flags: [Native|Public]
	void OnRep_FriendObservers(); // Offset: 0x103aa2ba8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_CurWeaponSchemeIndex
	// Flags: [Final|Native|Public]
	void OnRep_CurWeaponSchemeIndex(); // Offset: 0x103aa2b94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnRep_bRoomOwner
	// Flags: [Native|Public]
	void OnRep_bRoomOwner(); // Offset: 0x103aa2b78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.OnNetObjectPathNameMappingTableAsyncLoad
	// Flags: [Final|Native|Public]
	void OnNetObjectPathNameMappingTableAsyncLoad(); // Offset: 0x103aa2b64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.NotifyEnterBattle
	// Flags: [Final|Native|Public]
	void NotifyEnterBattle(); // Offset: 0x103aa2b50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.LuaDoString
	// Flags: [Native|Public|BlueprintCallable|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x103aa2ab0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.KickSelf
	// Flags: [Final|Exec|Native|Public]
	void KickSelf(); // Offset: 0x103aa2a9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.IsSpectatorOrDemoPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSpectatorOrDemoPlayer(); // Offset: 0x103aa2a68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSpectator(); // Offset: 0x103aa2a34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsRoomMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsRoomMode(); // Offset: 0x103aa2a10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsPureSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPureSpectator(); // Offset: 0x103aa29dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsObserver(); // Offset: 0x103aa29a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsInSpectatingEnemy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInSpectatingEnemy(); // Offset: 0x103aa2974 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsInSpectating
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInSpectating(); // Offset: 0x103aa2940 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsHawkEyeSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsHawkEyeSpectator(); // Offset: 0x103aa290c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsFriendOrEnemySpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsFriendOrEnemySpectator(); // Offset: 0x103aa28d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsFriendObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsFriendObserver(); // Offset: 0x103aa28a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsExited
	// Flags: [Final|Native|Public]
	bool IsExited(); // Offset: 0x103aa2870 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsDemoRecSpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDemoRecSpectator(); // Offset: 0x103aa283c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsDemoPlaySpectator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDemoPlaySpectator(); // Offset: 0x103aa2808 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.IsDemoPlayGlobalObserver
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDemoPlayGlobalObserver(); // Offset: 0x103aa27d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.InitWithPlayerParams
	// Flags: [Final|Native|Public|HasOutParms]
	void InitWithPlayerParams(struct FGameModePlayerParams& Params); // Offset: 0x103aa2720 // Return & Params: Num(1) Size(0x398)

	// Object Name: Function Gameplay.UAEPlayerController.InitWeaponAvatarItems
	// Flags: [Native|Public]
	void InitWeaponAvatarItems(); // Offset: 0x103aa2704 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitVehicleMusicList
	// Flags: [Native|Public]
	void InitVehicleMusicList(); // Offset: 0x103aa26e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitVehicleAvatarSkinList
	// Flags: [Native|Public]
	void InitVehicleAvatarSkinList(); // Offset: 0x103aa26cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitVehicleAvatarList
	// Flags: [Native|Public]
	void InitVehicleAvatarList(); // Offset: 0x103aa26b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitVehicleAdvanceAvatarList
	// Flags: [Native|Public]
	void InitVehicleAdvanceAvatarList(); // Offset: 0x103aa2694 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitIngameUI
	// Flags: [Native|Public|BlueprintCallable]
	void InitIngameUI(); // Offset: 0x103aa2678 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.InitGrenadeAvatarList
	// Flags: [Native|Public]
	void InitGrenadeAvatarList(bool ReInitial); // Offset: 0x103aa25ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerController.GotoSpectating
	// Flags: [Native|Public|BlueprintCallable]
	int GotoSpectating(int PlayerID); // Offset: 0x103aa2558 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerController.GetWeaponPandentReflect
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetWeaponPandentReflect(int wraponID, int& pendantID); // Offset: 0x103aa2480 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.UAEPlayerController.GetWeaponAvatarItemId
	// Flags: [Native|Public|BlueprintCallable]
	int GetWeaponAvatarItemId(int ID); // Offset: 0x103aa23ec // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerController.GetVisibleLevelsLoadedName
	// Flags: [Final|Native|Public|HasOutParms]
	void GetVisibleLevelsLoadedName(struct TArray<struct FString>& VisibleLevels); // Offset: 0x103aa2344 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.GetLobbyWatchedPlayerKeyAsString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetLobbyWatchedPlayerKeyAsString(); // Offset: 0x103aa22e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.GetDailyTaskStoreInfoByTaskId
	// Flags: [Final|Native|Public]
	struct FDailyTaskStoreInfo GetDailyTaskStoreInfoByTaskId(int TaskId); // Offset: 0x103aa2250 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.GetCurrentWeaponSchemeMainSlotItemId
	// Flags: [Final|Native|Public]
	int GetCurrentWeaponSchemeMainSlotItemId(); // Offset: 0x103aa221c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.GetCurrentOBPlayerKey
	// Flags: [Native|Public|Const]
	uint32_t GetCurrentOBPlayerKey(); // Offset: 0x103aa21e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.GetCurrentOBPlayerInfoIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetCurrentOBPlayerInfoIndex(); // Offset: 0x103aa21ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.ForceNetReady
	// Flags: [Final|Exec|Native|Public]
	void ForceNetReady(); // Offset: 0x103aa2198 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ExitGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExitGame(); // Offset: 0x103aa2184 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ExhaustCPU
	// Flags: [Final|Exec|Native|Public]
	void ExhaustCPU(); // Offset: 0x103aa2170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ExecDSCommand
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ExecDSCommand(struct FString DSCommand); // Offset: 0x103aa20d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.ExcuteIntRecord
	// Flags: [Final|Native|Public]
	void ExcuteIntRecord(struct FString Key, int Count); // Offset: 0x103aa1fd4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.UAEPlayerController.ExcuteIntCounterRecord
	// Flags: [Final|Native|Public]
	void ExcuteIntCounterRecord(struct FString Key, int Count); // Offset: 0x103aa1ed8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.UAEPlayerController.EnableInGameUI
	// Flags: [Final|Exec|Native|Public]
	void EnableInGameUI(); // Offset: 0x103aa1ec4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpUAENetActors
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void DumpUAENetActors(); // Offset: 0x103aa1eb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpRegions
	// Flags: [Final|Exec|Native|Public]
	void DumpRegions(); // Offset: 0x103aa1e9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpNetActors
	// Flags: [Final|Exec|Native|Public]
	void DumpNetActors(); // Offset: 0x103aa1e88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpCharacters
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void DumpCharacters(); // Offset: 0x103aa1e74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpAllUI
	// Flags: [Final|Exec|Native|Public]
	void DumpAllUI(); // Offset: 0x103aa1e60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpAllObjects
	// Flags: [Final|Exec|Native|Public]
	void DumpAllObjects(); // Offset: 0x103aa1e4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DumpAllActors
	// Flags: [Final|Exec|Native|Public]
	void DumpAllActors(); // Offset: 0x103aa1e38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DoLuaFile
	// Flags: [Native|Public|BlueprintCallable|Const]
	void DoLuaFile(struct FString Filename); // Offset: 0x103aa1d98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.DoCrash
	// Flags: [Final|Exec|Native|Public]
	void DoCrash(); // Offset: 0x103aa1d84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DisableInGameUI
	// Flags: [Final|Exec|Native|Public]
	void DisableInGameUI(); // Offset: 0x103aa1d70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DelayEnterBattleCheck
	// Flags: [Native|Event|Public|BlueprintEvent]
	void DelayEnterBattleCheck(); // Offset: 0x103aa1d54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.DealWithPickUpFailed
	// Flags: [Native|Event|Public|BlueprintEvent]
	void DealWithPickUpFailed(struct FItemDefineID DefineID); // Offset: 0x103aa1cc0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerController.ClientShowTeammateEscapeNotice
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientShowTeammateEscapeNotice(); // Offset: 0x103aa1ca4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsgWithStrings
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientRPC_CastUIMsgWithStrings(struct FString strMsg, struct FString module, int TipsID, struct FString Param1, struct FString Param2); // Offset: 0x103aa1ac8 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsgParams
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientRPC_CastUIMsgParams(struct FString strMsg, struct FString module, int Type); // Offset: 0x103aa1994 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Gameplay.UAEPlayerController.ClientRPC_CastUIMsg
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientRPC_CastUIMsg(struct FString strMsg, struct FString module); // Offset: 0x103aa18a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.UAEPlayerController.ClientInitPlayerOBInfoButton
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientInitPlayerOBInfoButton(); // Offset: 0x103aa1884 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ClientBroadcastRespawnComplete
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientBroadcastRespawnComplete(); // Offset: 0x103aa1868 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ClientBroadcastReconnectionSuccessful
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientBroadcastReconnectionSuccessful(); // Offset: 0x103aa184c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.ClientAcknowledgeReconnection_4
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientAcknowledgeReconnection_4(uint32_t Token); // Offset: 0x103aa17c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerController.CheckPlayerOBInfoButtonInit
	// Flags: [Native|Public]
	void CheckPlayerOBInfoButtonInit(); // Offset: 0x103aa17ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerController.CheckAcknowledgedPawn
	// Flags: [Native|Public|BlueprintCallable]
	bool CheckAcknowledgedPawn(struct APawn* InPawn); // Offset: 0x103aa1718 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Gameplay.UAEPlayerController.CastUIMsg
	// Flags: [Exec|Native|Public|BlueprintCallable]
	void CastUIMsg(struct FString strMsg, struct FString module); // Offset: 0x103aa1624 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.UAEPlayerController.CanPickUpItem
	// Flags: [Native|Event|Public|BlueprintEvent]
	enum class EPickUpCheckResult CanPickUpItem(struct FItemDefineID DefineID); // Offset: 0x103aa1580 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.UAEPlayerController.CallLuaTableFunction
	// Flags: [Native|Public|BlueprintCallable]
	void CallLuaTableFunction(struct FString tableName, struct FString FunctionName); // Offset: 0x103aa148c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.UAEPlayerController.CallLuaGlobalFunction
	// Flags: [Native|Public|BlueprintCallable]
	void CallLuaGlobalFunction(struct FString FunctionName); // Offset: 0x103aa13ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerController.BroadcastUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BroadcastUIMessage(struct FString MessageName, int TipsIDOrType, struct FString Param1, struct FString Param2); // Offset: 0x103aa126c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Gameplay.UAEPlayerController.BroadcastRespawnComplete
	// Flags: [Final|Native|Public]
	void BroadcastRespawnComplete(); // Offset: 0x103aa1258 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.UAEGameMode
// Size: 0x14f0 // Inherited bytes: 0x500
struct AUAEGameMode : ALuaGameMode {
	// Fields
	struct TWeakObjectPtr<struct UObject> UtilsPtr; // Offset: 0x500 // Size: 0x08
	float GridCheckSize; // Offset: 0x508 // Size: 0x04
	float DeepCheckSize; // Offset: 0x50c // Size: 0x04
	float HeightCheckSize; // Offset: 0x510 // Size: 0x04
	int MaxPlayerLimit; // Offset: 0x514 // Size: 0x04
	char pad_0x518[0xc]; // Offset: 0x518 // Size: 0x0c
	bool bEnableClimbing; // Offset: 0x524 // Size: 0x01
	bool IsUseFpsVault; // Offset: 0x525 // Size: 0x01
	bool bBornWithApple; // Offset: 0x526 // Size: 0x01
	bool bUseDefaultResultRules; // Offset: 0x527 // Size: 0x01
	int AntiDataCD; // Offset: 0x528 // Size: 0x04
	int WeatherID; // Offset: 0x52c // Size: 0x04
	struct FString WeatherName; // Offset: 0x530 // Size: 0x10
	int RoomMode; // Offset: 0x540 // Size: 0x04
	int SeasonIdx; // Offset: 0x544 // Size: 0x04
	float MeteorShowerRatio; // Offset: 0x548 // Size: 0x04
	char pad_0x54C[0x4]; // Offset: 0x54c // Size: 0x04
	struct FString ItemTableName; // Offset: 0x550 // Size: 0x10
	struct FString ItemClassPath; // Offset: 0x560 // Size: 0x10
	struct FString ReplayPushURL; // Offset: 0x570 // Size: 0x10
	int ReplayType; // Offset: 0x580 // Size: 0x04
	char pad_0x584[0x4]; // Offset: 0x584 // Size: 0x04
	struct FString ReplayTitle; // Offset: 0x588 // Size: 0x10
	enum class EObserverEnemyTraceType EnableObserverEnemyTrace; // Offset: 0x598 // Size: 0x01
	char pad_0x599[0x7]; // Offset: 0x599 // Size: 0x07
	struct TArray<struct FString> ItemSpawnTableList; // Offset: 0x5a0 // Size: 0x10
	struct TArray<struct FString> IgnoreItemClassPathList; // Offset: 0x5b0 // Size: 0x10
	struct TArray<struct FDSSwitchInfo> DsSwitch; // Offset: 0x5c0 // Size: 0x10
	struct TMap<uint64, struct FCharacterMoveDragData> CharacterMoveDragDataMap; // Offset: 0x5d0 // Size: 0x50
	struct TMap<uint64, struct FParachuteDragData> ParachuteDragDataMap; // Offset: 0x620 // Size: 0x50
	struct TMap<uint64, struct FVehicleMoveDragData> VehicleMoveDrag; // Offset: 0x670 // Size: 0x50
	struct TMap<uint64, struct FCharacterShootVerifyData> CharacterShootVerifyDataMap; // Offset: 0x6c0 // Size: 0x50
	uint32_t ServerStartTime; // Offset: 0x710 // Size: 0x04
	bool bOpenChangeWearing; // Offset: 0x714 // Size: 0x01
	bool bEnableVehicleInReady; // Offset: 0x715 // Size: 0x01
	char pad_0x716[0x2]; // Offset: 0x716 // Size: 0x02
	struct FString PickupBoxConfigClassPath; // Offset: 0x718 // Size: 0x10
	bool bUseAutoGroupParachuteTeam; // Offset: 0x728 // Size: 0x01
	char pad_0x729[0x7]; // Offset: 0x729 // Size: 0x07
	struct FString PickupBoxConfigDataTableName; // Offset: 0x730 // Size: 0x10
	struct FString VehicleTableName; // Offset: 0x740 // Size: 0x10
	struct FString VehicleClassPath; // Offset: 0x750 // Size: 0x10
	bool IsUsingSceneDropWeight; // Offset: 0x760 // Size: 0x01
	bool IsRegionItemGenerate; // Offset: 0x761 // Size: 0x01
	char pad_0x762[0x2]; // Offset: 0x762 // Size: 0x02
	struct FVector RegionCenter; // Offset: 0x764 // Size: 0x0c
	float RegionRadius; // Offset: 0x770 // Size: 0x04
	char pad_0x774[0x4]; // Offset: 0x774 // Size: 0x04
	struct TMap<struct FString, float> BattleCustomConfig; // Offset: 0x778 // Size: 0x50
	int MaxAllowReplicatedCharacterCount; // Offset: 0x7c8 // Size: 0x04
	int AINoRepTimeInReady; // Offset: 0x7cc // Size: 0x04
	struct AUAEOBState* ObserverPlayerStateClass; // Offset: 0x7d0 // Size: 0x08
	bool bEnableDamage; // Offset: 0x7d8 // Size: 0x01
	char pad_0x7D9[0x3]; // Offset: 0x7d9 // Size: 0x03
	float NearDeathRestoredOriginHealth; // Offset: 0x7dc // Size: 0x04
	float NearDeathDecreateBreathRate; // Offset: 0x7e0 // Size: 0x04
	float RescueOtherRestoreDuration; // Offset: 0x7e4 // Size: 0x04
	float RescueSelfRestoreDuration; // Offset: 0x7e8 // Size: 0x04
	float DeadTombBoxLifeSpan; // Offset: 0x7ec // Size: 0x04
	int DefaultPlayerBornPointID; // Offset: 0x7f0 // Size: 0x04
	bool bPlayerExitClearPlayerData; // Offset: 0x7f4 // Size: 0x01
	bool bEnableDSTickLua; // Offset: 0x7f5 // Size: 0x01
	char pad_0x7F6[0x2]; // Offset: 0x7f6 // Size: 0x02
	struct FString NetObjectPathNameMappingCSV; // Offset: 0x7f8 // Size: 0x10
	struct TArray<struct UGroupSpotSceneComponent*> ItemGroupComponents; // Offset: 0x808 // Size: 0x10
	struct AActor* ChosenPlayerStartBuildingGroup; // Offset: 0x818 // Size: 0x08
	struct TArray<struct FDynamicTriggerConfig> DynamicTriggerConfigs; // Offset: 0x820 // Size: 0x10
	struct TArray<struct AActor*> DynamicTriggers; // Offset: 0x830 // Size: 0x10
	int IsGameModeFpp; // Offset: 0x840 // Size: 0x04
	bool IsGameModeBandSpot; // Offset: 0x844 // Size: 0x01
	char pad_0x845[0x3]; // Offset: 0x845 // Size: 0x03
	struct TArray<struct FDynamicLoadItem> DynamicLoadItemArray; // Offset: 0x848 // Size: 0x10
	struct TMap<struct FDynamicLoadItem, struct FDynamicLoadActors> DynamicLoadItemMap; // Offset: 0x858 // Size: 0x50
	struct TArray<struct FVehicleAvatarReplaceCfg> VehicleAvatarReplaceCfgList; // Offset: 0x8a8 // Size: 0x10
	bool IsOpenItemGenerate; // Offset: 0x8b8 // Size: 0x01
	bool IsOpenVehicleGenerate; // Offset: 0x8b9 // Size: 0x01
	char pad_0x8BA[0x6]; // Offset: 0x8ba // Size: 0x06
	struct TArray<int> BuffEffectIDArray; // Offset: 0x8c0 // Size: 0x10
	struct TArray<int> BuffEffectDisplayIDArray; // Offset: 0x8d0 // Size: 0x10
	struct TArray<int> DynamicLevelArray; // Offset: 0x8e0 // Size: 0x10
	struct FString RoomType; // Offset: 0x8f0 // Size: 0x10
	bool bCanLedgeGrab; // Offset: 0x900 // Size: 0x01
	bool bOpenForbitTeammatePickUp; // Offset: 0x901 // Size: 0x01
	bool bOpenTeammateImprisonment; // Offset: 0x902 // Size: 0x01
	char pad_0x903[0x1]; // Offset: 0x903 // Size: 0x01
	int ZoneID; // Offset: 0x904 // Size: 0x04
	int nClientType; // Offset: 0x908 // Size: 0x04
	int nBattleType; // Offset: 0x90c // Size: 0x04
	char pad_0x910[0x48]; // Offset: 0x910 // Size: 0x48
	struct FScriptMulticastDelegate OnGameModeStateChanged; // Offset: 0x958 // Size: 0x10
	char pad_0x968[0x610]; // Offset: 0x968 // Size: 0x610
	bool bCollectedEventDataReportingEnabled; // Offset: 0xf78 // Size: 0x01
	char pad_0xF79[0x7]; // Offset: 0xf79 // Size: 0x07
	struct TArray<bool> EnabledCollectedEventDataEventIds; // Offset: 0xf80 // Size: 0x10
	char pad_0xF90[0x50]; // Offset: 0xf90 // Size: 0x50
	bool bIsPreCreatingPlayerController; // Offset: 0xfe0 // Size: 0x01
	char pad_0xFE1[0x127]; // Offset: 0xfe1 // Size: 0x127
	float OBInfoTimeStep; // Offset: 0x1108 // Size: 0x04
	char pad_0x110C[0x2c]; // Offset: 0x110c // Size: 0x2c
	struct TArray<struct FAirDropBoxInOb> AirDropBoxInfoList; // Offset: 0x1138 // Size: 0x10
	struct TArray<struct AUAEPlayerController*> KickFlagControllerList; // Offset: 0x1148 // Size: 0x10
	struct TArray<struct AUAEPlayerController*> ObserverControllerList; // Offset: 0x1158 // Size: 0x10
	char pad_0x1168[0xd8]; // Offset: 0x1168 // Size: 0xd8
	struct AUAEAdvertisementActor* AdvertisementActorBP; // Offset: 0x1240 // Size: 0x08
	struct TArray<struct FAdvertisementActorConfig> AdvConfigList; // Offset: 0x1248 // Size: 0x10
	struct TArray<struct AUAEAdvertisementActor*> AdvActorList; // Offset: 0x1258 // Size: 0x10
	struct TArray<struct FMissionBoardConfig> MissionBoardConfigList; // Offset: 0x1268 // Size: 0x10
	bool bEnablePlaneBanner; // Offset: 0x1278 // Size: 0x01
	char pad_0x1279[0x7]; // Offset: 0x1279 // Size: 0x07
	struct FString HttpPlaneBannerLeftImgPath; // Offset: 0x1280 // Size: 0x10
	struct FString HttpPlaneBannerRightImgPath; // Offset: 0x1290 // Size: 0x10
	struct FString GrenadeEffectPath; // Offset: 0x12a0 // Size: 0x10
	bool bUseSpecialGrenadeEffect; // Offset: 0x12b0 // Size: 0x01
	bool bAnniversarySignalGunEffect; // Offset: 0x12b1 // Size: 0x01
	bool bAvatarDownloadInBattle; // Offset: 0x12b2 // Size: 0x01
	bool bOpenAnniversaryActivity; // Offset: 0x12b3 // Size: 0x01
	char pad_0x12B4[0x4]; // Offset: 0x12b4 // Size: 0x04
	struct FString FestivalAirDropBoxMesh; // Offset: 0x12b8 // Size: 0x10
	bool bUseFestivalAirDropBox; // Offset: 0x12c8 // Size: 0x01
	char pad_0x12C9[0x3]; // Offset: 0x12c9 // Size: 0x03
	float FestivalAirDropProb; // Offset: 0x12cc // Size: 0x04
	float MonsterDropPar; // Offset: 0x12d0 // Size: 0x04
	float SceneDropParam; // Offset: 0x12d4 // Size: 0x04
	uint32_t DSOpenSwtich; // Offset: 0x12d8 // Size: 0x04
	char pad_0x12DC[0x4]; // Offset: 0x12dc // Size: 0x04
	struct UItemGeneratorComponent* ItemGenerator; // Offset: 0x12e0 // Size: 0x08
	struct UVehicleAndTreasureBoxGeneratorComponent* VehicleGenerator; // Offset: 0x12e8 // Size: 0x08
	bool bGameNeedReplay; // Offset: 0x12f0 // Size: 0x01
	char pad_0x12F1[0x7]; // Offset: 0x12f1 // Size: 0x07
	struct TArray<uint32_t> NeedReplayPlayers; // Offset: 0x12f8 // Size: 0x10
	struct TArray<struct FSeasonStatueData> SeasonStatueList; // Offset: 0x1308 // Size: 0x10
	struct FString SeasonStatueClassPath; // Offset: 0x1318 // Size: 0x10
	struct FString StatueBaseClassPath; // Offset: 0x1328 // Size: 0x10
	struct FStatueBaseData StatueBaseInfo; // Offset: 0x1338 // Size: 0x68
	int BattleStopJoin; // Offset: 0x13a0 // Size: 0x04
	int nSignalGunEffectId; // Offset: 0x13a4 // Size: 0x04
	struct TArray<struct FCharacterOverrideAttrData> CharacterOverrideAttrs; // Offset: 0x13a8 // Size: 0x10
	char pad_0x13B8[0xa0]; // Offset: 0x13b8 // Size: 0xa0
	bool UseGMSpawnItemSpotDefaultTag; // Offset: 0x1458 // Size: 0x01
	char pad_0x1459[0x7]; // Offset: 0x1459 // Size: 0x07
	struct FString GMSpawnItemSpotDefaultTag; // Offset: 0x1460 // Size: 0x10
	char pad_0x1470[0x70]; // Offset: 0x1470 // Size: 0x70
	bool bStandAloneGameMode; // Offset: 0x14e0 // Size: 0x01
	bool bStandAloneLuaGenAIData; // Offset: 0x14e1 // Size: 0x01
	char pad_0x14E2[0x2]; // Offset: 0x14e2 // Size: 0x02
	int StandAloneTestPlayerKey; // Offset: 0x14e4 // Size: 0x04
	struct FName StandAloneTestPlayerType; // Offset: 0x14e8 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.UAEGameMode.WriteStatistics
	// Flags: [Final|Exec|Native|Public]
	void WriteStatistics(); // Offset: 0x103a9255c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.SyncPlayerNames
	// Flags: [Native|Public]
	void SyncPlayerNames(); // Offset: 0x103a92540 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.SyncNewCorpsData
	// Flags: [Native|Public|HasOutParms]
	void SyncNewCorpsData(struct TArray<struct FDSCorpsInfo>& OutCorpsData); // Offset: 0x103a92490 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.SpawnUAEPawnFor
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent]
	struct APawn* SpawnUAEPawnFor(struct AController* NewPlayer, struct FTransform Trans); // Offset: 0x103a92398 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function Gameplay.UAEGameMode.SetVehicleReportEntry
	// Flags: [Final|Native|Public]
	void SetVehicleReportEntry(uint32_t InUniqueID, struct FVehicleReportEntry InEntry); // Offset: 0x103a922c4 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Gameplay.UAEGameMode.SetPlayerOpenId
	// Flags: [Native|Public]
	void SetPlayerOpenId(uint32_t InPlayerKey, struct FString InPlayerOpenID); // Offset: 0x103a921e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.SetMaxWeaponReportNum
	// Flags: [Final|Native|Public]
	void SetMaxWeaponReportNum(int Num); // Offset: 0x103a92170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.SetKillerPlayerKey
	// Flags: [Native|Public]
	void SetKillerPlayerKey(struct AController* VictimPlayer, uint32_t KillerPlayerKey); // Offset: 0x103a920b0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.UAEGameMode.SetGameEndReportData
	// Flags: [Native|Public]
	void SetGameEndReportData(); // Offset: 0x103a92094 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.RetrieveTeamBattleResultData
	// Flags: [Native|Public]
	struct FGameModeTeamBattleResultData RetrieveTeamBattleResultData(int TeamID); // Offset: 0x103a91fd8 // Return & Params: Num(2) Size(0xe0)

	// Object Name: Function Gameplay.UAEGameMode.RetrieveBattleData
	// Flags: [Native|Public|HasOutParms]
	void RetrieveBattleData(struct FBattleData& OutBattleData); // Offset: 0x103a91f44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.RestartPlayerAtPlayerStart
	// Flags: [Native|Public|BlueprintCallable]
	void RestartPlayerAtPlayerStart(struct AController* NewPlayer, struct AActor* StartSpot); // Offset: 0x103a91e88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.ResetGameParamsFromGameMode
	// Flags: [Native|Public]
	void ResetGameParamsFromGameMode(); // Offset: 0x103a91e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.Rescue
	// Flags: [Native|Public]
	void Rescue(struct APawn* RescueWho, struct APawn* Hero); // Offset: 0x103a91db0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.ReportCollectedEventDataWithPlayerValidation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	bool ReportCollectedEventDataWithPlayerValidation(struct AUAEPlayerController* UAEPlayerController, char EventId, DelegateProperty CollectReportedEventDataCallback); // Offset: 0x103a91c98 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function Gameplay.UAEGameMode.ReportCollectedEventDataWithPlayersValidation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	bool ReportCollectedEventDataWithPlayersValidation(struct UWorld* World, char EventId, DelegateProperty CollectReportedEventDataCallback); // Offset: 0x103a91b80 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function Gameplay.UAEGameMode.ReportCollectedEventData
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable]
	bool ReportCollectedEventData(struct FString& UId, char EventId, struct FCollectedEventData& Data); // Offset: 0x103a91a18 // Return & Params: Num(4) Size(0x69)

	// Object Name: Function Gameplay.UAEGameMode.RegisterItemGroupSpotsByTag
	// Flags: [Native|Public]
	void RegisterItemGroupSpotsByTag(struct FName Tag, struct UGroupSpotSceneComponent* GroupSpotComponent); // Offset: 0x103a9195c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.RegisterItemGroupSpots
	// Flags: [Native|Public]
	void RegisterItemGroupSpots(struct UGroupSpotSceneComponent* GroupSpotComponent); // Offset: 0x103a918d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.RefreshWorldActiveRange
	// Flags: [Native|Public]
	void RefreshWorldActiveRange(); // Offset: 0x103a918bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.RefreshWatchTeammates
	// Flags: [Native|Public]
	void RefreshWatchTeammates(struct AUAEPlayerController* InController, int InTeamID); // Offset: 0x103a917fc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.UAEGameMode.RefreshPlayerNames
	// Flags: [Native|Public]
	void RefreshPlayerNames(uint32_t InPlayerKey, struct FString InPlayerName, int TeamID, bool IsLogin, uint64 UId, int IdxInTeam); // Offset: 0x103a915e8 // Return & Params: Num(6) Size(0x2c)

	// Object Name: Function Gameplay.UAEGameMode.RecoardAlivePlayerNum
	// Flags: [Native|Public]
	int RecoardAlivePlayerNum(); // Offset: 0x103a915ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.PreCreatePlayerController
	// Flags: [Native|Public]
	struct APlayerController* PreCreatePlayerController(uint32_t PlayerKey); // Offset: 0x103a91518 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.OnStandAloneGameEnd
	// Flags: [Native|Public]
	void OnStandAloneGameEnd(); // Offset: 0x103a914fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.OnReportNetworkData
	// Flags: [Native|Public]
	void OnReportNetworkData(); // Offset: 0x103a914e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.OnPlayerFiring
	// Flags: [Native|Public]
	void OnPlayerFiring(uint32_t InPlayerKey); // Offset: 0x103a9145c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.OnPlayerControlDestroyEnd
	// Flags: [Native|Public]
	void OnPlayerControlDestroyEnd(uint32_t PlayerKey); // Offset: 0x103a913d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.OnPlayerBreathChange
	// Flags: [Native|Public]
	void OnPlayerBreathChange(uint32_t InPlayerKey, float InBreath); // Offset: 0x103a91318 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.OnObserverLogout
	// Flags: [Native|Protected]
	void OnObserverLogout(struct AUAEPlayerController* InController); // Offset: 0x103a91294 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.OnObserverLogin
	// Flags: [Native|Protected]
	void OnObserverLogin(struct AUAEPlayerController* InController); // Offset: 0x103a91210 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.OnMsg
	// Flags: [Native|Public|BlueprintCallable]
	void OnMsg(struct FString Msg); // Offset: 0x103a91170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.OnAirDropBoxLanded
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void OnAirDropBoxLanded(int boxId, struct FVector& pos); // Offset: 0x103a910a4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.OnAirDropBoxEmpty
	// Flags: [Native|Public]
	void OnAirDropBoxEmpty(int boxId); // Offset: 0x103a91020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.NotifyPlayerExitWhenNotStarted
	// Flags: [Native|Public]
	void NotifyPlayerExitWhenNotStarted(uint32_t PlayerKey, struct FName PlayerType, struct FString Reason); // Offset: 0x103a90f08 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.UAEGameMode.NotifyPlayerExit
	// Flags: [Native|Public]
	void NotifyPlayerExit(uint32_t PlayerKey, struct FName PlayerType, bool bDestroyPlayerController, bool bDestroyCharacter, bool bSendFailure, struct FString FailureMessage); // Offset: 0x103a90ce8 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function Gameplay.UAEGameMode.NotifyPlayerAbleToExitSafely
	// Flags: [Native|Public]
	void NotifyPlayerAbleToExitSafely(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x103a90c28 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.NotifyGameModeParamsChanged
	// Flags: [Native|Public|HasOutParms]
	void NotifyGameModeParamsChanged(struct FGameModeParams& GameModeParams); // Offset: 0x103a90b90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.NotifyGameModeLuckmate
	// Flags: [Native|Public]
	void NotifyGameModeLuckmate(int64_t MyUID, int64_t LuckmateUID); // Offset: 0x103a90ad4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.NotifyGameModeInit
	// Flags: [Native|Public]
	void NotifyGameModeInit(); // Offset: 0x103a90ab8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.NotifyExistPlayerReEnter
	// Flags: [Native|Public]
	void NotifyExistPlayerReEnter(uint32_t PlayerKey); // Offset: 0x103a90a34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.NotifyAIPlayerEnter
	// Flags: [Native|Public]
	void NotifyAIPlayerEnter(uint32_t PlayerKey, bool IsMLAI); // Offset: 0x103a90970 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEGameMode.NotifyAIDropInfo
	// Flags: [Native|Public|HasOutParms]
	void NotifyAIDropInfo(int NewAI, struct FDSAIDropInfo& Info); // Offset: 0x103a9086c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Gameplay.UAEGameMode.ModifyVehicleDamage
	// Flags: [Native|Public|HasOutParms]
	float ModifyVehicleDamage(float Damage, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* VictimVehicle, struct AActor* DamageCauser); // Offset: 0x103a906d0 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function Gameplay.UAEGameMode.ModifyDamage
	// Flags: [Native|Public|HasOutParms]
	float ModifyDamage(float Damage, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AController* VictimController, struct AActor* DamageCauser); // Offset: 0x103a90534 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function Gameplay.UAEGameMode.Killed
	// Flags: [Native|Public|HasOutParms]
	void Killed(struct AController* Killer, struct AController* VictimPlayer, struct APawn* VictimPawn, struct FDamageEvent& DamageEvent); // Offset: 0x103a903e4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Gameplay.UAEGameMode.IsSatisfyGeneratorArea
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool IsSatisfyGeneratorArea(struct FVector& Location); // Offset: 0x103a9034c // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Gameplay.UAEGameMode.IsPlayerCollectedEventDataReportingEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayerCollectedEventDataReportingEnabled(struct AUAEPlayerController* UAEPlayerController); // Offset: 0x103a902c0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Gameplay.UAEGameMode.IsCollectedEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCollectedEventEnabled(char EventId); // Offset: 0x103a90234 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.UAEGameMode.InitWorldActiveRange
	// Flags: [Native|Public]
	void InitWorldActiveRange(); // Offset: 0x103a90218 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitSeasonStatue
	// Flags: [Native|Public]
	void InitSeasonStatue(); // Offset: 0x103a901fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitMissionBoard
	// Flags: [Native|Public]
	void InitMissionBoard(); // Offset: 0x103a901e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitGenerator
	// Flags: [Native|Public]
	void InitGenerator(); // Offset: 0x103a901c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitGameParamsFromGameMode
	// Flags: [Native|Public]
	void InitGameParamsFromGameMode(); // Offset: 0x103a901a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitDynamicTriggers
	// Flags: [Native|Public]
	void InitDynamicTriggers(); // Offset: 0x103a9018c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitDynamicBuildingGroups
	// Flags: [Native|Public]
	void InitDynamicBuildingGroups(); // Offset: 0x103a90170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.InitBornWithApple
	// Flags: [Native|Public]
	void InitBornWithApple(); // Offset: 0x103a90154 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.Heartbeat
	// Flags: [Final|Native|Public]
	void Heartbeat(); // Offset: 0x103a90140 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.HasVehicleReportEntry
	// Flags: [Final|Native|Public]
	bool HasVehicleReportEntry(uint32_t InUniqueID); // Offset: 0x103a900b4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEGameMode.HasDynamicBuildingGroup
	// Flags: [Final|Native|Public|Const]
	bool HasDynamicBuildingGroup(); // Offset: 0x103a90080 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEGameMode.HandlePlayerPaintDecalResponse
	// Flags: [Native|Public]
	void HandlePlayerPaintDecalResponse(uint32_t PlayerKey, struct FName PlayerType, int Result, int DecalId, int Count); // Offset: 0x103a8ff10 // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Gameplay.UAEGameMode.GotoNearDeath
	// Flags: [Native|Public]
	void GotoNearDeath(struct AController* DamageInstigator, struct APawn* VictimPawn); // Offset: 0x103a8fe54 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.GetVehicleReportEntry
	// Flags: [Final|Native|Public]
	struct FVehicleReportEntry GetVehicleReportEntry(uint32_t InUniqueID); // Offset: 0x103a8fdb8 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Gameplay.UAEGameMode.GetSurvivingTeamCount
	// Flags: [Native|Public]
	int GetSurvivingTeamCount(); // Offset: 0x103a8fd7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.GetSurvivingCharacterCount
	// Flags: [Native|Public]
	int GetSurvivingCharacterCount(); // Offset: 0x103a8fd40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.GetPlayerStateListWithTeamID
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct AUAEPlayerState*> GetPlayerStateListWithTeamID(int TeamID, struct FName PlayerType); // Offset: 0x103a8fc50 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.UAEGameMode.GetPlayerControllerWithUID
	// Flags: [Final|Native|Public|Const]
	struct AUAEPlayerController* GetPlayerControllerWithUID(uint64 UId); // Offset: 0x103a8fbc4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.GetPlayerControllerListWithTeamID
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct AUAEPlayerController*> GetPlayerControllerListWithTeamID(int TeamID, struct FName PlayerType); // Offset: 0x103a8fad4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.UAEGameMode.GetPlayerAndRealAiNum
	// Flags: [Native|Public|HasOutParms]
	void GetPlayerAndRealAiNum(struct FHeartBeatData& Data); // Offset: 0x103a8fa3c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.GetObserverControllerList
	// Flags: [Final|Native|Public]
	struct TArray<struct AUAEPlayerController*> GetObserverControllerList(); // Offset: 0x103a8f9d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.GetMonsterNum
	// Flags: [Native|Public|HasOutParms]
	void GetMonsterNum(struct FHeartBeatData& Data); // Offset: 0x103a8f940 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.GetMaxWeaponReportNum
	// Flags: [Final|Native|Public]
	int GetMaxWeaponReportNum(); // Offset: 0x103a8f924 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEGameMode.GetClassicPlaneDirection
	// Flags: [Native|Public|HasDefaults]
	struct FVector GetClassicPlaneDirection(); // Offset: 0x103a8f8e4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Gameplay.UAEGameMode.FindPlayerStateWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct AUAEPlayerState* FindPlayerStateWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x103a8f81c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.FindPlayerControllerWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct AUAEPlayerController* FindPlayerControllerWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x103a8f754 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.FindPlayerControllerByUId
	// Flags: [Native|Public|Const]
	struct APlayerController* FindPlayerControllerByUId(uint64 UId); // Offset: 0x103a8f6c0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.FindControllerWithPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct AController* FindControllerWithPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x103a8f5f8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Gameplay.UAEGameMode.DestroyNoActiveWorldActor
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	void DestroyNoActiveWorldActor(struct FVector& Location, float& Radius); // Offset: 0x103a8f514 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAEGameMode.DestroyCharacterForPlayerController
	// Flags: [Native|Public]
	void DestroyCharacterForPlayerController(struct APlayerController* PC); // Offset: 0x103a8f490 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.DestroyAllPickUpObjs
	// Flags: [Final|Native|Public]
	void DestroyAllPickUpObjs(); // Offset: 0x103a8f47c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.DeleteSeasonStatue
	// Flags: [Native|Public]
	void DeleteSeasonStatue(); // Offset: 0x103a8f460 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.DeleteDynamicLoadItem
	// Flags: [Native|Public]
	void DeleteDynamicLoadItem(); // Offset: 0x103a8f444 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEGameMode.DebugEnterFriendObserver
	// Flags: [Native|Public]
	void DebugEnterFriendObserver(struct AUAEPlayerController* InController); // Offset: 0x103a8f3c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameMode.CreateDynamicBuildingGroups
	// Flags: [Final|Native|Public|HasDefaults]
	void CreateDynamicBuildingGroups(struct FVector Offset); // Offset: 0x103a8f344 // Return & Params: Num(1) Size(0xc)

	// Object Name: DelegateFunction Gameplay.UAEGameMode.CollectReportedEventDataCallback__DelegateSignature
	// Flags: [Public|Delegate]
	struct FCollectedEventData CollectReportedEventDataCallback__DelegateSignature(struct AUAEGameMode* UAEGameMode, struct AUAEPlayerController* UAEPlayerController, char EventId); // Offset: 0x103e03170 // Return & Params: Num(4) Size(0x68)

	// Object Name: Function Gameplay.UAEGameMode.CollectAllPlayerInfo
	// Flags: [Native|Public]
	void CollectAllPlayerInfo(float DeltaSeconds, bool bForce); // Offset: 0x103a8f27c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEGameMode.ChangeName
	// Flags: [Native|Public]
	void ChangeName(struct AController* Controller, struct FString NewName, bool bNameChange); // Offset: 0x103a8f158 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Gameplay.UAEGameMode.AddAirDropBox
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	void AddAirDropBox(int boxId, struct FVector& pos); // Offset: 0x103a8f08c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Gameplay.UAEGameState
// Size: 0x568 // Inherited bytes: 0x4e0
struct AUAEGameState : ALuaGameState {
	// Fields
	struct UUAEGameSubsystem* GameBridge; // Offset: 0x4e0 // Size: 0x08
	char pad_0x4E8[0x5]; // Offset: 0x4e8 // Size: 0x05
	bool bTeamIDChgDeactivePawn; // Offset: 0x4ed // Size: 0x01
	char pad_0x4EE[0x52]; // Offset: 0x4ee // Size: 0x52
	struct FString WeaponAttrReloadTableName; // Offset: 0x540 // Size: 0x10
	struct FString DamageSearchTableName; // Offset: 0x550 // Size: 0x10
	bool IsInitTable; // Offset: 0x560 // Size: 0x01
	char pad_0x561[0x7]; // Offset: 0x561 // Size: 0x07

	// Functions

	// Object Name: Function Gameplay.UAEGameState.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	void SendLuaDSToClient(int ID, struct TArray<char>& Content); // Offset: 0x103a97e78 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEGameState.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_LuaDSToClient(int ID, struct TArray<char> Content); // Offset: 0x103a97d70 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEGameState.GetGameBridge
	// Flags: [Final|Native|Public]
	struct UUAEGameSubsystem* GetGameBridge(); // Offset: 0x103a97d54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEGameState.CheckDSSwitchOpen
	// Flags: [Native|Public|BlueprintCallable]
	bool CheckDSSwitchOpen(int SwitchId); // Offset: 0x103a97cc0 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class Gameplay.ItemActorComponent
// Size: 0x1d8 // Inherited bytes: 0x1d8
struct UItemActorComponent : ULuaActorComponent {
};

// Object Name: Class Gameplay.BaseGeneratorComponent
// Size: 0x2d8 // Inherited bytes: 0x1d8
struct UBaseGeneratorComponent : UItemActorComponent {
	// Fields
	bool bWorldTileGenerator; // Offset: 0x1d1 // Size: 0x01
	bool bModeStateControl; // Offset: 0x1d2 // Size: 0x01
	int GenerateSpotCountPerTick; // Offset: 0x1d4 // Size: 0x04
	struct FString ItemTableName; // Offset: 0x1d8 // Size: 0x10
	struct TArray<struct FString> ItemSpawnTableList; // Offset: 0x1e8 // Size: 0x10
	struct UUAEDataTable* ItemTable; // Offset: 0x1f8 // Size: 0x08
	bool IsWriteStatisticsToLog; // Offset: 0x200 // Size: 0x01
	char pad_0x207[0x1]; // Offset: 0x207 // Size: 0x01
	struct TMap<enum class ESpotGroupType, struct FGroupSpotComponentArray> AllGroupSpots; // Offset: 0x208 // Size: 0x50
	struct TArray<struct USpotSceneComponent*> AllSpotsToTick; // Offset: 0x258 // Size: 0x10
	struct TMap<int, struct FWorldTileSpotArray> WorldTileSpots; // Offset: 0x268 // Size: 0x50
	struct FString CookedFilePath; // Offset: 0x2b8 // Size: 0x10
	struct TArray<struct FString> CookedFileAddPathArray; // Offset: 0x2c8 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.BaseGeneratorComponent.RegisterWorldTileSpot
	// Flags: [Native|Public]
	void RegisterWorldTileSpot(struct USpotSceneComponent* Spot); // Offset: 0x103a40f4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.BaseGeneratorComponent.RegisterSpotComponentToTick
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterSpotComponentToTick(struct USpotSceneComponent* SpotComponent); // Offset: 0x103a40ec8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.BaseGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent); // Offset: 0x103a40e44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.BaseGeneratorComponent.GetRandomCategory
	// Flags: [Native|Public|HasOutParms]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights); // Offset: 0x103a40d5c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.BaseGeneratorComponent.GeneratorWorldTileSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	void GeneratorWorldTileSpots(struct FWorldTileSpotArray& SpotArray); // Offset: 0x103a40ca4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.BaseGeneratorComponent.GenerateSpots
	// Flags: [Native|Public]
	void GenerateSpots(); // Offset: 0x103a40c88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BaseGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Public]
	void GenerateSpotOnTick(float DeltaTime); // Offset: 0x103a40c04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.BaseGeneratorComponent.GeneratePickupActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct AActor* GeneratePickupActor(struct UObject* ActorClass, struct FVector& ActorLocation, struct FRotator& ActorRotator, enum class ESpawnActorCollisionHandlingMethod SpawnActorCollisionHandlingMethod, struct FItemGenerateSpawnClass ItemData); // Offset: 0x103a409c8 // Return & Params: Num(6) Size(0x108)

	// Object Name: Function Gameplay.BaseGeneratorComponent.CheckTileLevelsVisible
	// Flags: [Final|Native|Protected]
	void CheckTileLevelsVisible(); // Offset: 0x103a409b4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.ItemGeneratorComponent
// Size: 0x9d0 // Inherited bytes: 0x2d8
struct UItemGeneratorComponent : UBaseGeneratorComponent {
	// Fields
	struct FVector ItemGenerateOffset; // Offset: 0x2d8 // Size: 0x0c
	enum class ESpotGroupType BornIslandGroupType; // Offset: 0x2e4 // Size: 0x01
	bool bStatisticsValid; // Offset: 0x2e5 // Size: 0x01
	char pad_0x2E6[0x2]; // Offset: 0x2e6 // Size: 0x02
	struct FItemGenerateStatisticsData ItemStatisticsData; // Offset: 0x2e8 // Size: 0x110
	struct TSet<struct FString> IgnoreItemClassPathSet; // Offset: 0x3f8 // Size: 0x50
	struct TArray<struct FSpotGroupProperty> SpotGroupPropertys; // Offset: 0x448 // Size: 0x10
	bool UseSpotGroupPropertysEx; // Offset: 0x458 // Size: 0x01
	bool UseAreaID; // Offset: 0x459 // Size: 0x01
	char pad_0x45A[0x6]; // Offset: 0x45a // Size: 0x06
	struct TArray<struct FString> AreaIDList; // Offset: 0x460 // Size: 0x10
	struct TArray<struct FItemRegionCircle> ReplacedGeneratorRegionMap; // Offset: 0x470 // Size: 0x10
	struct TArray<struct FSpotGroupProperty> SpotGroupPropertysEx; // Offset: 0x480 // Size: 0x10
	struct TArray<struct FExtraItemSpawn> ExtraSpawnItemsList; // Offset: 0x490 // Size: 0x10
	struct TMap<enum class ESpotGroupType, struct FSpotGroupProperty> SpotGroupPropertysDic; // Offset: 0x4a0 // Size: 0x50
	struct FSpotGroupProperty DefaultSpotGroupProperty; // Offset: 0x4f0 // Size: 0x28
	struct UCurveFloat* SpotRateCurve; // Offset: 0x518 // Size: 0x08
	struct UCurveFloat* ItemRateCurve; // Offset: 0x520 // Size: 0x08
	struct TMap<struct FString, float> CategoryRates; // Offset: 0x528 // Size: 0x50
	struct TMap<struct FString, struct FItemGenerateSpawnDataArray> ItemGenerateSpawnDatas; // Offset: 0x578 // Size: 0x50
	struct TArray<struct AActor*> BornIslandItems; // Offset: 0x5c8 // Size: 0x10
	struct TArray<struct UItemGroupSpotSceneComponent*> AllValidGroups; // Offset: 0x5d8 // Size: 0x10
	bool bIsGenerateBornIslandItems; // Offset: 0x5e8 // Size: 0x01
	bool bIsGenerateMainlandItems; // Offset: 0x5e9 // Size: 0x01
	bool bIsGenerateWorldTileItems; // Offset: 0x5ea // Size: 0x01
	char pad_0x5EB[0x5]; // Offset: 0x5eb // Size: 0x05
	struct FDateTime GenerateBornIslandTime; // Offset: 0x5f0 // Size: 0x08
	struct FDateTime GenerateMainlandTime; // Offset: 0x5f8 // Size: 0x08
	bool bUseLocalSpotFile; // Offset: 0x600 // Size: 0x01
	char pad_0x601[0x57]; // Offset: 0x601 // Size: 0x57
	struct TArray<struct FRepeatItemSpotData> AllRepeatItemSpotData; // Offset: 0x658 // Size: 0x10
	char pad_0x668[0x10]; // Offset: 0x668 // Size: 0x10
	struct TArray<struct FItemGenerateSpawnClass> AllItemSpotDataToTick; // Offset: 0x678 // Size: 0x10
	char pad_0x688[0x50]; // Offset: 0x688 // Size: 0x50
	struct FString CookedBandFilePath; // Offset: 0x6d8 // Size: 0x10
	char pad_0x6E8[0x50]; // Offset: 0x6e8 // Size: 0x50
	bool bIsAreaItemLimit; // Offset: 0x738 // Size: 0x01
	char pad_0x739[0x7]; // Offset: 0x739 // Size: 0x07
	struct TArray<struct FAreaItemsLimitEdit> AreaItemsLimit; // Offset: 0x740 // Size: 0x10
	struct TMap<struct FRegionID, struct FAreaItemsLimit> AreaItemsLimitMaps; // Offset: 0x750 // Size: 0x50
	int DSSwitchSyncLoadId; // Offset: 0x7a0 // Size: 0x04
	bool bUseDynamicSpotConfig; // Offset: 0x7a4 // Size: 0x01
	char pad_0x7A5[0x3]; // Offset: 0x7a5 // Size: 0x03
	struct TArray<struct FDynamicSpotConfig> DynamicSpotConfigs; // Offset: 0x7a8 // Size: 0x10
	char pad_0x7B8[0x50]; // Offset: 0x7b8 // Size: 0x50
	bool bEnablePreCalculate; // Offset: 0x808 // Size: 0x01
	char pad_0x809[0x3]; // Offset: 0x809 // Size: 0x03
	int RandomSpotCountPerTick; // Offset: 0x80c // Size: 0x04
	char pad_0x810[0x50]; // Offset: 0x810 // Size: 0x50
	struct FScriptMulticastDelegate PreCalculateCompleted; // Offset: 0x860 // Size: 0x10
	bool bCheckPreCalculateComplete; // Offset: 0x870 // Size: 0x01
	bool bEnablePrimeItemCircle; // Offset: 0x871 // Size: 0x01
	char pad_0x872[0x6]; // Offset: 0x872 // Size: 0x06
	struct TArray<struct FPrimeItemCircleConfig> PrimeItemCircleConfigs; // Offset: 0x878 // Size: 0x10
	char pad_0x888[0x30]; // Offset: 0x888 // Size: 0x30
	struct TMap<struct FVector, struct UUAESpotGroupObject*> SpotGroupObjectsMapByLoc; // Offset: 0x8b8 // Size: 0x50
	char pad_0x908[0xa1]; // Offset: 0x908 // Size: 0xa1
	bool bRemovableMode; // Offset: 0x9a9 // Size: 0x01
	char pad_0x9AA[0x2]; // Offset: 0x9aa // Size: 0x02
	int RemoveGeneratedItemPerTick; // Offset: 0x9ac // Size: 0x04
	int RemoveDropGroundItemPerTick; // Offset: 0x9b0 // Size: 0x04
	bool bAddHouseActorSerializeData; // Offset: 0x9b4 // Size: 0x01
	char pad_0x9B5[0x1b]; // Offset: 0x9b5 // Size: 0x1b

	// Functions

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteItemSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteItemSpotStatisticsDatas(); // Offset: 0x103a6caa4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteItemClassStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	void WriteItemClassStatisticsDatas_V15(); // Offset: 0x103a6ca90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteItemClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteItemClassStatisticsDatas(); // Offset: 0x103a6ca7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteGroupStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteGroupStatisticsDatas(); // Offset: 0x103a6ca68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteBuildingStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteBuildingStatisticsDatas(); // Offset: 0x103a6ca54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteAreaItemStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteAreaItemStatisticsDatas(); // Offset: 0x103a6ca40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteAllStatisticsDatasToLog
	// Flags: [Native|Protected|BlueprintCallable]
	void WriteAllStatisticsDatasToLog(); // Offset: 0x103a6ca24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.WriteAllStatisticsDatas
	// Flags: [Native|Public|BlueprintCallable]
	void WriteAllStatisticsDatas(); // Offset: 0x103a6ca08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.SetCatetoryRate
	// Flags: [Final|Native|Public]
	void SetCatetoryRate(struct TMap<struct FString, float> Rates); // Offset: 0x103a6c948 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RemoveSpotInfo
	// Flags: [Final|Native|Public]
	bool RemoveSpotInfo(bool bFirstEnterState); // Offset: 0x103a6c8b4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RemoveItemOnTick
	// Flags: [Final|Native|Public]
	void RemoveItemOnTick(); // Offset: 0x103a6c8a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RemoveDropGround
	// Flags: [Final|Native|Public]
	bool RemoveDropGround(bool bFirstEnterState); // Offset: 0x103a6c80c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RegisterItemGenerateSpawnData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterItemGenerateSpawnData(struct FItemGenerateSpawnData Data); // Offset: 0x103a6c744 // Return & Params: Num(1) Size(0x68)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RegisterBornIslandItem
	// Flags: [Native|Public]
	void RegisterBornIslandItem(struct AActor* Item); // Offset: 0x103a6c6c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.ItemGeneratorComponent.ReadItemGenerateTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* ReadItemGenerateTable(struct FString TablePath); // Offset: 0x103a6c5f4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.ItemGeneratorComponent.ReAddAllSpot
	// Flags: [Final|Native|Public]
	void ReAddAllSpot(); // Offset: 0x103a6c5e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RandomSingleGroup
	// Flags: [Final|Native|Protected|HasOutParms]
	struct UItemGroupSpotSceneComponent* RandomSingleGroup(struct TArray<struct UGroupSpotSceneComponent*>& Groups, struct FSpotGroupProperty& GroupProperty); // Offset: 0x103a6c4a8 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RandomGroupsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomGroupsByType(struct FSpotGroupProperty& GroupProperty); // Offset: 0x103a6c3e8 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Gameplay.ItemGeneratorComponent.RandomBornIslandGroups
	// Flags: [Native|Protected|BlueprintCallable]
	void RandomBornIslandGroups(); // Offset: 0x103a6c3cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.OnAsyncLoadItemClassFinish
	// Flags: [Final|Native|Public]
	void OnAsyncLoadItemClassFinish(struct UClass* ActorClassPtr, struct FItemGenerateSpawnClass SpawnClass); // Offset: 0x103a6c210 // Return & Params: Num(2) Size(0x100)

	// Object Name: Function Gameplay.ItemGeneratorComponent.LuaCustomFunctionAfterGenerate
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void LuaCustomFunctionAfterGenerate(struct FItemGenerateSpawnClass& SpawnClass, struct AActor* ItemActor); // Offset: 0x103a6c0d0 // Return & Params: Num(2) Size(0xe0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.LuaAddRandomItemClassArray
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool LuaAddRandomItemClassArray(struct FItemGenerateSpawnClass SpawnClass); // Offset: 0x103a6bfb4 // Return & Params: Num(2) Size(0xd9)

	// Object Name: Function Gameplay.ItemGeneratorComponent.LoadItemGenerateTable
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LoadItemGenerateTable(); // Offset: 0x103a6bf98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.IsCatetoryEnabled
	// Flags: [Final|Native|Protected]
	bool IsCatetoryEnabled(); // Offset: 0x103a6bf64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.ItemGeneratorComponent.InitCatetorys
	// Flags: [Final|Native|Protected]
	void InitCatetorys(); // Offset: 0x103a6bf50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.InitCategoryEx
	// Flags: [Final|Native|Protected]
	void InitCategoryEx(); // Offset: 0x103a6bf3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GMGenerateAllSpot
	// Flags: [Final|Native|Public]
	bool GMGenerateAllSpot(struct FString ItemPath); // Offset: 0x103a6be70 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetSpotTags
	// Flags: [Final|Native|Public]
	struct TArray<struct FString> GetSpotTags(); // Offset: 0x103a6be0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetSpotLocsByTag
	// Flags: [Final|Native|Public]
	struct TArray<struct FVector> GetSpotLocsByTag(struct FString ExTag); // Offset: 0x103a6bd3c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetSpotLocInPolygon
	// Flags: [Final|Native|Public|HasOutParms]
	int GetSpotLocInPolygon(struct TArray<struct FVector> Anchors, struct TArray<struct FVector>& OutLocs, int RandomNum); // Offset: 0x103a6bba0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetSpotLocInCircle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	int GetSpotLocInCircle(struct FVector Center, int Radius, struct TArray<struct FVector>& OutLocs, int RandomNum); // Offset: 0x103a6ba2c // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetSpotGroupPropertyByGroupType
	// Flags: [Final|Native|Public]
	struct FSpotGroupProperty GetSpotGroupPropertyByGroupType(enum class ESpotGroupType SpotGroupType); // Offset: 0x103a6b990 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetRandomItemClassArray
	// Flags: [Final|Native|Public|HasOutParms]
	bool GetRandomItemClassArray(struct FString& Value, struct FString& Category, struct TArray<struct FItemGenerateSpawnClass>& Results, bool RepeatGenerateItem, struct UItemSpotSceneComponent* SpotComponent); // Offset: 0x103a6b76c // Return & Params: Num(6) Size(0x41)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetItemDefineID
	// Flags: [Event|Public|BlueprintEvent]
	int GetItemDefineID(struct UObject* PickUpClass); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GetCatetoryRate
	// Flags: [Final|Native|Protected]
	float GetCatetoryRate(struct FString Catetory); // Offset: 0x103a6b6c4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.ItemGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Public]
	void GenerateSpotOnTick(float DeltaTime); // Offset: 0x103a6b640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.ItemGeneratorComponent.FindASpawnLoc
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector FindASpawnLoc(struct UWorld* InWorld, struct FVector TraceStart); // Offset: 0x103a6b570 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.ItemGeneratorComponent.EnableRefreshAllSpot
	// Flags: [Final|Native|Public]
	void EnableRefreshAllSpot(); // Offset: 0x103a6b55c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.EnablePrimeItemPolygon
	// Flags: [Final|Native|Public]
	void EnablePrimeItemPolygon(struct TArray<struct FVector> Anchors, int PrimeConfigIndex); // Offset: 0x103a6b438 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.ItemGeneratorComponent.EnablePrimeItemCircle
	// Flags: [Final|Native|Public|HasDefaults]
	void EnablePrimeItemCircle(struct FVector Center, int Radius, int PrimeConfigIndex); // Offset: 0x103a6b348 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Gameplay.ItemGeneratorComponent.EnableDynamicSpotConfigByIndex
	// Flags: [Final|Native|Public]
	void EnableDynamicSpotConfigByIndex(int DynamicIndex); // Offset: 0x103a6b2cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.ItemGeneratorComponent.DoPickUp
	// Flags: [Native|Event|Public|BlueprintEvent]
	void DoPickUp(int ItemSpotDataIndex, struct FString Value, struct FString Category); // Offset: 0x103a6b19c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Gameplay.ItemGeneratorComponent.DeleteBornIslandItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteBornIslandItems(); // Offset: 0x103a6b188 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.CheckShouldGenerateItem
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool CheckShouldGenerateItem(int ItemID); // Offset: 0x103a6b0f4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.ItemGeneratorComponent.CheckRecoverItems
	// Flags: [Final|Native|Public]
	void CheckRecoverItems(); // Offset: 0x103a6b0e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGeneratorComponent.CheckInPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool CheckInPolygon(struct FVector& pos, struct TArray<struct FVector>& Anchors); // Offset: 0x103a6afdc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Gameplay.ItemGeneratorComponent.CheckInCircle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool CheckInCircle(struct FVector& pos, struct FVector& Center, int& Radius); // Offset: 0x103a6aea8 // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function Gameplay.ItemGeneratorComponent.AddIgnoreItemClassPath
	// Flags: [Final|Native|Public|HasOutParms]
	void AddIgnoreItemClassPath(struct TArray<struct FString>& IgnoreItemClassList); // Offset: 0x103a6ae00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.ItemGeneratorComponent.AddDropGround
	// Flags: [Final|Native|Public]
	void AddDropGround(struct AActor* InActor); // Offset: 0x103a6ad84 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Gameplay.UAEPlayerState
// Size: 0x1238 // Inherited bytes: 0x508
struct AUAEPlayerState : ALuaPlayerState {
	// Fields
	bool IsForcedNetRelevant; // Offset: 0x508 // Size: 0x01
	char pad_0x509[0x3]; // Offset: 0x509 // Size: 0x03
	float surviveTime; // Offset: 0x50c // Size: 0x04
	float Pronetime; // Offset: 0x510 // Size: 0x04
	char pad_0x514[0x8]; // Offset: 0x514 // Size: 0x08
	float marchDistance; // Offset: 0x51c // Size: 0x04
	float travelDistance; // Offset: 0x520 // Size: 0x04
	float DriveDistance; // Offset: 0x524 // Size: 0x04
	float MonsterCatchupDistance; // Offset: 0x528 // Size: 0x04
	int destroyVehicleNum; // Offset: 0x52c // Size: 0x04
	int rescueTimes; // Offset: 0x530 // Size: 0x04
	char pad_0x534[0x4]; // Offset: 0x534 // Size: 0x04
	struct TArray<uint64> RescueTeammatesList; // Offset: 0x538 // Size: 0x10
	int NormalItemsNum; // Offset: 0x548 // Size: 0x04
	int SeniorItemsNum; // Offset: 0x54c // Size: 0x04
	int GVMemberID; // Offset: 0x550 // Size: 0x04
	char pad_0x554[0x4]; // Offset: 0x554 // Size: 0x04
	struct FName PlayerType; // Offset: 0x558 // Size: 0x08
	uint64 FinalTeamleaderUID; // Offset: 0x560 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x568 // Size: 0x04
	char pad_0x56C[0x4]; // Offset: 0x56c // Size: 0x04
	struct FString PlayerUID; // Offset: 0x570 // Size: 0x10
	struct FString MLAIStringUID; // Offset: 0x580 // Size: 0x10
	bool bAIPlayer; // Offset: 0x590 // Size: 0x01
	char pad_0x591[0x7]; // Offset: 0x591 // Size: 0x07
	struct FString iconUrl; // Offset: 0x598 // Size: 0x10
	int gender; // Offset: 0x5a8 // Size: 0x04
	int PlayerLevel; // Offset: 0x5ac // Size: 0x04
	int SegmentLevel; // Offset: 0x5b0 // Size: 0x04
	int AceImprintShowId; // Offset: 0x5b4 // Size: 0x04
	int AceImprintBaseId; // Offset: 0x5b8 // Size: 0x04
	int AvatarBoxId; // Offset: 0x5bc // Size: 0x04
	int planeAvatarId; // Offset: 0x5c0 // Size: 0x04
	int CampID; // Offset: 0x5c4 // Size: 0x04
	int resID; // Offset: 0x5c8 // Size: 0x04
	char pad_0x5CC[0x4]; // Offset: 0x5cc // Size: 0x04
	uint64 UId; // Offset: 0x5d0 // Size: 0x08
	uint64 MLAIDisplayUID; // Offset: 0x5d8 // Size: 0x08
	struct FString OpenID; // Offset: 0x5e0 // Size: 0x10
	struct FString Nation; // Offset: 0x5f0 // Size: 0x10
	int TeamID; // Offset: 0x600 // Size: 0x04
	char pad_0x604[0x4]; // Offset: 0x604 // Size: 0x04
	int64_t IdxInTeam; // Offset: 0x608 // Size: 0x08
	int PlayerBornPointID; // Offset: 0x610 // Size: 0x04
	int Kills; // Offset: 0x614 // Size: 0x04
	int KillsBeforeDie; // Offset: 0x618 // Size: 0x04
	int Knockouts; // Offset: 0x61c // Size: 0x04
	char pad_0x620[0x8]; // Offset: 0x620 // Size: 0x08
	int MlAIDeliverNum; // Offset: 0x628 // Size: 0x04
	int Assists; // Offset: 0x62c // Size: 0x04
	struct TArray<uint64> AssistTeammatesList; // Offset: 0x630 // Size: 0x10
	char pad_0x640[0x50]; // Offset: 0x640 // Size: 0x50
	struct TArray<int> OvertimeAssistsTime; // Offset: 0x690 // Size: 0x10
	char PlatformGender; // Offset: 0x6a0 // Size: 0x01
	char pad_0x6A1[0x3]; // Offset: 0x6a1 // Size: 0x03
	int MatchStrategyLabel; // Offset: 0x6a4 // Size: 0x04
	int MatchLabel; // Offset: 0x6a8 // Size: 0x04
	uint32_t Killer; // Offset: 0x6ac // Size: 0x04
	uint32_t KillerIGPlayerKey; // Offset: 0x6b0 // Size: 0x04
	char pad_0x6B4[0x4]; // Offset: 0x6b4 // Size: 0x04
	struct FString BeKilledOpenID; // Offset: 0x6b8 // Size: 0x10
	struct FString KillerName; // Offset: 0x6c8 // Size: 0x10
	uint32_t KillerType; // Offset: 0x6d8 // Size: 0x04
	uint32_t KillerDeliveryType; // Offset: 0x6dc // Size: 0x04
	uint32_t DeadCircleIndex; // Offset: 0x6e0 // Size: 0x04
	char pad_0x6E4[0x4]; // Offset: 0x6e4 // Size: 0x04
	uint64 MisKillTeammatePlayerKey; // Offset: 0x6e8 // Size: 0x08
	int ShootWeaponShotNum; // Offset: 0x6f0 // Size: 0x04
	int ShootWeaponShotAndHitPlayerNum; // Offset: 0x6f4 // Size: 0x04
	int ShootWeaponShotAndHitPlayerNumNoAI; // Offset: 0x6f8 // Size: 0x04
	int ShootWeaponShotHeadNum; // Offset: 0x6fc // Size: 0x04
	int ShootWeaponShotHeadNumNoAI; // Offset: 0x700 // Size: 0x04
	int HeadShotNum; // Offset: 0x704 // Size: 0x04
	int HeadShotNumNoAI; // Offset: 0x708 // Size: 0x04
	int KillNumByGrende; // Offset: 0x70c // Size: 0x04
	int UseFragGrenadeNum; // Offset: 0x710 // Size: 0x04
	int UseSmokeGrenadeNum; // Offset: 0x714 // Size: 0x04
	int UseFlashGrenadeNum; // Offset: 0x718 // Size: 0x04
	int UseBurnGrenadeNum; // Offset: 0x71c // Size: 0x04
	int MaxKillDistance; // Offset: 0x720 // Size: 0x04
	int HealTimes; // Offset: 0x724 // Size: 0x04
	float DamageAmount; // Offset: 0x728 // Size: 0x04
	int MeleeKillTimes; // Offset: 0x72c // Size: 0x04
	float MeleeDamageAmount; // Offset: 0x730 // Size: 0x04
	float RangedDamagedAmount; // Offset: 0x734 // Size: 0x04
	float VehicleDamageAmount; // Offset: 0x738 // Size: 0x04
	float HealAmount; // Offset: 0x73c // Size: 0x04
	struct TArray<struct FString> KillFlow; // Offset: 0x740 // Size: 0x10
	struct TSet<struct FString> TeammateKillUIDSet; // Offset: 0x750 // Size: 0x50
	struct TArray<struct FString> KnockOutFlow; // Offset: 0x7a0 // Size: 0x10
	struct TArray<struct FKnockOutData> KnockOutList; // Offset: 0x7b0 // Size: 0x10
	float InDamageAmount; // Offset: 0x7c0 // Size: 0x04
	char pad_0x7C4[0x14]; // Offset: 0x7c4 // Size: 0x14
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // Offset: 0x7d8 // Size: 0x10
	int PickUpItemTimes; // Offset: 0x7e8 // Size: 0x04
	bool bIsForbidItemFlowMerge; // Offset: 0x7ec // Size: 0x01
	char pad_0x7ED[0x3]; // Offset: 0x7ed // Size: 0x03
	struct TMap<int, struct FTLog_BornLandGrenadeData> TLog_BornLandGrenadeData; // Offset: 0x7f0 // Size: 0x50
	struct FAIDeliveryTlogData TLog_AIDeliveryTlogData; // Offset: 0x840 // Size: 0x58
	bool bHasSendAIDeliverData; // Offset: 0x898 // Size: 0x01
	char pad_0x899[0x7]; // Offset: 0x899 // Size: 0x07
	struct TMap<int, bool> TLog_PickUpItemIdMap; // Offset: 0x8a0 // Size: 0x50
	struct TArray<struct FGameModeLikeResultData> Like; // Offset: 0x8f0 // Size: 0x10
	uint32_t Switch; // Offset: 0x900 // Size: 0x04
	char pad_0x904[0x4]; // Offset: 0x904 // Size: 0x04
	struct TArray<uint32_t> Self; // Offset: 0x908 // Size: 0x10
	struct TArray<struct FGameModeTeammateLableCheckData> LabelCheck; // Offset: 0x918 // Size: 0x10
	struct TArray<struct FUseItemFlow> UseItemFlow; // Offset: 0x928 // Size: 0x10
	struct TArray<struct FUseBuffFlow> UseBuffFlow; // Offset: 0x938 // Size: 0x10
	struct TArray<struct FBuildingEnterFlow> BuildingEnterFlow; // Offset: 0x948 // Size: 0x10
	struct TArray<struct FTLog_PropEquipUnequipFlow> TLog_PropEquipUnequipFlowData; // Offset: 0x958 // Size: 0x10
	struct TMap<int, int> TLog_BulletCount; // Offset: 0x968 // Size: 0x50
	struct FTLog_SpecialStats TLog_SpecialStats; // Offset: 0x9b8 // Size: 0x08
	bool bIsOutsideBlueCircle; // Offset: 0x9c0 // Size: 0x01
	char pad_0x9C1[0x3]; // Offset: 0x9c1 // Size: 0x03
	float OutsideBlueCircleTime; // Offset: 0x9c4 // Size: 0x04
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // Offset: 0x9c8 // Size: 0x10
	int FirstOpenedAirDropBoxNum; // Offset: 0x9d8 // Size: 0x04
	int FirstOpenedPlayerTombBoxNum; // Offset: 0x9dc // Size: 0x04
	int FirstOpenedTreasureBoxNum; // Offset: 0x9e0 // Size: 0x04
	float HitEnemyHeadAmount; // Offset: 0x9e4 // Size: 0x04
	struct TArray<int> BuildFlow; // Offset: 0x9e8 // Size: 0x10
	struct TArray<int> DestroyShelterFlow; // Offset: 0x9f8 // Size: 0x10
	float ShelterTakeDamage; // Offset: 0xa08 // Size: 0x04
	float HitShelterDamage; // Offset: 0xa0c // Size: 0x04
	struct FVector LandLocation; // Offset: 0xa10 // Size: 0x0c
	struct FVector ParachuteLocation; // Offset: 0xa1c // Size: 0x0c
	int LandTime; // Offset: 0xa28 // Size: 0x04
	struct FVector DeadLocation; // Offset: 0xa2c // Size: 0x0c
	struct FString DeadDamangeType; // Offset: 0xa38 // Size: 0x10
	int PveDeadAttacker; // Offset: 0xa48 // Size: 0x04
	int PveStageId; // Offset: 0xa4c // Size: 0x04
	struct FString DeadTimeStr; // Offset: 0xa50 // Size: 0x10
	int NearDeathDamageType; // Offset: 0xa60 // Size: 0x04
	uint32_t NearDeathCauserId; // Offset: 0xa64 // Size: 0x04
	bool NearDeathIsHeadShot; // Offset: 0xa68 // Size: 0x01
	char pad_0xA69[0x3]; // Offset: 0xa69 // Size: 0x03
	int BeDownTimes; // Offset: 0xa6c // Size: 0x04
	int BeSavedTimes; // Offset: 0xa70 // Size: 0x04
	char pad_0xA74[0x4]; // Offset: 0xa74 // Size: 0x04
	struct FEquipmentData EquipmentData; // Offset: 0xa78 // Size: 0x70
	int PersonalRank; // Offset: 0xae8 // Size: 0x04
	char pad_0xAEC[0x8]; // Offset: 0xaec // Size: 0x08
	bool bIsGameTerminator; // Offset: 0xaf4 // Size: 0x01
	char pad_0xAF5[0x3]; // Offset: 0xaf5 // Size: 0x03
	int GamePlayingTime; // Offset: 0xaf8 // Size: 0x04
	int ObserverTime; // Offset: 0xafc // Size: 0x04
	int TouchDownAreaID; // Offset: 0xb00 // Size: 0x04
	int TouchDownLocTypeID; // Offset: 0xb04 // Size: 0x04
	struct TArray<int> TouchDownAreaList; // Offset: 0xb08 // Size: 0x10
	bool bHasTouchDownAreaList; // Offset: 0xb18 // Size: 0x01
	char pad_0xB19[0x3]; // Offset: 0xb19 // Size: 0x03
	float ReportTouchDownHeight; // Offset: 0xb1c // Size: 0x04
	struct TArray<struct FGameModePlayerTaskData> CompletedTaskList; // Offset: 0xb20 // Size: 0x10
	struct TArray<struct FReportCollection> SpecialCollectionList; // Offset: 0xb30 // Size: 0x10
	struct TArray<struct FWeaponDamageRecord> WeaponDamageRecordList; // Offset: 0xb40 // Size: 0x10
	struct TArray<int> SecretAreaIDList; // Offset: 0xb50 // Size: 0x10
	struct TArray<struct FSpecialPickItemState> CollectItemRecord; // Offset: 0xb60 // Size: 0x10
	float DrivingHelicopterTime; // Offset: 0xb70 // Size: 0x04
	float InHelicopterTime; // Offset: 0xb74 // Size: 0x04
	int RevivalNum; // Offset: 0xb78 // Size: 0x04
	int BeRevivedNum; // Offset: 0xb7c // Size: 0x04
	int KillNumInVehicle; // Offset: 0xb80 // Size: 0x04
	float MaxVehicleToLandHeight; // Offset: 0xb84 // Size: 0x04
	float MaxVehicleInAirInterval; // Offset: 0xb88 // Size: 0x04
	int KillPlayerNum; // Offset: 0xb8c // Size: 0x04
	int KillAINum; // Offset: 0xb90 // Size: 0x04
	float TotalSprintDistance; // Offset: 0xb94 // Size: 0x04
	float TotalBeenDamageAmount; // Offset: 0xb98 // Size: 0x04
	float DestroyVehicleWheelNum; // Offset: 0xb9c // Size: 0x04
	struct TArray<struct FDestroyVehicleWheelFlow> DestroyVehicleWheelFlow; // Offset: 0xba0 // Size: 0x10
	int ProneTimes; // Offset: 0xbb0 // Size: 0x04
	int CrouchTimes; // Offset: 0xbb4 // Size: 0x04
	int JumpTimes; // Offset: 0xbb8 // Size: 0x04
	int KillMonsterNum; // Offset: 0xbbc // Size: 0x04
	struct TMap<int, int> MonsterID2KillNum; // Offset: 0xbc0 // Size: 0x50
	float TotalDamageAmountToMonsters; // Offset: 0xc10 // Size: 0x04
	float TotalDamageAmountFromMonsters; // Offset: 0xc14 // Size: 0x04
	struct TMap<int, float> DamageAmountToMonsters; // Offset: 0xc18 // Size: 0x50
	struct TMap<int, float> DamageAmountFromMonsters; // Offset: 0xc68 // Size: 0x50
	int MonsterHeadShotKilledTimes; // Offset: 0xcb8 // Size: 0x04
	int BeMonsterDownTimes; // Offset: 0xcbc // Size: 0x04
	int LightCandleNum; // Offset: 0xcc0 // Size: 0x04
	char pad_0xCC4[0x4]; // Offset: 0xcc4 // Size: 0x04
	struct TMap<int, int> ActivityButtonCount; // Offset: 0xcc8 // Size: 0x50
	struct TArray<struct FActivityEventReportData> ActivityEventRecordList; // Offset: 0xd18 // Size: 0x10
	float BattleStateTime; // Offset: 0xd28 // Size: 0x04
	bool bIsKickedFromGame; // Offset: 0xd2c // Size: 0x01
	char pad_0xD2D[0x3]; // Offset: 0xd2d // Size: 0x03
	float DriveWithTeammateDistance; // Offset: 0xd30 // Size: 0x04
	int FistKillingCount; // Offset: 0xd34 // Size: 0x04
	int OpenedAirDropBoxNum; // Offset: 0xd38 // Size: 0x04
	char pad_0xD3C[0x4]; // Offset: 0xd3c // Size: 0x04
	struct TMap<uint32_t, uint32_t> VehicleUsedMap; // Offset: 0xd40 // Size: 0x50
	struct TArray<struct FString> DestroyVehicleFlow; // Offset: 0xd90 // Size: 0x10
	int UseHelicoperNum; // Offset: 0xda0 // Size: 0x04
	char pad_0xDA4[0x4]; // Offset: 0xda4 // Size: 0x04
	struct TArray<struct FTLog_KillInfo> PlayerKillAIInfo; // Offset: 0xda8 // Size: 0x10
	struct TArray<struct FTLog_KillInfo> PlayerNearDeathDuoToAI; // Offset: 0xdb8 // Size: 0x10
	struct FTLog_KillInfo AIKillPlayerInfo; // Offset: 0xdc8 // Size: 0x28
	float UseHelicoperDistance; // Offset: 0xdf0 // Size: 0x04
	char CharmRankIndex; // Offset: 0xdf4 // Size: 0x01
	char pad_0xDF5[0x3]; // Offset: 0xdf5 // Size: 0x03
	struct TSet<uint32_t> UseHelicoperRecord; // Offset: 0xdf8 // Size: 0x50
	char pad_0xE48[0x4]; // Offset: 0xe48 // Size: 0x04
	int SnowBoardJumpActionCount; // Offset: 0xe4c // Size: 0x04
	int EmoteOnTelpherCount; // Offset: 0xe50 // Size: 0x04
	int KillMagicWalkAI; // Offset: 0xe54 // Size: 0x04
	int SendMagicWalkAI; // Offset: 0xe58 // Size: 0x04
	char pad_0xE5C[0x4]; // Offset: 0xe5c // Size: 0x04
	struct TArray<int> FindBlackMonsterIDs; // Offset: 0xe60 // Size: 0x10
	int KillSnowManCount; // Offset: 0xe70 // Size: 0x04
	char pad_0xE74[0x4]; // Offset: 0xe74 // Size: 0x04
	uint64 LuckmateUID; // Offset: 0xe78 // Size: 0x08
	struct TMap<enum class EEventCounterDefine, int> EventCounterMap; // Offset: 0xe80 // Size: 0x50
	struct TMap<int, int> GeneralCounterMap; // Offset: 0xed0 // Size: 0x50
	char pad_0xF20[0x8]; // Offset: 0xf20 // Size: 0x08
	struct FScriptMulticastDelegate OnGenerelCountChanged; // Offset: 0xf28 // Size: 0x10
	int VeteranRecruitIndex; // Offset: 0xf38 // Size: 0x04
	char pad_0xF3C[0x4]; // Offset: 0xf3c // Size: 0x04
	struct TArray<struct FPlayEmoteData> FPlayEmoteDataArray; // Offset: 0xf40 // Size: 0x10
	struct FGameModePlayerAliasInfo AliasInfo; // Offset: 0xf50 // Size: 0x48
	int MemberIdInVoiceRoom; // Offset: 0xf98 // Size: 0x04
	bool PlayerVoiceEnable; // Offset: 0xf9c // Size: 0x01
	char pad_0xF9D[0x3]; // Offset: 0xf9d // Size: 0x03
	struct FGameModePlayerUpassInfo UpassInfo; // Offset: 0xfa0 // Size: 0x30
	int UpassShow; // Offset: 0xfd0 // Size: 0x04
	int upassKeepBuy; // Offset: 0xfd4 // Size: 0x04
	int upassCurValue; // Offset: 0xfd8 // Size: 0x04
	bool UpassIsBuy; // Offset: 0xfdc // Size: 0x01
	char pad_0xFDD[0x3]; // Offset: 0xfdd // Size: 0x03
	struct FTLog_Micphone MicphoneTlog; // Offset: 0xfe0 // Size: 0x18
	float TeammateMicrophoneTime; // Offset: 0xff8 // Size: 0x04
	float TeammateSpeakerTime; // Offset: 0xffc // Size: 0x04
	float EnemyMicrophoneTime; // Offset: 0x1000 // Size: 0x04
	float EnemySpeakerTime; // Offset: 0x1004 // Size: 0x04
	float TeammateInterphoneTime; // Offset: 0x1008 // Size: 0x04
	float EnemyInterphoneTime; // Offset: 0x100c // Size: 0x04
	float MicrophoneUseTimeStamp; // Offset: 0x1010 // Size: 0x04
	float SpeakerUseTimeStamp; // Offset: 0x1014 // Size: 0x04
	char pad_0x1018[0x38]; // Offset: 0x1018 // Size: 0x38
	struct FDamageInfo LuaNearDeathDamageInfo; // Offset: 0x1050 // Size: 0x90
	struct FDamageInfo LuaDeathDamageInfo; // Offset: 0x10e0 // Size: 0x90
	struct FName RepPropertyCategory; // Offset: 0x1170 // Size: 0x08
	bool IsOnline; // Offset: 0x1178 // Size: 0x01
	char pad_0x1179[0x1f]; // Offset: 0x1179 // Size: 0x1f
	struct FGameBaseInfo GameBaseInfo; // Offset: 0x1198 // Size: 0x80
	char pad_0x1218[0x8]; // Offset: 0x1218 // Size: 0x08
	struct FString RealPlayerName; // Offset: 0x1220 // Size: 0x10
	int CollectedEventType; // Offset: 0x1230 // Size: 0x04
	char pad_0x1234[0x4]; // Offset: 0x1234 // Size: 0x04

	// Functions

	// Object Name: Function Gameplay.UAEPlayerState.SetGVMemberIDServerCall
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void SetGVMemberIDServerCall(int memberID); // Offset: 0x103aa79c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.SetGVMemberID
	// Flags: [Final|Native|Public]
	void SetGVMemberID(int memberID); // Offset: 0x103aa7948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.SetDeliveryResult
	// Flags: [Final|Native|Public]
	void SetDeliveryResult(uint32_t InDeliverPlayerKey, bool bInSuccess, int EventTypeId); // Offset: 0x103aa7844 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Gameplay.UAEPlayerState.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	void SendLuaDSToClient(int ID, struct TArray<char>& Content); // Offset: 0x103aa7760 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerState.RPC_ServerAddGeneralCount
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void RPC_ServerAddGeneralCount(int ID, int InCount, bool bReset); // Offset: 0x103aa7628 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.UAEPlayerState.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_LuaDSToClient(int ID, struct TArray<char> Content); // Offset: 0x103aa7520 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerState.ReportTaskExtInfo
	// Flags: [Final|Native|Public]
	void ReportTaskExtInfo(int TaskId, struct FString ExtInfo); // Offset: 0x103aa7424 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEPlayerState.ReportTaskData
	// Flags: [Final|Native|Public]
	void ReportTaskData(int TaskId, int process); // Offset: 0x103aa7370 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerState.ReportSpecialCollection
	// Flags: [Final|Native|Public]
	void ReportSpecialCollection(int ItemID, int Count); // Offset: 0x103aa72bc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerState.ReportSecretAreaID
	// Flags: [Final|Native|Public]
	void ReportSecretAreaID(int SecretAreaID); // Offset: 0x103aa7240 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLikeTeammate
	// Flags: [Final|Native|Public]
	void ReportLikeTeammate(int64_t BeLikeUID, int LikeType); // Offset: 0x103aa7188 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLikeSwitch
	// Flags: [Final|Native|Public]
	void ReportLikeSwitch(int SwitchSetting); // Offset: 0x103aa710c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLikeSelf
	// Flags: [Final|Native|Public]
	void ReportLikeSelf(int LikeType); // Offset: 0x103aa7090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLandLocType
	// Flags: [Final|Native|Public]
	void ReportLandLocType(int TouchDownLocType); // Offset: 0x103aa7014 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLandAreaList
	// Flags: [Final|Native|Public|HasOutParms]
	void ReportLandAreaList(struct TArray<int>& TouchDownAreaIDs); // Offset: 0x103aa6f6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLandArea
	// Flags: [Final|Native|Public]
	void ReportLandArea(int TouchDownArea); // Offset: 0x103aa6ef0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.ReportLabelCheck
	// Flags: [Final|Native|Public]
	void ReportLabelCheck(int TeammateUID, int Result); // Offset: 0x103aa6e3c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerState.RecordUseHelicoper
	// Flags: [Final|Native|Public]
	void RecordUseHelicoper(uint32_t UseHelicoperId); // Offset: 0x103aa6dc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.OnRepCampIDBP
	// Flags: [Event|Public|BlueprintEvent]
	void OnRepCampIDBP(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_VeteranRecruitIndex
	// Flags: [Final|Native|Public]
	void OnRep_VeteranRecruitIndex(); // Offset: 0x103aa6dac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_UpdateKillMonsterNum
	// Flags: [Native|Public]
	void OnRep_UpdateKillMonsterNum(); // Offset: 0x103aa6d90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_UID
	// Flags: [Native|Public]
	void OnRep_UID(); // Offset: 0x103aa6d74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_RescueTimesChange
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnRep_RescueTimesChange(); // Offset: 0x103aa6d58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_PlayerKillsChange
	// Flags: [Native|Public]
	void OnRep_PlayerKillsChange(); // Offset: 0x103aa6d3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_MLAIDisplayUID
	// Flags: [Final|Native|Public]
	void OnRep_MLAIDisplayUID(); // Offset: 0x103aa6d28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_MatchLabel
	// Flags: [Final|Native|Public]
	void OnRep_MatchLabel(); // Offset: 0x103aa6d14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_CollectItemRecord
	// Flags: [Final|Native|Public]
	void OnRep_CollectItemRecord(); // Offset: 0x103aa6d00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_CampID
	// Flags: [Final|Native|Public]
	void OnRep_CampID(); // Offset: 0x103aa6cec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnRep_AliasInfo
	// Flags: [Final|Native|Public]
	void OnRep_AliasInfo(); // Offset: 0x103aa6cd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.OnClientVeteranRecruitIndexUpdated
	// Flags: [Native|Public]
	void OnClientVeteranRecruitIndexUpdated(); // Offset: 0x103aa6cbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.IsSpecialPickItemCollectionCompleted
	// Flags: [Final|Native|Public]
	bool IsSpecialPickItemCollectionCompleted(int ItemID); // Offset: 0x103aa6c30 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEPlayerState.IsSpecialPickItem
	// Flags: [Final|Native|Public]
	bool IsSpecialPickItem(int ItemID); // Offset: 0x103aa6ba4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEPlayerState.IsNearDeathDamageInfoValid
	// Flags: [Final|Native|Public]
	bool IsNearDeathDamageInfoValid(); // Offset: 0x103aa6b70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerState.IsItemForbidMerge
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsItemForbidMerge(int ItemResId); // Offset: 0x103aa6adc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEPlayerState.IsDeathDamageInfoValid
	// Flags: [Final|Native|Public]
	bool IsDeathDamageInfoValid(); // Offset: 0x103aa6aa8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerState.GetWeaponRecordData
	// Flags: [Final|Native|Public|HasOutParms|Const]
	void GetWeaponRecordData(struct FOnePlayerWeapon& OutWeaponInfo); // Offset: 0x103aa69fc // Return & Params: Num(1) Size(0x20)

	// Object Name: Function Gameplay.UAEPlayerState.GetVeteranPlayerLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int GetVeteranPlayerLevel(); // Offset: 0x103aa69c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.GetUserIDByMemberID
	// Flags: [Native|Public]
	uint32_t GetUserIDByMemberID(int memberID); // Offset: 0x103aa692c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.UAEPlayerState.GetUIDString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUIDString(); // Offset: 0x103aa68c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEPlayerState.GetTeammateBattleResultData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FGameModeTeammateBattleResultData GetTeammateBattleResultData(); // Offset: 0x103aa685c // Return & Params: Num(1) Size(0x1c0)

	// Object Name: Function Gameplay.UAEPlayerState.GetRank
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetRank(); // Offset: 0x103aa6828 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.GetPlayerKey
	// Flags: [Final|Native|Public]
	uint32_t GetPlayerKey(); // Offset: 0x103aa67f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEPlayerState.GetPlayerBattleResultData_SuperCold
	// Flags: [Native|Public|Const]
	struct FGameModePlayerBattleResultData_SuperCold GetPlayerBattleResultData_SuperCold(); // Offset: 0x103aa6784 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function Gameplay.UAEPlayerState.GetPlayerBattleResultData
	// Flags: [Native|Public|Const]
	struct FGameModePlayerBattleResultData GetPlayerBattleResultData(); // Offset: 0x103aa6718 // Return & Params: Num(1) Size(0x600)

	// Object Name: Function Gameplay.UAEPlayerState.GetMentorPlayerType
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure]
	enum class EMentorPlayerType GetMentorPlayerType(); // Offset: 0x103aa66dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEPlayerState.ForceUpdateCampCharacterList
	// Flags: [Native|Public]
	void ForceUpdateCampCharacterList(); // Offset: 0x103aa66c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.CopyNearDeathDamageInfo
	// Flags: [Final|Native|Public]
	void CopyNearDeathDamageInfo(); // Offset: 0x103aa66ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.CopyDeathDamageInfo
	// Flags: [Final|Native|Public]
	void CopyDeathDamageInfo(); // Offset: 0x103aa6698 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.ClearTlogData
	// Flags: [Native|Public]
	void ClearTlogData(); // Offset: 0x103aa667c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEPlayerState.ChangeCollectItemRecord
	// Flags: [Final|Native|Public]
	void ChangeCollectItemRecord(int InItemID, bool InNewState); // Offset: 0x103aa65c0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.UAEPlayerState.AddGeneralCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddGeneralCount(int ID, int InCount, bool bReset); // Offset: 0x103aa64c8 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.UAEPlayerState.AddEventCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddEventCount(char EventId, int InCount, bool bReset); // Offset: 0x103aa63d0 // Return & Params: Num(3) Size(0x9)
};

// Object Name: Class Gameplay.UAERegionActor
// Size: 0x498 // Inherited bytes: 0x488
struct AUAERegionActor : ALuaActor {
	// Fields
	char pad_0x488[0x8]; // Offset: 0x488 // Size: 0x08
	char AutoDormancyType; // Offset: 0x490 // Size: 0x01
	bool bStatic; // Offset: 0x491 // Size: 0x01
	enum class ERegionSizeIndex RegionSize; // Offset: 0x492 // Size: 0x01
	bool bNeedUpdateNetworkInfo; // Offset: 0x493 // Size: 0x01
	char pad_0x494[0x4]; // Offset: 0x494 // Size: 0x04

	// Functions

	// Object Name: Function Gameplay.UAERegionActor.ReceivedPlayerActiveRegionsChanged
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivedPlayerActiveRegionsChanged(bool bEnter); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Gameplay.UAECharacter
// Size: 0x9f0 // Inherited bytes: 0x800
struct AUAECharacter : ACharacter {
	// Fields
	char pad_0x800[0x68]; // Offset: 0x800 // Size: 0x68
	int iRegionCharacter; // Offset: 0x868 // Size: 0x04
	char pad_0x86C[0x4]; // Offset: 0x86c // Size: 0x04
	struct FName RepPropertyCategory; // Offset: 0x870 // Size: 0x08
	struct FName PlayerType; // Offset: 0x878 // Size: 0x08
	struct FString PlayerName; // Offset: 0x880 // Size: 0x10
	struct FString Nation; // Offset: 0x890 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x8a0 // Size: 0x04
	char pad_0x8A4[0x4]; // Offset: 0x8a4 // Size: 0x04
	struct FString PlayerUID; // Offset: 0x8a8 // Size: 0x10
	struct FString MLAIPlayerUID; // Offset: 0x8b8 // Size: 0x10
	int TeamID; // Offset: 0x8c8 // Size: 0x04
	bool bTeamLeader; // Offset: 0x8cc // Size: 0x01
	char pad_0x8CD[0x3]; // Offset: 0x8cd // Size: 0x03
	int CampID; // Offset: 0x8d0 // Size: 0x04
	int resID; // Offset: 0x8d4 // Size: 0x04
	enum class ECharacterGender DefaultCharacterGender; // Offset: 0x8d8 // Size: 0x01
	char pad_0x8D9[0x7]; // Offset: 0x8d9 // Size: 0x07
	struct TArray<struct FGameModePlayerItem> InitialItemList; // Offset: 0x8e0 // Size: 0x10
	struct FGameModePlayerUpassInfo UpassInfo; // Offset: 0x8f0 // Size: 0x30
	struct FGameModePlayerPetInfo PetInfo; // Offset: 0x920 // Size: 0x20
	int planeAvatarId; // Offset: 0x940 // Size: 0x04
	int DyeDebugFlag; // Offset: 0x944 // Size: 0x04
	struct TArray<struct FGameModePlayerTaskData> InitialTaskDataList; // Offset: 0x948 // Size: 0x10
	bool bIsAI; // Offset: 0x958 // Size: 0x01
	bool bIsMLAI; // Offset: 0x959 // Size: 0x01
	bool bIsAIWithPet; // Offset: 0x95a // Size: 0x01
	char pad_0x95B[0x1]; // Offset: 0x95b // Size: 0x01
	float DestinyValue; // Offset: 0x95c // Size: 0x04
	char pad_0x960[0xc]; // Offset: 0x960 // Size: 0x0c
	float RatingScore; // Offset: 0x96c // Size: 0x04
	bool UseWholeBodyModel; // Offset: 0x970 // Size: 0x01
	bool DefaultIsUseWholeBodyModel; // Offset: 0x971 // Size: 0x01
	char pad_0x972[0xe]; // Offset: 0x972 // Size: 0x0e
	struct FString LuaFilePath; // Offset: 0x980 // Size: 0x10
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x990 // Size: 0x50
	char pad_0x9E0[0x10]; // Offset: 0x9e0 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.UAECharacter.SetNetCullDistanceSquared
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNetCullDistanceSquared(float fNetCullDistanceSquared); // Offset: 0x103a84e18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAECharacter.SendLuaDSToClient
	// Flags: [Final|Native|Public|HasOutParms]
	void SendLuaDSToClient(int ID, struct TArray<char>& Content); // Offset: 0x103a84d34 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAECharacter.RPC_LuaDSToClient
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_LuaDSToClient(int ID, struct TArray<char> Content); // Offset: 0x103a84c2c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAECharacter.OnRep_UseWholeModel
	// Flags: [Final|Native|Public]
	void OnRep_UseWholeModel(); // Offset: 0x103a84c18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.OnRep_TeamID
	// Flags: [Final|Native|Public]
	void OnRep_TeamID(); // Offset: 0x103a84c04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.OnRep_PlayerUID
	// Flags: [Final|Native|Public]
	void OnRep_PlayerUID(); // Offset: 0x103a84bf0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.OnRep_PlayerKey
	// Flags: [Native|Public]
	void OnRep_PlayerKey(); // Offset: 0x103a84bd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.OnRep_MLAIPlayerUID
	// Flags: [Final|Native|Public]
	void OnRep_MLAIPlayerUID(); // Offset: 0x103a84bc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.OnRep_CampID
	// Flags: [Final|Native|Public]
	void OnRep_CampID(); // Offset: 0x103a84bac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAECharacter.IsDefaultCharType
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDefaultCharType(); // Offset: 0x103a84b70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAECharacter.GetTeamId
	// Flags: [Final|Native|Public|Const]
	int GetTeamId(); // Offset: 0x103a84b54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAECharacter.GetPlayerKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FString GetPlayerKey(); // Offset: 0x103a84af0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacter.GetNonSimulatedComponents_OnFighting
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents_OnFighting(); // Offset: 0x103a84a84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacter.GetNonSimulatedComponents_NonTeammates
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents_NonTeammates(); // Offset: 0x103a84a18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacter.GetNonSimulatedComponents
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UActorComponent*> GetNonSimulatedComponents(); // Offset: 0x103a849ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacter.GetNonDedicatedComponents
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct TArray<struct UActorComponent*> GetNonDedicatedComponents(); // Offset: 0x103a84940 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacter.GetMovementBaseComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPrimitiveComponent* GetMovementBaseComponent(); // Offset: 0x103a8490c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAECharacter.GetCampId
	// Flags: [Final|Native|Public]
	int GetCampId(); // Offset: 0x103a848d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAECharacter.ClientAcknowledgeReconnection_3
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientAcknowledgeReconnection_3(uint32_t Token); // Offset: 0x103a84854 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Gameplay.UAEHouseActor
// Size: 0x590 // Inherited bytes: 0x498
struct AUAEHouseActor : AUAENetActor {
	// Fields
	int iRegionHouse; // Offset: 0x498 // Size: 0x04
	float WindowHideDistanceSquared; // Offset: 0x49c // Size: 0x04
	float WindowLoadDistanceSquared; // Offset: 0x4a0 // Size: 0x04
	float WindowLoadDistanceSquaredOnVeryLowDevice; // Offset: 0x4a4 // Size: 0x04
	float WindowLoadDistanceSquaredOnServer; // Offset: 0x4a8 // Size: 0x04
	char pad_0x4AC[0x4]; // Offset: 0x4ac // Size: 0x04
	struct TArray<struct FUAEWindowRepData> WindowList; // Offset: 0x4b0 // Size: 0x10
	struct TMap<int, struct UUAEWindowComponent*> WindowComponents; // Offset: 0x4c0 // Size: 0x50
	bool bEnableWindow; // Offset: 0x510 // Size: 0x01
	bool bShouldConsiderDistance; // Offset: 0x511 // Size: 0x01
	char pad_0x512[0x66]; // Offset: 0x512 // Size: 0x66
	bool SerializeDataUse; // Offset: 0x578 // Size: 0x01
	bool IsStickToTheGround; // Offset: 0x579 // Size: 0x01
	char pad_0x57A[0x6]; // Offset: 0x57a // Size: 0x06
	struct TArray<char> SerializeData; // Offset: 0x580 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.UAEHouseActor.ProcessWindowCreateList
	// Flags: [Final|Native|Static|Public]
	void ProcessWindowCreateList(); // Offset: 0x103a990e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEHouseActor.OnRep_WindowList
	// Flags: [Final|Native|Private]
	void OnRep_WindowList(); // Offset: 0x103a990cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEHouseActor.ClearWindowList
	// Flags: [Final|Native|Public]
	void ClearWindowList(); // Offset: 0x103a990b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEHouseActor.BroadcastWindowRepDataUpdated
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void BroadcastWindowRepDataUpdated(struct FUAEWindowRepData InRepData); // Offset: 0x103a98fbc // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class Gameplay.UAEGameSubsystem
// Size: 0x348 // Inherited bytes: 0x28
struct UUAEGameSubsystem : UObject {
	// Fields
	struct FScriptMulticastDelegate GameModeStateChangeEvent; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate ActorOverlapEvent; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate ActorDieEvent; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate PawnDieEvent; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate CharacterDieEvent; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate EnterAreaTriggerEvent; // Offset: 0x78 // Size: 0x10
	struct FScriptMulticastDelegate ExitAreaTriggerEvent; // Offset: 0x88 // Size: 0x10
	struct FScriptMulticastDelegate PawnPickupItemEvent; // Offset: 0x98 // Size: 0x10
	struct FScriptMulticastDelegate VehicleOverlapEvent; // Offset: 0xa8 // Size: 0x10
	struct FScriptMulticastDelegate PawnAttachToVehicleSeatEvent; // Offset: 0xb8 // Size: 0x10
	struct FScriptMulticastDelegate InteractiveActorBeginEvent; // Offset: 0xc8 // Size: 0x10
	struct FScriptMulticastDelegate InteractiveActorDoneEvent; // Offset: 0xd8 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStartSkill; // Offset: 0xe8 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStopSkill; // Offset: 0xf8 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStartSkillPhase; // Offset: 0x108 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStopSkillPhase; // Offset: 0x118 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStartSkillCooldown; // Offset: 0x128 // Size: 0x10
	struct FScriptMulticastDelegate CharacterStopSkillCooldown; // Offset: 0x138 // Size: 0x10
	struct FScriptMulticastDelegate CharacterAddSkill; // Offset: 0x148 // Size: 0x10
	struct FScriptMulticastDelegate CharacterRemoveSkill; // Offset: 0x158 // Size: 0x10
	struct FScriptMulticastDelegate PlayerJoinEvent; // Offset: 0x168 // Size: 0x10
	struct FScriptMulticastDelegate PlayerRealExitEvent; // Offset: 0x178 // Size: 0x10
	struct FScriptMulticastDelegate PlayerExitEvent; // Offset: 0x188 // Size: 0x10
	struct FScriptMulticastDelegate ProjectileStopEvent; // Offset: 0x198 // Size: 0x10
	struct FScriptMulticastDelegate ProjectileBounceEvent; // Offset: 0x1a8 // Size: 0x10
	struct FScriptMulticastDelegate DecoraterActorSpawnEvent; // Offset: 0x1b8 // Size: 0x10
	struct FScriptMulticastDelegate RemoteEvent; // Offset: 0x1c8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerDamageQueryEvent; // Offset: 0x1d8 // Size: 0x10
	struct FScriptMulticastDelegate PawnNearDeathEvent; // Offset: 0x1e8 // Size: 0x10
	struct FScriptMulticastDelegate PawnNearDeathOrRescuedEvent; // Offset: 0x1f8 // Size: 0x10
	struct FScriptMulticastDelegate OnAIPawnSpawnEvent; // Offset: 0x208 // Size: 0x10
	struct FScriptMulticastDelegate OnCharacterRespawnEvent; // Offset: 0x218 // Size: 0x10
	struct FScriptMulticastDelegate ChooseEnemyLoseTargetEvent; // Offset: 0x228 // Size: 0x10
	struct FScriptMulticastDelegate FindEnemyWarningEvent; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate ModFindEnemyWarningEvent; // Offset: 0x248 // Size: 0x10
	struct FScriptMulticastDelegate TaskInterActiveActorBeginEvent; // Offset: 0x258 // Size: 0x10
	struct FScriptMulticastDelegate TaskInterActiveActorDoneEvent; // Offset: 0x268 // Size: 0x10
	struct FScriptMulticastDelegate LevelAddedEvent; // Offset: 0x278 // Size: 0x10
	struct FScriptMulticastDelegate DSLuaGMEvent; // Offset: 0x288 // Size: 0x10
	struct FScriptMulticastDelegate OnWeaponFireEvent; // Offset: 0x298 // Size: 0x10
	struct FScriptMulticastDelegate PlayerPickUpItemEvent; // Offset: 0x2a8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerDropItemEvent; // Offset: 0x2b8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerUseItemEvent; // Offset: 0x2c8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerDisUseItemEvent; // Offset: 0x2d8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerSwapItemEvent; // Offset: 0x2e8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerEquipItemEvent; // Offset: 0x2f8 // Size: 0x10
	struct FScriptMulticastDelegate PlayerUnEquipItemEvent; // Offset: 0x308 // Size: 0x10
	struct FScriptMulticastDelegate PlayerConsumeEvent; // Offset: 0x318 // Size: 0x10
	struct FScriptMulticastDelegate PawnChangeTeamEvent; // Offset: 0x328 // Size: 0x10
	struct FScriptMulticastDelegate PlayerRebirthEvent; // Offset: 0x338 // Size: 0x10
};

// Object Name: Class Gameplay.ItemSceneComponent
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UItemSceneComponent : USceneComponent {
};

// Object Name: Class Gameplay.GroupSpotSceneComponent
// Size: 0x2e0 // Inherited bytes: 0x2d0
struct UGroupSpotSceneComponent : UItemSceneComponent {
	// Fields
	enum class ESpotGroupType GroupType; // Offset: 0x2c9 // Size: 0x01
	bool bNearItem; // Offset: 0x2ca // Size: 0x01
	int WorldCompositionID; // Offset: 0x2cc // Size: 0x04
	float LastGenerateItemTime; // Offset: 0x2d0 // Size: 0x04
	float GenerateItemTimeCD; // Offset: 0x2d4 // Size: 0x04
	bool bPickup; // Offset: 0x2d8 // Size: 0x01
	bool bRepeatGenerateItem; // Offset: 0x2d9 // Size: 0x01
	bool bIsValidGroup; // Offset: 0x2da // Size: 0x01

	// Functions

	// Object Name: Function Gameplay.GroupSpotSceneComponent.SetGroupValid
	// Flags: [Native|Public]
	void SetGroupValid(bool Valid); // Offset: 0x103a68884 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.GroupSpotSceneComponent.IsValidGroup
	// Flags: [Native|Public]
	bool IsValidGroup(); // Offset: 0x103a68848 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.GroupSpotSceneComponent.FindWorldCompositionID
	// Flags: [Final|Native|Public]
	int FindWorldCompositionID(); // Offset: 0x103a68814 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.GroupSpotSceneComponent.DoPickUp
	// Flags: [Final|Native|Public]
	void DoPickUp(); // Offset: 0x103a68800 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.ItemGroupSpotSceneComponent
// Size: 0x310 // Inherited bytes: 0x2e0
struct UItemGroupSpotSceneComponent : UGroupSpotSceneComponent {
	// Fields
	struct UItemGeneratorComponent* ItemGenerator; // Offset: 0x2e0 // Size: 0x08
	struct TArray<struct UItemSpotSceneComponent*> SpotsCacheCur; // Offset: 0x2e8 // Size: 0x10
	struct TArray<struct UItemSpotSceneComponent*> SpotsCacheAll; // Offset: 0x2f8 // Size: 0x10
	char pad_0x308[0x8]; // Offset: 0x308 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.SetGroupProperty
	// Flags: [Final|Native|Public|HasOutParms]
	void SetGroupProperty(struct UItemGeneratorComponent* Generator, struct FSpotGroupProperty& Property); // Offset: 0x103a72230 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.RepeatSpots
	// Flags: [Final|Native|Protected]
	void RepeatSpots(); // Offset: 0x103a7221c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.RepeatSingleSpot
	// Flags: [Final|Native|Protected]
	void RepeatSingleSpot(struct UItemSpotSceneComponent* Spot); // Offset: 0x103a721a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.RandomSpotByType
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSpotByType(enum class ESpotType SpotType, struct TArray<struct UItemSpotSceneComponent*>& AllSpots, struct FSpotTypeProperty& Property); // Offset: 0x103a7203c // Return & Params: Num(3) Size(0x50)

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.RandomSingleSpot
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSingleSpot(struct TArray<struct UItemSpotSceneComponent*>& Spots, struct FSpotTypeProperty& Property); // Offset: 0x103a71f20 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function Gameplay.ItemGroupSpotSceneComponent.RandomRepeatGenerateItemCD
	// Flags: [Final|Native|Public|HasOutParms]
	float RandomRepeatGenerateItemCD(struct FSpotGroupProperty& GroupProperty); // Offset: 0x103a71e58 // Return & Params: Num(2) Size(0x2c)
};

// Object Name: Class Gameplay.SpotSceneComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct USpotSceneComponent : UItemSceneComponent {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x2c9 // Size: 0x01
	int ID; // Offset: 0x2cc // Size: 0x04
	int WorldCompositionID; // Offset: 0x2d0 // Size: 0x04
	float HalfHeight; // Offset: 0x2d4 // Size: 0x04
	int SpotProbability; // Offset: 0x2d8 // Size: 0x04
	float LineOffsetZ; // Offset: 0x2dc // Size: 0x04
	bool bRepeatGenerateItem; // Offset: 0x2e0 // Size: 0x01
	bool bIsSpotValid; // Offset: 0x2e1 // Size: 0x01
	char pad_0x2E7[0x9]; // Offset: 0x2e7 // Size: 0x09

	// Functions

	// Object Name: Function Gameplay.SpotSceneComponent.SetSpotValid
	// Flags: [Native|Public]
	void SetSpotValid(bool Valid); // Offset: 0x103a82ee8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.SpotSceneComponent.LineTraceSingle
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool LineTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, struct FHitResult& OutHit, bool bIgnoreSelf); // Offset: 0x103a82c68 // Return & Params: Num(8) Size(0xc2)

	// Object Name: Function Gameplay.SpotSceneComponent.IsSpotValid
	// Flags: [Native|Public]
	bool IsSpotValid(); // Offset: 0x103a82c2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.SpotSceneComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights); // Offset: 0x103a82b44 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.SpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	bool GenerateSpot(); // Offset: 0x103a82b08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.SpotSceneComponent.GenerateActor
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	struct AActor* GenerateActor(struct UObject* ActorClass, struct FVector& ActorLocation, struct FRotator& ActorRotator, enum class ESpawnActorCollisionHandlingMethod SpawnActorCollisionHandlingMethod); // Offset: 0x103a829a0 // Return & Params: Num(5) Size(0x30)
};

// Object Name: Class Gameplay.ItemSpotSceneComponent
// Size: 0x370 // Inherited bytes: 0x2f0
struct UItemSpotSceneComponent : USpotSceneComponent {
	// Fields
	int AIGroupID; // Offset: 0x2e4 // Size: 0x04
	bool bForceSpawn; // Offset: 0x2e8 // Size: 0x01
	enum class ESpotGroupType SpotGroupType; // Offset: 0x2ea // Size: 0x01
	float RepeatGenerateItemCD; // Offset: 0x2ec // Size: 0x04
	struct UItemGeneratorComponent* ItemGenerator; // Offset: 0x2f0 // Size: 0x08
	struct TArray<struct FItemGenerateSpawnClass> AllItems; // Offset: 0x2f8 // Size: 0x10
	struct UGroupSpotSceneComponent* GroupSpotSceneComponent; // Offset: 0x308 // Size: 0x08
	struct TMap<struct FString, int> CacheItemValeCategory; // Offset: 0x310 // Size: 0x50
	struct TArray<struct TWeakObjectPtr<struct AActor>> CacheItems; // Offset: 0x360 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.ItemSpotSceneComponent.SetSpotProperty
	// Flags: [Final|Native|Public|HasOutParms]
	void SetSpotProperty(int CompositionID, enum class ESpotGroupType GroupType, struct UItemGeneratorComponent* Generator, struct FSpotTypeProperty& Property, struct UGroupSpotSceneComponent* Component, bool RepeatGenerateItem); // Offset: 0x103a729c0 // Return & Params: Num(6) Size(0x51)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.RepeatSpotProperty
	// Flags: [Final|Native|Public|HasOutParms]
	void RepeatSpotProperty(struct FSpotTypeProperty& Property); // Offset: 0x103a72914 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	bool GenerateSpot(); // Offset: 0x103a728d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.GenerateItems
	// Flags: [Final|Native|Protected|HasOutParms]
	void GenerateItems(struct TArray<struct FItemGenerateSpawnClass>& AllItemClass); // Offset: 0x103a72830 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.DoPickUp
	// Flags: [Final|Native|Public]
	void DoPickUp(struct FString ItemValue, struct FString ItemCategory); // Offset: 0x103a726fc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.CountCacheItemValeCategory
	// Flags: [Final|Native|Public]
	int CountCacheItemValeCategory(); // Offset: 0x103a726c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.ItemSpotSceneComponent.ClearCacheItems
	// Flags: [Final|Native|Public]
	void ClearCacheItems(); // Offset: 0x103a726b4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.UAEProjectile
// Size: 0x4c8 // Inherited bytes: 0x488
struct AUAEProjectile : ALuaActor {
	// Fields
	char bNetUseDistanceRelevancy : 1; // Offset: 0x481 // Size: 0x01
	int GrenadeItemID; // Offset: 0x484 // Size: 0x04
	bool IsServerAlreadyExplodedCpp; // Offset: 0x488 // Size: 0x01
	struct FVector ProjInitialRelativeOffset; // Offset: 0x48c // Size: 0x0c
	struct FVector ProjStandOffset; // Offset: 0x498 // Size: 0x0c
	struct FVector ProjCrouchOffset; // Offset: 0x4a4 // Size: 0x0c
	struct FVector ProjProneOffset; // Offset: 0x4b0 // Size: 0x0c
	enum class ECharacterPoseType ProjPrevoisOwnerPose; // Offset: 0x4bc // Size: 0x01
	char pad_0x4BE_1 : 7; // Offset: 0x4be // Size: 0x01
	char pad_0x4BF[0x1]; // Offset: 0x4bf // Size: 0x01
	float SpawnSeconds; // Offset: 0x4c0 // Size: 0x04
	bool bShowGrenadeWarningFlag; // Offset: 0x4c4 // Size: 0x01
	bool bIsGroundedOnServerCpp; // Offset: 0x4c5 // Size: 0x01
	char pad_0x4C6[0x2]; // Offset: 0x4c6 // Size: 0x02

	// Functions

	// Object Name: Function Gameplay.UAEProjectile.WorkAsBuffApplierEvent
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void WorkAsBuffApplierEvent(struct FString& BuffName, struct APawn* BuffTarget); // Offset: 0x103aaaf38 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEProjectile.TimeoutExplodeMulticast_CPP
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable|NetValidate]
	void TimeoutExplodeMulticast_CPP(); // Offset: 0x103aaaedc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.TimeoutExplodeMulticast_BPEvent
	// Flags: [Native|Event|Public|BlueprintEvent]
	void TimeoutExplodeMulticast_BPEvent(); // Offset: 0x103aaaec0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.SetActorInitialRelativeOffset
	// Flags: [Final|Native|Public|HasDefaults]
	void SetActorInitialRelativeOffset(struct FVector Offset, struct FVector StandOffset, struct FVector CrouchOffset, struct FVector ProneOffset, enum class ECharacterPoseType PrevoisOwnerPose); // Offset: 0x103aaad44 // Return & Params: Num(5) Size(0x31)

	// Object Name: Function Gameplay.UAEProjectile.ServerNotifyGroundEventOnClient
	// Flags: [Event|Public|BlueprintEvent]
	void ServerNotifyGroundEventOnClient(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.OnRep_IsServerAlreadyExplodedCpp
	// Flags: [Final|Native|Public]
	void OnRep_IsServerAlreadyExplodedCpp(); // Offset: 0x103aaad30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.OnRep_IsGroundedOnServerCpp
	// Flags: [Final|Native|Public]
	void OnRep_IsGroundedOnServerCpp(); // Offset: 0x103aaad1c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.OnProjectileStopOnServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnProjectileStopOnServer(); // Offset: 0x103aaad08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.OnProjectileStopOnClient
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnProjectileStopOnClient(); // Offset: 0x103aaacf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.IsServerAlreadyExplodedCppNotify
	// Flags: [Native|Event|Public|BlueprintEvent]
	void IsServerAlreadyExplodedCppNotify(); // Offset: 0x103aaacd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.IsOwnerAutomous
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsOwnerAutomous(); // Offset: 0x103aaaca4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEProjectile.GlassDetect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GlassDetect(struct FVector& Start, struct FVector& End); // Offset: 0x103aaabcc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEProjectile.GetRemainingEffectTime
	// Flags: [Native|Event|Public|BlueprintEvent]
	float GetRemainingEffectTime(); // Offset: 0x103aaab90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEProjectile.CallExplode
	// Flags: [Native|Event|Public|BlueprintEvent]
	void CallExplode(); // Offset: 0x103aaab74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEProjectile.BroadcastClientExplode
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable|NetValidate]
	void BroadcastClientExplode(); // Offset: 0x103aaab18 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.UAEOBState
// Size: 0x448 // Inherited bytes: 0x448
struct AUAEOBState : APlayerState {
};

// Object Name: Class Gameplay.BackpackComponent
// Size: 0x500 // Inherited bytes: 0x1d8
struct UBackpackComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x10]; // Offset: 0x1d8 // Size: 0x10
	struct FScriptMulticastDelegate ItemListUpdatedDelegate; // Offset: 0x1e8 // Size: 0x10
	struct FScriptMulticastDelegate SingleItemUpdatedDelegate; // Offset: 0x1f8 // Size: 0x10
	struct FScriptMulticastDelegate SingleItemDeleteDelegate; // Offset: 0x208 // Size: 0x10
	struct FScriptMulticastDelegate BatchItemUpdateDelegate; // Offset: 0x218 // Size: 0x10
	struct FScriptMulticastDelegate BatchItemDeleteDelegate; // Offset: 0x228 // Size: 0x10
	struct FScriptMulticastDelegate CapacityUpdatedDelegate; // Offset: 0x238 // Size: 0x10
	struct FScriptMulticastDelegate ItemOperationDelegate; // Offset: 0x248 // Size: 0x10
	struct FScriptMulticastDelegate ItemOperationInfoDelegate; // Offset: 0x258 // Size: 0x10
	struct FScriptMulticastDelegate AssociationOperationDelegate; // Offset: 0x268 // Size: 0x10
	struct FScriptMulticastDelegate ItemOperCountDelegate; // Offset: 0x278 // Size: 0x10
	struct FScriptMulticastDelegate ItemOperationFailedDelegate; // Offset: 0x288 // Size: 0x10
	struct FScriptMulticastDelegate BackPackTipsToPlayerDelegate; // Offset: 0x298 // Size: 0x10
	struct FScriptMulticastDelegate ItemHandleAddDelegate; // Offset: 0x2a8 // Size: 0x10
	struct TMap<int, int> PickupLimitSetting; // Offset: 0x2b8 // Size: 0x50
	struct FScriptMulticastDelegate ItemUpdatedDelegate; // Offset: 0x308 // Size: 0x10
	struct FScriptMulticastDelegate ItemRemovedDelegate; // Offset: 0x318 // Size: 0x10
	struct TArray<struct FCustomAccessoriesData> CustomAccessoriesData; // Offset: 0x328 // Size: 0x10
	struct TArray<struct FBattleItemPickupAfterLand> BattleItemPickupAfterLandList; // Offset: 0x338 // Size: 0x10
	struct TArray<struct FSpecialPickInfo> specialCountLimit; // Offset: 0x348 // Size: 0x10
	char pad_0x358[0x10]; // Offset: 0x358 // Size: 0x10
	struct FIncNetArray ItemListNet; // Offset: 0x368 // Size: 0x20
	struct FIncNetArray ItemListNetCache; // Offset: 0x388 // Size: 0x20
	struct TMap<int, struct FBattleItemData> CacheBattleItemMap; // Offset: 0x3a8 // Size: 0x50
	struct TArray<struct FItemDefineID> BroadcastInsertItemList; // Offset: 0x3f8 // Size: 0x10
	struct TArray<struct FItemDefineID> BroadcastUpdateItemList; // Offset: 0x408 // Size: 0x10
	struct TArray<struct FItemDefineID> BroadcastDeleteItemList; // Offset: 0x418 // Size: 0x10
	bool AutoEquipAim; // Offset: 0x428 // Size: 0x01
	char pad_0x429[0x7]; // Offset: 0x429 // Size: 0x07
	struct TArray<struct UItemHandleBase*> ItemHandleList; // Offset: 0x430 // Size: 0x10
	struct TMap<struct FItemDefineID, struct UItemHandleBase*> ItemHandleMap; // Offset: 0x440 // Size: 0x50
	int CapacityThreshold; // Offset: 0x490 // Size: 0x04
	float Capacity; // Offset: 0x494 // Size: 0x04
	float OccupiedCapacity; // Offset: 0x498 // Size: 0x04
	float SafetyBoxCapacity; // Offset: 0x49c // Size: 0x04
	float SafetyBoxOccupiedCapacity; // Offset: 0x4a0 // Size: 0x04
	char pad_0x4A4[0x18]; // Offset: 0x4a4 // Size: 0x18
	int virtualitemid; // Offset: 0x4bc // Size: 0x04
	char pad_0x4C0[0x8]; // Offset: 0x4c0 // Size: 0x08
	bool IsForbidAutoEquipAttachments; // Offset: 0x4c8 // Size: 0x01
	char pad_0x4C9[0x7]; // Offset: 0x4c9 // Size: 0x07
	struct TArray<int> NeedToShowTypeList; // Offset: 0x4d0 // Size: 0x10
	bool bVerifyWeaponPackageData; // Offset: 0x4e0 // Size: 0x01
	bool bShowBounty; // Offset: 0x4e1 // Size: 0x01
	char pad_0x4E2[0x6]; // Offset: 0x4e2 // Size: 0x06
	struct FScriptMulticastDelegate BackpackShowBountyDelegate; // Offset: 0x4e8 // Size: 0x10
	char pad_0x4F8[0x8]; // Offset: 0x4f8 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.BackpackComponent.UseItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool UseItem(struct FItemDefineID DefineID, struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x103a3eb74 // Return & Params: Num(4) Size(0x42)

	// Object Name: Function Gameplay.BackpackComponent.UpdateCapacity
	// Flags: [Native|Event|Protected|BlueprintEvent]
	float UpdateCapacity(); // Offset: 0x103a3eb38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.BackpackComponent.UnlockUpdateItemListReceive
	// Flags: [Final|Native|Public]
	void UnlockUpdateItemListReceive(); // Offset: 0x103a3eb24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.TryMergeItemHandles
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void TryMergeItemHandles(struct FItemDefineID& DefineID, enum class EItemStoreArea InItemStoreArea); // Offset: 0x103a3ea50 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.TakeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	int TakeItem(struct FItemDefineID DefineID, int Count, bool bCallHandleDrop); // Offset: 0x103a3e930 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Gameplay.BackpackComponent.SwapItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool SwapItem(struct FItemDefineID DefineID1, struct FItemDefineID DefineID2); // Offset: 0x103a3e840 // Return & Params: Num(3) Size(0x31)

	// Object Name: Function Gameplay.BackpackComponent.ServerSetShowBounty
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerSetShowBounty(bool bInShowBounty); // Offset: 0x103a3e780 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.BackpackComponent.ServerSetCustomAccessories
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerSetCustomAccessories(int WeaponItemID, int Index, int ItemID); // Offset: 0x103a3e65c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Gameplay.BackpackComponent.ServerEnableItem
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ServerEnableItem(struct FItemDefineID DefineID, bool bUse); // Offset: 0x103a3e538 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.ReturnItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ReturnItem(struct FItemDefineID DefineID, int Count, bool bCallHandlePickup); // Offset: 0x103a3e418 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Gameplay.BackpackComponent.RemoveItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool RemoveItemHandle(struct FItemDefineID& DefineID); // Offset: 0x103a3e370 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.ReceiveItemList
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveItemList(); // Offset: 0x103a3e354 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.ReceiveCapacity
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveCapacity(); // Offset: 0x103a3e338 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.PreCheckCanPickupBagAvatar
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool PreCheckCanPickupBagAvatar(struct UBattleItemHandleBase* NewBackPackBagAvatar, enum class EBattleItemUseReason reson); // Offset: 0x103a3e268 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Gameplay.BackpackComponent.PostItemHandleEquippingState
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void PostItemHandleEquippingState(struct FItemDefineID& DefineID, bool bEquipping); // Offset: 0x103a3e18c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.PickupItemFromWrapperDetail
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool PickupItemFromWrapperDetail(struct FItemDefineID DefineID, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason, enum class EBattleItemClientPickupType BattleItemClientPickupType); // Offset: 0x103a3dfdc // Return & Params: Num(5) Size(0x73)

	// Object Name: Function Gameplay.BackpackComponent.PickUpItem_Default
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool PickUpItem_Default(struct FItemDefineID DefineID, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason); // Offset: 0x103a3de6c // Return & Params: Num(4) Size(0x72)

	// Object Name: Function Gameplay.BackpackComponent.PickupItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool PickupItem(struct FItemDefineID DefineID, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason, enum class EBattleItemClientPickupType BattleItemClientPickupType); // Offset: 0x103a3dcbc // Return & Params: Num(5) Size(0x73)

	// Object Name: Function Gameplay.BackpackComponent.PickupBattleItemOnPlane
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PickupBattleItemOnPlane(); // Offset: 0x103a3dca8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.PickItem_IntoSafetyBox
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool PickItem_IntoSafetyBox(struct FItemDefineID DefineID, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason); // Offset: 0x103a3db38 // Return & Params: Num(4) Size(0x72)

	// Object Name: Function Gameplay.BackpackComponent.PickItem_IntoBackpack
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool PickItem_IntoBackpack(struct FItemDefineID DefineID, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason); // Offset: 0x103a3d9c8 // Return & Params: Num(4) Size(0x72)

	// Object Name: Function Gameplay.BackpackComponent.OnRep_specialCountLimit
	// Flags: [Final|Native|Public]
	void OnRep_specialCountLimit(); // Offset: 0x103a3d9b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.OnRep_ItemListNet
	// Flags: [Final|Native|Protected]
	void OnRep_ItemListNet(); // Offset: 0x103a3d9a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.OnRep_Capacity
	// Flags: [Final|Native|Protected]
	void OnRep_Capacity(); // Offset: 0x103a3d98c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.NotifyItemUpdated
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void NotifyItemUpdated(struct FItemDefineID& DefineID); // Offset: 0x103a3d8f4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.BackpackComponent.NotifyItemRemoved
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void NotifyItemRemoved(struct FItemDefineID& DefineID); // Offset: 0x103a3d85c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.BackpackComponent.NotifyItemListUpdated
	// Flags: [Native|Public|BlueprintCallable]
	void NotifyItemListUpdated(); // Offset: 0x103a3d840 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.NotifyCapacityUpdated
	// Flags: [Native|Public|BlueprintCallable]
	void NotifyCapacityUpdated(); // Offset: 0x103a3d824 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.NewItemHandle
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent|Const]
	struct UBattleItemHandleBase* NewItemHandle(struct FItemDefineID& DefineID); // Offset: 0x103a3d77c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.NewItemDefineID
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent]
	struct FItemDefineID NewItemDefineID(struct FItemDefineID& DefineID); // Offset: 0x103a3d6c4 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Gameplay.BackpackComponent.ModifyItemHandleEquippingState
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ModifyItemHandleEquippingState(struct UItemHandleBase* ItemHandle, bool bEquipping); // Offset: 0x103a3d604 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Gameplay.BackpackComponent.ModifyItemHandleCount
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ModifyItemHandleCount(struct UItemHandleBase* ItemHandle, int Count); // Offset: 0x103a3d54c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.BackpackComponent.ModifyAutoPickClipType
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void ModifyAutoPickClipType(int InAutoPickClipType); // Offset: 0x103a3d4a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.BackpackComponent.ModifyAimNotAutoUse
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable|NetValidate]
	void ModifyAimNotAutoUse(bool bAdd); // Offset: 0x103a3d3e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.BackpackComponent.LockUpdateItemListReceive
	// Flags: [Final|Native|Public]
	void LockUpdateItemListReceive(); // Offset: 0x103a3d3cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.ItemNet2Data
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FBattleItemData ItemNet2Data(struct FNetArrayUnit& NetItem); // Offset: 0x103a3d2e8 // Return & Params: Num(2) Size(0x108)

	// Object Name: Function Gameplay.BackpackComponent.IsNeedToShowInBackpack
	// Flags: [Final|Native|Public]
	bool IsNeedToShowInBackpack(int TypeDefineID); // Offset: 0x103a3d25c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItemTypes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasSomeItemTypes(struct TArray<int>& ItemTypes); // Offset: 0x103a3d1a4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItemSubTypes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasSomeItemSubTypes(struct TArray<int>& ItemSubTypes); // Offset: 0x103a3d0ec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasSomeItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasSomeItems(struct TArray<int>& ItemTypeSpecificIDs); // Offset: 0x103a3d034 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItemType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasOneItemType(int ItemType); // Offset: 0x103a3cfa8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItemSubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasOneItemSubType(int ItemSubType); // Offset: 0x103a3cf1c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.IsItemListUpdatedHasOneItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsItemListUpdatedHasOneItem(int ItemTypeSpecificID); // Offset: 0x103a3ce90 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.IsItemExist
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool IsItemExist(struct FItemDefineID& DefineID); // Offset: 0x103a3cde8 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.IsEnableWeaponAttachmentBindToWeapon
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool IsEnableWeaponAttachmentBindToWeapon(); // Offset: 0x103a3cdac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.BackpackComponent.IsCustomIgnoreAccessories
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCustomIgnoreAccessories(int WeaponID, int Index); // Offset: 0x103a3cce8 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.BackpackComponent.IsCustomAccessories
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCustomAccessories(int WeaponID, int ItemID); // Offset: 0x103a3cc24 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.BackpackComponent.IsBackPackContainItemId
	// Flags: [Final|Native|Public|Const]
	bool IsBackPackContainItemId(int ItemID); // Offset: 0x103a3cb98 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.IsAutoUse
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	bool IsAutoUse(int ItemID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.HasUnEquipItemByDefindIdRange
	// Flags: [Final|Native|Public|Const]
	bool HasUnEquipItemByDefindIdRange(int LowValue, int HighValue); // Offset: 0x103a3cad4 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.BackpackComponent.HasTagSub
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool HasTagSub(int ItemID, struct FName& TagName); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Gameplay.BackpackComponent.HasItemBySubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasItemBySubType(int SubType); // Offset: 0x103a3ca48 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.HasItemByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool HasItemByDefineID(struct FItemDefineID& DefineID); // Offset: 0x103a3c9a8 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.HasItemByDefindIdRange
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasItemByDefindIdRange(int LowValue, int HighValue); // Offset: 0x103a3c8e4 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Gameplay.BackpackComponent.HandleDropInDisuse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void HandleDropInDisuse(struct FItemDefineID& DefineID, struct UBattleItemHandleBase* ItemHandle, enum class EBattleItemDisuseReason Reason, float OccupiedCapacityBeforeDisuse); // Offset: 0x103a3c790 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Gameplay.BackpackComponent.GetWorld_BP
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetWorld_BP(); // Offset: 0x103a3c75c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.BackpackComponent.GetUnEquipItemNumByItemId
	// Flags: [Final|Native|Public|Const]
	int GetUnEquipItemNumByItemId(int ItemID); // Offset: 0x103a3c6d0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.BackpackComponent.GetSpecialItemNow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FSpecialPickInfo GetSpecialItemNow(struct FItemDefineID DefineID); // Offset: 0x103a3c630 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function Gameplay.BackpackComponent.GetSpecialItemBefore
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FSpecialPickInfo GetSpecialItemBefore(int ItemResId); // Offset: 0x103a3c5a0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.BackpackComponent.GetSafetyBoxCapacity
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	float GetSafetyBoxCapacity(); // Offset: 0x103a3c564 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.BackpackComponent.GetLeastElectrictyBattleItemData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FBattleItemData GetLeastElectrictyBattleItemData(struct FItemDefineID DefineID, enum class EBattleItemAdditionalDataType AdditionalDataNameType); // Offset: 0x103a3c464 // Return & Params: Num(3) Size(0xd8)

	// Object Name: Function Gameplay.BackpackComponent.GetItemSubType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	int GetItemSubType(int ItemID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.BackpackComponent.GetItemListByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FBattleItemData> GetItemListByDefineID(struct FItemDefineID& DefineID); // Offset: 0x103a3c39c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Gameplay.BackpackComponent.GetItemHandleMap
	// Flags: [Native|Protected|BlueprintCallable]
	struct TMap<struct FItemDefineID, struct UItemHandleBase*> GetItemHandleMap(); // Offset: 0x103a3c35c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Gameplay.BackpackComponent.GetItemHandleList
	// Flags: [Native|Protected|BlueprintCallable]
	struct TArray<struct UItemHandleBase*> GetItemHandleList(); // Offset: 0x103a3c31c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.BackpackComponent.GetItemCountByType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemCountByType(int InItemType); // Offset: 0x103a3c290 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.BackpackComponent.GetItemCountByItemSpecialID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemCountByItemSpecialID(int InItemSpecialID); // Offset: 0x103a3c204 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Gameplay.BackpackComponent.GetItemByDefineID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FBattleItemData GetItemByDefineID(struct FItemDefineID& DefineID); // Offset: 0x103a3c13c // Return & Params: Num(2) Size(0xd0)

	// Object Name: Function Gameplay.BackpackComponent.GetItemAssociateWeights
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	float GetItemAssociateWeights(struct FBattleItemData& InItemData); // Offset: 0x103a3c080 // Return & Params: Num(2) Size(0xbc)

	// Object Name: Function Gameplay.BackpackComponent.GetFirstItemBySubType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FBattleItemData GetFirstItemBySubType(int SubType); // Offset: 0x103a3bfcc // Return & Params: Num(2) Size(0xc0)

	// Object Name: Function Gameplay.BackpackComponent.GetFirstItemByDefineIDIgnoreInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FBattleItemData GetFirstItemByDefineIDIgnoreInstance(struct FItemDefineID& DefineID); // Offset: 0x103a3bf04 // Return & Params: Num(2) Size(0xd0)

	// Object Name: Function Gameplay.BackpackComponent.GetBattleItemFeatureDataByDefineID
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	struct FBattleItemFeatureData GetBattleItemFeatureDataByDefineID(struct FItemDefineID& DefineID); // Offset: 0x103a3be48 // Return & Params: Num(2) Size(0x44)

	// Object Name: Function Gameplay.BackpackComponent.GetAllItemList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FBattleItemData> GetAllItemList(enum class EItemStoreArea InItemStoreArea); // Offset: 0x103a3bd94 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.BackpackComponent.GetAIPickupType
	// Flags: [Native|Event|Public|BlueprintEvent]
	enum class EBattleItemClientPickupType GetAIPickupType(int ItemID); // Offset: 0x103a3bd00 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Gameplay.BackpackComponent.ForceNetUpdate
	// Flags: [Native|Public|BlueprintCallable]
	void ForceNetUpdate(); // Offset: 0x103a3bce4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.BackpackComponent.DropItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool DropItem(struct FItemDefineID DefineID, int Count, enum class EBattleItemDropReason Reason); // Offset: 0x103a3bbc8 // Return & Params: Num(4) Size(0x1e)

	// Object Name: Function Gameplay.BackpackComponent.DisuseItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool DisuseItem(struct FItemDefineID DefineID, enum class EBattleItemDisuseReason Reason); // Offset: 0x103a3bae8 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.CreateItemHandleInternal
	// Flags: [Native|Event|Protected|HasOutParms|BlueprintEvent|Const]
	struct UBattleItemHandleBase* CreateItemHandleInternal(struct FItemDefineID& DefineID); // Offset: 0x103a3ba40 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.CreateItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UItemHandleBase* CreateItemHandle(struct FItemDefineID& DefineID); // Offset: 0x103a3b998 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.ConsumeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ConsumeItem(struct FItemDefineID DefineID, int Count); // Offset: 0x103a3b8c0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.ClientBroadcastItemOperationFailedDelegate
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientBroadcastItemOperationFailedDelegate(struct FItemDefineID DefineID, enum class EBattleItemOperationType OperationType, enum class EBattleItemOperationFailedReason FailedReason); // Offset: 0x103a3b7c0 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.ClientBroadcastItemOperationDelegate
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientBroadcastItemOperationDelegate(struct FItemDefineID DefineID, enum class EBattleItemOperationType OperationType, char Reason); // Offset: 0x103a3b6c0 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.CheckSpecialMaxCountForItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	int CheckSpecialMaxCountForItem(struct FItemDefineID DefineID, int Count); // Offset: 0x103a3b5e8 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.CheckSkillPropItemCanBePickup
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	bool CheckSkillPropItemCanBePickup(struct UBackpackComponent* BackpackComp, struct FItemDefineID DefineID); // Offset: 0x103a3b504 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Gameplay.BackpackComponent.CheckPickUpItemDefaultSuccess
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool CheckPickUpItemDefaultSuccess(struct FItemDefineID& DefineID, bool bPickupSucc, bool bAutoEquip); // Offset: 0x103a3b3cc // Return & Params: Num(4) Size(0x1b)

	// Object Name: Function Gameplay.BackpackComponent.CheckLeftLimitCountForItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	int CheckLeftLimitCountForItem(int InItemID, int InCount); // Offset: 0x103a3b300 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Gameplay.BackpackComponent.CheckItemEmptyInBackpack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckItemEmptyInBackpack(int InItemID); // Offset: 0x103a3b284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.BackpackComponent.CheckCapacityForItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int CheckCapacityForItem(struct FItemDefineID DefineID, int Count, enum class EItemStoreArea InItemStoreArea); // Offset: 0x103a3b170 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Gameplay.BackpackComponent.ChangeItemStoreArea
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool ChangeItemStoreArea(struct FItemDefineID DefineID, int InItemNum, enum class EItemStoreArea InItemStoreArea); // Offset: 0x103a3b054 // Return & Params: Num(4) Size(0x1e)

	// Object Name: Function Gameplay.BackpackComponent.CanDisuseToBackpack
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool CanDisuseToBackpack(struct FItemDefineID DefineID); // Offset: 0x103a3afb0 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function Gameplay.BackpackComponent.CacheItemAssociationBeforeDisuse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool CacheItemAssociationBeforeDisuse(struct FItemDefineID DefineID, enum class EBattleItemDisuseReason Reason); // Offset: 0x103a3aed0 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.BroadcastItemOperCountDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BroadcastItemOperCountDelegate(struct FItemDefineID& DefineID, enum class EBattleItemOperationType OperationType, int Count); // Offset: 0x103a3adc0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.BroadcastItemOperationInfoDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BroadcastItemOperationInfoDelegate(struct FItemOperationInfo& ItemOperationInfo); // Offset: 0x103a3ad30 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function Gameplay.BackpackComponent.BroadcastItemOperationFailedDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BroadcastItemOperationFailedDelegate(struct FItemDefineID& DefineID, enum class EBattleItemOperationType OperationType, enum class EBattleItemOperationFailedReason FailedReason); // Offset: 0x103a3ac20 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.BroadcastItemOperationDelegate
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BroadcastItemOperationDelegate(struct FItemDefineID& DefineID, enum class EBattleItemOperationType OperationType, char Reason); // Offset: 0x103a3ab10 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function Gameplay.BackpackComponent.AddItemHandle
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool AddItemHandle(struct FItemDefineID& DefineID, struct UItemHandleBase* ItemHandle); // Offset: 0x103a3aa2c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Gameplay.BackpackComponent.AddBattleItemPickupOnPlane
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddBattleItemPickupOnPlane(struct FItemDefineID& DefineID, struct FBattleItemPickupInfo& PickupInfo, enum class EBattleItemPickupReason Reason, enum class EBattleItemClientPickupType BattleItemClientPickupType); // Offset: 0x103a3a898 // Return & Params: Num(4) Size(0x72)
};

// Object Name: Class Gameplay.ConfigInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UConfigInterface : UInterface {
};

// Object Name: Class Gameplay.FoliageFakeCollision
// Size: 0x3c8 // Inherited bytes: 0x3c0
struct AFoliageFakeCollision : AActor {
	// Fields
	struct UCapsuleComponent* CollisionComponent; // Offset: 0x3c0 // Size: 0x08
};

// Object Name: Class Gameplay.GameModeConfigComponent
// Size: 0x128 // Inherited bytes: 0x110
struct UGameModeConfigComponent : UActorComponent {
	// Fields
	int appleGrenadeID; // Offset: 0x110 // Size: 0x04
	int appleGrenadeCount; // Offset: 0x114 // Size: 0x04
	struct TArray<int> forbitPickItemTypeList; // Offset: 0x118 // Size: 0x10
};

// Object Name: Class Gameplay.PatchTableUtils
// Size: 0x28 // Inherited bytes: 0x28
struct UPatchTableUtils : UBlueprintFunctionLibrary {
};

// Object Name: Class Gameplay.GameModeStatisticsComponent
// Size: 0x110 // Inherited bytes: 0x110
struct UGameModeStatisticsComponent : UActorComponent {
};

// Object Name: Class Gameplay.GeneratorActorAIInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGeneratorActorAIInterface : UInterface {
	// Functions

	// Object Name: Function Gameplay.GeneratorActorAIInterface.RegisterAIPickupPoint
	// Flags: [Native|Public|HasDefaults]
	void RegisterAIPickupPoint(struct FVector BuildingLoc, struct FVector SpotLoc, struct AActor* PickUpActor); // Offset: 0x103a6777c // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class Gameplay.GeneratorActorInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGeneratorActorInterface : UInterface {
	// Functions

	// Object Name: Function Gameplay.GeneratorActorInterface.SetExtendData
	// Flags: [Native|Public]
	void SetExtendData(struct FString Key, int Value); // Offset: 0x103a67eac // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.GeneratorActorInterface.SetAttachedActor
	// Flags: [Native|Public]
	void SetAttachedActor(struct AActor* AttachedActor); // Offset: 0x103a67e28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.GeneratorActorInterface.InitDataNew
	// Flags: [Native|Public]
	void InitDataNew(int ItemCount, struct FString Value, struct FString Category, bool RepeatGenerateItem, int SpotDataIndex); // Offset: 0x103a67c1c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Gameplay.GeneratorActorInterface.InitData
	// Flags: [Native|Public]
	void InitData(struct UItemSpotSceneComponent* ItemSpotSceneComponent, int ItemCount, struct FString Value, struct FString Category, bool RepeatGenerateItem); // Offset: 0x103a67a10 // Return & Params: Num(5) Size(0x31)

	// Object Name: Function Gameplay.GeneratorActorInterface.GetItemId
	// Flags: [Native|Public]
	int GetItemId(); // Offset: 0x103a679d4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Gameplay.GeneratorVehicleInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGeneratorVehicleInterface : UInterface {
	// Functions

	// Object Name: Function Gameplay.GeneratorVehicleInterface.SetSafeSpawn
	// Flags: [Native|Public]
	void SetSafeSpawn(bool ab_IsSafeSpawn); // Offset: 0x103a683f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.GeneratorVehicleInterface.InitVehicle
	// Flags: [Native|Public]
	void InitVehicle(int FuelPercent, bool bEngineOn, bool bInHouse); // Offset: 0x103a682e4 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Gameplay.GeneratorVehicleInterface.CheckSpawnLocation
	// Flags: [Native|Public|HasDefaults]
	void CheckSpawnLocation(struct FVector SpawnLocation, float MaxSpawnDistance); // Offset: 0x103a68224 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Gameplay.GlobalConfigActor
// Size: 0x3d0 // Inherited bytes: 0x3c0
struct AGlobalConfigActor : AActor {
	// Fields
	char pad_0x3C0[0x8]; // Offset: 0x3c0 // Size: 0x08
	bool bInitComponents; // Offset: 0x3c8 // Size: 0x01
	char pad_0x3C9[0x7]; // Offset: 0x3c9 // Size: 0x07

	// Functions

	// Object Name: Function Gameplay.GlobalConfigActor.Init
	// Flags: [Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x103a68684 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.ImplItemRegionInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UImplItemRegionInterface : UInterface {
	// Functions

	// Object Name: Function Gameplay.ImplItemRegionInterface.GetRegion
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FItemRegionCircle GetRegion(struct FString Tag); // Offset: 0x103a68f34 // Return & Params: Num(2) Size(0x48)
};

// Object Name: Class Gameplay.ItemBandSpotSceneComponent
// Size: 0x330 // Inherited bytes: 0x2f0
struct UItemBandSpotSceneComponent : USpotSceneComponent {
	// Fields
	struct FString SpotItemValue; // Offset: 0x2e8 // Size: 0x10
	struct FString SpotItemCategory; // Offset: 0x2f8 // Size: 0x10
	struct FString ConditionItemValue; // Offset: 0x308 // Size: 0x10
	struct FString ConditionItemCategory; // Offset: 0x318 // Size: 0x10
};

// Object Name: Class Gameplay.ItemConfigActorComponent
// Size: 0x170 // Inherited bytes: 0x110
struct UItemConfigActorComponent : UActorComponent {
	// Fields
	struct TArray<struct FItemSpawnData> ItemSpawnDatas; // Offset: 0x110 // Size: 0x10
	struct TMap<int, struct FGroupTypeSceneComponents> AllSpotGroups; // Offset: 0x120 // Size: 0x50

	// Functions

	// Object Name: Function Gameplay.ItemConfigActorComponent.RegisterGroupSceneComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterGroupSceneComponent(int GroupType, struct USceneComponent* GroupSceneComponent); // Offset: 0x103a69bf0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.ItemConfigActorComponent.RandomItemSpawnClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FItemSpawnClass> RandomItemSpawnClass(struct FString ItemValue, struct FString ItemCategory); // Offset: 0x103a69a84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Gameplay.ItemConfigActorComponent.RandomGroupSceneComponents
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct USceneComponent*> RandomGroupSceneComponents(int GroupType, int Persent); // Offset: 0x103a69998 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Gameplay.ItemConfigActorComponent.RandomGroupSceneComponent
	// Flags: [Final|Native|Public]
	struct USceneComponent* RandomGroupSceneComponent(struct TArray<struct USceneComponent*> AllGroups); // Offset: 0x103a698a4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.ItemConfigActorComponent.LoadActorClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* LoadActorClass(struct FString Path); // Offset: 0x103a697d8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.ItemConfigActorComponent.GetItemSpawnClass
	// Flags: [Final|Native|Public]
	struct TArray<struct FItemSpawnClass> GetItemSpawnClass(struct FItemSpawnData Data); // Offset: 0x103a696d4 // Return & Params: Num(2) Size(0x80)
};

// Object Name: Class Gameplay.ItemCountArea
// Size: 0x3c8 // Inherited bytes: 0x3c0
struct AItemCountArea : AActor {
	// Fields
	struct UBoxComponent* Area; // Offset: 0x3c0 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.ItemCountArea.IsInArea
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	bool IsInArea(struct FVector& Position); // Offset: 0x103a69f3c // Return & Params: Num(2) Size(0xd)
};

// Object Name: Class Gameplay.ItemGenerateInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UItemGenerateInterface : UInterface {
};

// Object Name: Class Gameplay.ItemGroupRepeatSpotComponent
// Size: 0x3a0 // Inherited bytes: 0x2e0
struct UItemGroupRepeatSpotComponent : UGroupSpotSceneComponent {
	// Fields
	int GenerateNumPerFrame; // Offset: 0x2dc // Size: 0x04
	float RepeatGenerateItemTimer; // Offset: 0x2e0 // Size: 0x04
	int GroupID; // Offset: 0x2e4 // Size: 0x04
	struct FString GroupTag; // Offset: 0x2e8 // Size: 0x10
	struct TArray<struct UItemSpotSceneComponent*> Spots; // Offset: 0x2f8 // Size: 0x10
	struct TArray<struct UItemSpotSceneComponent*> PendingGenerateSpots; // Offset: 0x308 // Size: 0x10
	struct UItemGeneratorComponent* ItemGenerator; // Offset: 0x318 // Size: 0x08
	struct FSpotGroupProperty SpotGroupProperty; // Offset: 0x320 // Size: 0x28
	struct TMap<enum class ESpotType, struct FSpotTypeProperty> SpotTypePropertys; // Offset: 0x348 // Size: 0x50
	bool bInitialize; // Offset: 0x398 // Size: 0x01
	bool bEnable; // Offset: 0x399 // Size: 0x01
	char pad_0x39E[0x2]; // Offset: 0x39e // Size: 0x02

	// Functions

	// Object Name: Function Gameplay.ItemGroupRepeatSpotComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x103a71b14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGroupRepeatSpotComponent.SetPropertySpotAll
	// Flags: [Final|Native|Public]
	void SetPropertySpotAll(); // Offset: 0x103a71b00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGroupRepeatSpotComponent.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AUAEGameMode* GetGameMode(); // Offset: 0x103a71acc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.ItemGroupRepeatSpotComponent.GenerateSpotAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GenerateSpotAll(); // Offset: 0x103a71ab8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.ItemGroupRepeatSpotComponent.ClearAllSpotItems
	// Flags: [Final|Native|Public]
	void ClearAllSpotItems(); // Offset: 0x103a71aa4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.LuaBTTaskBase
// Size: 0x110 // Inherited bytes: 0x70
struct ULuaBTTaskBase : UBTTaskNode {
	// Fields
	char pad_0x70[0x60]; // Offset: 0x70 // Size: 0x60
	struct AAIController* AIOwner; // Offset: 0xd0 // Size: 0x08
	struct AActor* ActorOwner; // Offset: 0xd8 // Size: 0x08
	char pad_0xE0[0x18]; // Offset: 0xe0 // Size: 0x18
	char bShowPropertyDetails : 1; // Offset: 0xf8 // Size: 0x01
	char pad_0xF8_1 : 7; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x7]; // Offset: 0xf9 // Size: 0x07
	struct FString LuaFilePath; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.LuaBTTaskBase.SetFinishOnMessageWithId
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetFinishOnMessageWithId(struct FName MessageName, int RequestID); // Offset: 0x103a73200 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.LuaBTTaskBase.SetFinishOnMessage
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetFinishOnMessage(struct FName MessageName); // Offset: 0x103a73184 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecute(struct AActor* OwnerActor); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveAbortAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.LuaBTTaskBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveAbort(struct AActor* OwnerActor); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.LuaBTTaskBase.IsTaskExecuting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskExecuting(); // Offset: 0x103a73150 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.LuaBTTaskBase.IsTaskAborting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsTaskAborting(); // Offset: 0x103a7311c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.LuaBTTaskBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishExecute(bool bSuccess); // Offset: 0x103a73098 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.LuaBTTaskBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void FinishAbort(); // Offset: 0x103a73084 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.MissionBoardComponent
// Size: 0x170 // Inherited bytes: 0x110
struct UMissionBoardComponent : UActorComponent {
	// Fields
	struct FMissionBoardConfig Config; // Offset: 0x110 // Size: 0x50
	struct FScriptMulticastDelegate OnRepConfigDelegate; // Offset: 0x160 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.MissionBoardComponent.OnRep_Config
	// Flags: [Final|Native|Public]
	void OnRep_Config(); // Offset: 0x103a73778 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.MissionBoardComponent.GetUtcLeftSecondsByConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetUtcLeftSecondsByConfig(); // Offset: 0x103a73744 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Gameplay.NewWeatherComponent
// Size: 0x1e0 // Inherited bytes: 0x1d8
struct UNewWeatherComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x8]; // Offset: 0x1d8 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.NewWeatherComponent.LuaInit
	// Flags: [Event|Public|BlueprintEvent]
	void LuaInit(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.SpotGeneratorStruct
// Size: 0x28 // Inherited bytes: 0x28
struct USpotGeneratorStruct : UObject {
};

// Object Name: Class Gameplay.TriggerActionSpawnItemInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UTriggerActionSpawnItemInterface : UInterface {
};

// Object Name: Class Gameplay.UAEActorMap
// Size: 0x410 // Inherited bytes: 0x3c0
struct AUAEActorMap : AInfo {
	// Fields
	struct TMap<struct FVector, struct AActor*> ActorsMap; // Offset: 0x3c0 // Size: 0x50
};

// Object Name: Class Gameplay.UAEAdvertisementActor
// Size: 0x4c0 // Inherited bytes: 0x3d0
struct AUAEAdvertisementActor : AStaticMeshActor {
	// Fields
	char pad_0x3D0[0x60]; // Offset: 0x3d0 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x430 // Size: 0x10
	bool bMultiAdvertisement; // Offset: 0x440 // Size: 0x01
	char pad_0x441[0x7]; // Offset: 0x441 // Size: 0x07
	struct TMap<char, struct UTexture2D*> IdTextureMap; // Offset: 0x448 // Size: 0x50
	struct UStaticMesh* StaticMesh; // Offset: 0x498 // Size: 0x08
	struct FString StaticMeshPath; // Offset: 0x4a0 // Size: 0x10
	struct UFrontendHUD* FrontendHUD; // Offset: 0x4b0 // Size: 0x08
	int ID; // Offset: 0x4b8 // Size: 0x04
	float NetCullDistance; // Offset: 0x4bc // Size: 0x04

	// Functions

	// Object Name: Function Gameplay.UAEAdvertisementActor.SetStaticMeshPath
	// Flags: [Native|Public]
	void SetStaticMeshPath(struct FString InMeshPath); // Offset: 0x103a838fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEAdvertisementActor.SetStaticMesh
	// Flags: [Native|Public]
	void SetStaticMesh(struct UStaticMesh* InStaticMesh); // Offset: 0x103a83878 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEAdvertisementActor.SetScale
	// Flags: [Native|Public|HasDefaults]
	void SetScale(struct FVector InScale); // Offset: 0x103a837f4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Gameplay.UAEAdvertisementActor.SetId
	// Flags: [Final|Native|Public]
	void SetId(int InputID); // Offset: 0x103a83778 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEAdvertisementActor.SetCulDistance
	// Flags: [Native|Public]
	void SetCulDistance(float CulDistance); // Offset: 0x103a836f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAEAdvertisementActor.RequestHttpImageByUrl
	// Flags: [Final|Native|Public]
	void RequestHttpImageByUrl(struct FString PicUrl); // Offset: 0x103a8365c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEAdvertisementActor.ReplaceTexture
	// Flags: [Final|Native|Protected]
	void ReplaceTexture(struct UTexture2D* Texture); // Offset: 0x103a835e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAEAdvertisementActor.OnRequestImgSuccess
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnRequestImgSuccess(struct UTexture2D* Texture, struct FString RequestedURL); // Offset: 0x103a83504 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAEAdvertisementActor.OnRep_MeshPath
	// Flags: [Event|Public|BlueprintEvent]
	void OnRep_MeshPath(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEAdvertisementActor.OnRep_Id
	// Flags: [Event|Public|BlueprintEvent]
	void OnRep_Id(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEAdvertisementActor.OnClientLoadMesh
	// Flags: [Event|Public|BlueprintEvent]
	void OnClientLoadMesh(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEAdvertisementActor.InitImageDownloadUtil
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitImageDownloadUtil(); // Offset: 0x103a834f0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Gameplay.UAEBuffApplierActor
// Size: 0x3c8 // Inherited bytes: 0x3c0
struct AUAEBuffApplierActor : AActor {
	// Fields
	struct AController* InstigatorController; // Offset: 0x3c0 // Size: 0x08

	// Functions

	// Object Name: Function Gameplay.UAEBuffApplierActor.GetTheInstigatorController
	// Flags: [Native|Public|Const]
	struct AController* GetTheInstigatorController(); // Offset: 0x103a83dc8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Gameplay.UAECharAnimListCompBase
// Size: 0x218 // Inherited bytes: 0x208
struct UUAECharAnimListCompBase : UUAEAnimListComponentBase {
	// Fields
	struct TArray<struct FCharacterAsynLoadedTypeAnim> CharacterAsynLoadedAnims; // Offset: 0x208 // Size: 0x10
};

// Object Name: Class Gameplay.UAEChaParachuteAnimListComponent
// Size: 0x248 // Inherited bytes: 0x218
struct UUAEChaParachuteAnimListComponent : UUAECharAnimListCompBase {
	// Fields
	struct TArray<struct FCharParachuteAnimData> CharParachuteAnimDataList; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0x20]; // Offset: 0x228 // Size: 0x20

	// Functions

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.ReleaseParachuteAnimAssets
	// Flags: [Final|Native|Public]
	void ReleaseParachuteAnimAssets(); // Offset: 0x103a842ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.OnParachuteAnimAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	void OnParachuteAnimAsyncLoadingFinished(struct FString AnimLoaded); // Offset: 0x103a841f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.OnAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	void OnAnimListAsyncLoadingFinished(); // Offset: 0x103a841dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.HasAnimAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	bool HasAnimAsyncLoadingFinished(); // Offset: 0x103a841a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.HandleAsyncLoadingFinishedEvent
	// Flags: [Final|Native|Public]
	void HandleAsyncLoadingFinishedEvent(); // Offset: 0x103a84194 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.GetOwnerName
	// Flags: [Final|Native|Public|Const]
	struct FString GetOwnerName(); // Offset: 0x103a84128 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEChaParachuteAnimListComponent.GetCharacterParachuteAnim
	// Flags: [Final|Native|Public|Const]
	struct UAnimationAsset* GetCharacterParachuteAnim(enum class ECharacterParachuteAnimType AnimType); // Offset: 0x103a8409c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Gameplay.UAECharacterAnimListComponent
// Size: 0x2d8 // Inherited bytes: 0x218
struct UUAECharacterAnimListComponent : UUAECharAnimListCompBase {
	// Fields
	struct TArray<struct FCharacterMovementAnimData> CharacterMovementAnimEditList; // Offset: 0x218 // Size: 0x10
	struct TArray<struct FCharacterMovementAnimData> CharacterFPPAnimEditList; // Offset: 0x228 // Size: 0x10
	struct TArray<struct FCharacterShieldAnimData> CharacterShieldAnimEditList; // Offset: 0x238 // Size: 0x10
	struct TArray<struct FCharacterJumpAnimData> CharacterJumpEditList; // Offset: 0x248 // Size: 0x10
	struct TArray<struct FCharacterJumpAnimData> CharacterJumpEditListFPP; // Offset: 0x258 // Size: 0x10
	struct UCurveFloat* FallingIKCurve; // Offset: 0x268 // Size: 0x08
	struct TArray<struct FCharacterShovelAnimData> CharacterShovelEditList; // Offset: 0x270 // Size: 0x10
	struct TArray<struct FCharacterShovelAnimData> CharacterShovelEditListFPP; // Offset: 0x280 // Size: 0x10
	struct TArray<struct FCharAnimModifyData> CharAnimModifyList; // Offset: 0x290 // Size: 0x10
	struct TArray<struct FCharacterVehAnimModifyData> CharVehAnimModifyList; // Offset: 0x2a0 // Size: 0x10
	bool IsInitByBeginPlay; // Offset: 0x2b0 // Size: 0x01
	bool EnablePreLoadingFinish; // Offset: 0x2b1 // Size: 0x01
	bool CurrentIsTPP; // Offset: 0x2b2 // Size: 0x01
	bool CurrentHoldShield; // Offset: 0x2b3 // Size: 0x01
	char pad_0x2B4[0x4]; // Offset: 0x2b4 // Size: 0x04
	struct FGetAnimUtil GetAnimUtil; // Offset: 0x2b8 // Size: 0x20

	// Functions

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.SetAnimListMapValueData
	// Flags: [Final|Native|Public|HasOutParms]
	void SetAnimListMapValueData(struct UAnimationAsset*& AnimPtr, struct FAnimListMapValueData& AnimListValue); // Offset: 0x103a85f7c // Return & Params: Num(2) Size(0x38)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.OnPreLoadingFinished
	// Flags: [Final|Native|Public]
	bool OnPreLoadingFinished(struct FAsyncLoadCharAnimParams LoadingParam); // Offset: 0x103a85ea0 // Return & Params: Num(2) Size(0x29)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.OnAsyncLoadingFinishedNew2
	// Flags: [Final|Native|Public]
	void OnAsyncLoadingFinishedNew2(struct FAsyncLoadCharAnimParams LoadingParam); // Offset: 0x103a85dd4 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.OnAsyncLoadingFinishedNew
	// Flags: [Final|Native|Public]
	void OnAsyncLoadingFinishedNew(struct FAsyncLoadCharAnimParams LoadingParam); // Offset: 0x103a85d08 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.InitAnimListMap
	// Flags: [Final|Native|Public]
	void InitAnimListMap(bool IsFPP); // Offset: 0x103a85c84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.GetCharacterShovelAnim
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FPlayerAnimData> GetCharacterShovelAnim(); // Offset: 0x103a85c20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.GetCharacterJumpAnim
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FPlayerAnimData> GetCharacterJumpAnim(enum class ECharacterJumpType JumpType); // Offset: 0x103a85b6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAECharacterAnimListComponent.GetAnimationAsset
	// Flags: [Final|Native|Private|HasOutParms]
	struct UAnimationAsset* GetAnimationAsset(struct UAnimationAsset*& AnimPtr); // Offset: 0x103a85a88 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class Gameplay.UAECharacterAnimListSubSystem
// Size: 0x80 // Inherited bytes: 0x30
struct UUAECharacterAnimListSubSystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x50]; // Offset: 0x30 // Size: 0x50
};

// Object Name: Class Gameplay.UAEChaVehAnimListComponent
// Size: 0x240 // Inherited bytes: 0x218
struct UUAEChaVehAnimListComponent : UUAECharAnimListCompBase {
	// Fields
	bool DefaultLoadAllAnim; // Offset: 0x218 // Size: 0x01
	char pad_0x219[0x7]; // Offset: 0x219 // Size: 0x07
	struct TArray<struct FVehCharAnimData> VehCharAnimDataList; // Offset: 0x220 // Size: 0x10
	char pad_0x230[0x10]; // Offset: 0x230 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.UAEChaVehAnimListComponent.SetVehCharAnimDataList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVehCharAnimDataList(struct TArray<struct FVehCharAnimData> InVehCharAnimDataList); // Offset: 0x103a8e82c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAEChaVehAnimListComponent.OnIdleAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	void OnIdleAnimListAsyncLoadingFinished(); // Offset: 0x103a8e818 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEChaVehAnimListComponent.OnAnimListAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	void OnAnimListAsyncLoadingFinished(struct FAsyncLoadCharVehAnimParams LoadingParam); // Offset: 0x103a8e744 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAEChaVehAnimListComponent.ChangeAnimData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeAnimData(struct TArray<struct FVehCharAnimData>& InAnimData); // Offset: 0x103a8e69c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Gameplay.UAEGameplayStatics
// Size: 0x28 // Inherited bytes: 0x28
struct UUAEGameplayStatics : UGameplayStatics {
	// Functions

	// Object Name: Function Gameplay.UAEGameplayStatics.GetGameBridge
	// Flags: [Final|Native|Static|Public]
	struct UUAEGameSubsystem* GetGameBridge(struct UObject* WorldContextObject); // Offset: 0x103a978ec // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Gameplay.UAEIndependentSpot
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct AUAEIndependentSpot : AActor {
	// Fields
	bool bIsEditorOnly; // Offset: 0x3bd // Size: 0x01
	enum class EIndependentSpotType SpotType; // Offset: 0x3be // Size: 0x01
};

// Object Name: Class Gameplay.UAELevelSequenceActor
// Size: 0x5b0 // Inherited bytes: 0x460
struct AUAELevelSequenceActor : ALevelSequenceActor {
	// Fields
	char pad_0x460[0x60]; // Offset: 0x460 // Size: 0x60
	bool bPlayOnServer; // Offset: 0x4c0 // Size: 0x01
	char pad_0x4C1[0x3]; // Offset: 0x4c1 // Size: 0x03
	float ClientSyncTime; // Offset: 0x4c4 // Size: 0x04
	bool bUseSelfTransformOrigin; // Offset: 0x4c8 // Size: 0x01
	bool bAutoDestroy; // Offset: 0x4c9 // Size: 0x01
	char pad_0x4CA[0x2]; // Offset: 0x4ca // Size: 0x02
	float DestroySelfDelayTime; // Offset: 0x4cc // Size: 0x04
	bool bInitPlayerBeforeBeginPlay; // Offset: 0x4d0 // Size: 0x01
	char pad_0x4D1[0x3]; // Offset: 0x4d1 // Size: 0x03
	float AuthorityStartPlayTime; // Offset: 0x4d4 // Size: 0x04
	struct FString LevelSequenceAssetPath; // Offset: 0x4d8 // Size: 0x10
	struct TMap<struct FString, struct FString> GreenSequenceMap; // Offset: 0x4e8 // Size: 0x50
	char pad_0x538[0x8]; // Offset: 0x538 // Size: 0x08
	struct FString LuaFilePath; // Offset: 0x540 // Size: 0x10
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x550 // Size: 0x50
	struct TArray<struct FMovieSceneBindingOverrideData> NetSyncBindingData; // Offset: 0x5a0 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.UAELevelSequenceActor.UpdateSequence
	// Flags: [Native|Public|BlueprintCallable]
	void UpdateSequence(struct FString LevelSequencePath); // Offset: 0x103a9a584 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAELevelSequenceActor.UpdatePlayback
	// Flags: [Native|Public|BlueprintCallable]
	void UpdatePlayback(bool bRestoreState, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer); // Offset: 0x103a9a41c // Return & Params: Num(4) Size(0x4)

	// Object Name: Function Gameplay.UAELevelSequenceActor.UpdateInstanceData
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void UpdateInstanceData(struct FVector& OffsetVector, struct FRotator& OffsetRotation); // Offset: 0x103a9a33c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAELevelSequenceActor.StopMontageParticle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopMontageParticle(struct FName SlotName); // Offset: 0x103a9a2c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.UAELevelSequenceActor.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x103a9a2ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.SetUseSelfTransformOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUseSelfTransformOrigin(bool bInUse); // Offset: 0x103a9a228 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Gameplay.UAELevelSequenceActor.SetTrackBindingInfo
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void SetTrackBindingInfo(struct TMap<struct FString, struct FString>& TrackBindingInfo); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Gameplay.UAELevelSequenceActor.SetNetSyncBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Offset: 0x103a9a0cc // Return & Params: Num(3) Size(0x29)

	// Object Name: Function Gameplay.UAELevelSequenceActor.SetLevelSequenceAssetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLevelSequenceAssetPath(struct FString InLevelSequenceAssetPath); // Offset: 0x103a9a034 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ResetNetSyncBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetNetSyncBindings(); // Offset: 0x103a9a020 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ResetNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetNetSyncBinding(struct FMovieSceneObjectBindingID Binding); // Offset: 0x103a99f80 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAELevelSequenceActor.RemoveNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x103a99ea4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnStop
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnStop(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnPreStop
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPreStop(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnPlayReverse
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPlayReverse(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPlay(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnPause
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPause(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnObjectSpawned
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void ReceiveOnObjectSpawned(struct UObject* InObject, struct FGuid& InBindingID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Gameplay.UAELevelSequenceActor.ReceiveOnFinished
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnFinished(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(float InPlaytime); // Offset: 0x103a99e28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnSequenceFinished
	// Flags: [Final|Native|Public]
	void OnSequenceFinished(); // Offset: 0x103a99e14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnRep_NetSyncBindingData
	// Flags: [Final|Native|Public]
	void OnRep_NetSyncBindingData(); // Offset: 0x103a99e00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnRep_LevelSequenceAssetPath
	// Flags: [Final|Native|Protected]
	void OnRep_LevelSequenceAssetPath(); // Offset: 0x103a99dec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnRep_bUseSelfTransformOrigin
	// Flags: [Final|Native|Protected]
	void OnRep_bUseSelfTransformOrigin(); // Offset: 0x103a99dd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnRep_AuthorityStartPlayTime
	// Flags: [Final|Native|Protected]
	void OnRep_AuthorityStartPlayTime(); // Offset: 0x103a99dc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.OnObjectSpawnedEvent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void OnObjectSpawnedEvent(struct UObject* InObject, struct FGuid& InBindingID, struct FMovieSceneSequenceID InSequenceID); // Offset: 0x103a99cb4 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Gameplay.UAELevelSequenceActor.GoToEndAndStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GoToEndAndStop(); // Offset: 0x103a99ca0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAELevelSequenceActor.GetPossessableByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FMovieSceneObjectBindingID GetPossessableByName(struct FString NameKeyString); // Offset: 0x103a99be4 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Gameplay.UAELevelSequenceActor.GetFirstPossessableTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FMovieSceneObjectBindingID GetFirstPossessableTrack(); // Offset: 0x103a99b98 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Gameplay.UAELevelSequenceActor.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* InLevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct AUAELevelSequenceActor*& OutActor); // Offset: 0x103a99a28 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Gameplay.UAELevelSequenceActor.AddNetSyncBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddNetSyncBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Offset: 0x103a99908 // Return & Params: Num(3) Size(0x21)
};

// Object Name: Class Gameplay.AELobbyCharAnimListComp
// Size: 0x270 // Inherited bytes: 0x218
struct UAELobbyCharAnimListComp : UUAECharAnimListCompBase {
	// Fields
	struct TArray<struct FLobbyCharacterWeaponAnimData> CharacterWeaponAnimEditList; // Offset: 0x218 // Size: 0x10
	struct TArray<struct FLobbyCharacterWeaponAnimData> AvatarSceneCharacterWeaponAnimEditList; // Offset: 0x228 // Size: 0x10
	struct TArray<struct FLobbyCharacterWeaponAnimData> LobbyWithCarCharacterWeaponAnimEditList; // Offset: 0x238 // Size: 0x10
	struct TArray<struct FLobbyCharacterWeaponAnimData> LobbySystemCharacterWeaponAnimEditList; // Offset: 0x248 // Size: 0x10
	int resultAvatarPoseIndex; // Offset: 0x258 // Size: 0x04
	char pad_0x25C[0x14]; // Offset: 0x25c // Size: 0x14

	// Functions

	// Object Name: Function Gameplay.AELobbyCharAnimListComp.OnAsyncLoadingFinished
	// Flags: [Final|Native|Public]
	void OnAsyncLoadingFinished(struct FLobbyAsyncLoadCharAnimParams LoadingParam); // Offset: 0x103a9b698 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function Gameplay.AELobbyCharAnimListComp.InitPendingList
	// Flags: [Final|Native|Public|HasOutParms]
	void InitPendingList(struct TArray<struct FLobbyCharacterWeaponAnimData>& animEditList, struct TArray<struct FSoftObjectPath>& PendingList); // Offset: 0x103a9b580 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.AELobbyCharAnimListComp.GetCharacterAnim
	// Flags: [Final|Native|Public|Const]
	struct UAnimationAsset* GetCharacterAnim(enum class ELobbyCharacterPosIndex PosIdx, enum class ELobbyCharacterAnimType GenderType, int WeaponAnimType, enum class ECharacterShowSceneType sceneType); // Offset: 0x103a9b440 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function Gameplay.AELobbyCharAnimListComp.BuildAnimMap
	// Flags: [Final|Native|Public|HasOutParms]
	void BuildAnimMap(struct TArray<struct FLobbyCharacterWeaponAnimData>& AnimList, enum class ECharacterShowSceneType sceneType); // Offset: 0x103a9b34c // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Gameplay.UAESimpleSceneActor
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct AUAESimpleSceneActor : AActor {
};

// Object Name: Class Gameplay.UAESpawnActorComponent
// Size: 0x110 // Inherited bytes: 0x110
struct UUAESpawnActorComponent : UActorComponent {
	// Functions

	// Object Name: Function Gameplay.UAESpawnActorComponent.UAESpawnActor
	// Flags: [Native|Public|BlueprintCallable]
	struct AActor* UAESpawnActor(struct FUAESpawnActorParam Param); // Offset: 0x103aabbc8 // Return & Params: Num(2) Size(0x98)

	// Object Name: Function Gameplay.UAESpawnActorComponent.PrepareSpawnData
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct UObject* PrepareSpawnData(int TemplateID); // Offset: 0x103aabb34 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Gameplay.UAESpawnActorComponent.InitializeActor
	// Flags: [Native|Event|Public|BlueprintEvent]
	void InitializeActor(struct AActor* InActor, int TemplateID); // Offset: 0x103aaba74 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class Gameplay.UAESpotGroupObject
// Size: 0x90 // Inherited bytes: 0x28
struct UUAESpotGroupObject : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 // Size: 0x58
	struct UObject* Host; // Offset: 0x80 // Size: 0x08
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08
};

// Object Name: Class Gameplay.UAEWindowComponent
// Size: 0x900 // Inherited bytes: 0x890
struct UUAEWindowComponent : UStaticMeshComponent {
	// Fields
	int ID; // Offset: 0x890 // Size: 0x04
	bool bBroken; // Offset: 0x894 // Size: 0x01
	char pad_0x895[0x3]; // Offset: 0x895 // Size: 0x03
	struct APawn* LastInstigatorPawn; // Offset: 0x898 // Size: 0x08
	struct UStaticMesh* BrokenMesh; // Offset: 0x8a0 // Size: 0x08
	struct UParticleSystem* BrokenEffect; // Offset: 0x8a8 // Size: 0x08
	char pad_0x8B0[0x50]; // Offset: 0x8b0 // Size: 0x50

	// Functions

	// Object Name: Function Gameplay.UAEWindowComponent.NotifyServerBroken
	// Flags: [Event|Protected|BlueprintEvent]
	void NotifyServerBroken(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.UAEWindowComponent.NotifyRepDataUpdated
	// Flags: [Final|Native|Protected]
	void NotifyRepDataUpdated(bool bInitial, bool bLocal); // Offset: 0x103aac47c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.UAEWindowComponent.LocalHandleWindowBrokenBP
	// Flags: [Event|Protected|BlueprintEvent]
	void LocalHandleWindowBrokenBP(bool bInitial, bool bLocal); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.UAEWindowComponent.LocalHandleWindowBroken
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void LocalHandleWindowBroken(bool bInitial, bool bLocal); // Offset: 0x103aac3ac // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Gameplay.UAEWindowComponent.HandleBroken
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleBroken(struct APlayerController* Instigator, bool bLocal); // Offset: 0x103aac2ec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Gameplay.UAEWindowComponent.GetRepData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FUAEWindowRepData GetRepData(); // Offset: 0x103aac284 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class Gameplay.VehicleConfigActorComponent
// Size: 0x110 // Inherited bytes: 0x110
struct UVehicleConfigActorComponent : UActorComponent {
	// Functions

	// Object Name: Function Gameplay.VehicleConfigActorComponent.LoadActorClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* LoadActorClass(struct FString Path); // Offset: 0x103aac844 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Gameplay.VehicleAndTreasureBoxGeneratorComponent
// Size: 0x498 // Inherited bytes: 0x2d8
struct UVehicleAndTreasureBoxGeneratorComponent : UBaseGeneratorComponent {
	// Fields
	bool bUseLocalSpotFile; // Offset: 0x2d8 // Size: 0x01
	bool bCanBackupVehicleSpotDatas; // Offset: 0x2d9 // Size: 0x01
	char pad_0x2DA[0x6]; // Offset: 0x2da // Size: 0x06
	struct TArray<struct UVehicleSpotSceneComponent*> VehicleSpotSceneComponentList; // Offset: 0x2e0 // Size: 0x10
	enum class ERegionType RegionType; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x7]; // Offset: 0x2f1 // Size: 0x07
	struct TArray<struct FBackupVehicleSpotData> BackupVehicleSpotDatas; // Offset: 0x2f8 // Size: 0x10
	struct TArray<struct FVehicleSpotProperty> VehicleSpotPropertys; // Offset: 0x308 // Size: 0x10
	struct TArray<struct FTreasureBoxSpotProperty> TreasureBoxSpotPropertys; // Offset: 0x318 // Size: 0x10
	bool bStatisticsValid; // Offset: 0x328 // Size: 0x01
	bool bIsRandom; // Offset: 0x329 // Size: 0x01
	char pad_0x32A[0x6]; // Offset: 0x32a // Size: 0x06
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllVehicleSpots; // Offset: 0x330 // Size: 0x50
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllTreasureBoxSpots; // Offset: 0x380 // Size: 0x50
	struct TMap<struct FString, struct FVehicleGenerateSpawnDataArray> VehicleGenerateSpawnDatas; // Offset: 0x3d0 // Size: 0x50
	struct FVehicleGenerateStatisticsData VehicleStatisticsData; // Offset: 0x420 // Size: 0x60
	struct UUAEDataTable* VehicleDataTable; // Offset: 0x480 // Size: 0x08
	char pad_0x488[0x10]; // Offset: 0x488 // Size: 0x10

	// Functions

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsFromSpotFile
	// Flags: [Final|Native|Public]
	void WriteVehicleSpotStatisticsFromSpotFile(); // Offset: 0x103aae09c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	void WriteVehicleSpotStatisticsDatas_V15(); // Offset: 0x103aae088 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteVehicleSpotStatisticsDatas(); // Offset: 0x103aae074 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleClassStatisticsDatas_V15
	// Flags: [Final|Native|Public]
	void WriteVehicleClassStatisticsDatas_V15(); // Offset: 0x103aae060 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteVehicleClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteVehicleClassStatisticsDatas(); // Offset: 0x103aae04c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatasToLog
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void WriteAllVehicleStatisticsDatasToLog(); // Offset: 0x103aae038 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatas_V15
	// Flags: [Final|Native|Public|BlueprintCallable]
	void WriteAllVehicleStatisticsDatas_V15(); // Offset: 0x103aae024 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.WriteAllVehicleStatisticsDatas
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void WriteAllVehicleStatisticsDatas(); // Offset: 0x103aae010 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RegisterVehicleGenerateSpawnData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterVehicleGenerateSpawnData(struct FVehicleGenerateSpawnData Data); // Offset: 0x103aadf4c // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent); // Offset: 0x103aadec8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomTreasureBoxSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomTreasureBoxSpotsByType(struct FTreasureBoxSpotProperty& Property, struct FVehicleSpotComponentArray& Spots); // Offset: 0x103aadd98 // Return & Params: Num(2) Size(0x38)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomTreasureBoxSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomTreasureBoxSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FTreasureBoxSpotProperty& Property); // Offset: 0x103aadc78 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSpotsByType(struct FVehicleSpotProperty& Property, struct FVehicleSpotComponentArray& Spots); // Offset: 0x103aadb48 // Return & Params: Num(2) Size(0x50)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FVehicleSpotProperty& Property); // Offset: 0x103aada28 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.RandomGroups
	// Flags: [Native|Public|BlueprintCallable]
	void RandomGroups(); // Offset: 0x103aada0c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.LoadVehicleGenerateTable
	// Flags: [Event|Public|BlueprintEvent]
	void LoadVehicleGenerateTable(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GMGenerateAllVehicleSpot
	// Flags: [Final|Native|Public]
	bool GMGenerateAllVehicleSpot(struct FString VehiclePath); // Offset: 0x103aad940 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfoWithCategory
	// Flags: [Final|Native|Public|HasOutParms]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoWithCategory(struct FVehicleSpotProperty& SpotProperty, struct FString Category); // Offset: 0x103aad7d4 // Return & Params: Num(3) Size(0x70)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfoBySpotType
	// Flags: [Final|Native|Public]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoBySpotType(enum class ESpotType SpotType, struct FString InCategory); // Offset: 0x103aad6c0 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetVehicleSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfo(struct FVehicleSpotProperty& SpotProperty, struct FString InCategory); // Offset: 0x103aad578 // Return & Params: Num(3) Size(0x70)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetTreasureBoxSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	struct FVehicleGenerateRandomInfo GetTreasureBoxSpotRandomInfo(struct FTreasureBoxSpotProperty& SpotProperty); // Offset: 0x103aad490 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetRandomVehicleClass
	// Flags: [Final|Native|Public]
	struct FVehicleGenerateSpawnData GetRandomVehicleClass(struct FString Category); // Offset: 0x103aad39c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights); // Offset: 0x103aad2b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Protected]
	void GenerateSpotOnTick(float DeltaTime); // Offset: 0x103aad230 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.DynamicSpawnVehicleBySpotId
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DynamicSpawnVehicleBySpotId(int ID, struct FString Category); // Offset: 0x103aad124 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.DeleteGroups
	// Flags: [Final|Native|Protected]
	void DeleteGroups(); // Offset: 0x103aad110 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.CanDynamicSpawnVehicle
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool CanDynamicSpawnVehicle(struct FVector SpawnLocation, struct FVector TestLocationOffset, struct FVector TestBoxSize); // Offset: 0x103aad004 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.AddVehicleSpotCount
	// Flags: [Final|Native|Protected]
	void AddVehicleSpotCount(enum class ESpotType SpotType, struct FString Path, float LocationX, float LocationY, float LocationZ); // Offset: 0x103aace48 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function Gameplay.VehicleAndTreasureBoxGeneratorComponent.AddVehicleClassCount
	// Flags: [Final|Native|Protected]
	void AddVehicleClassCount(struct FString Path, bool IsValid, int Count); // Offset: 0x103aaccfc // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Gameplay.VehicleGeneratorComponent
// Size: 0x3f0 // Inherited bytes: 0x2d8
struct UVehicleGeneratorComponent : UBaseGeneratorComponent {
	// Fields
	struct TArray<struct FVehicleSpotProperty> VehicleSpotPropertys; // Offset: 0x2d8 // Size: 0x10
	bool bStatisticsValid; // Offset: 0x2e8 // Size: 0x01
	bool bIsRandom; // Offset: 0x2e9 // Size: 0x01
	char pad_0x2EA[0x6]; // Offset: 0x2ea // Size: 0x06
	struct TMap<enum class ESpotType, struct FVehicleSpotComponentArray> AllVehicleSpots; // Offset: 0x2f0 // Size: 0x50
	struct TMap<struct FString, struct FVehicleGenerateSpawnDataArray> VehicleGenerateSpawnDatas; // Offset: 0x340 // Size: 0x50
	struct FVehicleGenerateStatisticsData VehicleStatisticsData; // Offset: 0x390 // Size: 0x60

	// Functions

	// Object Name: Function Gameplay.VehicleGeneratorComponent.WriteVehicleSpotStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteVehicleSpotStatisticsDatas(); // Offset: 0x103aaf4bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.WriteVehicleClassStatisticsDatas
	// Flags: [Final|Native|Protected]
	void WriteVehicleClassStatisticsDatas(); // Offset: 0x103aaf4a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.WriteAllVehicleStatisticsDatas
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void WriteAllVehicleStatisticsDatas(); // Offset: 0x103aaf494 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.RegisterVehicleGenerateSpawnData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterVehicleGenerateSpawnData(struct FVehicleGenerateSpawnData Data); // Offset: 0x103aaf3d0 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.RegisterGroupSpotComponent
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterGroupSpotComponent(struct UGroupSpotSceneComponent* GroupSpotComponent); // Offset: 0x103aaf34c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.RandomSpotsByType
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSpotsByType(struct FVehicleSpotProperty& Property, struct FVehicleSpotComponentArray& Spots); // Offset: 0x103aaf21c // Return & Params: Num(2) Size(0x50)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.RandomSingleSpots
	// Flags: [Final|Native|Protected|HasOutParms]
	void RandomSingleSpots(struct TArray<struct UVehicleSpotSceneComponent*>& AllSpots, struct FVehicleSpotProperty& Property); // Offset: 0x103aaf0fc // Return & Params: Num(2) Size(0x48)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.RandomGroups
	// Flags: [Native|Public|BlueprintCallable]
	void RandomGroups(); // Offset: 0x103aaf0e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.LoadVehicleGenerateTable
	// Flags: [Native|Event|Public|BlueprintEvent]
	void LoadVehicleGenerateTable(); // Offset: 0x103aaf0c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.GetVehicleSpotRandomInfoBySpotType
	// Flags: [Final|Native|Public]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfoBySpotType(enum class ESpotType SpotType); // Offset: 0x103aaf008 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.GetVehicleSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	struct FVehicleGenerateRandomInfo GetVehicleSpotRandomInfo(struct FVehicleSpotProperty& SpotProperty); // Offset: 0x103aaef20 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.GetRandomVehicleClass
	// Flags: [Final|Native|Public]
	struct FVehicleGenerateSpawnData GetRandomVehicleClass(struct FString Category); // Offset: 0x103aaee2c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.GetRandomCategory
	// Flags: [Native|Protected|HasOutParms]
	struct FString GetRandomCategory(struct TArray<struct FSpotWeight>& SpotWeights); // Offset: 0x103aaed44 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.GenerateSpotOnTick
	// Flags: [Native|Protected]
	void GenerateSpotOnTick(float DeltaTime); // Offset: 0x103aaecc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.DeleteGroups
	// Flags: [Final|Native|Protected]
	void DeleteGroups(); // Offset: 0x103aaecac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.AddVehicleSpotCount
	// Flags: [Final|Native|Protected]
	void AddVehicleSpotCount(enum class ESpotType SpotType, struct FString Path, float LocationX, float LocationY, float LocationZ); // Offset: 0x103aaeaf0 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function Gameplay.VehicleGeneratorComponent.AddVehicleClassCount
	// Flags: [Final|Native|Protected]
	void AddVehicleClassCount(struct FString Path, bool IsValid, int Count); // Offset: 0x103aae9a4 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Gameplay.VehicleGroupSpotSceneComponent
// Size: 0x2e0 // Inherited bytes: 0x2e0
struct UVehicleGroupSpotSceneComponent : UGroupSpotSceneComponent {
};

// Object Name: Class Gameplay.VehicleSpotObject
// Size: 0x98 // Inherited bytes: 0x28
struct UVehicleSpotObject : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
	struct FVehicleGenerateRandomInfo SpotRandomInfo; // Offset: 0x70 // Size: 0x28
};

// Object Name: Class Gameplay.VehicleSpotSceneComponent
// Size: 0x330 // Inherited bytes: 0x2f0
struct UVehicleSpotSceneComponent : USpotSceneComponent {
	// Fields
	enum class ESpotGroupType SpotGroupType; // Offset: 0x2f0 // Size: 0x01
	enum class ERegionType RegionType; // Offset: 0x2f1 // Size: 0x01
	bool bHasGenerateSpot; // Offset: 0x2f2 // Size: 0x01
	bool bRandomRotation; // Offset: 0x2f3 // Size: 0x01
	float RandomRotationMin; // Offset: 0x2f4 // Size: 0x04
	float RandomRotationMax; // Offset: 0x2f8 // Size: 0x04
	char pad_0x2FC[0x4]; // Offset: 0x2fc // Size: 0x04
	struct FVehicleGenerateRandomInfo SpotRandomInfo; // Offset: 0x300 // Size: 0x28
	bool IsEnableVehicleSpawnRestore; // Offset: 0x328 // Size: 0x01
	char pad_0x329[0x3]; // Offset: 0x329 // Size: 0x03
	float VehicleSpawnRestoreOffset; // Offset: 0x32c // Size: 0x04

	// Functions

	// Object Name: Function Gameplay.VehicleSpotSceneComponent.SetSpotRandomInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void SetSpotRandomInfo(struct FVehicleGenerateRandomInfo& RandomInfo); // Offset: 0x103aafc70 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Gameplay.VehicleSpotSceneComponent.GenerateSpot
	// Flags: [Native|Public]
	bool GenerateSpot(); // Offset: 0x103aafc34 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Gameplay.WeatherConfigComponent
// Size: 0x168 // Inherited bytes: 0x110
struct UWeatherConfigComponent : UActorComponent {
	// Fields
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08
	struct FScriptMulticastDelegate OnLoadWeatherLevelCompleted; // Offset: 0x118 // Size: 0x10
	struct FWeatherInfo WeatherLevelInfo; // Offset: 0x128 // Size: 0x18
	struct FString LastLoadedWeatherLevelName; // Offset: 0x140 // Size: 0x10
	struct FString DefaultWeatherLevelName; // Offset: 0x150 // Size: 0x10
	bool bLoadWeatherLevel; // Offset: 0x160 // Size: 0x01
	bool bDefaulLevelLoaded; // Offset: 0x161 // Size: 0x01
	char pad_0x162[0x6]; // Offset: 0x162 // Size: 0x06

	// Functions

	// Object Name: Function Gameplay.WeatherConfigComponent.UnloadStreamLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnloadStreamLevel(struct FString LevelName); // Offset: 0x103ab0784 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Gameplay.WeatherConfigComponent.SyncWeatherLevelInfo
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SyncWeatherLevelInfo(); // Offset: 0x103ab0770 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.SwitchDifferentWeather
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchDifferentWeather(struct FString oldMap, struct FString newMap, int iNewMapID); // Offset: 0x103ab05fc // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Gameplay.WeatherConfigComponent.OnWeatherLevelChanged
	// Flags: [Event|Public|BlueprintEvent]
	void OnWeatherLevelChanged(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.OnUnLoadStreamLevelCompleted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnUnLoadStreamLevelCompleted(); // Offset: 0x103ab05e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.OnRep_WeatherSyncCount
	// Flags: [Final|Native|Public]
	void OnRep_WeatherSyncCount(); // Offset: 0x103ab05d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Gameplay.WeatherConfigComponent.OnLoadWeatherLevelCompleted__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLoadWeatherLevelCompleted__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.OnLoadStreamLevelCompleted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnLoadStreamLevelCompleted(); // Offset: 0x103ab05c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.LoadWeatherLevel
	// Flags: [Final|Native|Public]
	void LoadWeatherLevel(); // Offset: 0x103ab05ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.LoadStreamLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadStreamLevel(struct FString LevelName, int WeatherID); // Offset: 0x103ab04b0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Gameplay.WeatherConfigComponent.LoadDefaultWeatherLevel
	// Flags: [Final|Native|Public]
	void LoadDefaultWeatherLevel(); // Offset: 0x103ab049c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Gameplay.WeatherConfigComponent.Init
	// Flags: [Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x103ab0480 // Return & Params: Num(0) Size(0x0)
};

