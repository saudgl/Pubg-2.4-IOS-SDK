#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Basic.OnlyActorComponent
// Size: 0x118 // Inherited bytes: 0x110
struct UOnlyActorComponent : UActorComponent {
	// Fields
	char bCanEverUpdate; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x7]; // Offset: 0x111 // Size: 0x07
};

// Object Name: Class Basic.UAENetActor
// Size: 0x498 // Inherited bytes: 0x488
struct AUAENetActor : ALuaActor {
	// Fields
	char pad_0x488[0x8]; // Offset: 0x488 // Size: 0x08
	int iRegionActor; // Offset: 0x490 // Size: 0x04
	char pad_0x494[0x2]; // Offset: 0x494 // Size: 0x02
	bool bStaticAddNetworkActor; // Offset: 0x496 // Size: 0x01
	char AutoDormancyType; // Offset: 0x497 // Size: 0x01

	// Functions

	// Object Name: Function Basic.UAENetActor.ReceivedPlayerActiveRegionsChanged
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivedPlayerActiveRegionsChanged(bool bEnter); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.UAEAnimListComponentBase
// Size: 0x208 // Inherited bytes: 0x110
struct UUAEAnimListComponentBase : UActorComponent {
	// Fields
	char pad_0x110[0x68]; // Offset: 0x110 // Size: 0x68
	struct TMap<int, struct FAnimListMapValueData> AnimListMap; // Offset: 0x178 // Size: 0x50
	struct TArray<struct UAnimationAsset*> AnimationCatcheList; // Offset: 0x1c8 // Size: 0x10
	char pad_0x1D8[0x28]; // Offset: 0x1d8 // Size: 0x28
	bool bDisableAnimListOnDS; // Offset: 0x200 // Size: 0x01
	char pad_0x201[0x7]; // Offset: 0x201 // Size: 0x07
};

// Object Name: Class Basic.ItemHandleBase
// Size: 0xa8 // Inherited bytes: 0x28
struct UItemHandleBase : UObject {
	// Fields
	int Count; // Offset: 0x28 // Size: 0x04
	int MaxCount; // Offset: 0x2c // Size: 0x04
	bool bUnique; // Offset: 0x30 // Size: 0x01
	bool bStackable; // Offset: 0x31 // Size: 0x01
	bool bSingle; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x5]; // Offset: 0x33 // Size: 0x05
	struct TMap<int, struct FItemAssociation> AssociationMap; // Offset: 0x38 // Size: 0x50
	struct FItemDefineID DefineID; // Offset: 0x88 // Size: 0x18
	char pad_0xA0[0x8]; // Offset: 0xa0 // Size: 0x08

	// Functions

	// Object Name: Function Basic.ItemHandleBase.SetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAssociation(int AssociationType, struct FItemAssociation Association); // Offset: 0x103774e10 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Basic.ItemHandleBase.RemoveAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAssociation(int AssociationType); // Offset: 0x103774d94 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.ItemHandleBase.Init
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void Init(struct FItemDefineID InDefineID); // Offset: 0x103774d00 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemDefineID GetDefineID(); // Offset: 0x103774cb0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TMap<int, struct FItemAssociation> GetAssociationMap(); // Offset: 0x103774c4c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationListByTargetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FItemAssociation> GetAssociationListByTargetType(int Type); // Offset: 0x103774b98 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.GetAssociationByTargetDefineID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemAssociation GetAssociationByTargetDefineID(struct FItemDefineID TargetDefineID); // Offset: 0x103774aec // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Basic.ItemHandleBase.GetAssociation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FItemAssociation GetAssociation(int AssociationType); // Offset: 0x103774a50 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function Basic.ItemHandleBase.Constuct
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Constuct(struct FItemDefineID& InDefineID); // Offset: 0x1037749b8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Basic.ItemHandleBase.AddAssociation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAssociation(int AssociationType, struct FItemAssociation Association); // Offset: 0x1037748ec // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class Basic.BattleItemHandleBase
// Size: 0x140 // Inherited bytes: 0xa8
struct UBattleItemHandleBase : UItemHandleBase {
	// Fields
	char pad_0xA8[0x60]; // Offset: 0xa8 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x108 // Size: 0x10
	bool bEquipping; // Offset: 0x118 // Size: 0x01
	enum class EItemStoreArea ItemStoreArea; // Offset: 0x119 // Size: 0x01
	char pad_0x11A[0x6]; // Offset: 0x11a // Size: 0x06
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x120 // Size: 0x10
	bool bDropOnDead; // Offset: 0x130 // Size: 0x01
	char pad_0x131[0x3]; // Offset: 0x131 // Size: 0x03
	float UnitWeight; // Offset: 0x134 // Size: 0x04
	bool bEquippable; // Offset: 0x138 // Size: 0x01
	bool bConsumable; // Offset: 0x139 // Size: 0x01
	bool bAutoEquipAndDrop; // Offset: 0x13a // Size: 0x01
	char pad_0x13B[0x1]; // Offset: 0x13b // Size: 0x01
	int ItemAttrsFlag; // Offset: 0x13c // Size: 0x04

	// Functions

	// Object Name: Function Basic.BattleItemHandleBase.UpdateAttributeModify
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void UpdateAttributeModify(bool bEnable); // Offset: 0x10376d4f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.UnEquip
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool UnEquip(); // Offset: 0x10376d4c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HanldePickupAssociationData
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool HanldePickupAssociationData(struct TArray<struct FBattleItemAdditionalData>& PickupAdditionalData); // Offset: 0x10376d404 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.BattleItemHandleBase.HanldeDropAssociationData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HanldeDropAssociationData(); // Offset: 0x10376d3c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HanldeCleared
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HanldeCleared(); // Offset: 0x10376d38c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.HandleUse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleUse(struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x10376d2ac // Return & Params: Num(3) Size(0x2a)

	// Object Name: Function Basic.BattleItemHandleBase.HandlePickup
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool HandlePickup(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemPickupInfo PickupInfo, enum class EBattleItemPickupReason Reason); // Offset: 0x10376d130 // Return & Params: Num(4) Size(0x6a)

	// Object Name: Function Basic.BattleItemHandleBase.HandleEnable
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleEnable(bool bEnable); // Offset: 0x10376d094 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleDrop
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleDrop(int InCount, enum class EBattleItemDropReason Reason); // Offset: 0x10376cfc4 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Basic.BattleItemHandleBase.HandleDisuse
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleDisuse(enum class EBattleItemDisuseReason Reason); // Offset: 0x10376cf30 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleChangeItemStoreArea
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleChangeItemStoreArea(enum class EItemStoreArea InItemStoreArea); // Offset: 0x10376ce9c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.BattleItemHandleBase.HandleBindToTargetItem
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	bool HandleBindToTargetItem(); // Offset: 0x10376ce60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.BattleItemHandleBase.GetWorldInternal
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	struct UWorld* GetWorldInternal(); // Offset: 0x10376ce24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.BattleItemHandleBase.GetCurrentWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetCurrentWorld(); // Offset: 0x10376cdf0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.BattleItemHandleBase.ExtractItemData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FBattleItemData ExtractItemData(); // Offset: 0x10376cd84 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function Basic.BattleItemHandleBase.ClearAdditionalData
	// Flags: [Final|Native|Public]
	void ClearAdditionalData(); // Offset: 0x10376cd70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.BattleItemHandleBase.CheckCanUse
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool CheckCanUse(struct TScriptInterface<Class>& ItemContainer, struct FBattleItemUseTarget Target, enum class EBattleItemUseReason Reason); // Offset: 0x10376cc40 // Return & Params: Num(4) Size(0x3a)
};

// Object Name: Class Basic.UAENetPoolActor
// Size: 0x4e0 // Inherited bytes: 0x498
struct AUAENetPoolActor : AUAENetActor {
	// Fields
	char pad_0x498[0x48]; // Offset: 0x498 // Size: 0x48

	// Functions

	// Object Name: Function Basic.UAENetPoolActor.OnBPRespawned
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnBPRespawned(); // Offset: 0x103792970 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAENetPoolActor.OnBPRecycled
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnBPRecycled(); // Offset: 0x103792954 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.UAEBaseSkillCondition
// Size: 0x70 // Inherited bytes: 0x60
struct UUAEBaseSkillCondition : UUTSkillCondition {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08
	struct APawn* OwnerPawnForBuff; // Offset: 0x68 // Size: 0x08
};

// Object Name: Class Basic.DataProviderBase
// Size: 0x28 // Inherited bytes: 0x28
struct UDataProviderBase : UObject {
};

// Object Name: Class Basic.STBuffAction
// Size: 0x50 // Inherited bytes: 0x28
struct USTBuffAction : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	float ExecuteDelay; // Offset: 0x30 // Size: 0x04
	int ArrayIndex; // Offset: 0x34 // Size: 0x04
	struct TWeakObjectPtr<struct USTBuff> OwnerBuff; // Offset: 0x38 // Size: 0x08
	struct UActorComponent* CurOwnerActorComponent; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function Basic.STBuffAction.Tick
	// Flags: [Final|Native|Public]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime); // Offset: 0x103782b10 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Basic.STBuffAction.SetEnabled
	// Flags: [Final|Native|Public]
	void SetEnabled(struct UActorComponent* BuffSystemComponent, int InstID, bool Enabled); // Offset: 0x103782a18 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBuffAction.ResetExecute
	// Flags: [Final|Native|Public]
	void ResetExecute(struct UActorComponent* BuffSystemComponent, int InstID, bool IgnoreEnd); // Offset: 0x103782920 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBuffAction.OnTick
	// Flags: [Native|Protected]
	void OnTick(float DetalTime); // Offset: 0x10378289c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffAction.OnResetExecute
	// Flags: [Native|Protected]
	void OnResetExecute(bool IgnoreEnd); // Offset: 0x103782810 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBuffAction.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x1037827f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnExecute
	// Flags: [Native|Protected]
	void OnExecute(); // Offset: 0x1037827d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnEnd
	// Flags: [Native|Protected]
	void OnEnd(); // Offset: 0x1037827bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x1037827a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnCheckLinkActionEnabled
	// Flags: [Native|Protected]
	void OnCheckLinkActionEnabled(); // Offset: 0x103782784 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.OnChangeNotify
	// Flags: [Native|Protected]
	void OnChangeNotify(); // Offset: 0x103782768 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x1037826b0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction.GetOwner
	// Flags: [Final|Native|Protected]
	struct AActor* GetOwner(); // Offset: 0x10378267c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.GetCauser
	// Flags: [Final|Native|Protected]
	struct AActor* GetCauser(); // Offset: 0x103782648 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffAction.End
	// Flags: [Final|Native|Public]
	void End(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103782590 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction.Destroy
	// Flags: [Final|Native|Public]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x1037824d8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction.CopyAction
	// Flags: [Native|Public]
	struct USTBuffAction* CopyAction(struct UObject* Outer); // Offset: 0x103782444 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffAction.CheckLinkActionEnabled
	// Flags: [Final|Native|Public]
	void CheckLinkActionEnabled(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x10378238c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction.ChangeNotify
	// Flags: [Final|Native|Public]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x1037822d4 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class Basic.STBuffCondition
// Size: 0x40 // Inherited bytes: 0x28
struct USTBuffCondition : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	enum class EBuffConditionAndOr AndOrPrev; // Offset: 0x30 // Size: 0x01
	bool IsKeepResult; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
	struct USTBuffAction* OwnerAction; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function Basic.STBuffCondition.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x103783c34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffCondition.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x103783c18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffCondition.GetOwner
	// Flags: [Final|Native|Protected]
	struct AActor* GetOwner(); // Offset: 0x103783be4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffCondition.GetCauser
	// Flags: [Final|Native|Protected]
	struct AActor* GetCauser(); // Offset: 0x103783bb0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffCondition.Copy
	// Flags: [Native|Public]
	struct USTBuffCondition* Copy(struct UObject* Outer); // Offset: 0x103783b1c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffCondition.CheckIsTrue
	// Flags: [Native|Protected]
	bool CheckIsTrue(); // Offset: 0x103783ae0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.STBaseBuffManager
// Size: 0x188 // Inherited bytes: 0x28
struct USTBaseBuffManager : UObject {
	// Fields
	struct TArray<struct FSTBaseBuffTemplateItem> BuffList; // Offset: 0x28 // Size: 0x10
	struct TArray<struct USTBaseBuffList*> BuffListTemplates; // Offset: 0x38 // Size: 0x10
	struct TMap<int, struct USTBaseBuff*> BuffInstancedTemplateMap; // Offset: 0x48 // Size: 0x50
	char pad_0x98[0xf0]; // Offset: 0x98 // Size: 0xf0
};

// Object Name: Class Basic.STBaseBuffStatusType
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffStatusType : UObject {
};

// Object Name: Class Basic.STBaseBuffSystemComponent
// Size: 0x288 // Inherited bytes: 0x110
struct USTBaseBuffSystemComponent : UActorComponent {
	// Fields
	char pad_0x110[0x50]; // Offset: 0x110 // Size: 0x50
	struct FScriptMulticastDelegate OnBuffAttached; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate OnBuffDetached; // Offset: 0x170 // Size: 0x10
	char pad_0x180[0x58]; // Offset: 0x180 // Size: 0x58
	struct TArray<struct FUTBuffSynData> BuffSyncList; // Offset: 0x1d8 // Size: 0x10
	struct FString ServerBuffString; // Offset: 0x1e8 // Size: 0x10
	float BuffSyncRemainingPeriod; // Offset: 0x1f8 // Size: 0x04
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
	struct TArray<struct FBuffInstancedItem> AllBuffs; // Offset: 0x200 // Size: 0x10
	char pad_0x210[0x8]; // Offset: 0x210 // Size: 0x08
	bool isNeedCheckValidation; // Offset: 0x218 // Size: 0x01
	char pad_0x219[0x6f]; // Offset: 0x219 // Size: 0x6f

	// Functions

	// Object Name: Function Basic.STBaseBuffSystemComponent.SetBuffExpiry
	// Flags: [Final|Native|Public]
	bool SetBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x103781094 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ResetForDeath
	// Flags: [Final|Native|Public]
	void ResetForDeath(); // Offset: 0x103781080 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RepBuffSyncList
	// Flags: [Final|Native|Public]
	void RepBuffSyncList(); // Offset: 0x10378106c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuffWithCauser
	// Flags: [Final|Native|Public]
	bool RemoveBuffWithCauser(struct FName BuffName, bool RemoveLayerOnly, struct AController* pCauser); // Offset: 0x103780f60 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuffByID
	// Flags: [Final|Native|Public]
	bool RemoveBuffByID(int BuffID, bool RemoveLayerOnly, struct AController* pCauser, struct AActor* BuffApplierActor); // Offset: 0x103780e1c // Return & Params: Num(5) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RemoveBuff
	// Flags: [Final|Native|Public]
	bool RemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x103780d10 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffSystemComponent.RefreshAllBuffs
	// Flags: [Native|Public]
	void RefreshAllBuffs(); // Offset: 0x103780cf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBaseBuffSystemComponent.IsBufferMutexed
	// Flags: [Final|Native|Public]
	bool IsBufferMutexed(struct FName NewBuffName); // Offset: 0x103780c68 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffSystemComponent.HasBuffID
	// Flags: [Final|Native|Public]
	bool HasBuffID(int BuffID); // Offset: 0x103780bdc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBaseBuffSystemComponent.HasBuff
	// Flags: [Final|Native|Public]
	bool HasBuff(struct FName BuffName); // Offset: 0x103780b50 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetPawnOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APawn* GetPawnOwner(); // Offset: 0x103780b1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffName
	// Flags: [Final|Native|Public]
	struct FName GetBuffName(int BuffID); // Offset: 0x103780a90 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffID
	// Flags: [Final|Native|Public]
	int GetBuffID(struct FName BuffName); // Offset: 0x103780a04 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffExpiry
	// Flags: [Final|Native|Public|HasOutParms]
	float GetBuffExpiry(struct FName& BuffName); // Offset: 0x103780968 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetBuffByName
	// Flags: [Final|Native|Public]
	struct USTBaseBuff* GetBuffByName(struct FName BuffName); // Offset: 0x1037808dc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffSystemComponent.GetActorOwner
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetActorOwner(); // Offset: 0x1037808a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientSimulateRemoveBuff
	// Flags: [Final|Native|Public]
	void ClientSimulateRemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1037807a4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientSimulateAddBuff
	// Flags: [Final|Native|Public]
	void ClientSimulateAddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x103780678 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSimulateRemoveBuff
	// Flags: [Final|Native|Public]
	void ClientMulticastSimulateRemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x103780574 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSimulateAddBuff
	// Flags: [Final|Native|Public]
	void ClientMulticastSimulateAddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x103780448 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClientMulticastSetBuffExpiry
	// Flags: [Final|Native|Public]
	void ClientMulticastSetBuffExpiry(struct FName BuffName, float LeftSecondsAfterNow); // Offset: 0x103780390 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffSystemComponent.ClearBuff
	// Flags: [Final|Native|Public]
	void ClearBuff(bool bDebuff, bool bGainBuff); // Offset: 0x1037802c0 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.STBaseBuffSystemComponent.CheckBuffStatus
	// Flags: [Final|Native|Public|HasOutParms]
	bool CheckBuffStatus(struct USTBaseBuffStatusType* Status, bool& Value); // Offset: 0x1037801e8 // Return & Params: Num(3) Size(0xa)

	// Object Name: DelegateFunction Basic.STBaseBuffSystemComponent.BuffDetached__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void BuffDetached__DelegateSignature(struct FName& BuffName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Basic.STBaseBuffSystemComponent.BuffAttached__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void BuffAttached__DelegateSignature(struct FName& BuffName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffLayer
	// Flags: [Final|Native|Public]
	bool AddBuffLayer(struct FName BuffName, int layerNum); // Offset: 0x103780120 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffExpiry
	// Flags: [Final|Native|Public]
	bool AddBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x103780058 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuffByID
	// Flags: [Native|Public]
	int AddBuffByID(int BuffID, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor); // Offset: 0x10377ff10 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function Basic.STBaseBuffSystemComponent.AddBuff
	// Flags: [Final|Native|Public]
	int AddBuff(struct FName BuffName, struct AController* BuffCauser, int LayerCount, struct AActor* BuffApplierActor, struct AActor* CauserActor); // Offset: 0x10377fd9c // Return & Params: Num(6) Size(0x2c)
};

// Object Name: Class Basic.STBaseBuffTriggerParam
// Size: 0x30 // Inherited bytes: 0x28
struct USTBaseBuffTriggerParam : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class Basic.UAEGameInstance
// Size: 0x508 // Inherited bytes: 0x2a0
struct UUAEGameInstance : UGameInstance {
	// Fields
	struct FClientBaseInfo ClientBaseInfo; // Offset: 0x2a0 // Size: 0x178
	struct FScriptMulticastDelegate EnginePreTick; // Offset: 0x418 // Size: 0x10
	char pad_0x428[0x68]; // Offset: 0x428 // Size: 0x68
	struct UFrontendHUD* AssociatedFrontendHUD; // Offset: 0x490 // Size: 0x08
	char pad_0x498[0x8]; // Offset: 0x498 // Size: 0x08
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x4a0 // Size: 0x08
	bool bStandAloneFromLobby; // Offset: 0x4a8 // Size: 0x01
	char pad_0x4A9[0x27]; // Offset: 0x4a9 // Size: 0x27
	struct FScriptMulticastDelegate OnPreBattleResult; // Offset: 0x4d0 // Size: 0x10
	char pad_0x4E0[0x10]; // Offset: 0x4e0 // Size: 0x10
	struct TArray<struct FString> HighWeatherNames; // Offset: 0x4f0 // Size: 0x10
	int HighWeatherMinRenderQuality; // Offset: 0x500 // Size: 0x04
	int HighWeatherMaxRenderQuality; // Offset: 0x504 // Size: 0x04

	// Functions

	// Object Name: Function Basic.UAEGameInstance.SetLuaStateWrapper
	// Flags: [Final|Native|Public]
	void SetLuaStateWrapper(struct ULuaStateWrapper* TLuaStateWrapper); // Offset: 0x10378ac10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.OpenAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	void OpenAssetLoadLog(); // Offset: 0x10378abfc // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.UAEGameInstance.OnPreBattleResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPreBattleResult__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAEGameInstance.LuaLeakDetect
	// Flags: [Final|Exec|Native|Public|Const]
	void LuaLeakDetect(); // Offset: 0x10378abe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAEGameInstance.LuaDoString
	// Flags: [Final|Exec|Native|Public|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x10378ab50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetWeatherTime(); // Offset: 0x10378ab34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherLevelName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetWeatherLevelName(); // Offset: 0x10378aacc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetWeatherID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetWeatherID(); // Offset: 0x10378aab0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetLuaStateWrapper
	// Flags: [Final|Native|Public]
	struct ULuaStateWrapper* GetLuaStateWrapper(); // Offset: 0x10378aa7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.GetLoadWeatherName
	// Flags: [Native|Public|BlueprintCallable]
	struct FString GetLoadWeatherName(struct FString InWeatherName); // Offset: 0x10378a9a4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.UAEGameInstance.GetIsHighWeatherLevel
	// Flags: [Native|Public|BlueprintCallable]
	bool GetIsHighWeatherLevel(struct FString InWeatherLevelName); // Offset: 0x10378a8f4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UAEGameInstance.GetGameId
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetGameId(); // Offset: 0x10378a880 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAEGameInstance.GetDeviceLevel
	// Flags: [Native|Public|BlueprintCallable]
	int GetDeviceLevel(); // Offset: 0x10378a844 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.UAEGameInstance.GetDataTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable_Mod(struct FString tableName); // Offset: 0x10378a79c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAEGameInstance.GetDataTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable(struct FString tableName); // Offset: 0x10378a6f4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAEGameInstance.GetAssociatedFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetAssociatedFrontendHUD(); // Offset: 0x10378a6c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAEGameInstance.CloseAssetLoadLog
	// Flags: [Final|Exec|Native|Public]
	void CloseAssetLoadLog(); // Offset: 0x10378a6ac // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.UAENetBunchQueueSystem
// Size: 0x30 // Inherited bytes: 0x30
struct UUAENetBunchQueueSystem : UWorldSubsystem {
};

// Object Name: Class Basic.AttrModifyComponent
// Size: 0x6c0 // Inherited bytes: 0x110
struct UAttrModifyComponent : UActorComponent {
	// Fields
	char pad_0x110[0x148]; // Offset: 0x110 // Size: 0x148
	struct TArray<struct FAttrModifyItem> ConfigAttrModifyList; // Offset: 0x258 // Size: 0x10
	uint32_t AttrModifyStateList; // Offset: 0x268 // Size: 0x04
	char pad_0x26C[0x74]; // Offset: 0x26c // Size: 0x74
	struct FRepAttributeModify DynamicModifierRep; // Offset: 0x2e0 // Size: 0x18
	struct FRepAttributeModify DynamicModifierRepOnlyOwner; // Offset: 0x2f8 // Size: 0x18
	char pad_0x310[0x20]; // Offset: 0x310 // Size: 0x20
	struct FScriptMulticastDelegate OnAttrModified; // Offset: 0x330 // Size: 0x10
	struct FAttrDynamicModifier DynamicModifier; // Offset: 0x340 // Size: 0xa8
	char pad_0x3E8[0x50]; // Offset: 0x3e8 // Size: 0x50
	struct TArray<struct FAttributeExpand> AttributeExpands; // Offset: 0x438 // Size: 0x10
	struct TMap<struct FString, struct FRelateAttributeGroup> RelateAttributeGroup; // Offset: 0x448 // Size: 0x50
	enum class EActorRegAttrTableType ActorAttrType; // Offset: 0x498 // Size: 0x01
	char pad_0x499[0x10f]; // Offset: 0x499 // Size: 0x10f
	struct TArray<struct FModAttrSimulateSyncItem> ModSimulateSyncList; // Offset: 0x5a8 // Size: 0x10
	char pad_0x5B8[0x108]; // Offset: 0x5b8 // Size: 0x108

	// Functions

	// Object Name: Function Basic.AttrModifyComponent.SetValueToAttributeSafety
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValueToAttributeSafety(struct FString AttrName, float Value); // Offset: 0x10376a1a0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.SetOrignalValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOrignalValueToAttribute(struct FString AttrName, float Value); // Offset: 0x10376a0c8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.SetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	void SetAttrModifyStateValue(int Index, bool Value); // Offset: 0x10376a00c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.SetAttributeMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttributeMaxValue(struct FString AttrName, float MaxValue); // Offset: 0x103769f34 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.ResponeAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ResponeAttrValue(struct FString AttrName, float FinalValue); // Offset: 0x103769e28 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.RequestAttrValue
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RequestAttrValue(struct FString AttrName); // Offset: 0x103769d60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyComponent.RemoveModifyItemFromCache
	// Flags: [Final|Native|Public]
	bool RemoveModifyItemFromCache(uint32_t ModifyUID); // Offset: 0x103769cd4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.RegisterModifyAbleAttr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool RegisterModifyAbleAttr(struct TArray<struct FAttrRegisterItem>& AttrRegists, bool bSetAttrByOrigin); // Offset: 0x103769bd0 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_ModSimulateSyncList
	// Flags: [Final|Native|Public]
	void OnRep_ModSimulateSyncList(); // Offset: 0x103769bbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_DynamicModifier
	// Flags: [Final|Native|Public]
	void OnRep_DynamicModifier(); // Offset: 0x103769ba8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyComponent.OnRep_AttrModifyStateList
	// Flags: [Final|Native|Public]
	void OnRep_AttrModifyStateList(); // Offset: 0x103769b94 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.AttrModifyComponent.OnAttrModifiedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnAttrModifiedEvent__DelegateSignature(struct TArray<struct FAttrAffected>& AffectedAttrS); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyComponent.IsAttrModifyStateValidIndex
	// Flags: [Final|Native|Public]
	bool IsAttrModifyStateValidIndex(int Index); // Offset: 0x103769b08 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.HasDynamicModifier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasDynamicModifier(struct FString AttrModifyId); // Offset: 0x103769a60 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	struct UAttrModifyModDataSubsystem* GetSubsystem(); // Offset: 0x103769a2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.AttrModifyComponent.GetMaxAttrName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetMaxAttrName(struct FString AttrName); // Offset: 0x10376995c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyStateValue
	// Flags: [Final|Native|Public]
	bool GetAttrModifyStateValue(int Index); // Offset: 0x1037698d0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyStateNum
	// Flags: [Final|Native|Public]
	int GetAttrModifyStateNum(); // Offset: 0x1037698b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.AttrModifyComponent.GetAttrModifyItemByItemName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FAttrModifyItem GetAttrModifyItemByItemName(struct FString ItemName); // Offset: 0x1037697c0 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Basic.AttrModifyComponent.GetAttributeValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttributeValue(struct FString AttrName); // Offset: 0x103769718 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.GetAttributeOrignalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttributeOrignalValue(struct FString AttrName); // Offset: 0x103769670 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.EnableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableAttrModifierByIndex(int ModifyConfigIndex); // Offset: 0x1037695e4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.EnableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableAttrModifier(struct FString AttrModifyItemName); // Offset: 0x103769518 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.DisableAttrModifierByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAttrModifierByIndex(int ModifyConfigIndex); // Offset: 0x10376948c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.AttrModifyComponent.DisableAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAttrModifier(struct FString AttrModifyItemName); // Offset: 0x1037693c0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.AttrModifyComponent.DisableAllAttrModifier
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DisableAllAttrModifier(); // Offset: 0x10376938c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.AttrModifyComponent.AddValueToAttribute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddValueToAttribute(struct FString AttrName, float Value); // Offset: 0x1037692b4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyComponent.AddModifyItemAndCache
	// Flags: [Final|Native|Public]
	uint32_t AddModifyItemAndCache(struct FString AttrName, enum class EAttrModifyRefType CModifyType, float CValue, bool bEnable, struct UObject* Causer, bool oldModify); // Offset: 0x1037690bc // Return & Params: Num(7) Size(0x30)

	// Object Name: Function Basic.AttrModifyComponent.AddDynamicModifier
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddDynamicModifier(struct FAttrModifyItem& AttrModifyItem, bool RepOnlyOwner); // Offset: 0x103768fbc // Return & Params: Num(2) Size(0x49)

	// Object Name: Function Basic.AttrModifyComponent.AddBModifyAndCacheWithCParam
	// Flags: [Final|Native|Public]
	uint32_t AddBModifyAndCacheWithCParam(struct FString AttrName, enum class EAttrModifyRefType CModifyType, float CValue); // Offset: 0x103768e94 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Basic.AttrModifyComponent.AddBModifyAndCache
	// Flags: [Final|Native|Public]
	uint32_t AddBModifyAndCache(struct FString AttrName, enum class EAttrOperator ModifyType, float Value); // Offset: 0x103768d6c // Return & Params: Num(4) Size(0x1c)
};

// Object Name: Class Basic.AttrModifyInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAttrModifyInterface : UInterface {
	// Functions

	// Object Name: Function Basic.AttrModifyInterface.SetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void SetAttrValue(struct FString AttrName, float NewVal, int Reason); // Offset: 0x10376afa8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.AttrModifyInterface.RequestAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void RequestAttrValue(struct FString AttrName); // Offset: 0x10376af08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyInterface.RegisterModifiedAttributes
	// Flags: [Native|Public|BlueprintCallable]
	void RegisterModifiedAttributes(); // Offset: 0x10376aeec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	float GetAttrValue(struct FString AttrName); // Offset: 0x10376ae3c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrModifyRelevantActors
	// Flags: [Native|Public|BlueprintCallable]
	struct TArray<struct AActor*> GetAttrModifyRelevantActors(); // Offset: 0x10376add0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.AttrModifyInterface.GetAttrModifyComponent
	// Flags: [Native|Public|BlueprintCallable]
	struct UAttrModifyComponent* GetAttrModifyComponent(); // Offset: 0x10376ad94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.AttrModifyInterface.GetAttributeValue
	// Flags: [Native|Public|BlueprintCallable]
	float GetAttributeValue(struct FString AttrName); // Offset: 0x10376ace4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.AttrModifyInterface.AddAttrValue
	// Flags: [Native|Public|BlueprintCallable]
	void AddAttrValue(struct FString AttrName, float AddVal, int Reason); // Offset: 0x10376abc4 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Basic.AttrModifyModDataSubsystem
// Size: 0x188 // Inherited bytes: 0x30
struct UAttrModifyModDataSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x158]; // Offset: 0x30 // Size: 0x158
};

// Object Name: Class Basic.BlueprintFunctionOverride
// Size: 0x98 // Inherited bytes: 0x28
struct UBlueprintFunctionOverride : UBlueprintFunctionLibrary {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class Basic.BPClassManager
// Size: 0x190 // Inherited bytes: 0x30
struct UBPClassManager : UDataAsset {
	// Fields
	struct TArray<struct FBPClassItem> BPClassList; // Offset: 0x30 // Size: 0x10
	struct TMap<struct UObject*, struct UClass*> BPClassLookUp; // Offset: 0x40 // Size: 0x50
	struct TMap<struct UObject*, struct FBPClassItemMap> BPClassLookUpOverride; // Offset: 0x90 // Size: 0x50
	struct TMap<struct FString, struct UClass*> BPClassNameLookUp; // Offset: 0xe0 // Size: 0x50
	struct TMap<struct FString, struct FBPClassItemMap> BPClassNameLookUpOverride; // Offset: 0x130 // Size: 0x50
	struct FString BPClassManagerPath; // Offset: 0x180 // Size: 0x10

	// Functions

	// Object Name: Function Basic.BPClassManager.ModifyClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyClass(struct UObject* InNativeClass, struct UClass* BPClass, struct FString ModTag); // Offset: 0x1037737a4 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function Basic.BPClassManager.GetUClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetUClass(int KeyIndex); // Offset: 0x103773718 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPClassManager.GetBPClassOverrideByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetBPClassOverrideByName(struct FString ClassTagName, struct FString ModTag); // Offset: 0x1037735d4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.BPClassManager.GetBPClassOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetBPClassOverride(struct UObject* InNativeClass, struct FString ModTag); // Offset: 0x1037734c8 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.BPClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UBPClassManager* Get(); // Offset: 0x103773494 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.BuffUtils
// Size: 0x28 // Inherited bytes: 0x28
struct UBuffUtils : UBlueprintFunctionLibrary {
};

// Object Name: Class Basic.DataSearcherInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDataSearcherInterface : UInterface {
};

// Object Name: Class Basic.DelayReplicationInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UDelayReplicationInterface : UInterface {
	// Functions

	// Object Name: Function Basic.DelayReplicationInterface.ReSendRPCAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	void ReSendRPCAfterBeginPlay(); // Offset: 0x103773f40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.DelayReplicationInterface.ReCallRepAfterBeginPlay
	// Flags: [Native|Public|BlueprintCallable]
	void ReCallRepAfterBeginPlay(); // Offset: 0x103773f24 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.FeatureSetDefine
// Size: 0x28 // Inherited bytes: 0x28
struct UFeatureSetDefine : UObject {
};

// Object Name: Class Basic.PathCompressionRef
// Size: 0x58 // Inherited bytes: 0x30
struct UPathCompressionRef : UDataAsset {
	// Fields
	struct FString Dict; // Offset: 0x30 // Size: 0x10
	struct FSoftObjectPath DataTableRef; // Offset: 0x40 // Size: 0x18
};

// Object Name: Class Basic.GameModeEnvInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGameModeEnvInterface : UInterface {
};

// Object Name: Class Basic.ItemContainerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UItemContainerInterface : UInterface {
	// Functions

	// Object Name: Function Basic.ItemContainerInterface.GetOwningObject
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetOwningObject(); // Offset: 0x103775630 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.ItemContainerInterface.GetItemHandleListByDefineID
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct UItemHandleBase*> GetItemHandleListByDefineID(struct FItemDefineID& DefineID); // Offset: 0x103775560 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Basic.ItemContainerInterface.GetItemHandleByDefineID
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct UItemHandleBase* GetItemHandleByDefineID(struct FItemDefineID& DefineID); // Offset: 0x1037754b8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Basic.ItemContainerInterface.GetItemDefineIDList
	// Flags: [Native|Public|BlueprintCallable]
	struct TArray<struct FItemDefineID> GetItemDefineIDList(); // Offset: 0x10377544c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Basic.ItemFactoryInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UItemFactoryInterface : UInterface {
};

// Object Name: Class Basic.LuaEventBridgeFunction
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaEventBridgeFunction : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.LuaEventBridgeFunction.UnRegisterEventByTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnRegisterEventByTarget(struct UObject* ObjContext); // Offset: 0x1037760ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.LuaEventBridgeFunction.UnRegisterEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnRegisterEvent(struct FString FEventType, struct FString EventId, struct UObject* ObjContext, int EventHandle); // Offset: 0x103775f88 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Basic.LuaEventBridgeFunction.RegistEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int RegistEvent(struct FString EventType, struct FString EventId, struct UObject* ObjContext, struct FString FunctionName); // Offset: 0x103775e08 // Return & Params: Num(5) Size(0x3c)
};

// Object Name: Class Basic.LuaEventBridge
// Size: 0x158 // Inherited bytes: 0x28
struct ULuaEventBridge : UObject {
	// Fields
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
	struct TMap<struct FString, struct FEventTypeContainer> RegisterEventMap; // Offset: 0x38 // Size: 0x50
	struct TMap<struct FString, struct FLuaEventTypeContainer> LuaRegisterEventMap; // Offset: 0x88 // Size: 0x50
	struct TMap<uint32_t, struct FLuaEventTypeToIDSet> FilterKeyRegisterMap; // Offset: 0xd8 // Size: 0x50
	struct TArray<struct ULuaTemBPData*> CurrentParamArray; // Offset: 0x128 // Size: 0x10
	struct TArray<struct UProperty*> Params; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x10]; // Offset: 0x148 // Size: 0x10

	// Functions

	// Object Name: Function Basic.LuaEventBridge.SyncLuaRegisterEventNum
	// Flags: [Final|Native|Public]
	void SyncLuaRegisterEventNum(struct FString EventType, struct FString EventId, int Number); // Offset: 0x103776718 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.LuaEventBridge.GetCurrentParam
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct ULuaTemBPData*> GetCurrentParam(); // Offset: 0x1037766e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.LuaEventBridge.DeactivateEventsByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	void DeactivateEventsByFilterKey(uint32_t& FilterKey); // Offset: 0x103776654 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.LuaEventBridge.CheckNeedPostEventWithFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	bool CheckNeedPostEventWithFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventId, bool bCheckNeedPostLua); // Offset: 0x1037764c0 // Return & Params: Num(5) Size(0x2a)

	// Object Name: Function Basic.LuaEventBridge.ActiveEventByFilterKey
	// Flags: [Final|Native|Public|HasOutParms]
	void ActiveEventByFilterKey(uint32_t& FilterKey, struct FString EventType, struct FString EventId, bool bActive); // Offset: 0x103776334 // Return & Params: Num(4) Size(0x29)
};

// Object Name: Class Basic.LuaEventSubsystem
// Size: 0x160 // Inherited bytes: 0x30
struct ULuaEventSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x80]; // Offset: 0x30 // Size: 0x80
	struct TArray<struct ULuaTemBPData*> CurrentParamArray; // Offset: 0xb0 // Size: 0x10
	char pad_0xC0[0xa0]; // Offset: 0xc0 // Size: 0xa0

	// Functions

	// Object Name: Function Basic.LuaEventSubsystem.UnRegistEvent
	// Flags: [Final|Native|Public]
	void UnRegistEvent(int EventHandle); // Offset: 0x103776e90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.LuaEventSubsystem.SetBridgeFunction
	// Flags: [Final|Native|Public]
	void SetBridgeFunction(struct FSluaBPVar OnRegistEvent, struct FSluaBPVar OnUnRegistEvent, struct FSluaBPVar OnPostEvent, struct FSluaBPVar OnPostBlueprintEvent); // Offset: 0x103776c48 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Basic.LuaEventSubsystem.RegistEvent
	// Flags: [Final|Native|Public]
	int RegistEvent(struct FString EventId, struct FString EventType, struct UObject* Object, struct FString FunctionName); // Offset: 0x103776ab8 // Return & Params: Num(5) Size(0x3c)
};

// Object Name: Class Basic.ModTable
// Size: 0x120 // Inherited bytes: 0x28
struct UModTable : UObject {
	// Fields
	char pad_0x28[0xf8]; // Offset: 0x28 // Size: 0xf8
};

// Object Name: Class Basic.NetRelevancyGroup
// Size: 0x60 // Inherited bytes: 0x28
struct UNetRelevancyGroup : UObject {
	// Fields
	struct FNetRelevancyGroupID GroupID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct UUAENetConnection*> Connections; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x20]; // Offset: 0x40 // Size: 0x20
};

// Object Name: Class Basic.OnlyActorCompManagerComponent
// Size: 0x170 // Inherited bytes: 0x110
struct UOnlyActorCompManagerComponent : UActorComponent {
	// Fields
	struct TMap<struct FString, struct UOnlyActorComponent*> CacheComponents; // Offset: 0x110 // Size: 0x50
	struct TArray<struct UOnlyActorComponent*> CacheUpdateComponents; // Offset: 0x160 // Size: 0x10
};

// Object Name: Class Basic.OnlyActorComponentManagerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UOnlyActorComponentManagerInterface : UInterface {
};

// Object Name: Class Basic.OwnerRelevancyDependencyInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UOwnerRelevancyDependencyInterface : UInterface {
};

// Object Name: Class Basic.RenderFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct URenderFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.RenderFunctionLibrary.MarkComponentRenderStateDirty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MarkComponentRenderStateDirty(struct UActorComponent* Comp); // Offset: 0x103777838 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Basic.RepPropertyModOptim
// Size: 0x88 // Inherited bytes: 0x28
struct URepPropertyModOptim : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
};

// Object Name: Class Basic.STBaseBuff
// Size: 0x198 // Inherited bytes: 0x28
struct USTBaseBuff : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FString BuffName; // Offset: 0x38 // Size: 0x10
	struct FString DisplayName; // Offset: 0x48 // Size: 0x10
	struct FString Message; // Offset: 0x58 // Size: 0x10
	struct UTexture2D* Icon; // Offset: 0x68 // Size: 0x08
	struct USoundBase* SoundData; // Offset: 0x70 // Size: 0x08
	bool IsDeBuff; // Offset: 0x78 // Size: 0x01
	bool IgnoreMagicalImmunity; // Offset: 0x79 // Size: 0x01
	bool bAllowOtherPawnRefreshBuff; // Offset: 0x7a // Size: 0x01
	bool Layerable; // Offset: 0x7b // Size: 0x01
	bool NeedDetachAndAttachForReplaceExit; // Offset: 0x7c // Size: 0x01
	bool NeedDetachAndAttachForAddLayer; // Offset: 0x7d // Size: 0x01
	bool ReplaceExsist; // Offset: 0x7e // Size: 0x01
	bool StaysOnDeath; // Offset: 0x7f // Size: 0x01
	int LayerMax; // Offset: 0x80 // Size: 0x04
	int InitialLayerCount; // Offset: 0x84 // Size: 0x04
	int LayerCount; // Offset: 0x88 // Size: 0x04
	float ValidityTime; // Offset: 0x8c // Size: 0x04
	float Internal; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct TArray<struct UUTSkillCondition*> BuffConditions; // Offset: 0x98 // Size: 0x10
	float Expiry; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct TArray<struct FStatusChange> StatusChanges; // Offset: 0xb0 // Size: 0x10
	bool NeedSimulateToClientMulticast; // Offset: 0xc0 // Size: 0x01
	bool NeedSimulateToClient; // Offset: 0xc1 // Size: 0x01
	enum class ESimulateAddBuffRole SimulateAddBuffRole; // Offset: 0xc2 // Size: 0x01
	char pad_0xC3[0x5]; // Offset: 0xc3 // Size: 0x05
	struct TArray<struct FName> MutexBuffers; // Offset: 0xc8 // Size: 0x10
	struct TArray<struct FBuffActionItem> BuffActions; // Offset: 0xd8 // Size: 0x10
	struct TArray<struct FBuffEventActionItem> EventBuffActions; // Offset: 0xe8 // Size: 0x10
	float fADScale; // Offset: 0xf8 // Size: 0x04
	float fAPScale; // Offset: 0xfc // Size: 0x04
	bool IsAlwaysExists; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct AController* CauserPawnController; // Offset: 0x108 // Size: 0x08
	struct AActor* CauserPawnActor; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x10]; // Offset: 0x118 // Size: 0x10
	struct TArray<struct FUAEBlackboardParameter> UAEBlackboardParamList; // Offset: 0x128 // Size: 0x10
	struct AActor* BuffApplier; // Offset: 0x138 // Size: 0x08
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0x140 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x190 // Size: 0x04
	char pad_0x194[0x4]; // Offset: 0x194 // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffCarrierInterface
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffCarrierInterface : UInterface {
	// Functions

	// Object Name: Function Basic.STBaseBuffCarrierInterface.SyncInvincibleData
	// Flags: [Native|Public]
	void SyncInvincibleData(float TotalTime); // Offset: 0x103778e08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.SetBuffExpiry
	// Flags: [Native|Public]
	bool SetBuffExpiry(struct FName BuffName, float ExpirySecondsFromNow); // Offset: 0x103778d38 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuffBySkill
	// Flags: [Native|Public]
	bool RemoveBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer); // Offset: 0x103778c30 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuffByID
	// Flags: [Native|Public]
	bool RemoveBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID); // Offset: 0x103778aec // Return & Params: Num(5) Size(0x19)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.RemoveBuff
	// Flags: [Native|Public]
	bool RemoveBuff(struct FName BuffName, bool RemoveLayerOnly, struct AActor* BuffApplierActor); // Offset: 0x1037789d8 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.IsSameTeamWithFirstPC
	// Flags: [Native|Public]
	bool IsSameTeamWithFirstPC(); // Offset: 0x10377899c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.HasBuffID
	// Flags: [Native|Public]
	bool HasBuffID(int BuffID); // Offset: 0x103778908 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.HasBuff
	// Flags: [Native|Public]
	bool HasBuff(struct FName BuffName); // Offset: 0x103778874 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffExpiry
	// Flags: [Native|Public]
	float GetBuffExpiry(struct FName BuffName); // Offset: 0x1037787e0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffDuration
	// Flags: [Native|Public]
	float GetBuffDuration(int InstID, int CauseSkillID); // Offset: 0x103778714 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.GetBuffByName
	// Flags: [Native|Public]
	struct USTBaseBuff* GetBuffByName(struct FName BuffName); // Offset: 0x103778680 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.CheckBuffTarget
	// Flags: [Native|Public]
	bool CheckBuffTarget(struct USTBuff* Buff); // Offset: 0x1037785ec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.ChangeBuffDuration
	// Flags: [Native|Public]
	bool ChangeBuffDuration(int InstID, float Duration); // Offset: 0x10377851c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffLayer
	// Flags: [Native|Public]
	bool AddBuffLayer(struct FName BuffName, int layerNum); // Offset: 0x10377844c // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffExpiry
	// Flags: [Native|Public]
	bool AddBuffExpiry(struct FName BuffName, float ExpirySeconds); // Offset: 0x10377837c // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffBySkill
	// Flags: [Native|Public]
	bool AddBuffBySkill(int SkillID, int LayerCount, struct AActor* Causer, int Level); // Offset: 0x103778238 // Return & Params: Num(5) Size(0x15)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuffByID
	// Flags: [Native|Public]
	int AddBuffByID(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID, int Level); // Offset: 0x1037780b8 // Return & Params: Num(6) Size(0x20)

	// Object Name: Function Basic.STBaseBuffCarrierInterface.AddBuff
	// Flags: [Native|Public]
	int AddBuff(struct FName BuffName, struct AController* SkillActor, int LayerCount, struct AActor* BuffApplierActor, struct AActor* CauserActor); // Offset: 0x103777f3c // Return & Params: Num(6) Size(0x2c)
};

// Object Name: Class Basic.STBaseBuffConditionBase
// Size: 0x118 // Inherited bytes: 0x110
struct USTBaseBuffConditionBase : UActorComponent {
	// Fields
	struct TWeakObjectPtr<struct USTBaseBuff> OwnerBuff; // Offset: 0x110 // Size: 0x08
};

// Object Name: Class Basic.STBaseBuffEventType
// Size: 0x30 // Inherited bytes: 0x28
struct USTBaseBuffEventType : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class Basic.STBaseBuffEventType_LayerMax
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_LayerMax : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_LayerSpecific
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_LayerSpecific : USTBaseBuffEventType {
	// Fields
	int LayerCountParam; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffEventType_Removed
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_Removed : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_TakeBuffDamage
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_TakeBuffDamage : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_OnAttach
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_OnAttach : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_ConditionNotMatch
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_ConditionNotMatch : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_Resurrection
// Size: 0x30 // Inherited bytes: 0x30
struct USTBaseBuffEventType_Resurrection : USTBaseBuffEventType {
};

// Object Name: Class Basic.STBaseBuffEventType_WeaponAttack
// Size: 0x48 // Inherited bytes: 0x30
struct USTBaseBuffEventType_WeaponAttack : USTBaseBuffEventType {
	// Fields
	struct AActor* Attacter; // Offset: 0x30 // Size: 0x08
	struct AActor* Victim; // Offset: 0x38 // Size: 0x08
	int HitCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class Basic.STBaseBuffList
// Size: 0x48 // Inherited bytes: 0x28
struct USTBaseBuffList : UObject {
	// Fields
	struct FString BuffListName; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FSTBaseBuffTemplateItem> BuffList; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class Basic.BuffManagerPathClass
// Size: 0x3e0 // Inherited bytes: 0x3c0
struct ABuffManagerPathClass : AActor {
	// Fields
	struct FString BuffManagerBlueprintPath; // Offset: 0x3c0 // Size: 0x10
	struct TArray<struct FBuffManagerModPath> BuffListPathMap; // Offset: 0x3d0 // Size: 0x10
};

// Object Name: Class Basic.STBaseBuffStatusType_ImmuneDebuff
// Size: 0x28 // Inherited bytes: 0x28
struct USTBaseBuffStatusType_ImmuneDebuff : USTBaseBuffStatusType {
};

// Object Name: Class Basic.STBuff
// Size: 0x158 // Inherited bytes: 0x28
struct USTBuff : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	int BuffID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString BuffName; // Offset: 0x38 // Size: 0x10
	struct FString Desc; // Offset: 0x48 // Size: 0x10
	int LayerMax; // Offset: 0x58 // Size: 0x04
	int InitialLayerCount; // Offset: 0x5c // Size: 0x04
	float Duration; // Offset: 0x60 // Size: 0x04
	float ClientSyncInterval; // Offset: 0x64 // Size: 0x04
	enum class EBuffClientSyncType ClientSyncType; // Offset: 0x68 // Size: 0x01
	enum class EBuffTargetType TargetType; // Offset: 0x69 // Size: 0x01
	enum class EBuffRefreshType RefreshType; // Offset: 0x6a // Size: 0x01
	enum class EBuffReActionType ReActionType; // Offset: 0x6b // Size: 0x01
	enum class EMultiCauserHandleType MultiCauserHandleType; // Offset: 0x6c // Size: 0x01
	enum class EMultiSkillHandleType MultiSkillHandleType; // Offset: 0x6d // Size: 0x01
	bool IsExecuteOnece; // Offset: 0x6e // Size: 0x01
	bool RemoveAllLayer; // Offset: 0x6f // Size: 0x01
	struct TArray<struct USTBuffAction*> Actions; // Offset: 0x70 // Size: 0x10
	bool bNeedShowBuffInBuffList; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int LocalizeDescID; // Offset: 0x84 // Size: 0x04
	struct FString IconPath; // Offset: 0x88 // Size: 0x10
	bool IsClientOwnLife; // Offset: 0x98 // Size: 0x01
	bool ExistForever; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x2]; // Offset: 0x9a // Size: 0x02
	int TipsOnAddBuff; // Offset: 0x9c // Size: 0x04
	struct TArray<struct UDataProviderBase*> DataProviders; // Offset: 0xa0 // Size: 0x10
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0xb0 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x54]; // Offset: 0x104 // Size: 0x54

	// Functions

	// Object Name: Function Basic.STBuff.Tick
	// Flags: [Final|Native|Public]
	void Tick(struct UActorComponent* BuffSystemComponent, int InstID, float DetalTime, float TimeSeconds); // Offset: 0x103781e90 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Basic.STBuff.ResetActionExecute
	// Flags: [Final|Native|Public]
	void ResetActionExecute(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103781dd8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuff.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103781d20 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuff.End
	// Flags: [Final|Native|Public]
	void End(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103781c68 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuff.Destroy
	// Flags: [Final|Native|Public]
	void Destroy(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103781bb0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuff.CopyActions
	// Flags: [Final|Native|Public]
	bool CopyActions(); // Offset: 0x103781b7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.STBuff.ChangeNotify
	// Flags: [Final|Native|Public]
	void ChangeNotify(struct UActorComponent* BuffSystemComponent, int InstID); // Offset: 0x103781ac4 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class Basic.STBuffAction_Lua
// Size: 0x110 // Inherited bytes: 0x50
struct USTBuffAction_Lua : USTBuffAction {
	// Fields
	char pad_0x50[0x60]; // Offset: 0x50 // Size: 0x60
	struct TMap<struct FName, struct FString> ActionParams; // Offset: 0xb0 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffAction_Lua.OnTick
	// Flags: [Native|Public]
	void OnTick(float DetalTime); // Offset: 0x1037835c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffAction_Lua.OnInitialize
	// Flags: [Native|Public]
	void OnInitialize(); // Offset: 0x1037835a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnExecute
	// Flags: [Native|Public]
	void OnExecute(); // Offset: 0x103783588 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnEnd
	// Flags: [Native|Public]
	void OnEnd(); // Offset: 0x10378356c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnDestroy
	// Flags: [Native|Public]
	void OnDestroy(); // Offset: 0x103783550 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.OnChangeNotify
	// Flags: [Native|Public]
	void OnChangeNotify(); // Offset: 0x103783534 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffAction_Lua.GetVectorValue
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|Const]
	struct FVector GetVectorValue(struct FName& Key); // Offset: 0x103783490 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Basic.STBuffAction_Lua.GetStringValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct FString GetStringValue(struct FName& Key); // Offset: 0x1037833cc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.STBuffAction_Lua.GetIntValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	int GetIntValue(struct FName& Key); // Offset: 0x103783330 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction_Lua.GetFloatValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	float GetFloatValue(struct FName& Key); // Offset: 0x103783294 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Basic.STBuffAction_Lua.GetBoolValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValue(struct FName& Key); // Offset: 0x1037831f8 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Basic.STBuffConditionComplex
// Size: 0x50 // Inherited bytes: 0x40
struct USTBuffConditionComplex : USTBuffCondition {
	// Fields
	struct TArray<struct USTBuffCondition*> Conditions; // Offset: 0x40 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffConditionComplex.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x103783fe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionComplex.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x103783fcc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionComplex.Copy
	// Flags: [Native|Public]
	struct USTBuffCondition* Copy(struct UObject* Outer); // Offset: 0x103783f38 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffConditionComplex.CheckIsTrue
	// Flags: [Native|Protected]
	bool CheckIsTrue(); // Offset: 0x103783efc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.STBuffConditionAction
// Size: 0x78 // Inherited bytes: 0x50
struct USTBuffConditionAction : USTBuffAction {
	// Fields
	struct USTBuffCondition* Condition; // Offset: 0x50 // Size: 0x08
	float ConditionTickInterval; // Offset: 0x58 // Size: 0x04
	float Probality; // Offset: 0x5c // Size: 0x04
	enum class EBuffConditionExecuteTimeType ExecuteTimeType; // Offset: 0x60 // Size: 0x01
	bool IsDoOnFalse; // Offset: 0x61 // Size: 0x01
	bool IsNeedTick; // Offset: 0x62 // Size: 0x01
	bool IsSetFalseWhenExecute; // Offset: 0x63 // Size: 0x01
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<struct FBuffConditionActionItem> LinkActions; // Offset: 0x68 // Size: 0x10

	// Functions

	// Object Name: Function Basic.STBuffConditionAction.OnTick
	// Flags: [Native|Protected]
	void OnTick(float DetalTime); // Offset: 0x1037842b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffConditionAction.OnInitialize
	// Flags: [Native|Protected]
	void OnInitialize(); // Offset: 0x103784298 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnDestroy
	// Flags: [Native|Protected]
	void OnDestroy(); // Offset: 0x10378427c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnConditionTrue
	// Flags: [Final|Native|Protected]
	void OnConditionTrue(); // Offset: 0x103784268 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnConditionFalse
	// Flags: [Final|Native|Protected]
	void OnConditionFalse(); // Offset: 0x103784254 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.OnChangeNotify
	// Flags: [Native|Protected]
	void OnChangeNotify(); // Offset: 0x103784238 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffConditionAction.CheckCondition
	// Flags: [Final|Native|Protected]
	void CheckCondition(); // Offset: 0x103784224 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.STBuffSystemComponent
// Size: 0x508 // Inherited bytes: 0x110
struct USTBuffSystemComponent : UActorComponent {
	// Fields
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08
	float RPCSyncInterval; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct FScriptMulticastDelegate OnClientAddBuffEvent; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate OnClientRemoveBuffEvent; // Offset: 0x130 // Size: 0x10
	struct FScriptMulticastDelegate OnClientUpdateBuffEvent; // Offset: 0x140 // Size: 0x10
	struct FScriptMulticastDelegate OnAddBuffEvent; // Offset: 0x150 // Size: 0x10
	struct TMap<int, struct UUAEBlackboard*> BuffBlackboardMap; // Offset: 0x160 // Size: 0x50
	int SyncBriefNum; // Offset: 0x1b0 // Size: 0x04
	char pad_0x1B4[0x4]; // Offset: 0x1b4 // Size: 0x04
	struct FClientSyncBrief SyncBriefs[0x6]; // Offset: 0x1b8 // Size: 0xf0
	struct FClientSyncBrief SyncRefBriefs[0x6]; // Offset: 0x2a8 // Size: 0xf0
	struct TSet<int> BriefRemoveInstIds; // Offset: 0x398 // Size: 0x50
	char pad_0x3E8[0x120]; // Offset: 0x3e8 // Size: 0x120

	// Functions

	// Object Name: Function Basic.STBuffSystemComponent.UpdateClientBuff
	// Flags: [Final|Native|Protected]
	void UpdateClientBuff(int InstID, int BuffID, int LayerCount, int CauseSkillID, int Level, struct AActor* CauseActor, float DSEndTime); // Offset: 0x103785840 // Return & Params: Num(7) Size(0x24)

	// Object Name: Function Basic.STBuffSystemComponent.UpdateBriefs
	// Flags: [Final|Native|Protected]
	void UpdateBriefs(); // Offset: 0x10378582c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Server_ReqBriefs
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void RPC_Server_ReqBriefs(); // Offset: 0x1037857d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Client_SyncBrief
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void RPC_Client_SyncBrief(struct FClientSyncBrief Brief); // Offset: 0x103785728 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Basic.STBuffSystemComponent.RPC_Client_RspBriefs
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void RPC_Client_RspBriefs(struct TArray<struct FClientSyncBrief> Briefs); // Offset: 0x103785688 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveClientBuff
	// Flags: [Final|Native|Protected]
	void RemoveClientBuff(int InstID); // Offset: 0x10378560c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveBuff
	// Flags: [Final|Native|Public]
	void RemoveBuff(int BuffID, int LayerCount, struct AActor* Causer, int CauseSkillID); // Offset: 0x1037854dc // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Basic.STBuffSystemComponent.RemoveAllBuffs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAllBuffs(); // Offset: 0x1037854c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.STBuffSystemComponent.OnRep_SyncBriefs
	// Flags: [Final|Native|Public]
	void OnRep_SyncBriefs(); // Offset: 0x1037854b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientUpdateBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientRemoveBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnClientAddBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClientAddBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: DelegateFunction Basic.STBuffSystemComponent.OnAddBuffEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAddBuffEvent__DelegateSignature(int BuffID, int SkillID, bool IsExist, struct AActor* Causer); // Offset: 0x103e03170 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Basic.STBuffSystemComponent.HasSkillID
	// Flags: [Final|Native|Public]
	bool HasSkillID(int SkillID); // Offset: 0x103785428 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBuffSystemComponent.HasBuff
	// Flags: [Final|Native|Public]
	bool HasBuff(int BuffID); // Offset: 0x10378539c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Basic.STBuffSystemComponent.GetSubsystem
	// Flags: [Final|Native|Public]
	struct UBuffConfigSubsystem* GetSubsystem(); // Offset: 0x103785368 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.STBuffSystemComponent.GetSTBuffByBuffID
	// Flags: [Final|Native|Public]
	struct USTBuff* GetSTBuffByBuffID(int BuffID); // Offset: 0x1037852dc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffInfoByBuffID
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FBuffInstInfo> GetBuffInfoByBuffID(int BuffID); // Offset: 0x103785228 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffInfo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetBuffInfo(int InstID, struct FBuffInstInfo& OutBuff); // Offset: 0x103785144 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffDuration
	// Flags: [Final|Native|Public]
	float GetBuffDuration(int InstID, int CauseSkillID); // Offset: 0x103785080 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBuffSystemComponent.GetBuffDSEndTime
	// Flags: [Final|Native|Public]
	float GetBuffDSEndTime(int InstID, int CauseSkillID); // Offset: 0x103784fbc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Basic.STBuffSystemComponent.GetAllBuffInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FBuffInstInfo> GetAllBuffInfo(); // Offset: 0x103784f58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.STBuffSystemComponent.ClearBuffs
	// Flags: [Final|Native|Public]
	void ClearBuffs(bool bClearAll, bool bImmediately); // Offset: 0x103784e88 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Basic.STBuffSystemComponent.ChangeDuration
	// Flags: [Final|Native|Public]
	bool ChangeDuration(int InstID, float Duration); // Offset: 0x103784dc0 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Basic.STBuffSystemComponent.AddBuff
	// Flags: [Final|Native|Public]
	int AddBuff(int BuffID, struct AActor* Causer, int LayerCount, int CauseSkillID, int Level); // Offset: 0x103784c48 // Return & Params: Num(6) Size(0x20)
};

// Object Name: Class Basic.BuffConfigSubsystem
// Size: 0x160 // Inherited bytes: 0x30
struct UBuffConfigSubsystem : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x30]; // Offset: 0x30 // Size: 0x30
	struct TMap<int, struct FBuffTableRow> Table; // Offset: 0x60 // Size: 0x50
	struct TMap<struct FString, struct UObject*> BuffClassMap; // Offset: 0xb0 // Size: 0x50
	char pad_0x100[0x60]; // Offset: 0x100 // Size: 0x60
};

// Object Name: Class Basic.UStringMap
// Size: 0x78 // Inherited bytes: 0x28
struct UUStringMap : UObject {
	// Fields
	struct FStringMap Map; // Offset: 0x28 // Size: 0x50
};

// Object Name: Class Basic.STExtraNetPriorityConfig
// Size: 0xe8 // Inherited bytes: 0x30
struct USTExtraNetPriorityConfig : UWorldSubsystem {
	// Fields
	bool ExtraNetPriorityEnabled; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TMap<enum class ESTExtraNetPriorityFlags, float> ExtraNetPriorityFactor; // Offset: 0x38 // Size: 0x50
	bool EnemyExtraNetPriorityEnabled; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	float EnemyExtraNetPriorityFactor; // Offset: 0x8c // Size: 0x04
	struct TMap<enum class ESTExtraNetPriorityIssueID, enum class ESTExtraNetPriorityFlags> NetPriorityIssue; // Offset: 0x90 // Size: 0x50
	float MoveExtraNetPriorityVelocitySquared; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
};

// Object Name: Class Basic.STExtraNetPriorityInterface
// Size: 0x28 // Inherited bytes: 0x28
struct USTExtraNetPriorityInterface : UInterface {
};

// Object Name: Class Basic.DataTableRowDesc
// Size: 0x98 // Inherited bytes: 0x28
struct UDataTableRowDesc : UObject {
	// Fields
	char pad_0x28[0x70]; // Offset: 0x28 // Size: 0x70
};

// Object Name: Class Basic.DataTableProxy
// Size: 0xe0 // Inherited bytes: 0x28
struct UDataTableProxy : UObject {
	// Fields
	struct UDataTable* ModDataTable; // Offset: 0x28 // Size: 0x08
	struct UDataTable* DataTable; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0xa0]; // Offset: 0x38 // Size: 0xa0
	struct UDataTableRowDesc* Desc; // Offset: 0xd8 // Size: 0x08
};

// Object Name: Class Basic.TableManagerSubsystem
// Size: 0xd0 // Inherited bytes: 0x30
struct UTableManagerSubsystem : UGameInstanceSubsystem {
	// Fields
	struct FString BaseTableRelativeDir; // Offset: 0x30 // Size: 0x10
	struct FString ModTableRelativeDir; // Offset: 0x40 // Size: 0x10
	struct FString TableRelativeDir; // Offset: 0x50 // Size: 0x10
	struct FString ManualTableDirectory; // Offset: 0x60 // Size: 0x10
	struct FString CurrentModName; // Offset: 0x70 // Size: 0x10
	struct TMap<struct FString, struct UDataTableProxy*> TableCache; // Offset: 0x80 // Size: 0x50

	// Functions

	// Object Name: Function Basic.TableManagerSubsystem.SetModName
	// Flags: [Final|Native|Public]
	void SetModName(struct FString ModName); // Offset: 0x1037897cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableProxy
	// Flags: [Final|Native|Public]
	struct UDataTableProxy* GetTableProxy(struct FString tableName, bool bTempory); // Offset: 0x1037896dc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableDataField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetTableDataField(struct FString tableName, struct FTableRowBase& Key, struct FString Field, struct FTableRowBase& Out); // Offset: 0x103737b40 // Return & Params: Num(5) Size(0x31)

	// Object Name: Function Basic.TableManagerSubsystem.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow); // Offset: 0x103789560 // Return & Params: Num(4) Size(0x29)
};

// Object Name: Class Basic.UAEBPGameSubsystem
// Size: 0xa0 // Inherited bytes: 0x30
struct UUAEBPGameSubsystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x70]; // Offset: 0x30 // Size: 0x70
};

// Object Name: Class Basic.UAEBuffPoolSubsystem
// Size: 0x90 // Inherited bytes: 0x30
struct UUAEBuffPoolSubsystem : UWorldSubsystem {
	// Fields
	struct TArray<struct USTBuff*> BuffList; // Offset: 0x30 // Size: 0x10
	struct TMap<struct FString, struct USTBuff*> BuffInstancedTemplateMap; // Offset: 0x40 // Size: 0x50
};

// Object Name: Class Basic.UAEGameEngine
// Size: 0xe48 // Inherited bytes: 0xdf8
struct UUAEGameEngine : UGameEngine {
	// Fields
	char pad_0xDF8[0x10]; // Offset: 0xdf8 // Size: 0x10
	struct UBackendHUD* AssociatedBackendHUD; // Offset: 0xe08 // Size: 0x08
	char pad_0xE10[0xc]; // Offset: 0xe10 // Size: 0x0c
	bool bEnableAutoStat; // Offset: 0xe1c // Size: 0x01
	bool bEnableAutoTickDeltaThreshold; // Offset: 0xe1d // Size: 0x01
	char pad_0xE1E[0x2]; // Offset: 0xe1e // Size: 0x02
	float AutoTickDeltaThresholdFactor; // Offset: 0xe20 // Size: 0x04
	float StatCollection_AvgTickDeltaThreshold; // Offset: 0xe24 // Size: 0x04
	float AutoStat_AvgTickDeltaThreshold; // Offset: 0xe28 // Size: 0x04
	float AutoStat_StartTime; // Offset: 0xe2c // Size: 0x04
	char pad_0xE30[0x4]; // Offset: 0xe30 // Size: 0x04
	float AutoStat_Duration_Engine; // Offset: 0xe34 // Size: 0x04
	float AutoStat_Duration_PhysX; // Offset: 0xe38 // Size: 0x04
	char pad_0xE3C[0xc]; // Offset: 0xe3c // Size: 0x0c
};

// Object Name: Class Basic.BPTable
// Size: 0xd8 // Inherited bytes: 0x28
struct UBPTable : UObject {
	// Fields
	struct FString BPTableName; // Offset: 0x28 // Size: 0x10
	struct TMap<int, struct FBPTableItem> BPTableItemMap; // Offset: 0x38 // Size: 0x50
	struct TMap<int, struct FBPTableItem> BPTableItemMap_Mod; // Offset: 0x88 // Size: 0x50

	// Functions

	// Object Name: Function Basic.BPTable.GetWrapperPath
	// Flags: [Final|Native|Public]
	struct FString GetWrapperPath(int ID); // Offset: 0x10378bb88 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.BPTable.GetWrapperClass
	// Flags: [Final|Native|Public]
	struct UObject* GetWrapperClass(int ID); // Offset: 0x10378bafc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPTable.GetPath
	// Flags: [Final|Native|Public]
	struct FString GetPath(int ID, bool IsLobby, bool bForceLobby); // Offset: 0x10378b9c0 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Basic.BPTable.GetObject
	// Flags: [Final|Native|Public]
	struct UObject* GetObject(int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice); // Offset: 0x10378b870 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Basic.BPTable.GetModObject
	// Flags: [Final|Native|Public]
	struct UObject* GetModObject(int ID, struct UObject* Outer, bool IsLobby); // Offset: 0x10378b764 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Basic.BPTable.GetModClass
	// Flags: [Final|Native|Public]
	struct UObject* GetModClass(int ID, bool IsLobby); // Offset: 0x10378b698 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Basic.BPTable.GetCustom1Class
	// Flags: [Final|Native|Public]
	struct UObject* GetCustom1Class(int ID); // Offset: 0x10378b60c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.BPTable.GetClass
	// Flags: [Final|Native|Public]
	struct UObject* GetClass(int ID, bool IsLobby, bool IsLowDevice); // Offset: 0x10378b4f8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Basic.BPTable.ConvertPath
	// Flags: [Final|Native|Public]
	void ConvertPath(int ID); // Offset: 0x10378b47c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Basic.UAELoadedClassManager
// Size: 0x340 // Inherited bytes: 0x28
struct UUAELoadedClassManager : UObject {
	// Fields
	struct TMap<struct FString, struct UBPTable*> BPTableMap; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FString, struct UBPTable*> BPTableMap_Mod; // Offset: 0x78 // Size: 0x50
	struct TMap<int, struct FString> BPTableNameMap; // Offset: 0xc8 // Size: 0x50
	struct FString LoadedClassManagerClassName; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x1c0]; // Offset: 0x128 // Size: 0x1c0
	struct TMap<struct UObject*, struct FSoftClassPath> AsyncLoadClassDict; // Offset: 0x2e8 // Size: 0x50
	char pad_0x338[0x8]; // Offset: 0x338 // Size: 0x08

	// Functions

	// Object Name: Function Basic.UAELoadedClassManager.InitTableData
	// Flags: [Native|Event|Public|BlueprintEvent]
	void InitTableData(); // Offset: 0x10378cd08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitialModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	void InitialModTableItemMap(); // Offset: 0x10378ccec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitBPTableMap_Mod
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap_Mod(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.InitBPTableMap
	// Flags: [Event|Public|BlueprintEvent]
	void InitBPTableMap(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.HandleTableModNameChanged
	// Flags: [Final|Native|Public]
	void HandleTableModNameChanged(struct FString InModName); // Offset: 0x10378cc54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAELoadedClassManager.GetWrapperPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetWrapperPath(struct FString BPTableName, int ID); // Offset: 0x10378cb44 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.GetWrapperClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetWrapperClass(struct FString BPTableName, int ID); // Offset: 0x10378ca5c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetPath
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPath(struct FString BPTableName, int ID, bool IsLobby, bool bForceLobby); // Offset: 0x10378c8bc // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.GetObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetObject(struct FString BPTableName, int ID, struct UObject* Outer, bool IsLobby, bool IsLowDevice); // Offset: 0x10378c704 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function Basic.UAELoadedClassManager.GetCustom1Class
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetCustom1Class(struct FString BPTableName, int ID); // Offset: 0x10378c61c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* GetClass(struct FString BPTableName, int ID, bool IsLobby, bool IsLowDevice); // Offset: 0x10378c4a4 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Basic.UAELoadedClassManager.GetBPTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetBPTableName(int Type); // Offset: 0x10378c3f0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.GetAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public|HasDefaults]
	void GetAssetByAssetReferenceAsync(struct FSoftObjectPath AssetReference, DelegateProperty AssetLoadSuccessDelegate); // Offset: 0x10378c2d0 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Basic.UAELoadedClassManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAELoadedClassManager* Get(); // Offset: 0x10378c29c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAELoadedClassManager.CreateAndAddBPTable_Mod
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UBPTable* CreateAndAddBPTable_Mod(struct FString BPTableName); // Offset: 0x10378c1f4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.CreateAndAddBPTable
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UBPTable* CreateAndAddBPTable(struct FString BPTableName); // Offset: 0x10378c14c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAELoadedClassManager.ClearModTableItemMap
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ClearModTableItemMap(); // Offset: 0x10378c130 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearBPTable_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearBPTable_Mod(); // Offset: 0x10378c11c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearBPTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearBPTable(); // Offset: 0x10378c108 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Basic.UAELoadedClassManager.ClearAssetByAssetReferenceAsync
	// Flags: [Final|Native|Public]
	void ClearAssetByAssetReferenceAsync(DelegateProperty AssetLoadSuccessDelegate); // Offset: 0x10378c078 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UAELoadedClassManager.ClearAllData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllData(); // Offset: 0x10378c064 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Basic.UAEMeshComponent
// Size: 0xe10 // Inherited bytes: 0xe10
struct UUAEMeshComponent : USkeletalMeshComponent {
	// Fields
	bool bUseBoneRetargetLODFeature; // Offset: 0xe04 // Size: 0x01
};

// Object Name: Class Basic.UAENetConnection
// Size: 0x33ac0 // Inherited bytes: 0x337b8
struct UUAENetConnection : UIpConnection {
	// Fields
	char pad_0x337B8[0xbc]; // Offset: 0x337b8 // Size: 0xbc
	int InitialHandshakeTimeoutNumThreshold; // Offset: 0x33874 // Size: 0x04
	char pad_0x33878[0x4]; // Offset: 0x33878 // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Server_Global; // Offset: 0x3387c // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Client_Global; // Offset: 0x33880 // Size: 0x04
	int ActorChannelProcessBunchErrorNumThreshold_Client_PerActor; // Offset: 0x33884 // Size: 0x04
	char pad_0x33888[0x50]; // Offset: 0x33888 // Size: 0x50
	bool bEnableHTTPDNS; // Offset: 0x338d8 // Size: 0x01
	char pad_0x338D9[0x7]; // Offset: 0x338d9 // Size: 0x07
	struct FString HTTPDNSServerAddr; // Offset: 0x338e0 // Size: 0x10
	float HTTPDNSResponseTimeout; // Offset: 0x338f0 // Size: 0x04
	char pad_0x338F4[0xc]; // Offset: 0x338f4 // Size: 0x0c
	float CheckLevelInitializedTime; // Offset: 0x33900 // Size: 0x04
	float CheckLevelActorsOvertime; // Offset: 0x33904 // Size: 0x04
	float TempCheckLevelInitializedTime; // Offset: 0x33908 // Size: 0x04
	char pad_0x3390C[0x4]; // Offset: 0x3390c // Size: 0x04
	struct TMap<struct FName, struct FUnLoadLevelActorCollection> UnLevelInitActors; // Offset: 0x33910 // Size: 0x50
	struct UNetRelevancyGroup* RelevancyGroup; // Offset: 0x33960 // Size: 0x08
	char pad_0x33968[0xe0]; // Offset: 0x33968 // Size: 0xe0
	struct TArray<struct FPendingRegionNetworkObject> PendingRegionNetworkObjects; // Offset: 0x33a48 // Size: 0x10
	float MinRegionActorTickDelta; // Offset: 0x33a58 // Size: 0x04
	float MaxRegionActorTickDelta; // Offset: 0x33a5c // Size: 0x04
	char pad_0x33A60[0xc]; // Offset: 0x33a60 // Size: 0x0c
	bool EnableWeakNetUpdate; // Offset: 0x33a6c // Size: 0x01
	char pad_0x33A6D[0x3]; // Offset: 0x33a6d // Size: 0x03
	float MinWeakNetUpdateDelay; // Offset: 0x33a70 // Size: 0x04
	float MaxWeakNetUpdateDelay; // Offset: 0x33a74 // Size: 0x04
	float SquareSegmentSize; // Offset: 0x33a78 // Size: 0x04
	float MaxSegmentDistance; // Offset: 0x33a7c // Size: 0x04
	int MaxObjectNumInSegments; // Offset: 0x33a80 // Size: 0x04
	char pad_0x33A84[0x15]; // Offset: 0x33a84 // Size: 0x15
	bool bRecreateSocketOnLost; // Offset: 0x33a99 // Size: 0x01
	char pad_0x33A9A[0x12]; // Offset: 0x33a9a // Size: 0x12
	float UpdateClientPingTimeThreshold; // Offset: 0x33aac // Size: 0x04
	char pad_0x33AB0[0x10]; // Offset: 0x33ab0 // Size: 0x10
};

// Object Name: Class Basic.UAENetDriver
// Size: 0x7d0 // Inherited bytes: 0x698
struct UUAENetDriver : UIpNetDriver {
	// Fields
	float NetCullChangeTime; // Offset: 0x698 // Size: 0x04
	bool bEnableCollectNetStats; // Offset: 0x69c // Size: 0x01
	bool bEnableResetNetStats; // Offset: 0x69d // Size: 0x01
	char pad_0x69E[0x132]; // Offset: 0x69e // Size: 0x132
};

// Object Name: Class Basic.UAETableManager
// Size: 0x598 // Inherited bytes: 0x28
struct UUAETableManager : UObject {
	// Fields
	struct FString TableRelativeDir; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FName> TablesNeedReleasedInBattle; // Offset: 0x38 // Size: 0x10
	struct FString ManualTableDirectory; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x100]; // Offset: 0x58 // Size: 0x100
	bool AllowItemTable; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07
	struct TArray<struct UUAEDataTable*> TableObjList; // Offset: 0x160 // Size: 0x10
	struct UWorld* CurWorld; // Offset: 0x170 // Size: 0x08
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap; // Offset: 0x178 // Size: 0x50
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> TableObjMap_Mod; // Offset: 0x1c8 // Size: 0x50
	struct FScriptMulticastDelegate OnTableCreateInFighting; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0x118]; // Offset: 0x228 // Size: 0x118
	struct FString PathCompressionConfigsPath; // Offset: 0x340 // Size: 0x10
	bool bIsPathCompression; // Offset: 0x350 // Size: 0x01
	bool bIsPathCompressionCache; // Offset: 0x351 // Size: 0x01
	char pad_0x352[0x2]; // Offset: 0x352 // Size: 0x02
	int PathCompressionCacheMaxSize; // Offset: 0x354 // Size: 0x04
	bool bTranslationFallBackUnloadDuplicate; // Offset: 0x358 // Size: 0x01
	bool bShrinkTranslationMap; // Offset: 0x359 // Size: 0x01
	char pad_0x35A[0xe]; // Offset: 0x35a // Size: 0x0e
	struct FString BaseTableRelativeDir; // Offset: 0x368 // Size: 0x10
	struct FString ModTableRelativeDir; // Offset: 0x378 // Size: 0x10
	struct TMap<struct FName, struct UModTable*> ModTableMap; // Offset: 0x388 // Size: 0x50
	struct TMap<struct FName, struct TWeakObjectPtr<struct UUAEDataTable>> ModTableObjMap; // Offset: 0x3d8 // Size: 0x50
	struct TArray<struct UUAEDataTable*> InGameTableObjList; // Offset: 0x428 // Size: 0x10
	struct TMap<struct FName, bool> CheckNeedModMap; // Offset: 0x438 // Size: 0x50
	struct FString CurrentModName; // Offset: 0x488 // Size: 0x10
	struct FString EmptyModName; // Offset: 0x498 // Size: 0x10
	struct TMap<struct FString, struct UBaseTableResMap*> LoadedTableMap; // Offset: 0x4a8 // Size: 0x50
	struct TMap<struct FString, bool> CheckMapTable; // Offset: 0x4f8 // Size: 0x50
	struct TMap<struct FString, struct UDataTableProxy*> TableCache; // Offset: 0x548 // Size: 0x50

	// Functions

	// Object Name: Function Basic.UAETableManager.ReleaseTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReleaseTable(struct FName TableFName); // Offset: 0x1037935ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAETableManager.GetTablePtr_Mod
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetTablePtr_Mod(struct FName tableName); // Offset: 0x103793560 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Basic.UAETableManager.GetTablePtr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEDataTable* GetTablePtr(struct FName tableName, bool bCheckModTable); // Offset: 0x103793490 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetTableMap
	// Flags: [Final|Native|Public]
	struct UBaseTableResMap* GetTableMap(struct FString tableName); // Offset: 0x1037933e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetTableData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetTableData(struct FString tableName, struct FString Key, struct FTableRowBase& OutRow); // Offset: 0x103792fdc // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Basic.UAETableManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAETableManager* GetInstance(); // Offset: 0x103792fa8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Basic.UAETableManager.GetDomainByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDomainByID(int ID); // Offset: 0x103792f04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetDataTableStatic_Mod
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTableStatic_Mod(struct FString tableName); // Offset: 0x103792e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetDataTableStatic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTableStatic(struct FString tableName); // Offset: 0x103792dd4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UAETableManager.GetDataTableProxy
	// Flags: [Final|Native|Public]
	struct UDataTableProxy* GetDataTableProxy(struct FString tableName, bool bTempory); // Offset: 0x103792ce4 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class Basic.UELanguageUtilityMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UUELanguageUtilityMethods : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.UELanguageUtilityMethods.SetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetDownLoadLanguageName(struct FString Language); // Offset: 0x103793c74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UELanguageUtilityMethods.IsJaguar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsJaguar(); // Offset: 0x103793c40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Basic.UELanguageUtilityMethods.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x103793bdc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UELanguageUtilityMethods.GetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDownLoadLanguageName(); // Offset: 0x103793b78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UELanguageUtilityMethods.GetCurrentLanguageName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCurrentLanguageName(); // Offset: 0x103793b14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Basic.UELanguageUtilityMethods.CheckLocalizationExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckLocalizationExist(); // Offset: 0x103793ae0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Basic.UEMathUtilityMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UUEMathUtilityMethods : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.UEMathUtilityMethods.VectorNormalizeMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorNormalizeMultiple(struct FVector& Out, struct FVector& v1, float Multiple); // Offset: 0x1037947b0 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorMultiple
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorMultiple(struct FVector& Out, struct FVector& v1, float Multiple); // Offset: 0x1037946a4 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorMinus
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorMinus(struct FVector& Out, struct FVector& v1, struct FVector& v2); // Offset: 0x10379458c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.UEMathUtilityMethods.VectorAdditive
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void VectorAdditive(struct FVector& Out, struct FVector& v1, struct FVector& v2); // Offset: 0x103794474 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Basic.UEMathUtilityMethods.FilterOKForCurrentMode
	// Flags: [Final|Native|Static|Public]
	bool FilterOKForCurrentMode(char ModeType, int ModeOpenFlag, struct FString ModeTypes); // Offset: 0x103794330 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function Basic.UEMathUtilityMethods.Conv_VectorToRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void Conv_VectorToRotator(struct FRotator& Out, struct FVector& Vec); // Offset: 0x103794268 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UEMathUtilityMethods.CalculateAngleToTargetAngle
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float CalculateAngleToTargetAngle(float StartAngle, float targetAngle, float stepAngle, enum class EAngleRotationDirectionType Dir); // Offset: 0x10379413c // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Basic.UEMathUtilityMethods.BKDRHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BKDRHash(struct FString StrToHash, int Mod); // Offset: 0x103794064 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Basic.UEMathUtilityMethods.AngleDis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float AngleDis(float angleA, float angleB); // Offset: 0x103793fb0 // Return & Params: Num(3) Size(0xc)
};

// Object Name: Class Basic.UEPathUtilityMethods
// Size: 0x28 // Inherited bytes: 0x28
struct UUEPathUtilityMethods : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Basic.UEPathUtilityMethods.IsPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsPathExist(struct FString HandlePath); // Offset: 0x10379502c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UEPathUtilityMethods.IsAvatarResPathExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAvatarResPathExist(struct FString HandlePath); // Offset: 0x103794f94 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Basic.UEPathUtilityMethods.GetModName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetModName(struct UObject* WorldContext); // Offset: 0x103794ef0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Basic.UEPathUtilityMethods.GetFullModName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFullModName(struct UObject* WorldContext, struct FString& MainMod, struct FString& SubMod); // Offset: 0x103794dac // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Basic.UEPathUtilityMethods.FilterOKForCurrentModeString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool FilterOKForCurrentModeString(struct FString CurrentModeString, struct FString ModStringInfo, char ModeType, int ModeOpenFlag); // Offset: 0x103794c1c // Return & Params: Num(5) Size(0x29)
};

