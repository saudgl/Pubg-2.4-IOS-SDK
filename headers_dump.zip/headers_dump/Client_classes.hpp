#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Client.AppBaseConfig
// Size: 0x150 // Inherited bytes: 0x28
struct UAppBaseConfig : UObject {
	// Fields
	int PUBLISH_REGION_ID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PUBLISH_AREA; // Offset: 0x30 // Size: 0x10
	struct FString IMSDK_GAME_ID; // Offset: 0x40 // Size: 0x10
	struct FString GEMAppID; // Offset: 0x50 // Size: 0x10
	uint32_t TSSGameId; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	uint64 GameID; // Offset: 0x68 // Size: 0x08
	struct FString GameKey; // Offset: 0x70 // Size: 0x10
	uint64 GVoiceGameId; // Offset: 0x80 // Size: 0x08
	struct FString GVoiceGameKey; // Offset: 0x88 // Size: 0x10
	struct FString APPID_FACEBOOK; // Offset: 0x98 // Size: 0x10
	struct FString APPID_APPLE; // Offset: 0xa8 // Size: 0x10
	struct FString APPID_GOOGLE; // Offset: 0xb8 // Size: 0x10
	struct FString APPID_TWITTER; // Offset: 0xc8 // Size: 0x10
	struct FString APPID_WECHAT; // Offset: 0xd8 // Size: 0x10
	struct FString APPID_VK; // Offset: 0xe8 // Size: 0x10
	struct FString APPID_LINE; // Offset: 0xf8 // Size: 0x10
	struct FString APPID_QQ; // Offset: 0x108 // Size: 0x10
	struct FString GUID_GAMEMASTER; // Offset: 0x118 // Size: 0x10
	struct FString GEMCtrlURL; // Offset: 0x128 // Size: 0x10
	struct FString TGPACtrlURL; // Offset: 0x138 // Size: 0x10
	int SubsideFeatureLevel; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class Client.AsyncLoadHelper
// Size: 0xe0 // Inherited bytes: 0x28
struct UAsyncLoadHelper : UObject {
	// Fields
	struct TMap<struct FString, struct UObject*> PreloadObjectMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x68]; // Offset: 0x78 // Size: 0x68

	// Functions

	// Object Name: Function Client.AsyncLoadHelper.SetMaxTaskNum
	// Flags: [Final|Native|Public]
	void SetMaxTaskNum(int Num); // Offset: 0x103909570 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.AsyncLoadHelper.RunNextTask
	// Flags: [Final|Native|Public]
	void RunNextTask(); // Offset: 0x10390955c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.OnLoadCallBack
	// Flags: [Final|Native|Public|HasDefaults]
	void OnLoadCallBack(struct FSoftObjectPath softObjPath); // Offset: 0x103909490 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.AsyncLoadHelper.ClearOneTask
	// Flags: [Final|Native|Public]
	void ClearOneTask(struct FString ObjectPath); // Offset: 0x1039093d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AsyncLoadHelper.ClearAllTask
	// Flags: [Final|Native|Public]
	void ClearAllTask(); // Offset: 0x1039093c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.AddTask
	// Flags: [Final|Native|Public]
	void AddTask(struct FString ObjectPath, int LoadPriority); // Offset: 0x1039092c4 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class Client.AsyncLoadWidgetBlueprint
// Size: 0x80 // Inherited bytes: 0x28
struct UAsyncLoadWidgetBlueprint : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate BeforeLoad; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate AfterLoad; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnCancelled; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x28]; // Offset: 0x58 // Size: 0x28

	// Functions

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.Cancel
	// Flags: [Native|Public|BlueprintCallable]
	void Cancel(); // Offset: 0x103909a94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.AsyncLoadWidgetBlueprint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncLoadWidgetBlueprint* AsyncLoadWidgetBlueprint(struct FString BlueprintPath, int Priority); // Offset: 0x103909998 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.AfterLoadCallback
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void AfterLoadCallback(struct FSoftObjectPath& SoftObjectPath); // Offset: 0x1039098d8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.Activate
	// Flags: [Native|Public|BlueprintCallable]
	void Activate(); // Offset: 0x1039098bc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.AsyncTaskCDNDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskCDNDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskCDNDownloader.DownloadCDNContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskCDNDownloader* DownloadCDNContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x103909ee0 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.AsyncTaskDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskDownloader.DownloadContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloader* DownloadContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x10390a420 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.BattleScriptHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleScriptHelper : UObject {
	// Functions

	// Object Name: Function Client.BattleScriptHelper.SyncNewBattlePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(struct UBattleUtils* Utils, uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x10390ac3c // Return & Params: Num(4) Size(0xd4)

	// Object Name: Function Client.BattleScriptHelper.SyncGameInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SyncGameInfo(struct UBattleUtils* Utils, struct FBattleGameInfo& Info); // Offset: 0x10390ab54 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.BattleScriptHelper.SyncGameExit
	// Flags: [Final|Native|Static|Public]
	void SyncGameExit(struct UBattleUtils* Utils); // Offset: 0x10390aae0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleScriptHelper.SyncBattlePlayerExit
	// Flags: [Final|Native|Static|Public]
	void SyncBattlePlayerExit(struct UBattleUtils* Utils, uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x10390a968 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.BattleScriptHelper.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Static|Public]
	void ResponPlayerWeaponDIYData(struct UBattleUtils* Utils, uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x10390a82c // Return & Params: Num(3) Size(0x60)

	// Object Name: Function Client.BattleScriptHelper.GenerateAIPlayerParams
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateAIPlayerParams(struct UBattleUtils* Utils, struct FPlayerInfoData& Info); // Offset: 0x10390a74c // Return & Params: Num(2) Size(0xc8)
};

// Object Name: Class Client.BattlePlayer
// Size: 0x160 // Inherited bytes: 0x28
struct UBattlePlayer : UObject {
	// Fields
	uint64 UId; // Offset: 0x28 // Size: 0x08
	struct FPlayerInfoData PlayerInfoData; // Offset: 0x30 // Size: 0xc0
	struct FPlayerAvatarData PlayerAvatarData; // Offset: 0xf0 // Size: 0x18
	struct TMap<int, struct FWeaponDIYData> WeaponDIYData; // Offset: 0x108 // Size: 0x50
	struct UBattleUtils* OwningBattleUtils; // Offset: 0x158 // Size: 0x08

	// Functions

	// Object Name: Function Client.BattlePlayer.ExtractGameModePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams ExtractGameModePlayerParams(); // Offset: 0x10390b0c4 // Return & Params: Num(1) Size(0x398)
};

// Object Name: Class Client.BattleAIPlayer
// Size: 0x160 // Inherited bytes: 0x160
struct UBattleAIPlayer : UBattlePlayer {
	// Functions

	// Object Name: Function Client.BattleAIPlayer.ExtractGameModeAIPlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModeAIPlayerParams ExtractGameModeAIPlayerParams(); // Offset: 0x10390b278 // Return & Params: Num(1) Size(0x3a8)
};

// Object Name: Class Client.BattleUtils
// Size: 0x4f8 // Inherited bytes: 0x28
struct UBattleUtils : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct UGameFrontendHUD* OwningFrontendHUD; // Offset: 0x88 // Size: 0x08
	char pad_0x90[0x10]; // Offset: 0x90 // Size: 0x10
	struct AUAEGameMode* BattleGameMode; // Offset: 0xa0 // Size: 0x08
	struct TArray<struct UBattlePlayer*> BattlePlayerList; // Offset: 0xa8 // Size: 0x10
	struct FBattleGameInfo CachedBattleGameInfo; // Offset: 0xb8 // Size: 0x38
	struct FGameModeAIPlayerParams CachedAIPlayerParams; // Offset: 0xf0 // Size: 0x3a8
	struct FString LuaFilePath; // Offset: 0x498 // Size: 0x10
	char pad_0x4A8[0x50]; // Offset: 0x4a8 // Size: 0x50

	// Functions

	// Object Name: Function Client.BattleUtils.SyncNewBattlePlayer
	// Flags: [Final|Native|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x10390c12c // Return & Params: Num(3) Size(0xcc)

	// Object Name: Function Client.BattleUtils.SyncGameInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void SyncGameInfo(struct FBattleGameInfo& Info); // Offset: 0x10390c078 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function Client.BattleUtils.SyncGameExit
	// Flags: [Final|Native|Public]
	void SyncGameExit(); // Offset: 0x10390c064 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BattleUtils.SyncBattlePlayerExit
	// Flags: [Final|Native|Public]
	void SyncBattlePlayerExit(uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x10390bf24 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.RetrievePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams RetrievePlayerParams(struct FPlayerID PlayerID); // Offset: 0x10390be64 // Return & Params: Num(2) Size(0x3a8)

	// Object Name: Function Client.BattleUtils.RetrieveAIPlayerParams
	// Flags: [Final|Native|Public]
	struct FGameModeAIPlayerParams RetrieveAIPlayerParams(struct FPlayerID PlayerID); // Offset: 0x10390bda4 // Return & Params: Num(2) Size(0x3b8)

	// Object Name: Function Client.BattleUtils.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void ResponPlayerWeaponDIYData(uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x10390bc94 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.BattleUtils.RequestSomePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestSomePlayersBattleData(struct TArray<uint64> PlayerUIDList, char DataType); // Offset: 0x10390bb70 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BattleUtils.RequestPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void RequestPlayerWeaponDIYData(uint64 PlayerUID, int WeaponSkinID, int PlanID); // Offset: 0x10390ba80 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.BattleUtils.RequestOnePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestOnePlayersBattleData(uint64 PlayerUID, char DataType); // Offset: 0x10390b9c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.BattleUtils.RequestAllPlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestAllPlayersBattleData(char DataType); // Offset: 0x10390b94c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BattleUtils.OnPostLoadMapWithWorld
	// Flags: [Final|Native|Public]
	void OnPostLoadMapWithWorld(struct UWorld* World); // Offset: 0x10390b8d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattlePlayer
	// Flags: [Final|Native|Public]
	struct UBattlePlayer* NewBattlePlayer(); // Offset: 0x10390b89c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattleAIPlayer
	// Flags: [Final|Native|Public]
	struct UBattleAIPlayer* NewBattleAIPlayer(); // Offset: 0x10390b868 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.HandleGameModeStateChanged
	// Flags: [Final|Native|Public|HasOutParms]
	void HandleGameModeStateChanged(struct FGameModeStateChangedParams& Params); // Offset: 0x10390b7ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BattleUtils.GetBattleGameMode
	// Flags: [Final|Native|Public|Const]
	struct AUAEGameMode* GetBattleGameMode(); // Offset: 0x10390b778 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.GenerateAIPlayerParams
	// Flags: [Final|Native|Public|HasOutParms]
	void GenerateAIPlayerParams(struct FPlayerInfoData& Info); // Offset: 0x10390b6cc // Return & Params: Num(1) Size(0xc0)

	// Object Name: Function Client.BattleUtils.FindPlayerByUID
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByUID(uint64 UId, struct FName PlayerType); // Offset: 0x10390b608 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerName
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerName(struct FString PlayerName, struct FName PlayerType); // Offset: 0x10390b4fc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x10390b434 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Client.BattleWindowMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleWindowMgr : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BattleWindowMgr.ShowUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowUI(struct UObject* WorldContextObject, struct FString WindowName, struct UObject* ObjectParam); // Offset: 0x10390cad0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleWindowMgr.SetInstance
	// Flags: [Final|Native|Static|Public]
	void SetInstance(struct UBattleWindowMgrLuaUtils* InInstance, struct ULuaStateWrapper* InLuaStateWrapper); // Offset: 0x10390ca24 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BattleWindowMgr.HideUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideUI(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x10390c930 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BattleWindowMgr.CheckWindowOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckWindowOpen(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x10390c834 // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.BattleWindowMgrLuaUtils
// Size: 0x70 // Inherited bytes: 0x28
struct UBattleWindowMgrLuaUtils : UObject {
	// Fields
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // Offset: 0x28 // Size: 0x08
	struct FString LuaManagerName; // Offset: 0x30 // Size: 0x10
	struct FString ShowUI; // Offset: 0x40 // Size: 0x10
	struct FString HideUI; // Offset: 0x50 // Size: 0x10
	struct FString CheckWindowOpen; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class Client.BugReporter
// Size: 0xa0 // Inherited bytes: 0x28
struct UBugReporter : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78

	// Functions

	// Object Name: Function Client.BugReporter.SendScreenShot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendScreenShot(struct FString errorReason, struct FString errorDescription, struct FString ImagePath, float X, float Y, float Z); // Offset: 0x10390d318 // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function Client.BugReporter.SendLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendLog(struct FString errorReason, struct FString errorDescription, float X, float Y, float Z, bool pullAll, bool zipLogUpload); // Offset: 0x10390d090 // Return & Params: Num(7) Size(0x2e)

	// Object Name: Function Client.BugReporter.ReadZipLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReadZipLog(struct FString Filename); // Offset: 0x10390cfd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BugReporter.CompressLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<char> CompressLog(bool pullAllLog); // Offset: 0x10390cf18 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.BuildConfig
// Size: 0x58 // Inherited bytes: 0x28
struct UBuildConfig : UObject {
	// Fields
	struct FString branch_name; // Offset: 0x28 // Size: 0x10
	struct FString build_no; // Offset: 0x38 // Size: 0x10
	struct FString build_url; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Client.BusinessHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBusinessHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BusinessHelper.UIGetResWithPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* UIGetResWithPath(struct FString DesManagerName); // Offset: 0x10390f030 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x10390ef34 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManager(struct UUAEUserWidget* pUIClass); // Offset: 0x10390eeb8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StopUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x10390edbc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BusinessHelper.StopTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float StopTimeWatch(); // Offset: 0x10390ed88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.StartUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartUIStat(struct FString UIName); // Offset: 0x10390ecd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StartTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTimeWatch(); // Offset: 0x10390ecc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x10390ec4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.ReportUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportUIStat(struct FString UIName, bool bGStatTime, bool bReport, float TotalTime); // Offset: 0x10390eac0 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Client.BusinessHelper.RemoveKnownMissingPackageRefObjectByObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveKnownMissingPackageRefObjectByObj(struct UObject* RefedObject); // Offset: 0x10390ea4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BusinessHelper.LoadAssetFromPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* LoadAssetFromPath(struct FString DesManagerName); // Offset: 0x10390e9b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMiniPakVersion(); // Offset: 0x10390e980 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMapPakVersion(); // Offset: 0x10390e94c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsFit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFit(); // Offset: 0x10390e918 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsClassOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsClassOf(struct UObject* Object, struct UObject* Class); // Offset: 0x10390e864 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.BusinessHelper.IsChildOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsChildOf(struct UObject* ChildClass, struct UObject* Class); // Offset: 0x10390e7b0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.BusinessHelper.IsCEVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCEVersion(); // Offset: 0x10390e77c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsAppFromStore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAppFromStore(); // Offset: 0x10390e748 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasDownloadedBasePak(); // Offset: 0x10390e714 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.GetWidgetByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEUserWidget* GetWidgetByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName, struct FString InWidgtName); // Offset: 0x10390e5ec // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.BusinessHelper.GetTSSGameId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetTSSGameId(); // Offset: 0x10390e5b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetTime(); // Offset: 0x10390e584 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x10390e520 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPublishRegionID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPublishRegionID(); // Offset: 0x10390e4ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x10390e488 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPackChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x10390e424 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetOpenId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOpenId(); // Offset: 0x10390e3c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetObjectClassName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetObjectClassName(struct UObject* Object); // Offset: 0x10390e31c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.GetMobileBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetMobileBasePath(struct FString InPath); // Offset: 0x10390e25c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* GetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x10390e160 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetITopGameId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetITopGameId(); // Offset: 0x10390e0fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetInGameLocalConnectURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetInGameLocalConnectURL(); // Offset: 0x10390e098 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIMSDKEnv(); // Offset: 0x10390e064 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetGVoiceGameId
	// Flags: [Final|Native|Static|Public]
	uint64 GetGVoiceGameId(); // Offset: 0x10390e030 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BusinessHelper.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceQualityLevel(); // Offset: 0x10390dffc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDeviceOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceOrientation(); // Offset: 0x10390dfc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDataTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable(struct FString tableName); // Offset: 0x10390df30 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.GetCurrentNetworkState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentNetworkState(); // Offset: 0x10390defc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetChildByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UWidget* GetChildByName(struct UUserWidget* pParent, struct FString Name); // Offset: 0x10390de28 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetBuildURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildURL(); // Offset: 0x10390ddc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBuildNo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildNo(); // Offset: 0x10390dd60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBranchName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBranchName(); // Offset: 0x10390dcfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBase64Key
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBase64Key(); // Offset: 0x10390dc98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAppVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppVersion(); // Offset: 0x10390dc34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOPID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetAOSSHOPID(); // Offset: 0x10390dc00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOP
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAOSSHOP(); // Offset: 0x10390db9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.ClearDisplayLookupTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearDisplayLookupTable(); // Offset: 0x10390db88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.BroadCastMSG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BroadCastMSG(struct UFrontendHUD* FrontendHUD, struct FString DesManagerName, struct FString Msg); // Offset: 0x10390da68 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.BusinessHelper.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x10390d92c // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.IntlHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UIntlHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.IntlHelper.UpdateXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushNightTag(bool bInit); // Offset: 0x103911cd4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushDayTag(bool bInit); // Offset: 0x103911c58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateVoiceUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateVoiceUrl(struct FString regionVoiceUrl); // Offset: 0x103911ba4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.UnInitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnInitTweenMaker(); // Offset: 0x103911b90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.TimeFormatString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TimeFormatString(struct FString Format, int hours, int Mins, int secs); // Offset: 0x103911a14 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.IntlHelper.SaveXGTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveXGTags(struct FString Language, struct FString timezone, struct FString Region); // Offset: 0x103911870 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.OnSwitchLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnSwitchLanguage(); // Offset: 0x10391185c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.OnChoosingZone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnChoosingZone(int ZoneID, struct FString AddrIP, struct FString regionVoiceUrl); // Offset: 0x1039116f0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.IntlHelper.IsRemoteNotificationsEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRemoteNotificationsEnabled(); // Offset: 0x1039116bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable4CurrentChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable4CurrentChannel(); // Offset: 0x103911688 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable(); // Offset: 0x103911654 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.InitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitTweenMaker(); // Offset: 0x103911640 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftUploadLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftUploadLog(); // Offset: 0x10391162c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowSingleFAQWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowSingleFAQWithInfo(struct FString publishID, struct FString PlayerName, struct FString PlayerLevel, struct FString PlayerGold, int PlayerRecharge, int PlayerRegisterTime, struct FString ExtraTags); // Offset: 0x1039113d0 // Return & Params: Num(7) Size(0x58)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQsWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQsWithInfo(struct FString PlayerName, struct FString PlayerLevel, struct FString PlayerGold, int PlayerRecharge, int PlayerRegisterTime, struct FString ExtraTags); // Offset: 0x1039111c8 // Return & Params: Num(6) Size(0x48)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQs(); // Offset: 0x1039111b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversionWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversionWithInfo(struct FString Name, struct FString Level, struct FString Gold); // Offset: 0x103911010 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversion(); // Offset: 0x103910ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftRequestUnreadMessagesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftRequestUnreadMessagesCount(); // Offset: 0x103910fe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftGetUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	int HelpshiftGetUnreadMessgesCount(); // Offset: 0x103910fb4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.HelpshiftClearUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftClearUnreadMessgesCount(); // Offset: 0x103910fa0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.GetSavedXGTimezoneTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGTimezoneTag(); // Offset: 0x103910f3c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGRegionTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGRegionTag(); // Offset: 0x103910ed8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushNightTag(); // Offset: 0x103910e74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushDayTag(); // Offset: 0x103910e10 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGLanguageTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGLanguageTag(); // Offset: 0x103910dac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetPlayerUCLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPlayerUCLevel(); // Offset: 0x103910d48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetLocalTimezone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetLocalTimezone(); // Offset: 0x103910d14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithString(struct FString sourceString, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103910ac4 // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithNum(int ID, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103910894 // Return & Params: Num(7) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByStr(struct FString Source, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103910684 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByID(int ID, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x10391048c // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizationStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationStringWithID(int ID); // Offset: 0x1039103e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetLocalizationString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationString(struct FString Key); // Offset: 0x103910328 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlHelper.GetLocalizationBattleStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationBattleStringWithID(int ID); // Offset: 0x103910284 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetHistoryErrorCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHistoryErrorCode(); // Offset: 0x103910220 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetGameMasterVID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameMasterVID(); // Offset: 0x1039101bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetCurrentZoneID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentZoneID(); // Offset: 0x103910188 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.FormatLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString FormatLocalizeStrByStr(struct FString Source, struct TArray<struct FString>& stringArr); // Offset: 0x103910064 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.DownloadTranslation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadTranslation(struct FString PatchName); // Offset: 0x10390ffb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.DownloadServerList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadServerList(); // Offset: 0x10390ff9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.DirectToNotificationSetup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DirectToNotificationSetup(); // Offset: 0x10390ff88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.ClearAdjustDeepLink
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearAdjustDeepLink(); // Offset: 0x10390ff74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AdjustParaAnalysis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AdjustParaAnalysis(); // Offset: 0x10390ff60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AddErrorCodeToHistory
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddErrorCodeToHistory(struct FString InErrorCode); // Offset: 0x10390feac // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.TestHUD
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct ATestHUD : AActor {
	// Functions

	// Object Name: Function Client.TestHUD.TestFunctionNOParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestFunctionNOParam(); // Offset: 0x103912c3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.TestHUD.TestFunctionBP_LUA
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP_LUA(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.TestFunctionBP
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_Lua
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_Lua(); // Offset: 0x103912c08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus_Call(); // Offset: 0x103912bd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus(); // Offset: 0x103912ba0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_CPP(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_LUA
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_LUA(); // Offset: 0x103912b6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_Call_CPP(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_CPlus(); // Offset: 0x103912b38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call(); // Offset: 0x103912b04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP(); // Offset: 0x103912ad0 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.CDNUpdate
// Size: 0x368 // Inherited bytes: 0x28
struct UCDNUpdate : UObject {
	// Fields
	char pad_0x28[0x90]; // Offset: 0x28 // Size: 0x90
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb8 // Size: 0x08
	char pad_0xC0[0x2a8]; // Offset: 0xc0 // Size: 0x2a8

	// Functions

	// Object Name: Function Client.CDNUpdate.StartUpdateApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartUpdateApp(); // Offset: 0x1039159d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(bool StartGrayUpdate); // Offset: 0x10391594c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.OnRequestProgress
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestProgress(struct FCDNDownloaderInfo& Info); // Offset: 0x103915898 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x1039157e4 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x1039157b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x10391577c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x103915640 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.CDNUpdate.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x10391562c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x103915618 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x103915604 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ClientNetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UClientNetInterface : UNetInterface {
};

// Object Name: Class Client.CommonItemBase
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UCommonItemBase : ULuaUserWidget {
};

// Object Name: Class Client.CompressTextureHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UCompressTextureHelper : UObject {
	// Functions

	// Object Name: Function Client.CompressTextureHelper.TestGetTexture2DFromDisk_KTX2
	// Flags: [Final|Native|Static|Public]
	struct UTexture2D* TestGetTexture2DFromDisk_KTX2(struct FString PathName); // Offset: 0x103916da8 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.DragDropTextBox
// Size: 0xca0 // Inherited bytes: 0xca0
struct UDragDropTextBox : UEditableTextBox {
};

// Object Name: Class Client.GameBackendUtils
// Size: 0x30 // Inherited bytes: 0x30
struct UGameBackendUtils : UBackendUtils {
	// Functions

	// Object Name: Function Client.GameBackendUtils.GetTableManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAETableManager* GetTableManager(); // Offset: 0x10391716c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameBackendHUD
// Size: 0xb0 // Inherited bytes: 0xb0
struct UGameBackendHUD : UBackendHUD {
	// Functions

	// Object Name: Function Client.GameBackendHUD.GetUtils
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameBackendUtils* GetUtils(); // Offset: 0x103917448 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGameBackendHUD* GetInstance(); // Offset: 0x103917414 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetGameFrontendHUDByGameInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUDByGameInstance(struct UGameInstance* GameInstance); // Offset: 0x103917388 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBackendHUD.GetFirstGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetFirstGameFrontendHUD(struct UObject* WorldContextObject); // Offset: 0x1039172fc // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Client.GameBusinessManager
// Size: 0x170 // Inherited bytes: 0xf8
struct UGameBusinessManager : ULogicManagerBase {
	// Fields
	struct TArray<struct FGameWidgetConfig> WidgetConfigList; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0x50]; // Offset: 0x108 // Size: 0x50
	struct AUAEPlayerController* OwningController; // Offset: 0x158 // Size: 0x08
	char pad_0x160[0x8]; // Offset: 0x160 // Size: 0x08
	struct ALuaClassObj* LuaObject; // Offset: 0x168 // Size: 0x08

	// Functions

	// Object Name: Function Client.GameBusinessManager.GetWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEUserWidget* GetWidget(int Index); // Offset: 0x1039177cc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBusinessManager.GetLuaObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ALuaClassObj* GetLuaObject(); // Offset: 0x103917798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBusinessManager.GetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUD(); // Offset: 0x103917764 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendHUD
// Size: 0x7f8 // Inherited bytes: 0x1d0
struct UGameFrontendHUD : UFrontendHUD {
	// Fields
	struct FScriptMulticastDelegate OnHandleWebviewActionDelegate; // Offset: 0x1d0 // Size: 0x10
	struct FScriptMulticastDelegate OnGetTicketNotifyDelegate; // Offset: 0x1e0 // Size: 0x10
	struct FScriptMulticastDelegate OnHandleServerListDownload; // Offset: 0x1f0 // Size: 0x10
	struct FScriptMulticastDelegate OnUIStatReport; // Offset: 0x200 // Size: 0x10
	struct FScriptMulticastDelegate OnReportClientTool; // Offset: 0x210 // Size: 0x10
	struct FString CSVTableRelativeDir; // Offset: 0x220 // Size: 0x10
	struct TMap<struct FName, struct FString> GameStatusMap; // Offset: 0x230 // Size: 0x50
	bool EnableTickLog; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x1]; // Offset: 0x281 // Size: 0x01
	bool bEnableReportMemory; // Offset: 0x282 // Size: 0x01
	char pad_0x283[0x1d]; // Offset: 0x283 // Size: 0x1d
	struct UGVoiceInterface* GVoice; // Offset: 0x2a0 // Size: 0x08
	bool IsNewGVoiceCreated; // Offset: 0x2a8 // Size: 0x01
	bool DisableGVoice; // Offset: 0x2a9 // Size: 0x01
	char pad_0x2AA[0x6]; // Offset: 0x2aa // Size: 0x06
	struct UBugReporter* GameBugReporter; // Offset: 0x2b0 // Size: 0x08
	struct UGMLogShare* LogShare; // Offset: 0x2b8 // Size: 0x08
	int MaxUpdateRetryTimes; // Offset: 0x2c0 // Size: 0x04
	char pad_0x2C4[0xc]; // Offset: 0x2c4 // Size: 0x0c
	struct UGDolphinUpdater* GDolphin; // Offset: 0x2d0 // Size: 0x08
	struct UTranslator* Translator; // Offset: 0x2d8 // Size: 0x08
	struct UHttpWrapper* HttpWrapper; // Offset: 0x2e0 // Size: 0x08
	struct UGCPufferDownloader* GPuffer; // Offset: 0x2e8 // Size: 0x08
	struct ULaggingReporter* LaggingReporter; // Offset: 0x2f0 // Size: 0x08
	char pad_0x2F8[0x8]; // Offset: 0x2f8 // Size: 0x08
	struct UAsyncTaskDownloader* DownloadTask; // Offset: 0x300 // Size: 0x08
	char pad_0x308[0x44]; // Offset: 0x308 // Size: 0x44
	bool bUseDolphinUpdateFirst; // Offset: 0x34c // Size: 0x01
	bool bEnableUseDolphinUpdate; // Offset: 0x34d // Size: 0x01
	bool bEnableUseCDNUpdate; // Offset: 0x34e // Size: 0x01
	bool bUseDolphinUpdateAfterCDNFailed; // Offset: 0x34f // Size: 0x01
	bool bUseCDNUpdateAfterDolphinFailed; // Offset: 0x350 // Size: 0x01
	bool bEnableEditorPufferDownload; // Offset: 0x351 // Size: 0x01
	bool bIsWaitingUpdateStateData; // Offset: 0x352 // Size: 0x01
	bool IsUsingDolphinUpdate; // Offset: 0x353 // Size: 0x01
	bool IsUsingCDNUpdate; // Offset: 0x354 // Size: 0x01
	char pad_0x355[0x13]; // Offset: 0x355 // Size: 0x13
	struct UCDNUpdate* CDNUpdater; // Offset: 0x368 // Size: 0x08
	int ODPaksPoolSize; // Offset: 0x370 // Size: 0x04
	int ODPaksPoolSizeLowend; // Offset: 0x374 // Size: 0x04
	int ODPaksPoolSizeLowendThreshold; // Offset: 0x378 // Size: 0x04
	bool ODPaksEnable; // Offset: 0x37c // Size: 0x01
	char pad_0x37D[0x33]; // Offset: 0x37d // Size: 0x33
	struct FName UnrealNetworkStatus; // Offset: 0x3b0 // Size: 0x08
	char pad_0x3B8[0x18]; // Offset: 0x3b8 // Size: 0x18
	float UnrealNetworkConnectingTimer; // Offset: 0x3d0 // Size: 0x04
	char pad_0x3D4[0x1c]; // Offset: 0x3d4 // Size: 0x1c
	float UnrealNetworkConnectingTime; // Offset: 0x3f0 // Size: 0x04
	bool bUseDynamicCreateLuaManager; // Offset: 0x3f4 // Size: 0x01
	char pad_0x3F5[0x3]; // Offset: 0x3f5 // Size: 0x03
	struct TArray<struct FString> PersistentLuaManager; // Offset: 0x3f8 // Size: 0x10
	char pad_0x408[0x4]; // Offset: 0x408 // Size: 0x04
	bool bPatchReInitSequence; // Offset: 0x40c // Size: 0x01
	char pad_0x40D[0x3]; // Offset: 0x40d // Size: 0x03
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x410 // Size: 0x08
	struct ULuaEventBridge* LuaEventBridgeInstace; // Offset: 0x418 // Size: 0x08
	struct UBattleWindowMgrLuaUtils* LuaBattleWindowMgr; // Offset: 0x420 // Size: 0x08
	struct ULuaBlueprintMgr* LuaBlueprintSysMgr; // Offset: 0x428 // Size: 0x08
	char pad_0x430[0x8]; // Offset: 0x430 // Size: 0x08
	struct FString ScriptBPRelativeDir; // Offset: 0x438 // Size: 0x10
	struct FString ScriptRelativeDir; // Offset: 0x448 // Size: 0x10
	struct FString InGameLuaDir; // Offset: 0x458 // Size: 0x10
	struct FString PreloadLuaFileRelativePath; // Offset: 0x468 // Size: 0x10
	struct TArray<struct FString> LuaDirList; // Offset: 0x478 // Size: 0x10
	struct TArray<struct FString> NoGCPackage; // Offset: 0x488 // Size: 0x10
	float LuaTickTime; // Offset: 0x498 // Size: 0x04
	bool bCallLuaTick; // Offset: 0x49c // Size: 0x01
	bool bAutoLoginEnable; // Offset: 0x49d // Size: 0x01
	char pad_0x49E[0x1a]; // Offset: 0x49e // Size: 0x1a
	int PingFirstReportIntervalSecond; // Offset: 0x4b8 // Size: 0x04
	int PingReportIntervalSecond; // Offset: 0x4bc // Size: 0x04
	int LossSyncIntervalSecond; // Offset: 0x4c0 // Size: 0x04
	int vmInstrumentOptimization; // Offset: 0x4c4 // Size: 0x04
	struct UTssManager* TssMgr; // Offset: 0x4c8 // Size: 0x08
	char pad_0x4D0[0x1c]; // Offset: 0x4d0 // Size: 0x1c
	float PingReportInterval; // Offset: 0x4ec // Size: 0x04
	char pad_0x4F0[0xd4]; // Offset: 0x4f0 // Size: 0xd4
	uint32_t ImageDownloadClearDayCount; // Offset: 0x5c4 // Size: 0x04
	struct FScriptMulticastDelegate UIStackChangeDelegate; // Offset: 0x5c8 // Size: 0x10
	struct FScriptMulticastDelegate UIStackRecoverDelegate; // Offset: 0x5d8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationUIEvent; // Offset: 0x5e8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationExUIEvent; // Offset: 0x5f8 // Size: 0x10
	char pad_0x608[0x78]; // Offset: 0x608 // Size: 0x78
	struct UImageDownloader* ImageDownloaderInGame; // Offset: 0x680 // Size: 0x08
	int FpsForWindowClient; // Offset: 0x688 // Size: 0x04
	char pad_0x68C[0x4]; // Offset: 0x68c // Size: 0x04
	struct UUDPPingCollector* UDPPingCollector; // Offset: 0x690 // Size: 0x08
	bool UIElemLayoutJsonConfigSwitch; // Offset: 0x698 // Size: 0x01
	bool NationAllSwitch; // Offset: 0x699 // Size: 0x01
	bool NationBattleSwitch; // Offset: 0x69a // Size: 0x01
	bool NationRankSwitch; // Offset: 0x69b // Size: 0x01
	bool SelfieSwitch; // Offset: 0x69c // Size: 0x01
	bool ReportBugSwitch; // Offset: 0x69d // Size: 0x01
	bool FirstVoicePopupSwitch; // Offset: 0x69e // Size: 0x01
	bool GDPRForbidVoiceSwitch; // Offset: 0x69f // Size: 0x01
	bool GDPRSettingSwitch; // Offset: 0x6a0 // Size: 0x01
	char pad_0x6A1[0x3]; // Offset: 0x6a1 // Size: 0x03
	int GDPRUserType; // Offset: 0x6a4 // Size: 0x04
	bool bShouldShowAdaptTipInLobby; // Offset: 0x6a8 // Size: 0x01
	char pad_0x6A9[0x3]; // Offset: 0x6a9 // Size: 0x03
	float fLaggingFPSDiffThreshold; // Offset: 0x6ac // Size: 0x04
	float fLaggingFPSDiffThresholdMin; // Offset: 0x6b0 // Size: 0x04
	float fLaggingFPSDiffThresholdMax; // Offset: 0x6b4 // Size: 0x04
	float fLaggingFrameTimeThreshold; // Offset: 0x6b8 // Size: 0x04
	float fLaggingFrameTimeThresholdMin; // Offset: 0x6bc // Size: 0x04
	float fLaggingFrameTimeThresholdMax; // Offset: 0x6c0 // Size: 0x04
	float fFPSReportInterval; // Offset: 0x6c4 // Size: 0x04
	char pad_0x6C8[0x10]; // Offset: 0x6c8 // Size: 0x10
	bool bUnLoadNoGcPackage; // Offset: 0x6d8 // Size: 0x01
	char pad_0x6D9[0x7]; // Offset: 0x6d9 // Size: 0x07
	struct TArray<struct UPackage*> NoGcPackages; // Offset: 0x6e0 // Size: 0x10
	bool bFlushAsyncLoadingBeforeGC; // Offset: 0x6f0 // Size: 0x01
	bool bEnablePandora; // Offset: 0x6f1 // Size: 0x01
	char pad_0x6F2[0x1]; // Offset: 0x6f2 // Size: 0x01
	bool bEnableJMLog; // Offset: 0x6f3 // Size: 0x01
	char pad_0x6F4[0xb4]; // Offset: 0x6f4 // Size: 0xb4
	bool bEnableH5Cache; // Offset: 0x7a8 // Size: 0x01
	bool bCheckWorldNameForLoadConfig; // Offset: 0x7a9 // Size: 0x01
	char pad_0x7AA[0x6]; // Offset: 0x7aa // Size: 0x06
	struct UColorBlindnessMgr* ColorBlindnessMgrInstace; // Offset: 0x7b0 // Size: 0x08
	struct TArray<struct FNativeHUDTickContainer> NativeHUDTickList; // Offset: 0x7b8 // Size: 0x10
	bool IsNativeHUDTickLock; // Offset: 0x7c8 // Size: 0x01
	bool IsShutDown; // Offset: 0x7c9 // Size: 0x01
	char pad_0x7CA[0x2]; // Offset: 0x7ca // Size: 0x02
	int NativeHUDTickIndex; // Offset: 0x7cc // Size: 0x04
	struct UAsyncLoadHelper* AsyncLoadHelper; // Offset: 0x7d0 // Size: 0x08
	struct FString BattleUtilsClassName; // Offset: 0x7d8 // Size: 0x10
	struct UBattleUtils* BattleUtils; // Offset: 0x7e8 // Size: 0x08
	char pad_0x7F0[0x8]; // Offset: 0x7f0 // Size: 0x08

	// Functions

	// Object Name: Function Client.GameFrontendHUD.VNGPostPersonalInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void VNGPostPersonalInfo(struct FString OpenID, struct FString Name, struct FString passportId, struct FString email, struct FString phone, struct FString address); // Offset: 0x10391a150 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.GameFrontendHUD.UnRegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterUIShowHideEventDelegate(struct FString Source); // Offset: 0x10391a094 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStop(int Type, struct FString Name); // Offset: 0x103919f98 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStart(int Type); // Offset: 0x103919f1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.TickUdpCollector
	// Flags: [Final|Native|Public]
	void TickUdpCollector(float DeltaTime); // Offset: 0x103919ea0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.StatisVisibilityWidget
	// Flags: [Final|Native|Public]
	void StatisVisibilityWidget(struct UWidget* Widget); // Offset: 0x103919e24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StatisLoadedTexture
	// Flags: [Final|Native|Public]
	void StatisLoadedTexture(struct UTexture* Texture); // Offset: 0x103919da8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StartGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool StartGrayUpdate(); // Offset: 0x103919d74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.StartDolphinUpdateAfterCDNUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartDolphinUpdateAfterCDNUpdateFailed(); // Offset: 0x103919d60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCDNUpdateAfterDolphinUpdateFailed(); // Offset: 0x103919d4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ShutdownUnrealNetwork
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShutdownUnrealNetwork(); // Offset: 0x103919d30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.SetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShouldShowAdaptTipInLobby(bool bShoudShow); // Offset: 0x103919cac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.SetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameSubMode(struct FString SubMode); // Offset: 0x103919c14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetGameStatusMap
	// Flags: [Final|Native|Public]
	void SetGameStatusMap(struct TMap<struct FName, struct FString> InGameStatusMap); // Offset: 0x103919b54 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.SetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClientEnterBattleStage(struct FString InStageStr); // Offset: 0x103919abc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetAccountByWebLogin
	// Flags: [Final|Native|Public]
	void SetAccountByWebLogin(int Channel, struct FString OpenID, struct FString userId, struct FString TokenID, int ExpireTime); // Offset: 0x103919900 // Return & Params: Num(5) Size(0x3c)

	// Object Name: Function Client.GameFrontendHUD.RetryDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryDownload(); // Offset: 0x1039198ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RetryCDNDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryCDNDownload(); // Offset: 0x1039198d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ReleaseBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReleaseBattleUtils(); // Offset: 0x1039198c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x103919834 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.RegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUIShowHideEventDelegate(struct FString Source, DelegateProperty Delegate); // Offset: 0x103919724 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnWebviewNotify(struct FWebviewInfoWrapper& webviewinfo); // Offset: 0x103919678 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewActionNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnWebviewActionNotify(struct FString URL); // Offset: 0x1039195bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnUAAssistantEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnUAAssistantEvent(struct FUAAssistantInfoWrapper& UAAssistentInfo); // Offset: 0x10391950c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnSDKCallbackEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnSDKCallbackEvent(struct FSDKCallbackInfoWrapper& sdkCallbackInfo); // Offset: 0x10391945c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x1039193a8 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnRefreshAccountInfo
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnRefreshAccountInfo(bool Result, int InChannel, struct FString InOpenId); // Offset: 0x103919260 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnQuickLoginNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnQuickLoginNotify(struct FWakeupInfoWrapper& wakeupinfo); // Offset: 0x1039191b4 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnPlatformFriendNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnPlatformFriendNotify(struct FPlatformFriendInfoMap& PlatformFriendInfoMap); // Offset: 0x1039190f8 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function Client.GameFrontendHUD.OnNotUpdateFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnNotUpdateFinished(); // Offset: 0x1039190e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.OnLoginFlowNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnLoginFlowNotify(int _Flow, int _Param, struct FString ExtraData); // Offset: 0x103918fa0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnHttpImgResponse
	// Flags: [Final|Native|Protected]
	void OnHttpImgResponse(struct UTexture2D* Texture, struct UImageDownloader* downloader); // Offset: 0x103918eec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGroupNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnGroupNotify(struct FGroupInfoWrapper& groupInfo); // Offset: 0x103918e3c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnGetTicketNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetTicketNotify(struct FString Ticket); // Offset: 0x103918d80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGetShortUrlNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetShortUrlNotify(int Ret, struct FString ShortUrl); // Offset: 0x103918c84 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGetCountryNoNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetCountryNoNotify(int country); // Offset: 0x103918c08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.OnGenQRImgNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGenQRImgNotify(int Ret, int Size, struct FString imgPath); // Offset: 0x103918af8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGCloudNetStateChangeNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGCloudNetStateChangeNotify(int State, int EventParam1, int EventParam2, int EventParam3); // Offset: 0x1039189d0 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGameMasterEvent
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGameMasterEvent(struct FString EventName, int Ret); // Offset: 0x1039188d4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GameFrontendHUD.OnCheckUpdateStateFinished
	// Flags: [Final|Native|Private|HasOutParms]
	void OnCheckUpdateStateFinished(struct FDownloaderInfo& Info); // Offset: 0x103918828 // Return & Params: Num(1) Size(0x40)

	// Object Name: Function Client.GameFrontendHUD.OnAreaChanged
	// Flags: [Final|Native|Public]
	void OnAreaChanged(struct FString InArea); // Offset: 0x103918790 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.NotifyLoadingUIOperation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NotifyLoadingUIOperation(int OperationType); // Offset: 0x103918714 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.MakeToSuppotAdaptation
	// Flags: [Final|Native|Public]
	void MakeToSuppotAdaptation(struct UPanelSlot* PanelSlot); // Offset: 0x103918698 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.LuaDoString
	// Flags: [Native|Public|BlueprintCallable|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x1039185f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.IsWindowOB
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsWindowOB(); // Offset: 0x1039185c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.IsInstallPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstallPlatform(struct FString PlatForm); // Offset: 0x1039184f8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GameFrontendHUD.IsCEHideLobbyUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCEHideLobbyUI(); // Offset: 0x1039184c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.HasAnyNetMsgToHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnyNetMsgToHandle(); // Offset: 0x103918490 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetWidgetRenderCanChange
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetWidgetRenderCanChange(); // Offset: 0x10391845c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x103918420 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetUpdater
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGDolphinUpdater* GetUpdater(); // Offset: 0x103918404 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetTranslator
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTranslator* GetTranslator(); // Offset: 0x1039183e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetShouldShowAdaptTipInLobby(); // Offset: 0x1039183b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetSettingSubsystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USettingSubsystem* GetSettingSubsystem(); // Offset: 0x103918380 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPufferDownloader
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGCPufferDownloader* GetPufferDownloader(); // Offset: 0x103918364 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPingReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPingReportInfo(); // Offset: 0x103918300 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetPacketLossReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPacketLossReportInfo(); // Offset: 0x10391829c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetLuaStateWrapper
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULuaStateWrapper* GetLuaStateWrapper(); // Offset: 0x103918268 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaEventBridge
	// Flags: [Final|Native|Public]
	struct ULuaEventBridge* GetLuaEventBridge(); // Offset: 0x103918234 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaBlueprintSysMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBlueprintMgr* GetLuaBlueprintSysMgr(); // Offset: 0x103918200 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetHttpWrapper
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHttpWrapper* GetHttpWrapper(); // Offset: 0x1039181e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGVoiceInterface
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGVoiceInterface* GetGVoiceInterface(); // Offset: 0x1039181a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameSubMode(); // Offset: 0x103918170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetGameState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AGameStateBase* GetGameState(); // Offset: 0x10391813c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetFPSReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetFPSReportInfo(); // Offset: 0x1039180d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x10391809c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetDetailNetInfoFromGCloud
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDetailNetInfoFromGCloud(); // Offset: 0x103918068 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetColorBlindnessMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UColorBlindnessMgr* GetColorBlindnessMgr(); // Offset: 0x10391802c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientNetObj
	// Flags: [Final|Native|Public|Const]
	struct UObject* GetClientNetObj(); // Offset: 0x103917ff8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetClientEnterBattleStage(); // Offset: 0x103917fc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetBugReporter
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBugReporter* GetBugReporter(); // Offset: 0x103917f8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBattleUtils* GetBattleUtils(); // Offset: 0x103917f58 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleIDHexStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetBattleIDHexStr(); // Offset: 0x103917ef4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetAutoRunModID
	// Flags: [Final|Native|Public]
	int GetAutoRunModID(); // Offset: 0x103917ec0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetAsyncLoadHelper
	// Flags: [Final|Native|Public]
	struct UAsyncLoadHelper* GetAsyncLoadHelper(); // Offset: 0x103917e8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x103917e78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.EnableFPSAndMemoryLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableFPSAndMemoryLog(bool bEnable); // Offset: 0x103917df4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.DispatchLongTimeNoOperation
	// Flags: [Final|Native|Public|HasOutParms]
	void DispatchLongTimeNoOperation(int& TimeOutCounter); // Offset: 0x103917d68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.DispatchConfirmMisKill
	// Flags: [Final|Native|Public]
	void DispatchConfirmMisKill(struct FString KillerName); // Offset: 0x103917ce0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.CreateBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateBattleUtils(); // Offset: 0x103917ccc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.CallGlobalScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallGlobalScriptFunction(struct FString InFunctionName); // Offset: 0x103917c2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x103917c18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.BattleUtilsGameEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BattleUtilsGameEnd(); // Offset: 0x103917c04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AfterLoadedEditorLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AfterLoadedEditorLogin(); // Offset: 0x103917bf0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegateEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegateEx(struct UPanelSlot* PanelSlot); // Offset: 0x103917b74 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegate(struct UPanelSlot* PanelSlot); // Offset: 0x103917af8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendUtils
// Size: 0x398 // Inherited bytes: 0x398
struct UGameFrontendUtils : UFrontendUtils {
};

// Object Name: Class Client.GameJoyInterface
// Size: 0x48 // Inherited bytes: 0x28
struct UGameJoyInterface : UObject {
	// Fields
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18

	// Functions

	// Object Name: Function Client.GameJoyInterface.ShareVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShareVideo(int Channel); // Offset: 0x103920af0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103920a74 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnVideoShare
	// Flags: [Final|Native|Private]
	void OnVideoShare(struct FString Msg); // Offset: 0x1039209b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameJoyInterface.OnShowVideoPlayer
	// Flags: [Final|Native|Private]
	void OnShowVideoPlayer(int IsShow); // Offset: 0x10392093c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingStart
	// Flags: [Final|Native|Private]
	void OnRecordingStart(int Status); // Offset: 0x1039208c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingEnd
	// Flags: [Final|Native|Private]
	void OnRecordingEnd(int64_t Duration); // Offset: 0x103920844 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnManualRecordingStart
	// Flags: [Final|Native|Private]
	void OnManualRecordingStart(int Status); // Offset: 0x1039207c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKPermission
	// Flags: [Final|Native|Private]
	void OnCheckSDKPermission(bool IsSuccess); // Offset: 0x103920744 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKFeature
	// Flags: [Final|Native|Private]
	void OnCheckSDKFeature(int sdkFeatureInt); // Offset: 0x1039206c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.IsSDKFeatureSupport
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsSDKFeatureSupport(); // Offset: 0x103920694 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UGameJoyInterface* GetInstance(); // Offset: 0x103920660 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GDolphinUpdater
// Size: 0x318 // Inherited bytes: 0x28
struct UGDolphinUpdater : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FString, struct FString> pakHashList; // Offset: 0x78 // Size: 0x50
	char pad_0xC8[0xc8]; // Offset: 0xc8 // Size: 0xc8
	bool AllowIOSBGDownload; // Offset: 0x190 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x191 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x192 // Size: 0x01
	char pad_0x193[0x1]; // Offset: 0x193 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x194 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x198 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x19c // Size: 0x04
	bool EnableRandomBackupURL; // Offset: 0x1a0 // Size: 0x01
	bool EnablePufferUpdate; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A2[0x16]; // Offset: 0x1a2 // Size: 0x16
	struct FString UpdateInfoPath; // Offset: 0x1b8 // Size: 0x10
	bool OpenDebugLog; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x14f]; // Offset: 0x1c9 // Size: 0x14f

	// Functions

	// Object Name: Function Client.GDolphinUpdater.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(); // Offset: 0x1039215d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.SetEnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableCDNGetVersion(bool Enable); // Offset: 0x10392154c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.OnUpdateError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnUpdateError(int curVersionStage, int ErrorCode); // Offset: 0x103921498 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GDolphinUpdater.OnDolphinBGDownloadDone
	// Flags: [Final|Native|Public]
	void OnDolphinBGDownloadDone(); // Offset: 0x103921484 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.OnAreaChanged
	// Flags: [Final|Native|Private]
	void OnAreaChanged(struct FString InArea); // Offset: 0x1039213ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x1039213b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsInstallInApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstallInApp(); // Offset: 0x103921384 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x103921350 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsExamine
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsExamine(); // Offset: 0x10392131c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.Install
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Install(); // Offset: 0x103921308 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.GetTotalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetTotalValue(); // Offset: 0x1039212d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetCurValue(); // Offset: 0x1039212a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x103921164 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.GetCurPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetCurPercent(); // Offset: 0x103921130 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetChannelIDWithHUD
	// Flags: [Final|Native|Private]
	uint32_t GetChannelIDWithHUD(struct UGameFrontendHUD* InGameFrontendHUD); // Offset: 0x1039210a4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.GDolphinUpdater.GetChannelID
	// Flags: [Final|Native|Private]
	uint32_t GetChannelID(); // Offset: 0x103921070 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x10392105c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.FinishPufferUpdate
	// Flags: [Final|Native|Public]
	void FinishPufferUpdate(); // Offset: 0x103921048 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.EnableIOSBGDownload4G
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableIOSBGDownload4G(bool bEnableCellularAccess); // Offset: 0x103920fc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.EnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableCDNGetVersion(); // Offset: 0x103920f90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x103920f7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x103920f68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelAppUpdate(); // Offset: 0x103920f54 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.IMSDKNotice
// Size: 0xa8 // Inherited bytes: 0x28
struct UIMSDKNotice : UObject {
	// Fields
	char pad_0x28[0x80]; // Offset: 0x28 // Size: 0x80

	// Functions

	// Object Name: Function Client.IMSDKNotice.GetNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FIMSDKNoticeInfo> GetNotice(struct FString Scene); // Offset: 0x103922550 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IMSDKNotice.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIMSDKNotice* GetInstance(); // Offset: 0x10392251c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IMSDKNotice.ClearNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearNotice(); // Offset: 0x103922508 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.AvatarItemDownloadPuffer
// Size: 0x30 // Inherited bytes: 0x30
struct UAvatarItemDownloadPuffer : UAvatarItemDownload {
	// Functions

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartDownloadItem
	// Flags: [Native|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x103922d54 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartBatchDownloadItem
	// Flags: [Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103922bd4 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.GCPufferDownloader
// Size: 0x440 // Inherited bytes: 0x28
struct UGCPufferDownloader : UObject {
	// Fields
	char pad_0x28[0x2c8]; // Offset: 0x28 // Size: 0x2c8
	bool Disable; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x97]; // Offset: 0x2f1 // Size: 0x97
	struct FString DownloadDir; // Offset: 0x388 // Size: 0x10
	struct FString PufferTmpDir; // Offset: 0x398 // Size: 0x10
	uint32_t CleanFlagVer; // Offset: 0x3a8 // Size: 0x04
	char pad_0x3AC[0x4]; // Offset: 0x3ac // Size: 0x04
	struct TArray<struct FString> CleanFileNamePattern; // Offset: 0x3b0 // Size: 0x10
	bool PreFetchPakEnable; // Offset: 0x3c0 // Size: 0x01
	bool PreFetchFileClearEnable; // Offset: 0x3c1 // Size: 0x01
	bool PreFetchConvertEnable; // Offset: 0x3c2 // Size: 0x01
	char pad_0x3C3[0x5]; // Offset: 0x3c3 // Size: 0x05
	struct TArray<struct FString> PreFetchPakNames; // Offset: 0x3c8 // Size: 0x10
	uint32_t PreFetchReserveredDiskSpace; // Offset: 0x3d8 // Size: 0x04
	bool PreFetchODPak_Enable; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	int PreFetchODPaks_MaxNum; // Offset: 0x3e0 // Size: 0x04
	int PreFetchODPaks_BatchSize; // Offset: 0x3e4 // Size: 0x04
	int PreFetchODPaks_FetchedNum; // Offset: 0x3e8 // Size: 0x04
	int PreFetchODPaks_FetchedIndex; // Offset: 0x3ec // Size: 0x04
	struct TArray<struct FString> PreFetchODPaks_Filenames; // Offset: 0x3f0 // Size: 0x10
	bool AllowIOSBGDownload; // Offset: 0x400 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x401 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x402 // Size: 0x01
	char pad_0x403[0x1]; // Offset: 0x403 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x404 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x408 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x40c // Size: 0x04
	bool DisableBGDownloadNotification; // Offset: 0x410 // Size: 0x01
	char pad_0x411[0x3]; // Offset: 0x411 // Size: 0x03
	float PreFetchODPaks_StartTime; // Offset: 0x414 // Size: 0x04
	struct FString PreFetchODPaks_ConfigName; // Offset: 0x418 // Size: 0x10
	char pad_0x428[0x18]; // Offset: 0x428 // Size: 0x18

	// Functions

	// Object Name: Function Client.GCPufferDownloader.StopTask
	// Flags: [Final|Native|Public]
	bool StopTask(uint64 TaskId); // Offset: 0x103925424 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.StopMergeBinDiffPak
	// Flags: [Final|Native|Public]
	int StopMergeBinDiffPak(int outterTaskID); // Offset: 0x103925398 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StopCheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool StopCheckDownloadFileFraming(int outterTaskID); // Offset: 0x10392530c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.StopBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StopBGDownloadNotification(); // Offset: 0x1039252f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GCPufferDownloader.StopAllTask
	// Flags: [Final|Native|Public]
	bool StopAllTask(); // Offset: 0x1039252c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.StartDownloadItem
	// Flags: [Final|Native|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty downloadDelegate); // Offset: 0x1039251c0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.StartBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StartBGDownloadNotification(uint64 InDownloadedSize); // Offset: 0x103925144 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StartBatchDownloadItem
	// Flags: [Final|Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103924fcc // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductIdBase
	// Flags: [Final|Native|Public]
	void SetTempProductIdBase(int ProductIdRaw); // Offset: 0x103924f50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductId
	// Flags: [Final|Native|Public]
	void SetTempProductId(struct FString ProductIdRaw); // Offset: 0x103924e94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.SetPrefetchConfig
	// Flags: [Final|Native|Public]
	void SetPrefetchConfig(bool pakEnable, bool fileClearEnable, bool convertEnable, int reserveredDiskSpace, struct FString FileList, int InPreFetchODPaksMaxNum, int InPreFetchODPaksBatchSize); // Offset: 0x103924c40 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Public]
	void SetIOSBGDownloadAttribute(bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x103924afc // Return & Params: Num(4) Size(0xc)

	// Object Name: Function Client.GCPufferDownloader.SetImmDLMaxSpeed
	// Flags: [Final|Native|Public]
	bool SetImmDLMaxSpeed(uint64 MaxSpeed); // Offset: 0x103924a70 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.SetBattleDownloadSwitch
	// Flags: [Final|Native|Public]
	void SetBattleDownloadSwitch(bool Enable); // Offset: 0x1039249ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ReturnSplitMiniPakFilelist_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnSplitMiniPakFilelist_LuaState(); // Offset: 0x1039249d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.ReturnLocalFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnLocalFiles_LuaState(); // Offset: 0x1039249bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.RequestFile
	// Flags: [Final|Native|Public]
	uint64 RequestFile(struct FString FilePath, bool ForceUpdate); // Offset: 0x1039248a8 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.RemountPakFiles
	// Flags: [Final|Native|Public]
	bool RemountPakFiles(); // Offset: 0x103924874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ReadFile
	// Flags: [Final|Native|Public]
	struct FString ReadFile(struct FString Filename); // Offset: 0x103924780 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.PreFetchPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchPakFiles(); // Offset: 0x10392474c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesUpdate
	// Flags: [Final|Native|Public]
	int PreFetchODPakFilesUpdate(); // Offset: 0x103924718 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPreProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPreProcess(bool Start); // Offset: 0x103924684 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPostProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPostProcess(int ErrorCode); // Offset: 0x1039245f8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFiles(bool Start); // Offset: 0x103924564 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.OnItemDownloadedInFighting
	// Flags: [Final|Native|Public]
	void OnItemDownloadedInFighting(struct FString PackHash, struct FString ErrorCode); // Offset: 0x103924430 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.OnHashGenerateFinished
	// Flags: [Final|Native|Public]
	void OnHashGenerateFinished(int outterTaskID, struct FString hashCode); // Offset: 0x103924334 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.MoveFileTo
	// Flags: [Final|Native|Public]
	int MoveFileTo(struct FString Filename, struct FString from, struct FString to); // Offset: 0x103924178 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.GCPufferDownloader.MoveFile
	// Flags: [Final|Native|Public]
	int MoveFile(struct FString from, struct FString to); // Offset: 0x103924034 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.GCPufferDownloader.MergeBinDiffPak
	// Flags: [Final|Native|Public]
	int MergeBinDiffPak(int outterTaskID, struct FString PakFilenameOld, struct FString PakFilenameDiff, struct FString PakFilenameNew, bool fast); // Offset: 0x103923df0 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function Client.GCPufferDownloader.IsODPaks
	// Flags: [Final|Native|Public]
	bool IsODPaks(struct FString FilePath); // Offset: 0x103923d24 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsODFileExists
	// Flags: [Final|Native|Public]
	bool IsODFileExists(struct FString Path); // Offset: 0x103923c7c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsInitSuccess
	// Flags: [Final|Native|Public]
	bool IsInitSuccess(); // Offset: 0x103923c48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.IsFileReady
	// Flags: [Final|Native|Public]
	bool IsFileReady(struct FString FilePath); // Offset: 0x103923b7c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsFileExist
	// Flags: [Final|Native|Public]
	bool IsFileExist(struct FString Filename, struct FString extension); // Offset: 0x103923a38 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GCPufferDownloader.InitializeODPaks
	// Flags: [Final|Native|Public]
	bool InitializeODPaks(); // Offset: 0x103923a04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.GetTempWorkPath
	// Flags: [Final|Native|Public]
	struct FString GetTempWorkPath(); // Offset: 0x1039239a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductIDBase
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductIDBase(struct TArray<int>& ProductIDs); // Offset: 0x1039238f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductID
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductID(struct TArray<int>& ProductIDs); // Offset: 0x103923850 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetODPakNum
	// Flags: [Final|Native|Public]
	int GetODPakNum(); // Offset: 0x10392381c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetODPakName
	// Flags: [Final|Native|Public]
	struct FString GetODPakName(struct FString Path); // Offset: 0x10392374c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.GetInitErrcode
	// Flags: [Final|Native|Public]
	uint32_t GetInitErrcode(); // Offset: 0x103923718 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetFileSizeCompressed
	// Flags: [Final|Native|Public]
	uint64 GetFileSizeCompressed(struct FString FilePath); // Offset: 0x10392364c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.GetFileSize
	// Flags: [Final|Native|Public]
	float GetFileSize(struct FString Filename); // Offset: 0x103923580 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GCPufferDownloader.GetDownloadPath
	// Flags: [Final|Native|Public]
	struct FString GetDownloadPath(); // Offset: 0x10392351c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetCurrentSpeed
	// Flags: [Final|Native|Public]
	float GetCurrentSpeed(); // Offset: 0x1039234e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetBatchODPaksDownloadList_LuaState
	// Flags: [Final|Native|Public]
	int GetBatchODPaksDownloadList_LuaState(); // Offset: 0x1039234d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.EnableUseOldInterface
	// Flags: [Final|Native|Public]
	void EnableUseOldInterface(bool Enable); // Offset: 0x10392344c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.DeleteFileEvenIfUnfinished
	// Flags: [Final|Native|Public]
	bool DeleteFileEvenIfUnfinished(struct FString FilePath); // Offset: 0x103923380 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x1039232c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.ConvertPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ConvertPreFetchFiles(); // Offset: 0x103923290 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ConvertItemIdToPakName
	// Flags: [Final|Native|Public]
	struct FString ConvertItemIdToPakName(uint32_t ItemID); // Offset: 0x1039231dc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.ClearUselessODPaks
	// Flags: [Final|Native|Public]
	bool ClearUselessODPaks(); // Offset: 0x1039231a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchODPaksFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchODPaksFiles(); // Offset: 0x103923174 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchFiles(); // Offset: 0x103923140 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.CheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool CheckDownloadFileFraming(int outterTaskID, struct FString Filename, int chunkSize); // Offset: 0x103922ff4 // Return & Params: Num(4) Size(0x1d)
};

// Object Name: Class Client.GMLogShare
// Size: 0x30 // Inherited bytes: 0x28
struct UGMLogShare : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function Client.GMLogShare.ShareLogFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShareLogFile(); // Offset: 0x103926590 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GMLogShare.Init
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Init(); // Offset: 0x10392657c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.GVoiceInterface
// Size: 0x4a0 // Inherited bytes: 0x28
struct UGVoiceInterface : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	int lbsRoomMemberID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x1c]; // Offset: 0x34 // Size: 0x1c
	DelegateProperty CheckTempLbsRoomOnJoinRoom; // Offset: 0x50 // Size: 0x10
	DelegateProperty CheckTempLbsRoomOnQuitRoom; // Offset: 0x60 // Size: 0x10
	DelegateProperty OnSTTReportCallback; // Offset: 0x70 // Size: 0x10
	DelegateProperty OnRSTSCallback; // Offset: 0x80 // Size: 0x10
	DelegateProperty OnRSTSSpeechToTextCallback; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x10]; // Offset: 0xa0 // Size: 0x10
	struct FString ServerInfo; // Offset: 0xb0 // Size: 0x10
	uint32_t openGvoiceLog; // Offset: 0xc0 // Size: 0x04
	uint32_t MicVolumeMUFactor; // Offset: 0xc4 // Size: 0x04
	uint32_t SpeekerVolumeMUFactor; // Offset: 0xc8 // Size: 0x04
	int RoomOperationTimeout; // Offset: 0xcc // Size: 0x04
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xd0 // Size: 0x08
	char pad_0xD8[0x88]; // Offset: 0xd8 // Size: 0x88
	DelegateProperty OpenMicFail; // Offset: 0x160 // Size: 0x10
	DelegateProperty OpenMicSuccess; // Offset: 0x170 // Size: 0x10
	DelegateProperty CloseMicFail; // Offset: 0x180 // Size: 0x10
	DelegateProperty CloseMicSuccess; // Offset: 0x190 // Size: 0x10
	DelegateProperty OpenSpeakerFail; // Offset: 0x1a0 // Size: 0x10
	DelegateProperty OpenSpeakerSuccess; // Offset: 0x1b0 // Size: 0x10
	DelegateProperty CloseSpeakerFail; // Offset: 0x1c0 // Size: 0x10
	DelegateProperty CloseSpeakerSuccess; // Offset: 0x1d0 // Size: 0x10
	DelegateProperty JoinRoomFail; // Offset: 0x1e0 // Size: 0x10
	DelegateProperty JoinRoomNotify; // Offset: 0x1f0 // Size: 0x10
	DelegateProperty QuitRoomNotify; // Offset: 0x200 // Size: 0x10
	DelegateProperty JoinLbsRoomNotify; // Offset: 0x210 // Size: 0x10
	DelegateProperty QuitLbsRoomNotify; // Offset: 0x220 // Size: 0x10
	DelegateProperty RoomStatusUpdatedNotify; // Offset: 0x230 // Size: 0x10
	DelegateProperty SetAppInfoSuccess; // Offset: 0x240 // Size: 0x10
	DelegateProperty SetAppInfoFail; // Offset: 0x250 // Size: 0x10
	DelegateProperty GetReconnectInfo; // Offset: 0x260 // Size: 0x10
	DelegateProperty ImSpeakingNotify; // Offset: 0x270 // Size: 0x10
	DelegateProperty TestMicFail; // Offset: 0x280 // Size: 0x10
	DelegateProperty TestMicSuccess; // Offset: 0x290 // Size: 0x10
	DelegateProperty QuitRoomFail; // Offset: 0x2a0 // Size: 0x10
	DelegateProperty DownLoadFileNotify; // Offset: 0x2b0 // Size: 0x10
	DelegateProperty SpeechToTextNotify; // Offset: 0x2c0 // Size: 0x10
	DelegateProperty UploadFileNotify; // Offset: 0x2d0 // Size: 0x10
	DelegateProperty ApplyMessageKeyNotify; // Offset: 0x2e0 // Size: 0x10
	DelegateProperty MemberIsSpeakingNotify; // Offset: 0x2f0 // Size: 0x10
	DelegateProperty LbsMemberIsSpeakingNotify; // Offset: 0x300 // Size: 0x10
	DelegateProperty OnMuteSwitchResult; // Offset: 0x310 // Size: 0x10
	DelegateProperty ReportVoiceTimeToServer; // Offset: 0x320 // Size: 0x10
	DelegateProperty RecordSuccess; // Offset: 0x330 // Size: 0x10
	DelegateProperty RecordFail; // Offset: 0x340 // Size: 0x10
	DelegateProperty UploadSuccess; // Offset: 0x350 // Size: 0x10
	DelegateProperty UploadFail; // Offset: 0x360 // Size: 0x10
	DelegateProperty SpeechToTextSuccess; // Offset: 0x370 // Size: 0x10
	DelegateProperty SpeechToTextFail; // Offset: 0x380 // Size: 0x10
	DelegateProperty DownloadFileSuccess; // Offset: 0x390 // Size: 0x10
	DelegateProperty DownloadFileFail; // Offset: 0x3a0 // Size: 0x10
	DelegateProperty EnableRoomMicrophone; // Offset: 0x3b0 // Size: 0x10
	DelegateProperty ExitInfectionGameMode; // Offset: 0x3c0 // Size: 0x10
	DelegateProperty JoinInfectionGameMode; // Offset: 0x3d0 // Size: 0x10
	DelegateProperty RequestPrivacyInSetting; // Offset: 0x3e0 // Size: 0x10
	DelegateProperty OnReportPlayerCallback; // Offset: 0x3f0 // Size: 0x10
	DelegateProperty OnGVoiceEvent; // Offset: 0x400 // Size: 0x10
	char pad_0x410[0x90]; // Offset: 0x410 // Size: 0x90

	// Functions

	// Object Name: Function Client.GVoiceInterface.VoiceSpeechToText
	// Flags: [Final|Native|Public]
	int VoiceSpeechToText(struct FString InFileID, int InTimeout, int InLanguage); // Offset: 0x10392a624 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.UploadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UploadRecordFile(); // Offset: 0x10392a610 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.UploadRecordedFile
	// Flags: [Final|Native|Public]
	int UploadRecordedFile(struct FString InFilePath, int InTimeout, bool InPermanent); // Offset: 0x10392a4e4 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.UpdateVoiceCoordinate
	// Flags: [Final|Native|Public]
	int UpdateVoiceCoordinate(struct FString InRoomName, int64_t X, int64_t Y, int64_t Z, int64_t Radius); // Offset: 0x10392a344 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function Client.GVoiceInterface.TestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestMic(); // Offset: 0x10392a330 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.TeamSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamSpeakerEnable(); // Offset: 0x10392a314 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.TeamMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamMicphoneEnable(); // Offset: 0x10392a2f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMode(enum class ECharacterMainType CharMode); // Offset: 0x10392a27c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMicphoneWhenCorpsMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMicphoneWhenCorpsMode(); // Offset: 0x10392a268 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SwitchCampRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchCampRoom(enum class ECharacterMainType campMode); // Offset: 0x10392a1ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.StopRecording
	// Flags: [Final|Native|Public]
	int StopRecording(); // Offset: 0x10392a1b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.StopRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopRecord(); // Offset: 0x10392a1a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopPlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopPlayRecordFile(); // Offset: 0x10392a190 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopInterphone(); // Offset: 0x10392a17c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopCampMode(); // Offset: 0x10392a168 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartRecording
	// Flags: [Final|Native|Public]
	int StartRecording(struct FString InFilePath, bool InNotVoip); // Offset: 0x10392a078 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceInterface.StartRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartRecord(); // Offset: 0x10392a064 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInterphone(); // Offset: 0x10392a050 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCampMode(struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x103929f10 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.GVoiceInterface.SpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SpeechToText(); // Offset: 0x103929efc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowOpenSpeakerAtFirstMsg
	// Flags: [Native|Public|BlueprintCallable]
	void ShowOpenSpeakerAtFirstMsg(); // Offset: 0x103929ee0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowCorpsModeCannotUseLBSVoice
	// Flags: [Native|Public|BlueprintCallable]
	void ShowCorpsModeCannotUseLBSVoice(); // Offset: 0x103929ec4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SetVoiceServer
	// Flags: [Final|Native|Public]
	void SetVoiceServer(struct FString ServerInfo); // Offset: 0x103929e2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetVoiceMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVoiceMode(int Type); // Offset: 0x103929db0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerVolum(float Value); // Offset: 0x103929d34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerStatus(bool Flag); // Offset: 0x103929cb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetServerInfo
	// Flags: [Final|Native|Public]
	int SetServerInfo(struct FString URL, struct FString InDefaultIpSvr); // Offset: 0x103929bb4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.GVoiceInterface.SetRoomOperationTimeout
	// Flags: [Final|Native|Public]
	void SetRoomOperationTimeout(int InTimeout); // Offset: 0x103929b38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetReportBufferTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReportBufferTime(int nTimeSec); // Offset: 0x103929abc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayerVolume(struct FString InPlayerId, int InVol); // Offset: 0x1039299c0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.SetNotify
	// Flags: [Final|Native|Public]
	int SetNotify(); // Offset: 0x10392998c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetMode
	// Flags: [Final|Native|Public]
	int SetMode(int InGVMode); // Offset: 0x103929900 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneVolum(float Value); // Offset: 0x103929884 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneStatus(bool Flag); // Offset: 0x103929800 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetLbsVoiceRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsVoiceRadius(float Radius); // Offset: 0x103929788 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetLbsRoomEnableStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsRoomEnableStatus(bool Flag); // Offset: 0x103929704 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGVoiceSupportBackgroundChat
	// Flags: [Final|Native|Public]
	void SetGVoiceSupportBackgroundChat(bool isSupportBGChat); // Offset: 0x103929680 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGVoiceChatServiceEnable
	// Flags: [Final|Native|Public]
	void SetGVoiceChatServiceEnable(bool IsEnable); // Offset: 0x1039295fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGMServerUrl
	// Flags: [Final|Native|Public]
	void SetGMServerUrl(struct FString InServerUrl); // Offset: 0x103929564 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x1039294e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.SetFeature
	// Flags: [Final|Native|Public]
	void SetFeature(uint8_t InFeature, bool Inactive); // Offset: 0x103929428 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GVoiceInterface.SetCurrentDownloadFieldID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentDownloadFieldID(struct FString filedId); // Offset: 0x10392936c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetAppInfo
	// Flags: [Final|Native|Public]
	int SetAppInfo(struct FString InAppId, struct FString InAppKey, struct FString InOpenId); // Offset: 0x10392921c // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.GVoiceInterface.SetAllVoiceStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SetAllVoiceStatus(bool Flag); // Offset: 0x103929190 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.RSTSStopRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RSTSStopRecording(); // Offset: 0x10392917c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.RSTSSpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	int RSTSSpeechToText(int InSrcLang); // Offset: 0x1039290f0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.ResetWhenLogOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetWhenLogOut(); // Offset: 0x1039290dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ReportPlayers
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ReportPlayers(struct FString InExtraInfo, struct TArray<struct FString> InOpenids); // Offset: 0x103928f78 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GVoiceInterface.ReportFileForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ReportFileForAbroad(struct FString InFilePath, bool InTranslate, bool InChangeVoice, int InTime); // Offset: 0x103928df8 // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.ReactiveLbsStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReactiveLbsStatus(); // Offset: 0x103928de4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.QuitVoiceRoom
	// Flags: [Final|Native|Public]
	int QuitVoiceRoom(struct FString InRoomName); // Offset: 0x103928d3c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.QuitTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitTempLbsRoom(struct FString roomStr); // Offset: 0x103928c80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.QuitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitRoom(); // Offset: 0x103928c6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.QuitCommonRoom
	// Flags: [Final|Native|Public]
	void QuitCommonRoom(struct FString InRoomName); // Offset: 0x103928bd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.Poll
	// Flags: [Final|Native|Public]
	int Poll(); // Offset: 0x103928ba0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.PlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayRecordFile(); // Offset: 0x103928b8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.PlayRecordedFile
	// Flags: [Final|Native|Public]
	int PlayRecordedFile(struct FString InDownloadInFilePath); // Offset: 0x103928ae4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.OpenVoiceSpeaker
	// Flags: [Final|Native|Public]
	int OpenVoiceSpeaker(); // Offset: 0x103928ab0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenVoiceMic
	// Flags: [Final|Native|Public]
	int OpenVoiceMic(); // Offset: 0x103928a7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenTeamSpeakerOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenTeamSpeakerOnly(bool ShowTips); // Offset: 0x1039289f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenTeamMicphoneOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamMicphoneOnly(bool ShowTips); // Offset: 0x103928964 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenTeamInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamInterphone(); // Offset: 0x103928930 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenSpeakerByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenSpeakerByTempLbs(bool Open); // Offset: 0x1039288ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenSpeaker(); // Offset: 0x103928878 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenMicByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicByTempLbs(bool Open); // Offset: 0x1039287f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenMicAndSpeakerAfterJoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicAndSpeakerAfterJoinLbsRoom(); // Offset: 0x1039287e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenMic(); // Offset: 0x1039287ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenIngameSpeaker(); // Offset: 0x103928798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenIngameMicphone(); // Offset: 0x103928764 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenAllSpeaker(bool ShowTips); // Offset: 0x1039286e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllMicphone(bool ShowTips); // Offset: 0x10392864c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenAllInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllInterphone(); // Offset: 0x103928618 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OnRoomTypeChanged
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnRoomTypeChanged(struct FString itemtext); // Offset: 0x10392857c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.OnResume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnResume(); // Offset: 0x103928568 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OnPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnPause(); // Offset: 0x103928554 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.LbsSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsSpeakerEnable(); // Offset: 0x103928538 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.LbsMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsMicphoneEnable(); // Offset: 0x10392851c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.JoinTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinTempLbsRoom(struct FString Room, struct FString userId); // Offset: 0x1039283e8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinTeamRoom
	// Flags: [Final|Native|Public]
	int JoinTeamRoom(struct FString InRoomName); // Offset: 0x103928340 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.JoinRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinRoom(struct FString Room, struct FString userId); // Offset: 0x10392820c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinRangeRoom
	// Flags: [Final|Native|Public]
	int JoinRangeRoom(struct FString InRoomName); // Offset: 0x103928164 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.JoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinLbsRoom(struct FString lbsRoom, struct FString userId); // Offset: 0x103928030 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinCommonRoom
	// Flags: [Final|Native|Public]
	void JoinCommonRoom(struct FString InRoomName); // Offset: 0x103927f98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.IsTeamInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTeamInterphoneOpenned(); // Offset: 0x103927f7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsSpeaking
	// Flags: [Final|Native|Public]
	bool IsSpeaking(); // Offset: 0x103927f48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsNewGVoiceInterface
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsNewGVoiceInterface(); // Offset: 0x103927f2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsLbsInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLbsInterphoneOpenned(); // Offset: 0x103927f10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsInterphoneMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInterphoneMode(); // Offset: 0x103927edc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsGVoiceEnable
	// Flags: [Final|Native|Public]
	bool IsGVoiceEnable(); // Offset: 0x103927ea8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.Invoke
	// Flags: [Final|Native|Public]
	int Invoke(uint32_t InCmd, uint32_t InParam1, uint32_t InParam2); // Offset: 0x103927da8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.InitGVoiceComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitGVoiceComponent(struct FString userId); // Offset: 0x103927cec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.InitGVoice
	// Flags: [Final|Native|Public]
	int InitGVoice(); // Offset: 0x103927cb8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x103927ca4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.HaveTeamRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveTeamRoom(); // Offset: 0x103927c70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.HaveLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveLbsRoom(); // Offset: 0x103927c3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.GetVoiceLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetVoiceLength(); // Offset: 0x103927c08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.GetTeamRoomName
	// Flags: [Final|Native|Public]
	struct FString GetTeamRoomName(); // Offset: 0x103927ba4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetRoomStatus
	// Flags: [Final|Native|Public]
	int GetRoomStatus(struct FString InRoomName); // Offset: 0x103927afc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.GetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPlayerVolume(struct FString InPlayerId); // Offset: 0x103927a30 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.GetMicState
	// Flags: [Final|Native|Public]
	int GetMicState(); // Offset: 0x1039279fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.GetLbsRoomName
	// Flags: [Final|Native|Public]
	struct FString GetLbsRoomName(); // Offset: 0x103927998 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetGMServerUrl
	// Flags: [Final|Native|Public]
	struct FString GetGMServerUrl(); // Offset: 0x103927930 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetAuthKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAuthKey(); // Offset: 0x10392791c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.GetAudioDeviceConnectionState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAudioDeviceConnectionState(); // Offset: 0x1039278e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.ForbidTeammateVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidTeammateVoiceById(int memberID, bool IsEnable); // Offset: 0x10392782c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceInterface.ForbidMemberVoice
	// Flags: [Final|Native|Public]
	int ForbidMemberVoice(int InMember, bool InEnable, struct FString InRoomName); // Offset: 0x103927704 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.ForbidLbsMemberVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidLbsMemberVoiceById(int memberID, bool IsEnable); // Offset: 0x103927648 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceInterface.EnbleMicAndSpeakerByRoomName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnbleMicAndSpeakerByRoomName(struct FString RoomName, bool Enable); // Offset: 0x10392753c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GVoiceInterface.EnableVoiceChat
	// Flags: [Final|Native|Public]
	void EnableVoiceChat(bool InEnable); // Offset: 0x1039274b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.EnableRoomSpeaker
	// Flags: [Final|Native|Public]
	int EnableRoomSpeaker(struct FString InRoomName, bool InEnable); // Offset: 0x1039273c8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceInterface.EnableReportForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int EnableReportForAbroad(bool InIsWholeRoundaudit); // Offset: 0x103927334 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.EnableReportALLAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout); // Offset: 0x103927218 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Client.GVoiceInterface.EnableMultiRoom
	// Flags: [Final|Native|Public]
	int EnableMultiRoom(bool InEnable); // Offset: 0x103927184 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.EnableLog
	// Flags: [Final|Native|Public]
	void EnableLog(bool InEnable); // Offset: 0x103927100 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.EnableGVoiceRoomMicrophone
	// Flags: [Final|Native|Public]
	int EnableGVoiceRoomMicrophone(struct FString InRoomName, bool InEnable); // Offset: 0x103927010 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceInterface.DownloadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DownloadRecordFile(); // Offset: 0x103926ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.DownloadRecordedFile
	// Flags: [Final|Native|Public]
	int DownloadRecordedFile(struct FString InFileID, struct FString InDownloadInFilePath, int InTimeout, bool InPermanent); // Offset: 0x103926e7c // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function Client.GVoiceInterface.CommonTestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommonTestMic(); // Offset: 0x103926e68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseVoiceSpeaker
	// Flags: [Final|Native|Public]
	int CloseVoiceSpeaker(); // Offset: 0x103926e34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CloseVoiceMic
	// Flags: [Final|Native|Public]
	int CloseVoiceMic(); // Offset: 0x103926e00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CloseSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSpeaker(); // Offset: 0x103926dec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseMic(); // Offset: 0x103926dd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void CloseIngameSpeaker(); // Offset: 0x103926dbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameMicphone
	// Flags: [Native|Public|BlueprintCallable]
	void CloseIngameMicphone(); // Offset: 0x103926da0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllSpeaker(bool ShowTips); // Offset: 0x103926d1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CloseAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllMicphone(bool ShowTips); // Offset: 0x103926c98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CheckDeviceMuteState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int CheckDeviceMuteState(); // Offset: 0x103926c64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CheckAndEnableRoomSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckAndEnableRoomSpeaker(); // Offset: 0x103926c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInLobby
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInLobby(); // Offset: 0x103926c34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInFighting
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInFighting(); // Offset: 0x103926c18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInChat
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInChat(); // Offset: 0x103926bfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInSetting(); // Offset: 0x103926be8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInGame(); // Offset: 0x103926bd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ApplyMessageKey
	// Flags: [Final|Native|Public]
	int ApplyMessageKey(); // Offset: 0x103926ba0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.AlwaysDisableRoomMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AlwaysDisableRoomMic(struct FString InRoomName, bool WithClear); // Offset: 0x103926ac0 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Client.HttpWrapper
// Size: 0xb0 // Inherited bytes: 0x28
struct UHttpWrapper : UObject {
	// Fields
	struct FScriptMulticastDelegate OnResponseEvent; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnImageDownloadResponseEvent; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x68]; // Offset: 0x48 // Size: 0x68

	// Functions

	// Object Name: Function Client.HttpWrapper.SimplePostForLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SimplePostForLua(struct FString URL, struct FString Content, int Priority, int QueueType); // Offset: 0x103930cb0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.HttpWrapper.SetQueueSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueSize(int QueueType, int InSize); // Offset: 0x103930bfc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.HttpWrapper.SetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueEnable(bool InEnableQueue); // Offset: 0x103930b7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.SetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPoolEnable(bool InEnablePool); // Offset: 0x103930af4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.RequestForLua
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int RequestForLua(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString>& Headers, struct FString Content, int Priority, int QueueType); // Offset: 0x1039308b8 // Return & Params: Num(7) Size(0x8c)

	// Object Name: Function Client.HttpWrapper.ImageDownloadRequestForLua
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int ImageDownloadRequestForLua(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString>& Headers, struct FString Content, int Priority); // Offset: 0x1039306b8 // Return & Params: Num(6) Size(0x88)

	// Object Name: Function Client.HttpWrapper.GetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetQueueEnable(); // Offset: 0x10393069c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetPoolEnable(); // Offset: 0x103930670 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetInternalIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetInternalIndex(); // Offset: 0x103930654 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequestAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequestAll(int QueueType); // Offset: 0x1039305d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequest(int QueueType, int ReqIndex); // Offset: 0x103930524 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class Client.ImageDownloader
// Size: 0xb0 // Inherited bytes: 0x28
struct UImageDownloader : UObject {
	// Fields
	struct FScriptMulticastDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnFail; // Offset: 0x38 // Size: 0x10
	struct FString FileURL; // Offset: 0x48 // Size: 0x10
	struct FString CompreesedFileUrl; // Offset: 0x58 // Size: 0x10
	struct FString FileSavePath; // Offset: 0x68 // Size: 0x10
	struct FString CompreesedFileSavePath; // Offset: 0x78 // Size: 0x10
	struct FString UrlHash; // Offset: 0x88 // Size: 0x10
	struct FString CompreesedUrlHash; // Offset: 0x98 // Size: 0x10
	bool InvalidImageFormat; // Offset: 0xa8 // Size: 0x01
	bool SaveDiskFile; // Offset: 0xa9 // Size: 0x01
	bool ForceUpdate; // Offset: 0xaa // Size: 0x01
	char pad_0xAB[0x5]; // Offset: 0xab // Size: 0x05

	// Functions

	// Object Name: Function Client.ImageDownloader.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(struct FString URL); // Offset: 0x103931460 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ImageDownloader.MakeDownloaderInGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloaderInGame(); // Offset: 0x10393142c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.MakeDownloader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloader(); // Offset: 0x1039313f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.GetTextureFromUrlWithoutDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTextureFromUrlWithoutDownload(struct FString URL); // Offset: 0x10393132c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ImageDownloader.CheckAndGetEncryptUrl
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString CheckAndGetEncryptUrl(struct FString& InUrl); // Offset: 0x10393125c // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.ImageDownloadUtil
// Size: 0x28 // Inherited bytes: 0x28
struct UImageDownloadUtil : UObject {
	// Functions

	// Object Name: Function Client.ImageDownloadUtil.SaveImageDownloadDiskFile
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SaveImageDownloadDiskFile(struct TArray<char>& OutArray, struct FString SavePath); // Offset: 0x103931ba4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.GetTextureFromMemory
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTextureFromMemory(struct FString PathName); // Offset: 0x103931ad8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ImageDownloadUtil.GetTexture2DFromDisk
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromDisk(struct FString SavePath, bool IsCompressed); // Offset: 0x1039319c4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.GetTexture2DFromArray
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromArray(struct TArray<char>& OutArray, bool IsCompressed); // Offset: 0x1039318c0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.CheckDiskFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckDiskFile(struct FString ImgDir, struct FString SubDir); // Offset: 0x10393178c // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.InGameUIManager
// Size: 0x360 // Inherited bytes: 0x170
struct UInGameUIManager : UGameBusinessManager {
	// Fields
	char pad_0x170[0x8]; // Offset: 0x170 // Size: 0x08
	struct TArray<struct UObject*> InGameUIList; // Offset: 0x178 // Size: 0x10
	char pad_0x188[0x68]; // Offset: 0x188 // Size: 0x68
	struct TMap<struct FString, struct TWeakObjectPtr<struct UUAEUserWidget>> WidgetsMap; // Offset: 0x1f0 // Size: 0x50
	struct TMap<int, struct FDynamicWidgetAsyncLoadData> PendingAsyncLoadRequests; // Offset: 0x240 // Size: 0x50
	char pad_0x290[0xd0]; // Offset: 0x290 // Size: 0xd0

	// Functions

	// Object Name: Function Client.InGameUIManager.SubUIWidgetListWithMountData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetListWithMountData(struct TArray<struct FInGameWidgetData>& InGameWidgetDataList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly, int inUIControlState); // Offset: 0x103932ac0 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function Client.InGameUIManager.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly); // Offset: 0x1039328c4 // Return & Params: Num(5) Size(0x23)

	// Object Name: Function Client.InGameUIManager.SubDynamicUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDynamicUIWidgetList(struct TArray<struct FDynamicWidgetData>& DynamicWidgetMap); // Offset: 0x10393281c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.OnAsyncLoadWidgetClassObj
	// Flags: [Final|Native|Public]
	void OnAsyncLoadWidgetClassObj(struct UObject* InClassObj, int RequestID); // Offset: 0x103932764 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.InGameUIManager.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x1039326cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.HandleMountWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleMountWidget(struct UInGameUIManager* IngameManager); // Offset: 0x103932650 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.InGameUIManager.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x10393263c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.InGameUIManager.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x1039325b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Public]
	void GetWidgetHandleAsyncWithCallBack(struct FString WidgetKey, DelegateProperty InCallback); // Offset: 0x1039324cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandle
	// Flags: [Final|Native|Public]
	struct UUAEUserWidget* GetWidgetHandle(struct FString WidgetKey); // Offset: 0x103932424 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.InGameUIManager.GetMountCanvasPanel
	// Flags: [Final|Native|Public]
	struct UCanvasPanel* GetMountCanvasPanel(struct FString MountOuterName, struct FString MountName); // Offset: 0x103932328 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.InGameUIManager.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x103932280 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.IntlSDKComplianceHelper
// Size: 0x70 // Inherited bytes: 0x28
struct UIntlSDKComplianceHelper : UObject {
	// Fields
	struct FString IntlGameId; // Offset: 0x28 // Size: 0x10
	struct FString IntlSdkUrl; // Offset: 0x38 // Size: 0x10
	struct FString IntlSdkUrlDebug; // Offset: 0x48 // Size: 0x10
	struct FString IntlSdkKey; // Offset: 0x58 // Size: 0x10
	bool IntlSdkEnable; // Offset: 0x68 // Size: 0x01
	bool IntlLogEnable; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x6]; // Offset: 0x6a // Size: 0x06

	// Functions

	// Object Name: Function Client.IntlSDKComplianceHelper.SetUserProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserProfile(struct FString InRegion); // Offset: 0x103933860 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetParentStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentStatus(int ParentCertificateStatus); // Offset: 0x1039337e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetLogConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLogConfig(bool enableConsoleLog, bool enableFileLog, int LogLevel); // Offset: 0x1039336d8 // Return & Params: Num(3) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetEUAgreeStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEUAgreeStatus(int AgreeStatus); // Offset: 0x10393365c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetAdulthood
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdulthood(int AgeStatus); // Offset: 0x1039335e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SendEmail
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendEmail(struct FString InEmail, struct FString UserName); // Offset: 0x1039334f4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryUserStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryUserStatus(); // Offset: 0x1039334e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryIsEEA
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryIsEEA(struct FString InRegion); // Offset: 0x103933448 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryConfig(); // Offset: 0x103933434 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.OnMSDKEvnSwitched
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnMSDKEvnSwitched(int Env); // Offset: 0x1039333b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIntlSDKComplianceHelper* GetInstance(); // Offset: 0x103933384 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.ComplianceInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ComplianceInit(); // Offset: 0x103933370 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.CommitBirthday
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommitBirthday(struct FString InBirthday); // Offset: 0x1039332d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlSDKComplianceHelper.ChangeRegion
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangeRegion(struct FString InRegion); // Offset: 0x103933240 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.LaggingReporter
// Size: 0x98 // Inherited bytes: 0x28
struct ULaggingReporter : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x48]; // Offset: 0x50 // Size: 0x48
};

// Object Name: Class Client.LiveBroadcast
// Size: 0x38 // Inherited bytes: 0x28
struct ULiveBroadcast : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function Client.LiveBroadcast.SetFullScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFullScreen(bool FullScreen); // Offset: 0x103934140 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LiveBroadcast.OpenLiveBroadcast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenLiveBroadcast(struct FString URL, float Margin); // Offset: 0x103934044 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.LiveBroadcast.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULiveBroadcast* GetInstance(); // Offset: 0x103934010 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.LiveBroadcast.CloseWebView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseWebView(); // Offset: 0x103933ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LiveBroadcast.C2JSetString
	// Flags: [Final|Native|Static|Public]
	void C2JSetString(struct FString str); // Offset: 0x103933f48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LiveBroadcast.C2JSetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void C2JSetIndex(int Index); // Offset: 0x103933ecc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.LoadTexture
// Size: 0x28 // Inherited bytes: 0x28
struct ULoadTexture : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LoadTexture.LoadTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTexture2D* LoadTexture2D(struct FString ImagePath, bool& IsValid, int& OutWidth, int& OutHeight); // Offset: 0x1039344f8 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.LoadTexture.GetTexture2DFromDiskFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromDiskFile(struct FString FilePath); // Offset: 0x103934460 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.LuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LuaBlueprintLibrary.StringToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar StringToLVar(struct UObject* WorldContextObject, struct FString Value); // Offset: 0x10393697c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.SetMemAllocLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMemAllocLog(struct UObject* WorldContextObject, bool bMemAllocLog); // Offset: 0x1039368c4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.LuaBlueprintLibrary.RequireAndCallLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RequireAndCallLuaWithArgs(struct UObject* WorldContextObject, struct FString& ModulePath, struct FString& FunctionName, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x1039363e0 // Return & Params: Num(11) Size(0x128)

	// Object Name: Function Client.LuaBlueprintLibrary.ObjectToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar ObjectToLVar(struct UObject* WorldContextObject, struct UObject* O); // Offset: 0x103936300 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString LVarToString(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x1039361f0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* LVarToObject(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103936108 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int LVarToInt(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103936020 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float LVarToFloat(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103935f38 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool LVarToBool(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103935e50 // Return & Params: Num(3) Size(0x29)

	// Object Name: Function Client.LuaBlueprintLibrary.IntToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar IntToLVar(struct UObject* WorldContextObject, int Value); // Offset: 0x103935d70 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.FloatToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar FloatToLVar(struct UObject* WorldContextObject, float Value); // Offset: 0x103935c90 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithMultiArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithMultiArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& InE, struct FLuaBPVar& InF, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103935734 // Return & Params: Num(12) Size(0x158)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithHUD
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithHUD(struct UObject* WorldContextObject, struct UGameFrontendHUD* GameFrontendHUD, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103935280 // Return & Params: Num(11) Size(0x120)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103934e04 // Return & Params: Num(10) Size(0x118)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLua
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLua(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103934b58 // Return & Params: Num(6) Size(0x98)

	// Object Name: Function Client.LuaBlueprintLibrary.BoolToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar BoolToLVar(struct UObject* WorldContextObject, bool Value); // Offset: 0x103934a70 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class Client.LuaBlueprintMgr
// Size: 0x80 // Inherited bytes: 0x28
struct ULuaBlueprintMgr : UObject {
	// Fields
	struct TMap<struct FString, struct ULuaBluepirntSys*> SystemMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBlueprintMgr.GetSystemByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBluepirntSys* GetSystemByName(struct FString SystemName); // Offset: 0x10393710c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.LuaBlueprintMgr.AddSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSystem(struct FString SystemName, struct FString BPPath); // Offset: 0x103936fd8 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.LuaBluepirntSys
// Size: 0xa0 // Inherited bytes: 0x28
struct ULuaBluepirntSys : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBluepirntSys.Init
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.LuaClassObj
// Size: 0x428 // Inherited bytes: 0x3d8
struct ALuaClassObj : ALuaContext {
	// Fields
	struct UGameBusinessManager* pManager; // Offset: 0x3d8 // Size: 0x08
	char pad_0x3E0[0x2]; // Offset: 0x3e0 // Size: 0x02
	bool bClearSourceCodeAfterInitialized; // Offset: 0x3e2 // Size: 0x01
	char pad_0x3E3[0x45]; // Offset: 0x3e3 // Size: 0x45

	// Functions

	// Object Name: Function Client.LuaClassObj.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool bPersistentUI, bool InStatusConcern, bool bDynamicWidget, bool bKeepDynamicWidget); // Offset: 0x103937ef8 // Return & Params: Num(6) Size(0x24)

	// Object Name: Function Client.LuaClassObj.SubShowHideEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubShowHideEvent(struct TArray<struct FString>& WidgetPathList); // Offset: 0x103937e50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultSceneCamera(int sceneCameraIndex); // Offset: 0x103937dd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.SubDefaultChildUI
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDefaultChildUI(struct TArray<struct FString>& childList); // Offset: 0x103937d2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultBaseUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultBaseUI(struct FString baseUI); // Offset: 0x103937c94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubCollapseWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubCollapseWidgetList(struct FString RootWidgetName, struct TArray<struct FString>& ChildWidgetNames); // Offset: 0x103937b98 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.LuaClassObj.SetWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetZorder(int Index, int ZOrder); // Offset: 0x103937ae4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.LuaClassObj.RestoreWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreWidgetZorder(int Index); // Offset: 0x103937a68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.RestoreAllWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreAllWidgetZorder(); // Offset: 0x103937a54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.IsTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTopStackPanel(); // Offset: 0x103937a20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.IsPushedPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsPushedPanel(); // Offset: 0x1039379ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.InCombatState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool InCombatState(); // Offset: 0x1039379b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleUIMessageNoFetch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessageNoFetch(struct FString UIMessage); // Offset: 0x103937920 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x103937888 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleStopAsyncLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleStopAsyncLoad(); // Offset: 0x103937874 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x103937860 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreationInternal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreationInternal(bool isAsyncLoad); // Offset: 0x1039377dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x103937758 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleCollapseWidgetList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleCollapseWidgetList(struct FString RootWidgetName); // Offset: 0x1039376c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelSrcTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelSrcTag(); // Offset: 0x10393765c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelDstTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelDstTag(); // Offset: 0x1039375f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetGameStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameStatus(); // Offset: 0x103937594 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x1039374ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.AddToTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddToTopStackPanel(); // Offset: 0x1039374d8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.MaskBox
// Size: 0x160 // Inherited bytes: 0x118
struct UMaskBox : UContentWidget {
	// Fields
	int InvalidateFrameCount; // Offset: 0x114 // Size: 0x04
	int Phase; // Offset: 0x118 // Size: 0x04
	int PhaseCount; // Offset: 0x11c // Size: 0x04
	bool IgnoreStretch; // Offset: 0x120 // Size: 0x01
	bool UpdateRenderTarget; // Offset: 0x121 // Size: 0x01
	int MaskType; // Offset: 0x124 // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x128 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x130 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x138 // Size: 0x04
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	struct UMaterialInterface* MaskMaterial; // Offset: 0x140 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function Client.MaskBox.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x103938b7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x103938b04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x103938a88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MaskBox.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x103938a0c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x103938990 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.MaskBox.GetVector2D__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FVector2D GetVector2D__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x10393895c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.MaskImage
// Size: 0x2a8 // Inherited bytes: 0x268
struct UMaskImage : UImage {
	// Fields
	bool bIgnoreStretch; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x3]; // Offset: 0x269 // Size: 0x03
	int MaskType; // Offset: 0x26c // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x270 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x278 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x280 // Size: 0x04
	char pad_0x284[0x4]; // Offset: 0x284 // Size: 0x04
	struct UMaterialInterface* MaskMaterial; // Offset: 0x288 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x290 // Size: 0x08
	char pad_0x298[0x10]; // Offset: 0x298 // Size: 0x10

	// Functions

	// Object Name: Function Client.MaskImage.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x10393b47c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x10393b404 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x10393b388 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MaskImage.SetMaskTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTexture(struct UTexture2D* Texture); // Offset: 0x10393b30c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* InEffectMaterial); // Offset: 0x10393b290 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x10393b25c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.MidasManager
// Size: 0x1c8 // Inherited bytes: 0x28
struct UMidasManager : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FString payChannel; // Offset: 0x58 // Size: 0x10
	struct FString midasIdc; // Offset: 0x68 // Size: 0x10
	struct FString ZoneID; // Offset: 0x78 // Size: 0x10
	struct FString goodsZoneID; // Offset: 0x88 // Size: 0x10
	struct FString offerID; // Offset: 0x98 // Size: 0x10
	int iAOSShop; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString offerID_H5; // Offset: 0xb0 // Size: 0x10
	struct FString payChannel_H5; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x70]; // Offset: 0xd0 // Size: 0x70
	struct FString PAY_TYPE_UC; // Offset: 0x140 // Size: 0x10
	struct FString PAY_TYPE_GOODS; // Offset: 0x150 // Size: 0x10
	struct FString PAY_TYPE_SUBSCRIBE; // Offset: 0x160 // Size: 0x10
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x170 // Size: 0x08
	char pad_0x178[0x50]; // Offset: 0x178 // Size: 0x50

	// Functions

	// Object Name: Function Client.MidasManager.TickMidasPackage
	// Flags: [Final|Native|Private]
	void TickMidasPackage(); // Offset: 0x10393d3a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Tick
	// Flags: [Final|Native|Public]
	void Tick(float DeltaTime); // Offset: 0x10393d32c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SwitchPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchPayChannel(enum class EMidasMultiPayChannelSwitch switchChannel); // Offset: 0x10393d2b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Subscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Subscribe(struct FString productid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x10393cf80 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function Client.MidasManager.SetZoneID
	// Flags: [Final|Native|Public]
	void SetZoneID(struct FString inZoneID, struct FString inGoodsZoneID); // Offset: 0x10393ce4c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.SetRoleInfo
	// Flags: [Final|Native|Public]
	void SetRoleInfo(int InChannel, struct FString OpenID); // Offset: 0x10393cd50 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.MidasManager.SetMidasIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMidasIDC(struct FString idc); // Offset: 0x10393cc94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.SetJPAge
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJPAge(int Age); // Offset: 0x10393cc18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SetFrontendHUD
	// Flags: [Final|Native|Public]
	void SetFrontendHUD(struct UGameFrontendHUD* InFrontendHUD); // Offset: 0x10393cb9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.Reprovide
	// Flags: [Final|Native|Public]
	void Reprovide(); // Offset: 0x10393cb88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x10393c998 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.MidasManager.ModifySubscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifySubscribe(struct FString oldProductId, struct FString newProductid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x10393c5ec // Return & Params: Num(8) Size(0x69)

	// Object Name: Function Client.MidasManager.IsH5PayEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsH5PayEnable(); // Offset: 0x10393c5b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Initialize(enum class EMidasMultiPayChannelSwitch envior); // Offset: 0x10393c53c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.H5Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void H5Pay(struct FString country); // Offset: 0x10393c480 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GoodsPresent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x10393c1a0 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.MidasManager.Goods
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Goods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x10393bf38 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.MidasManager.GetProductInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetProductInfo(struct TMap<struct FString, struct FString> listProductID); // Offset: 0x10393be78 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.MidasManager.getPF
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getPF(); // Offset: 0x10393be14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayEnvironment
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayEnvironment(); // Offset: 0x10393bdb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayChannel(); // Offset: 0x10393bd4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPackChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x10393bce8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetOfferID
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetOfferID(); // Offset: 0x10393bc84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetNativePackageTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetNativePackageTag(); // Offset: 0x10393bc20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetMPInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetMPInfo(struct FString country, struct FString currency); // Offset: 0x10393baec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.GetIntroPrice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetIntroPrice(struct TMap<struct FString, struct FString> listProductID); // Offset: 0x10393ba2c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.MidasManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UMidasManager* GetInstance(); // Offset: 0x10393b9f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.GetInIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetInIDC(); // Offset: 0x10393b994 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetAOSSHOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAOSSHOP(); // Offset: 0x10393b960 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.NewButton
// Size: 0x520 // Inherited bytes: 0x518
struct UNewButton : UButton {
	// Fields
	enum class EButtonClickSoundTypes ClickSound; // Offset: 0x518 // Size: 0x01
	char pad_0x519[0x7]; // Offset: 0x519 // Size: 0x07

	// Functions

	// Object Name: Function Client.NewButton.SetClickSound
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickSound(enum class EButtonClickSoundTypes inSoundType); // Offset: 0x10393dc34 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.PlatformAppraise
// Size: 0x28 // Inherited bytes: 0x28
struct UPlatformAppraise : UObject {
};

// Object Name: Class Client.PublishAreaMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UPublishAreaMgr : UObject {
	// Functions

	// Object Name: Function Client.PublishAreaMgr.SelectArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SelectArea(struct FString InArea); // Offset: 0x10393e2bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.IsMultiAreaBuild
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsMultiAreaBuild(); // Offset: 0x10393e288 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.PublishAreaMgr.GetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x10393e174 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.PublishAreaMgr.GetPublishAreas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishAreas(); // Offset: 0x10393e110 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.GetInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetInt(struct FString InKey, int InDefaultValue); // Offset: 0x10393e038 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.PublishAreaMgr.GetBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x10393df58 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.PublishAreaMgr.GetArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetArea(); // Offset: 0x10393def4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScreenInput
// Size: 0x70 // Inherited bytes: 0x28
struct UScreenInput : UObject {
	// Fields
	struct FScriptMulticastDelegate OnScreenTouch; // Offset: 0x28 // Size: 0x10
	DelegateProperty OnMouseButtonUp; // Offset: 0x38 // Size: 0x10
	DelegateProperty OnMouseButtonDown; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x18]; // Offset: 0x58 // Size: 0x18

	// Functions

	// Object Name: Function Client.ScreenInput.Shutdown
	// Flags: [Final|Native|Public]
	void Shutdown(); // Offset: 0x10393e710 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnScreenTouch__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScreenTouch__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnMouseButtonDown__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms|HasDefaults]
	void OnMouseButtonDown__DelegateSignature(struct FVector2D& ContainerPos); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScreenInput.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x10393e6fc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ScreenshotMaker
// Size: 0x28 // Inherited bytes: 0x28
struct UScreenshotMaker : UObject {
	// Functions

	// Object Name: Function Client.ScreenshotMaker.SetDefaultShowUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetDefaultShowUI(bool ShowUI); // Offset: 0x10393f46c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbumEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbumEx(struct FString pathStr); // Offset: 0x10393f3b0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbum(struct FString pathStr); // Offset: 0x10393f2f4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.ResizePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResizePicture(struct FString pathStr, float Scale, struct FString savePathStr); // Offset: 0x10393f17c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScreenshotMaker.ReMakePicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void ReMakePicture(struct FString pathStr, struct FVector4 Vector4); // Offset: 0x10393f07c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.ReMakeMomentPicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FString ReMakeMomentPicture(struct FString srcPath, struct FVector4 Vector4); // Offset: 0x10393ef4c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScreenshotMaker.MakePictureWithName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureWithName(struct FString PicName); // Offset: 0x10393ee68 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.MakePictureToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureToLua(struct UGameFrontendHUD* InFrontendHUD, struct FString tableName, struct FString FunctionName, bool isShowUI); // Offset: 0x10393ec7c // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScreenshotMaker.MakePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePicture(bool isShowUI); // Offset: 0x10393ebd0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.MakeBugReprotPic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakeBugReprotPic(bool isShowUI); // Offset: 0x10393eb24 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.HasCaptured
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasCaptured(struct FString pathStr); // Offset: 0x10393ea68 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.GetSaveStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetSaveStatus(); // Offset: 0x10393ea34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScreenshotMaker.GetPhotoHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPhotoHash(struct FString pathStr, int algorithmVersion); // Offset: 0x10393e938 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.GetMomentThumbPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentThumbPictureFullPathFiles(); // Offset: 0x10393e8d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScreenshotMaker.GetMomentPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentPictureFullPathFiles(); // Offset: 0x10393e870 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScriptHelperClient
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperClient : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperClient.ZLIBDecompress
	// Flags: [Final|Native|Static|Public]
	struct FString ZLIBDecompress(struct FString CompressedData, int CompressedSize, int UnCompressedSize); // Offset: 0x10395dbd4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ZLIBCompress_LuaState
	// Flags: [Final|Native|Static|Public]
	int ZLIBCompress_LuaState(); // Offset: 0x10395dbbc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.WechatShareWithUrlInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareWithUrlInfo(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _url, int _shareScene); // Offset: 0x10395d9a0 // Return & Params: Num(6) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.WeChatShareWithMiniApp
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WeChatShareWithMiniApp(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _webpageUrl, struct FString _userName, struct FString _path, struct FString _messageExt, struct FString _messageAction, int _shareScene); // Offset: 0x10395d628 // Return & Params: Num(10) Size(0x94)

	// Object Name: Function Client.ScriptHelperClient.WechatShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Title, struct FString Desc, struct FString mediaId, struct FString messageExt, struct FString mediaTagName, struct FString msdkExtInfo); // Offset: 0x10395d350 // Return & Params: Num(8) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.WechatShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt); // Offset: 0x10395d120 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.WechatQueryGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatQueryGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString OpenIdList); // Offset: 0x10395cfec // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatJoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatJoinGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomNickName); // Offset: 0x10395ceb8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatCreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatCreateGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomName, struct FString chatRoomNickName); // Offset: 0x10395cd30 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.WakeupFromSuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void WakeupFromSuspendSound(); // Offset: 0x10395cd1c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.VPNTearDown
	// Flags: [Final|Native|Static|Public]
	int VPNTearDown(); // Offset: 0x10395cce8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNSetUserInfo
	// Flags: [Final|Native|Static|Public]
	int VPNSetUserInfo(struct FString InUserId, struct FString InUserToken, struct FString InAppId); // Offset: 0x10395cba8 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.VPNSetPortRange
	// Flags: [Final|Native|Static|Public]
	int VPNSetPortRange(int Min, int Max); // Offset: 0x10395caf4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.VPNSetNodelist
	// Flags: [Final|Native|Static|Public]
	int VPNSetNodelist(struct FString InNodelist); // Offset: 0x10395ca5c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.VPNPrepare
	// Flags: [Final|Native|Static|Public]
	int VPNPrepare(); // Offset: 0x10395ca28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNHandUp
	// Flags: [Final|Native|Static|Public]
	int VPNHandUp(); // Offset: 0x10395c9f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNGetNodeRegionList
	// Flags: [Final|Native|Static|Public]
	struct FString VPNGetNodeRegionList(); // Offset: 0x10395c990 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.VPNDialUp
	// Flags: [Final|Native|Static|Public]
	int VPNDialUp(struct FString InRegion); // Offset: 0x10395c8f8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.Vibrate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Vibrate(int Param); // Offset: 0x10395c884 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UserName
	// Flags: [Final|Native|Static|Public]
	struct FString UserName(); // Offset: 0x10395c820 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UrlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString UrlEncode(struct FString UnencodedString); // Offset: 0x10395c760 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMSetAppVersion
	// Flags: [Final|Native|Static|Public]
	void UQMSetAppVersion(struct FString Version); // Offset: 0x10395c6d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPutUserData
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPutUserData(struct FString Key, struct FString Value); // Offset: 0x10395c5ec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPostExceptionFull
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPostExceptionFull(int Category, struct FString Name, struct FString Msg, struct FString stack); // Offset: 0x10395c478 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPostException
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPostException(int Category, struct FString Reason); // Offset: 0x10395c3ac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyLog
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyLog(int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x10395c244 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.UpdatePublishRegionForBattle
	// Flags: [Final|Native|Static|Public]
	void UpdatePublishRegionForBattle(); // Offset: 0x10395c230 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void UpdateMemResource(struct FString ResType, struct FString KeyWord); // Offset: 0x10395c104 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UpdateAkAudioDeviceBluetoothDelay
	// Flags: [Final|Native|Static|Public]
	void UpdateAkAudioDeviceBluetoothDelay(int InDelayTime); // Offset: 0x10395c090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UnsubscribeFromTopic
	// Flags: [Final|Native|Static|Public]
	void UnsubscribeFromTopic(struct FString Topic); // Offset: 0x10395c000 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UnmountPakFile
	// Flags: [Final|Native|Static|Public]
	bool UnmountPakFile(struct FString InPakFilename); // Offset: 0x10395bf68 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.UnitTestODPaksOpen
	// Flags: [Final|Native|Static|Public]
	void UnitTestODPaksOpen(int fileCount, int Times, int threadNum); // Offset: 0x10395be80 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TVMacroTesting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TVMacroTesting(); // Offset: 0x10395be6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerTouchEvent(float X, float Y, int event_type); // Offset: 0x10395bd84 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TriggerOOMCrash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerOOMCrash(); // Offset: 0x10395bd70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerLoginCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLoginCrashTest(int Type); // Offset: 0x10395bcfc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TriggerLobbyCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLobbyCrashTest(int Type); // Offset: 0x10395bc88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TriggerBlockAndroidANR
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerBlockAndroidANR(); // Offset: 0x10395bc74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPASwitchRichTapMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPASwitchRichTapMode(struct FString Mode); // Offset: 0x10395bbc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAStopRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStopRichTap(); // Offset: 0x10395bbac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTapWithData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TGPAStartRichTapWithData(struct FString InKey, struct TMap<struct FString, struct FString>& InMapData); // Offset: 0x10395bab0 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStartRichTap(struct FString Filename); // Offset: 0x10395b9fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPALoadHeFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPALoadHeFile(struct FString StrFilePath); // Offset: 0x10395b93c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapSupport(); // Offset: 0x10395b8d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapAmplitudeSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapAmplitudeSupport(); // Offset: 0x10395b874 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Tex_UpdateMemResource(struct FString KeyWord); // Offset: 0x10395b7c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_DumpMemObjectInfo
	// Flags: [Final|Native|Static|Public]
	void Tex_DumpMemObjectInfo(struct FString KeyWord); // Offset: 0x10395b70c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TestSaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void TestSaveStringToFile(struct FString String, struct FString TargetDir, struct FString FullPathName); // Offset: 0x10395b5d4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.TestLoadGameSlotMultiThread
	// Flags: [Final|Native|Static|Public]
	void TestLoadGameSlotMultiThread(); // Offset: 0x10395b5c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TestLoadGameSlot
	// Flags: [Final|Native|Static|Public]
	void TestLoadGameSlot(); // Offset: 0x10395b5ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.Tea2Encrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Encrypt_LuaState(); // Offset: 0x10395b594 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.Tea2Decrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Decrypt_LuaState(); // Offset: 0x10395b57c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmReport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmReport(int Type, struct FString ExtraInfo, bool send); // Offset: 0x10395b440 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.TapmPostLargeValueS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmPostLargeValueS(struct FString catgory, struct FString Key, struct FString Value); // Offset: 0x10395b29c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmMarkTime(int Type); // Offset: 0x10395b228 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkLevelFin
	// Flags: [Final|Native|Static|Public]
	void TapmMarkLevelFin(); // Offset: 0x10395b214 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TApmDisconnectReport
	// Flags: [Final|Native|Static|Public]
	void TApmDisconnectReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId); // Offset: 0x10395b164 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TApmDataReport
	// Flags: [Final|Native|Static|Public]
	void TApmDataReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId, struct FString EventInfo); // Offset: 0x10395b030 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageUpdateCurrentWorldName
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageUpdateCurrentWorldName(struct FString WorldName); // Offset: 0x10395af7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInitialize
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInitialize(struct FString CfgFilename); // Offset: 0x10395aec8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInit
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInit(struct FString ConfigFilename); // Offset: 0x10395ae14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInfoCollect
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInfoCollect(struct FString PackageName, struct FString WorldName); // Offset: 0x10395ace8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageGetPackageListForWorld
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> SyncLoadPackageGetPackageListForWorld(struct FString WorldName); // Offset: 0x10395ac04 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageDumpInfo
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageDumpInfo(struct FString DumpFilename); // Offset: 0x10395ab50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SwitchUser
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SwitchUser(struct TScriptInterface<Class>& ClientNetInterface, bool useExternalAccount); // Offset: 0x10395aa88 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.SwitchSceneCamera
	// Flags: [Final|Native|Static|Public]
	void SwitchSceneCamera(struct UGameFrontendHUD* GameFrontendHUD, struct FString SceneCameraName, float BlendTime, bool bForce); // Offset: 0x10395a90c // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.SwitchCampRoom
	// Flags: [Final|Native|Static|Public]
	void SwitchCampRoom(struct UGameFrontendHUD* GameFrontendHUD, int campMode); // Offset: 0x10395a85c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SuspendSound(); // Offset: 0x10395a848 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SubscribeToTopic
	// Flags: [Final|Native|Static|Public]
	void SubscribeToTopic(struct FString Topic); // Offset: 0x10395a7b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StringToJsonString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString StringToJsonString(struct FString String); // Offset: 0x10395a6f8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.StringToFMargin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FMargin StringToFMargin(struct FString MarginStr); // Offset: 0x10395a650 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.StopUIStat
	// Flags: [Final|Native|Static|Public]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x10395a554 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FTouchInputRecord StopTouchRecord(); // Offset: 0x10395a4f0 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.StopTask
	// Flags: [Final|Native|Static|Public]
	bool StopTask(struct UGameFrontendHUD* GameFrontendHUD, uint64 TaskId); // Offset: 0x10395a43c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StopShaderPrecompile(); // Offset: 0x10395a408 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StopPuffer
	// Flags: [Final|Native|Static|Public]
	void StopPuffer(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10395a394 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StopHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopHapticsEngine(); // Offset: 0x10395a380 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopH5Downloading
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopH5Downloading(); // Offset: 0x10395a36c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopCampMode
	// Flags: [Final|Native|Static|Public]
	void StopCampMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10395a2f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartUIStat
	// Flags: [Final|Native|Static|Public]
	void StartUIStat(struct FString UIName); // Offset: 0x10395a244 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartTrace
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTrace(struct FString InHost, int InStartTTL, int InMaxTTL, int InCount); // Offset: 0x10395a0f8 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.StartTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTouchRecord(); // Offset: 0x10395a0e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StartShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StartShaderPrecompile(); // Offset: 0x10395a0b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StartOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void StartOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, bool bStart); // Offset: 0x103959ff8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartHapticsEngine(DelegateProperty Callback); // Offset: 0x103959f70 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartGrayUpdate
	// Flags: [Final|Native|Static|Public]
	bool StartGrayUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103959ef4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x103959df8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.StartDolphinResourceUpdate
	// Flags: [Final|Native|Static|Public]
	void StartDolphinResourceUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103959d84 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Static|Public]
	void StartCDNUpdateAfterDolphinUpdateFailed(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103959d10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCampMode
	// Flags: [Final|Native|Static|Public]
	void StartCampMode(struct UGameFrontendHUD* GameFrontendHUD, struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x103959b9c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.StartBatchDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103959a2c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ShutdownUnrealNetwork
	// Flags: [Final|Native|Static|Public]
	void ShutdownUnrealNetwork(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039599b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShutdownPuffer
	// Flags: [Final|Native|Static|Public]
	void ShutdownPuffer(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103959944 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShrinkUObjectHashTables
	// Flags: [Final|Native|Static|Public]
	void ShrinkUObjectHashTables(); // Offset: 0x103959930 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShowWebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowWebView(bool Show); // Offset: 0x1039598b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.ShowVLink
	// Flags: [Final|Native|Static|Public]
	void ShowVLink(struct FString jsonString, struct FString signString); // Offset: 0x1039597d0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ShowVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowVideoListDialog(); // Offset: 0x1039597bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShowScreenDebugMessage
	// Flags: [Final|Native|Static|Public]
	void ShowScreenDebugMessage(struct FString Message); // Offset: 0x103959708 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ShowH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowH5WebView(); // Offset: 0x1039596f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShorterStreamingDistanceWhenGameEnd
	// Flags: [Final|Native|Static|Public]
	void ShorterStreamingDistanceWhenGameEnd(uint32_t Distance); // Offset: 0x103959680 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ShareWithUploadPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithUploadPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, int _channel, struct FString _url); // Offset: 0x10395950c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.ShareWithPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt, struct FString _messageAction, int _channel, struct FString _url); // Offset: 0x10395929c // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.ShareLogFile
	// Flags: [Final|Native|Static|Public]
	void ShareLogFile(); // Offset: 0x103959288 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetWebViewCacheInfoDelegate
	// Flags: [Final|Native|Static|Public]
	void SetWebViewCacheInfoDelegate(DelegateProperty Delegate); // Offset: 0x103959200 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetVpnServiceStrategy
	// Flags: [Final|Native|Static|Public]
	bool SetVpnServiceStrategy(struct FString InKey, int InValue); // Offset: 0x103959128 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceSwitch
	// Flags: [Final|Native|Static|Public]
	void SetVoiceSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool FirstVoicePopupSwitch, bool GDPRForbidVoiceSwitch, bool GDPRSettingSwitch); // Offset: 0x103958fe0 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceReEneterInfo
	// Flags: [Final|Native|Static|Public]
	void SetVoiceReEneterInfo(struct UGameFrontendHUD* GameFrontendHUD, float Duration, int MaxCount); // Offset: 0x103958ef4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	void SetUserVulkanSetting(bool Enable); // Offset: 0x103958e78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUserTGPATapEnableFlag(int EnableFlag); // Offset: 0x103958e04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUserProperty
	// Flags: [Final|Native|Static|Public]
	void SetUserProperty(struct FString propertyKey, struct FString propertyValue); // Offset: 0x103958d20 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetUpdatedSoPatchFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SetUpdatedSoPatchFile(struct FString InSourceFile, int InABI); // Offset: 0x103958c48 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetupAkAudioDeviceListener
	// Flags: [Final|Native|Static|Public]
	void SetupAkAudioDeviceListener(); // Offset: 0x103958c34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x103958bc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIRectOffset(struct FString uirect); // Offset: 0x103958b0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUIElemLayoutJsonConfigSwitch
	// Flags: [Final|Native|Static|Public]
	void SetUIElemLayoutJsonConfigSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool UIElemLayoutJsonConfigSwitch); // Offset: 0x103958a54 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetUIConfigTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIConfigTGPATapEnableFlag(int uiEnable); // Offset: 0x1039589e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTssNetworkStatus
	// Flags: [Final|Native|Static|Public]
	void SetTssNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD, int Status); // Offset: 0x103958930 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTickMemoryInterval
	// Flags: [Final|Native|Static|Public]
	void SetTickMemoryInterval(struct UGameFrontendHUD* GameFrontendHUD, float interval); // Offset: 0x103958880 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTGPATapWhiteListFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTGPATapWhiteListFlag(int TapWhiteList); // Offset: 0x10395880c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTestEditorNum
	// Flags: [Final|Native|Static|Public]
	void SetTestEditorNum(int PlayerCount, struct FString Num, struct FString SceneName, int PlatForm); // Offset: 0x103958660 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	bool SetSoundEffectQuality(int Type); // Offset: 0x1039585e4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ScriptHelperClient.SetShowFriendObservers
	// Flags: [Final|Native|Static|Public]
	void SetShowFriendObservers(struct UGameFrontendHUD* GameFrontendHUD, bool bShow); // Offset: 0x10395852c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSelfieSwitch
	// Flags: [Final|Native|Static|Public]
	void SetSelfieSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool SelfieSwitch); // Offset: 0x103958474 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSdkIoctl
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int SetSdkIoctl(struct UGameFrontendHUD* GameFrontendHUD, int request, struct FString& Token); // Offset: 0x103958354 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.SetReportBugSwitch
	// Flags: [Final|Native|Static|Public]
	void SetReportBugSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool ReportBugSwitch); // Offset: 0x10395829c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetRemoteResource
	// Flags: [Final|Native|Static|Public]
	void SetRemoteResource(struct FString AssetId, struct UObject* DescObj); // Offset: 0x1039581a8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetRegionNoByLua
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetRegionNoByLua(struct TScriptInterface<Class>& ClientNetInterface, int regionNo); // Offset: 0x1039580e8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetRedBloodSwitch(bool redBloodSwitch); // Offset: 0x10395806c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetPufferBuildInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPufferBuildInfo(struct FString PipeLineID, struct FString BuildNo); // Offset: 0x103957f40 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetPublishRegion
	// Flags: [Final|Native|Static|Public]
	void SetPublishRegion(struct FString Region); // Offset: 0x103957e8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetPlayerBaseInfo
	// Flags: [Final|Native|Static|Public]
	void SetPlayerBaseInfo(struct UGameFrontendHUD* GameFrontendHUD, struct FString OpenID, uint64 RoleID, struct FString PlayerName, struct FString HeadIconUrl); // Offset: 0x103957c64 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.SetOnGetItemBigIcon
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnGetItemBigIcon(DelegateProperty onShow); // Offset: 0x103957bdc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetNationSwitch
	// Flags: [Final|Native|Static|Public]
	void SetNationSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool NationAllSwitch, bool NationBattleSwitch, bool NationRankSwitch); // Offset: 0x103957a94 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetMyFriendObserversDetail
	// Flags: [Final|Native|Static|Public]
	void SetMyFriendObserversDetail(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FFriendObserver> FriendObserversDetails); // Offset: 0x103957978 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetMiniGameFinalAwardResId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMiniGameFinalAwardResId(struct UGameFrontendHUD* GameFrontendHUD, int AwardResId); // Offset: 0x1039578c8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetMidasZoneID_LuaState
	// Flags: [Final|Native|Static|Public]
	int SetMidasZoneID_LuaState(); // Offset: 0x1039578b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetMidasIDC
	// Flags: [Final|Native|Static|Public]
	void SetMidasIDC(struct FString midasIdc); // Offset: 0x1039577fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetLinkStyle
	// Flags: [Final|Native|Static|Public]
	bool SetLinkStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool ShowUnderline, struct FString PathHyperLinkNormalBrush, struct FString PathHyperLinkHoveredrBrush); // Offset: 0x1039574cc // Return & Params: Num(8) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.SetLevelStreamingUnloadTimeslice
	// Flags: [Final|Native|Static|Public]
	void SetLevelStreamingUnloadTimeslice(bool Enabled); // Offset: 0x103957450 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	void SetiTOPLbsDelay(int Delay); // Offset: 0x1039573dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIPRegion
	// Flags: [Final|Native|Static|Public]
	void SetIPRegion(int region_no); // Offset: 0x103957368 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIosStuckEnableByServerConfig
	// Flags: [Final|Native|Static|Public]
	void SetIosStuckEnableByServerConfig(int bEnable); // Offset: 0x1039572f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Static|Public]
	void SetIOSBGDownloadAttribute(struct UGameFrontendHUD* GameFrontendHUD, bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x10395717c // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetImageVersionString
	// Flags: [Final|Native|Static|Public]
	void SetImageVersionString(struct FString oldVersion, struct FString newVersion); // Offset: 0x103957098 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetImageStyle
	// Flags: [Final|Native|Static|Public]
	bool SetImageStyle(struct FString StyleName, int ImageSize, struct FString ImagePath, struct FString ImageColor, bool bPreLoad); // Offset: 0x103956e58 // Return & Params: Num(6) Size(0x3a)

	// Object Name: Function Client.ScriptHelperClient.SetIGProxyData
	// Flags: [Final|Native|Static|Public]
	void SetIGProxyData(struct FString InJsonData); // Offset: 0x103956dc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetHapticsEngineEnable(bool bEnable); // Offset: 0x103956d4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGlobalRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGlobalRedBloodSwitch(bool redBloodSwitch); // Offset: 0x103956cd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGDPRUserType
	// Flags: [Final|Native|Static|Public]
	void SetGDPRUserType(struct UGameFrontendHUD* GameFrontendHUD, int GDPRUserType); // Offset: 0x103956c20 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetGameStatusMap
	// Flags: [Final|Native|Static|Public]
	void SetGameStatusMap(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FName, struct FString> GameStatusMap); // Offset: 0x103956b28 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.SetGameSrvID
	// Flags: [Final|Native|Static|Public]
	void SetGameSrvID(struct UGameFrontendHUD* GameFrontendHUD, int GameSrvID); // Offset: 0x103956a78 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetFontStyle
	// Flags: [Final|Native|Static|Public]
	bool SetFontStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool UseShadow, bool IsBold); // Offset: 0x1039567f0 // Return & Params: Num(7) Size(0x3b)

	// Object Name: Function Client.ScriptHelperClient.SetExtraLocalizationMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetExtraLocalizationMap(struct TMap<struct FString, struct FString>& translationMap); // Offset: 0x10395674c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetExtraItemTableMappingByFix
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetExtraItemTableMappingByFix(struct TMap<int, struct FItemFixTableItem>& ItemFixMap); // Offset: 0x1039566a8 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetDynamicLevels
	// Flags: [Final|Native|Static|Public]
	void SetDynamicLevels(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FString> DynamicLevels); // Offset: 0x10395658c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetDumpShaderCompile
	// Flags: [Final|Native|Static|Public]
	void SetDumpShaderCompile(int iDumpVal); // Offset: 0x103956518 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public]
	void SetDownLoadLanguageName(struct FString Language); // Offset: 0x103956488 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetCrashContextReportLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetCrashContextReportLevel(int Level); // Offset: 0x103956414 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetCanWatchEnemy
	// Flags: [Final|Native|Static|Public]
	void SetCanWatchEnemy(struct UGameFrontendHUD* GameFrontendHUD, bool bCan); // Offset: 0x10395635c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetBtnClickInCdFunc
	// Flags: [Final|Native|Static|Public]
	void SetBtnClickInCdFunc(); // Offset: 0x103956348 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetAppDetailInfo
	// Flags: [Final|Native|Static|Public]
	void SetAppDetailInfo(struct FString appInfo); // Offset: 0x1039562b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetAccountRegion
	// Flags: [Final|Native|Static|Public]
	void SetAccountRegion(struct FString Region); // Offset: 0x103956204 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SendRetriveBeginnerFinisheGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRetriveBeginnerFinisheGuideReq(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103956190 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.SendRecordFinishedGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRecordFinishedGuideReq(struct UGameFrontendHUD* GameFrontendHUD, struct FString TipsID); // Offset: 0x10395609c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SendPlayEmote
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendPlayEmote(struct UGameFrontendHUD* GameFrontendHUD, int EmoteIndex); // Offset: 0x103955fec // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SendLobbyChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendLobbyChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Content); // Offset: 0x103955e80 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.SendDirtyToFilter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendDirtyToFilter(struct UGameFrontendHUD* GameFrontendHUD, struct FString dirtyString, struct FString prefixString, int UId); // Offset: 0x103955cd4 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SendClientLog
	// Flags: [Final|Native|Static|Public]
	void SendClientLog(struct UGameFrontendHUD* GameFrontendHUD, struct FString errorReason, struct FString errorDescription, bool pullAll); // Offset: 0x103955b6c // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.ScheduleLocalNotificationAtTime
	// Flags: [Final|Native|Static|Public]
	void ScheduleLocalNotificationAtTime(int Year, int Month, int Day, int Hour, int Minute, int Second, bool LocalTime, struct FString Title, struct FString Body, struct FString Action, int NotificationID); // Offset: 0x1039557b0 // Return & Params: Num(11) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToIntermediateFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToIntermediateFile(struct FString String, struct FString Filename); // Offset: 0x1039556cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToFile(struct FString String, struct FString Filename); // Offset: 0x1039555e8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveStringArrayToFile
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SaveStringArrayToFile(struct TArray<struct FString>& Lines, struct FString Filename); // Offset: 0x1039554f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveSavFile
	// Flags: [Final|Native|Static|Public]
	bool SaveSavFile(struct FString CompressedData, struct FString Filename, int CompressedSize, int UnCompressedSize); // Offset: 0x103955340 // Return & Params: Num(5) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.SaveLuaMemoryFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveLuaMemoryFile(struct FString Filename, struct FString InputContent, bool RmExistFile); // Offset: 0x103955214 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.SaveLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	void SaveLoadGameSlotCrashFlag(); // Offset: 0x103955200 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SaveGameSlotMultiThread
	// Flags: [Final|Native|Static|Public]
	void SaveGameSlotMultiThread(); // Offset: 0x1039551ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SaveArrayToFile
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool SaveArrayToFile(struct TArray<char>& Content, struct FString Filename); // Offset: 0x1039550e4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommondAndGetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString RunConsoleCommondAndGetString(struct FString commond); // Offset: 0x103955024 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommond
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RunConsoleCommond(struct FString commond); // Offset: 0x103954f94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RoomOwnerInterruptGame
	// Flags: [Final|Native|Static|Public]
	void RoomOwnerInterruptGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103954f20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ReturnToLobby
	// Flags: [Final|Native|Static|Public]
	void ReturnToLobby(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103954eac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.RestartShaderPrecompile
	// Flags: [Final|Native|Static|Public]
	void RestartShaderPrecompile(); // Offset: 0x103954e98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.RestartPuffer
	// Flags: [Final|Native|Static|Public]
	void RestartPuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x103954c64 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RestartGame
	// Flags: [Final|Native|Static|Public]
	void RestartGame(); // Offset: 0x103954c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.RequestFile
	// Flags: [Final|Native|Static|Public]
	uint64 RequestFile(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath, bool ForceUpdate); // Offset: 0x103954b04 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithString
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithString(struct FString eventTypeString, struct FString bundleExtraKey, struct FString bundleExtraValue, bool isUnique); // Offset: 0x103954984 // Return & Params: Num(4) Size(0x31)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithParam
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithParam(struct FString eventTypeString, struct TMap<struct FString, struct FString> _params, bool isUnique); // Offset: 0x10395482c // Return & Params: Num(3) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.ReportEventRegisterCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventRegisterCompleted(); // Offset: 0x103954818 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventPurchaseConsider
	// Flags: [Final|Native|Static|Public]
	void ReportEventPurchaseConsider(); // Offset: 0x103954804 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventLoadingCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventLoadingCompleted(); // Offset: 0x1039547f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportContextValuesOnCrash
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReportContextValuesOnCrash(struct FString& Json); // Offset: 0x103954750 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBuglyLogWithFDNum
	// Flags: [Final|Native|Static|Public]
	void ReportBuglyLogWithFDNum(struct FString baseLogInfo); // Offset: 0x10395469c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBattleChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportBattleChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString Msg, int MsgExtraParam); // Offset: 0x103954568 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.ReplyInvite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReplyInvite(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, bool bReply); // Offset: 0x10395442c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.RemoveKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void RemoveKnownMissingPackage(struct FString PackageName); // Offset: 0x103954378 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RemountPakFiles
	// Flags: [Final|Native|Static|Public]
	bool RemountPakFiles(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039542fc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.ReInitializePuffer
	// Flags: [Final|Native|Static|Public]
	void ReInitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x1039540c8 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RecordLuaExceptionInfo
	// Flags: [Final|Native|Static|Public]
	void RecordLuaExceptionInfo(struct FString exception); // Offset: 0x103954014 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RebuildHISM
	// Flags: [Final|Native|Static|Public]
	void RebuildHISM(struct UHierarchicalInstancedStaticMeshComponent* Comp, bool Async, bool ForceUpdate); // Offset: 0x103953f18 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Client.ScriptHelperClient.QuitVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103953ea4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103953e30 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QuitFightChat(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103953dbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuickLogin
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QuickLogin(struct TScriptInterface<Class>& ClientNetInterface, int refreshTokenBeforeExpDays); // Offset: 0x103953cfc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.QQShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, int act, struct FString OpenID, struct FString Title, struct FString Desc, struct FString targetUrl, struct FString imgUrl, struct FString previewText, struct FString gameTag, struct FString msdkExtInfo); // Offset: 0x103953990 // Return & Params: Num(10) Size(0x98)

	// Object Name: Function Client.ScriptHelperClient.QQShareH5WithPhoto
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareH5WithPhoto(struct TScriptInterface<Class>& ClientNetInterface, struct FString _title, struct FString _fullURL, int Channel); // Offset: 0x10395381c // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.QQShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _imgUrl, struct FString _url, int _shareScene); // Offset: 0x1039535ac // Return & Params: Num(7) Size(0x64)

	// Object Name: Function Client.ScriptHelperClient.QQAddFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQAddFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Desc, struct FString Message); // Offset: 0x103953424 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.PVEAutoTestGetEnermyLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector PVEAutoTestGetEnermyLocation(); // Offset: 0x1039533ec // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.PubgmSimulateActionClientEx
	// Flags: [Final|Native|Static|Public]
	void PubgmSimulateActionClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SimulateType); // Offset: 0x10395333c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ProjectSavedDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectSavedDir(); // Offset: 0x1039532d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProjectDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectDir(); // Offset: 0x103953274 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProjectContentDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectContentDir(); // Offset: 0x103953210 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProcessSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ProcessSoPatch(struct FString InAppVerStr); // Offset: 0x103953178 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.ProcessServerRelationChainError
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ProcessServerRelationChainError(struct TScriptInterface<Class>& ClientNetInterface, struct FString ErrorMsg, int iForceLoginInterval); // Offset: 0x103953034 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.PostGameStatusToTGPASMap
	// Flags: [Final|Native|Static|Public]
	void PostGameStatusToTGPASMap(struct UGameFrontendHUD* GameFrontendHUD, struct FString Key, struct TMap<struct FString, struct FString> mapData); // Offset: 0x103952ec0 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.PlayHapticsFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PlayHapticsFile(struct FString FilePath, int Duration, DelegateProperty Callback); // Offset: 0x103952d78 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.PandoraSendCmd
	// Flags: [Final|Native|Static|Public]
	void PandoraSendCmd(struct FString jsonStr); // Offset: 0x103952cc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.PandoraInit
	// Flags: [Final|Native|Static|Public]
	void PandoraInit(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion, struct FString InRoleName, struct FString InPayToken, struct FString InHeadUrl, struct FString InChanelId, struct FString InBelongingId, struct FString InLanguage, struct FString InTicket, struct FString InIp, struct FString InNation, struct FString InNetType); // Offset: 0x10395227c // Return & Params: Num(21) Size(0x150)

	// Object Name: Function Client.ScriptHelperClient.PandoraErrorReport
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void PandoraErrorReport(int iType, int iActId, int errCode, struct FString errMsg, struct FString extraMsg, struct TMap<struct FString, struct FString>& extendDict); // Offset: 0x10395207c // Return & Params: Num(6) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.PandoraEnable
	// Flags: [Final|Native|Static|Public]
	void PandoraEnable(bool Enable); // Offset: 0x103952000 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.PandoraClose
	// Flags: [Final|Native|Static|Public]
	void PandoraClose(); // Offset: 0x103951fec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.OpenWebviewInGameProcess
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenWebviewInGameProcess(struct FString URL, int Left, int Top, int Right, int Bottom); // Offset: 0x103951e64 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OpenURLWithExtra
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURLWithExtra(struct FString URL, struct TMap<struct FString, struct FString> ExtraMap); // Offset: 0x103951d30 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.OpenURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURL(struct FString URL, bool isGetTicket, bool withNeverAdjust, bool bKeepCache); // Offset: 0x103951b9c // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.ScriptHelperClient.OpenShaderCodeLibrary
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OpenShaderCodeLibrary(struct FString Path, struct FString VersionNum); // Offset: 0x103951a68 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.OpenH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x103951790 // Return & Params: Num(8) Size(0x48)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnWebViewCacheInfoDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnWebViewCacheInfoDelegate__DelegateSignature(int code); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnWebViewCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnWebViewCache(int code); // Offset: 0x10395171c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnNotifyFightFriendChat
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void OnNotifyFightFriendChat(struct UGameFrontendHUD* GameFrontendHUD, struct FFightFriendChat& Data); // Offset: 0x103951638 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.OnMiniGameEnded
	// Flags: [Final|Native|Static|Public]
	void OnMiniGameEnded(struct UGameFrontendHUD* GameFrontendHUD, int Score, int Duration, bool bGameClosed); // Offset: 0x10395150c // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.OnIslandPlayerInfoNotify
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnIslandPlayerInfoNotify(struct UGameFrontendHUD* GameFrontendHUD, int LandId); // Offset: 0x10395145c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.OnInviteNextBattle
	// Flags: [Final|Native|Static|Public]
	bool OnInviteNextBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Name); // Offset: 0x103951334 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.OnGetUpdateStateCDNConfigUrl
	// Flags: [Final|Native|Static|Public]
	void OnGetUpdateStateCDNConfigUrl(struct UGameFrontendHUD* GameFrontendHUD, struct FString URL); // Offset: 0x103951268 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnGetItemBigIcon__DelegateSignature
	// Flags: [Public|Delegate]
	struct FString OnGetItemBigIcon__DelegateSignature(struct FString strPath); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OnFilterFinish
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnFilterFinish(struct UGameFrontendHUD* GameFrontendHUD, struct FString filterText); // Offset: 0x10395119c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.OnEnterLobbyReloadLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterLobbyReloadLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103951128 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnEnterGameReleaseLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterGameReleaseLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039510b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnDolphinAppUpdateFinished
	// Flags: [Final|Native|Static|Public]
	void OnDolphinAppUpdateFinished(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103951040 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnCombatHitFeedback
	// Flags: [Final|Native|Static|Public]
	void OnCombatHitFeedback(struct UGameFrontendHUD* GameFrontendHUD, bool bCombatHitFeedbackEnable); // Offset: 0x103950f88 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResultCallBack
	// Flags: [Final|Native|Static|Public]
	void OnBattleResultCallBack(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x103950e88 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResult
	// Flags: [Final|Native|Static|Public]
	void OnBattleResult(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x103950d88 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.ObjectPoolServerSwitch
	// Flags: [Final|Native|Static|Public]
	void ObjectPoolServerSwitch(bool bSwitchOn); // Offset: 0x103950d0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.NotifyBeginnerFinishedGuideUpdated
	// Flags: [Final|Native|Static|Public]
	void NotifyBeginnerFinishedGuideUpdated(struct UGameFrontendHUD* GameFrontendHUD, bool GuideSwitch, struct TArray<struct FPlayerFinishedGuide> finished_guide, int player_level, int player_exp_type); // Offset: 0x103950b30 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.MSDKWebViewCallJS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MSDKWebViewCallJS(struct FString strJS); // Offset: 0x103950a7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MoveFollowTarget
	// Flags: [Final|Native|Static|Public]
	void MoveFollowTarget(struct UGameFrontendHUD* GameFrontendHUD, int FollowType, uint64 UId); // Offset: 0x103950990 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.MoveFile
	// Flags: [Final|Native|Static|Public]
	bool MoveFile(struct FString SrcFullPath, struct FString DesFullPath); // Offset: 0x1039508a4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MountPakFile
	// Flags: [Final|Native|Static|Public]
	bool MountPakFile(struct FString InPakFilename, struct FString Key); // Offset: 0x1039507b8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MidasSDKInit_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasSDKInit_LuaState(); // Offset: 0x1039507a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasReprovide_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasReprovide_LuaState(); // Offset: 0x103950788 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasPay
	// Flags: [Final|Native|Static|Public]
	void MidasPay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x103950610 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.MidasH5Pay
	// Flags: [Final|Native|Static|Public]
	void MidasH5Pay(struct FString country); // Offset: 0x103950580 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MidasGoodsPresent
	// Flags: [Final|Native|Static|Public]
	void MidasGoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x103950360 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.MidasGoods
	// Flags: [Final|Native|Static|Public]
	void MidasGoods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x103950194 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.MessageBoxExt
	// Flags: [Final|Native|Static|Public]
	void MessageBoxExt(struct FString Caption, struct FString Text); // Offset: 0x1039500b0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.MediaCopyFromPakToLocal
	// Flags: [Final|Native|Static|Public]
	bool MediaCopyFromPakToLocal(struct FString from, bool bForce); // Offset: 0x10394ffa4 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.MD5LuaString_LuaState
	// Flags: [Final|Native|Static|Public]
	int MD5LuaString_LuaState(); // Offset: 0x10394ff8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MD5HashAnsiString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MD5HashAnsiString(struct FString str); // Offset: 0x10394fea8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ManualSleep
	// Flags: [Final|Native|Static|Public]
	void ManualSleep(float Seconds); // Offset: 0x10394fe34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LuaLoadFileToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LuaLoadFileToString(struct FString InFileName); // Offset: 0x10394fd74 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LogoutAllDevices
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LogoutAllDevices(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394fcf0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Logout(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394fc6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LoginWithExtraInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LoginWithExtraInfo(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel, struct FString InExtraJson); // Offset: 0x10394fb50 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Login
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Login(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel); // Offset: 0x10394fa90 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.LobbySetUserRegion
	// Flags: [Final|Native|Static|Public]
	void LobbySetUserRegion(int InRegion); // Offset: 0x10394fa1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyPortlist(struct FString InNodePortList); // Offset: 0x10394f98c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyNodelist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyNodelist(struct FString InNodeIpList); // Offset: 0x10394f8fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetEchoPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetEchoPortlist(struct FString InEchoPortList); // Offset: 0x10394f86c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbyIsLinkProxy
	// Flags: [Final|Native|Static|Public]
	bool LobbyIsLinkProxy(struct FString InIp, int InPort); // Offset: 0x10394f794 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.LobbyAddAddress
	// Flags: [Final|Native|Static|Public]
	void LobbyAddAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x10394f670 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.LoadSavFile_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadSavFile_LuaState(); // Offset: 0x10394f658 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadMidasMP_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadMidasMP_LuaState(); // Offset: 0x10394f640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadIntermediateFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadIntermediateFileToString(struct FString Filename); // Offset: 0x10394f580 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LoadH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x10394f2a8 // Return & Params: Num(8) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToStringByFullPath
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToStringByFullPath(struct FString FullPathName); // Offset: 0x10394f1e8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToString(struct FString Filename); // Offset: 0x10394f128 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToArray
	// Flags: [Final|Native|Static|Public]
	struct TArray<char> LoadFileToArray(struct FString Filename); // Offset: 0x10394f068 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadAmendODs
	// Flags: [Final|Native|Static|Public]
	bool LoadAmendODs(struct TMap<uint32_t, struct FString> Keys); // Offset: 0x10394efa8 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function Client.ScriptHelperClient.LoadAFDTranslation
	// Flags: [Final|Native|Static|Public]
	void LoadAFDTranslation(); // Offset: 0x10394ef94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.LaunchUrl
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LaunchUrl(struct FString& URL); // Offset: 0x10394eef4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.JoinVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString RoomName, struct FString userId); // Offset: 0x10394ed88 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.JoinLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString lbsRoomName, struct FString userId); // Offset: 0x10394ec1c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.IsWindowsClientReplay
	// Flags: [Final|Native|Static|Public]
	bool IsWindowsClientReplay(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394eba0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsWindowOB
	// Flags: [Final|Native|Static|Public]
	bool IsWindowOB(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394eb24 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUsingBluetooth
	// Flags: [Final|Native|Static|Public]
	bool IsUsingBluetooth(); // Offset: 0x10394eaf0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsUseTypicalResultFlowMode
	// Flags: [Final|Native|Static|Public]
	bool IsUseTypicalResultFlowMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394ea74 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUpdateSkip
	// Flags: [Final|Native|Static|Public]
	bool IsUpdateSkip(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e9f8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUIAutoTest
	// Flags: [Final|Native|Static|Public]
	bool IsUIAutoTest(); // Offset: 0x10394e9c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsTypicalMode
	// Flags: [Final|Native|Static|Public]
	bool IsTypicalMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e948 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsTest
	// Flags: [Final|Native|Static|Public]
	bool IsTest(); // Offset: 0x10394e914 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSystemVPNOpened
	// Flags: [Final|Native|Static|Public]
	bool IsSystemVPNOpened(); // Offset: 0x10394e8e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSupportVulkan(); // Offset: 0x10394e8ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMiniPakVersion(); // Offset: 0x10394e878 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMapPakVersion(); // Offset: 0x10394e844 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.isSkipUpdateByRepair
	// Flags: [Final|Native|Static|Public]
	bool isSkipUpdateByRepair(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e7c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsShipping
	// Flags: [Final|Native|Static|Public]
	bool IsShipping(); // Offset: 0x10394e794 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSavFileData
	// Flags: [Final|Native|Static|Public]
	bool IsSavFileData(struct FString CompressedData, int CompressedSize, int UnCompressedSize, int ToCheckEndWithCDLenght); // Offset: 0x10394e61c // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.IsRuningOnVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRuningOnVulkan(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e5a0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsReleaseVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsReleaseVersion(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394e514 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsPVEMode
	// Flags: [Final|Native|Static|Public]
	bool IsPVEMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e498 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsOpenAOS90FPSConfig
	// Flags: [Final|Native|Static|Public]
	bool IsOpenAOS90FPSConfig(); // Offset: 0x10394e464 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsODPakMonted
	// Flags: [Final|Native|Static|Public]
	bool IsODPakMonted(struct FString Filename); // Offset: 0x10394e3cc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsNotificationEnabled
	// Flags: [Final|Native|Static|Public]
	bool IsNotificationEnabled(); // Offset: 0x10394e398 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNoAuthMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsNoAuthMode(); // Offset: 0x10394e364 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNetworkReachable
	// Flags: [Final|Native|Static|Public]
	bool IsNetworkReachable(); // Offset: 0x10394e330 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNeedClearHiddenUI
	// Flags: [Final|Native|Static|Public]
	bool IsNeedClearHiddenUI(struct UFrontendHUD* GameFrontendHUD); // Offset: 0x10394e2b4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsMounted
	// Flags: [Final|Native|Static|Public]
	bool IsMounted(struct FString Filename); // Offset: 0x10394e21c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsMlAIDebug
	// Flags: [Final|Native|Static|Public]
	bool IsMlAIDebug(); // Offset: 0x10394e1e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsLaunchedByLocalNotification
	// Flags: [Final|Native|Static|Public]
	bool IsLaunchedByLocalNotification(); // Offset: 0x10394e1b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsJaguar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsJaguar(); // Offset: 0x10394e180 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveSOriginal
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveSOriginal(); // Offset: 0x10394e14c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveS
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveS(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394e0d0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsIOSVersionAbove13
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsIOSVersionAbove13(); // Offset: 0x10394e09c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWX
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWX(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394e010 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWhatsapp
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWhatsapp(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394df84 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallVK
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallVK(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394def8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallTwitter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallTwitter(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394de6c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallQQByiTOP
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallQQByiTOP(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394dde0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallOpenRec
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallOpenRec(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394dd54 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMirrativ
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMirrativ(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394dcc8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMessenger
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMessenger(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394dc3c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLite
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLite(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394dbb0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLine
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLine(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394db24 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallFaceBook
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallFaceBook(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394da98 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallDiscord
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallDiscord(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394da0c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsHarmonyOS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHarmonyOS(); // Offset: 0x10394d9d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHapticsEngineEnable(); // Offset: 0x10394d9a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsForCE
	// Flags: [Final|Native|Static|Public]
	bool IsForCE(); // Offset: 0x10394d970 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsFileReady
	// Flags: [Final|Native|Static|Public]
	bool IsFileReady(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x10394d874 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheckMatchExt
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheckMatchExt(struct FString Filename); // Offset: 0x10394d7dc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheck(struct FString Filename); // Offset: 0x10394d744 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithOutPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithOutPakCheck(struct FString Path); // Offset: 0x10394d6ac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFileExistByFileName(struct FString Filename); // Offset: 0x10394d614 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByExtension
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistByExtension(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename, struct FString fileExtension); // Offset: 0x10394d4a0 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.IsFileExist
	// Flags: [Final|Native|Static|Public]
	bool IsFileExist(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename); // Offset: 0x10394d3a4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsEnableDSGrayPublishFlag
	// Flags: [Final|Native|Static|Public]
	bool IsEnableDSGrayPublishFlag(uint64 nGrayPublishFlag); // Offset: 0x10394d328 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsEmulatorWhenInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEmulatorWhenInit(); // Offset: 0x10394d2f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEmulator
	// Flags: [Final|Native|Static|Public]
	bool IsEmulator(); // Offset: 0x10394d2c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditorDedicatedServer
	// Flags: [Final|Native|Static|Public]
	bool IsEditorDedicatedServer(); // Offset: 0x10394d28c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditor
	// Flags: [Final|Native|Static|Public]
	bool IsEditor(); // Offset: 0x10394d258 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDolbyAtmosSupported
	// Flags: [Final|Native|Static|Public]
	bool IsDolbyAtmosSupported(); // Offset: 0x10394d224 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsViberation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsViberation(); // Offset: 0x10394d1f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsHapticsEngine(); // Offset: 0x10394d1bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceHWSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceHWSupportVulkan(); // Offset: 0x10394d188 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDevelopment
	// Flags: [Final|Native|Static|Public]
	bool IsDevelopment(); // Offset: 0x10394d154 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsConnected
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsConnected(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394d0c8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsCEVersion
	// Flags: [Final|Native|Static|Public]
	bool IsCEVersion(); // Offset: 0x10394d094 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsCEHideLobbyUI
	// Flags: [Final|Native|Static|Public]
	bool IsCEHideLobbyUI(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394d018 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsBasePrefecthOpen
	// Flags: [Final|Native|Static|Public]
	bool IsBasePrefecthOpen(); // Offset: 0x10394cfe4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAwakedByNotification
	// Flags: [Final|Native|Static|Public]
	bool IsAwakedByNotification(); // Offset: 0x10394cfb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAndroidHasGyr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAndroidHasGyr(); // Offset: 0x10394cf7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.InviteWhatsappOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteWhatsappOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x10394ce48 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSystemOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSystemOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x10394cd14 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSMSOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSMSOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Content); // Offset: 0x10394cc34 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InviteLineOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteLineOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x10394cb00 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteFBOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteFBOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content, struct FString link); // Offset: 0x10394c978 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.InstallNewApp
	// Flags: [Final|Native|Static|Public]
	void InstallNewApp(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394c904 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.InitVPN
	// Flags: [Final|Native|Static|Public]
	int InitVPN(struct FString InVPNGUID, struct FString InClientVersion); // Offset: 0x10394c818 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.InitVlink
	// Flags: [Final|Native|Static|Public]
	void InitVlink(); // Offset: 0x10394c804 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitQuantumPlatformMisc
	// Flags: [Final|Native|Static|Public]
	void InitQuantumPlatformMisc(); // Offset: 0x10394c7f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitLoginAccount
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitLoginAccount(struct TScriptInterface<Class>& ClientNetInterface, uint64 AccUin, struct FString AccPswd); // Offset: 0x10394c6ac // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.InitJavaFunctions
	// Flags: [Final|Native|Static|Public]
	void InitJavaFunctions(); // Offset: 0x10394c698 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitIMSDKEnv
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitIMSDKEnv(struct TScriptInterface<Class>& ClientNetInterface, uint32_t iEnv); // Offset: 0x10394c5d8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.InitializePuffer
	// Flags: [Final|Native|Static|Public]
	void InitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x10394c3a4 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InitializeLaggingReporter
	// Flags: [Final|Native|Static|Public]
	void InitializeLaggingReporter(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x10394c2ec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.InitHF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitHF(); // Offset: 0x10394c2d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitGCloudRemoteConfig
	// Flags: [Final|Native|Static|Public]
	void InitGCloudRemoteConfig(); // Offset: 0x10394c2c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitDH
	// Flags: [Final|Native|Static|Public]
	int InitDH(struct FString gen, struct FString prime, int v_srand); // Offset: 0x10394c150 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Ini_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Ini_UpdateMemResource(struct FString KeyWord, struct FString CMDvalue); // Offset: 0x10394c024 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HtmlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString HtmlEncode(struct FString UnencodedString); // Offset: 0x10394bf64 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HideH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideH5WebView(); // Offset: 0x10394bf50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.HaveReceivedNoticeCallback
	// Flags: [Final|Native|Static|Public]
	bool HaveReceivedNoticeCallback(); // Offset: 0x10394bf1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasRemoteConfigReady
	// Flags: [Final|Native|Static|Public]
	bool HasRemoteConfigReady(); // Offset: 0x10394bee8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasNotice
	// Flags: [Final|Native|Static|Public]
	bool HasNotice(int Type, struct FString Scene); // Offset: 0x10394be14 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.HasNotchInScreen
	// Flags: [Final|Native|Static|Public]
	bool HasNotchInScreen(); // Offset: 0x10394bde0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	bool HasLoadGameSlotCrashFlag(); // Offset: 0x10394bdac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public]
	bool HasDownloadedBasePak(); // Offset: 0x10394bd78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasDefinePermission
	// Flags: [Final|Native|Static|Public]
	bool HasDefinePermission(struct FString InPermissionName); // Offset: 0x10394bce0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.HasActiveWifi
	// Flags: [Final|Native|Static|Public]
	bool HasActiveWifi(); // Offset: 0x10394bcac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GuestLogin
	// Flags: [Final|Native|Static|Public]
	void GuestLogin(); // Offset: 0x10394bc98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GotoPlatformAppraise
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GotoPlatformAppraise(); // Offset: 0x10394bc84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GMTestAllocUObjs
	// Flags: [Final|Native|Static|Public]
	void GMTestAllocUObjs(struct UGameFrontendHUD* GameFrontendHUD, int Num); // Offset: 0x10394bbd4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GMH5Enable
	// Flags: [Final|Native|Static|Public]
	void GMH5Enable(bool Flag); // Offset: 0x10394bb58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetWidgetsByClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetWidgetsByClass(struct UWidget* Parent, struct UObject* Type, struct TArray<struct UWidget*>& Children); // Offset: 0x10394ba44 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWebViewTicket
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetWebViewTicket(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394b990 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWeaponDIYIconPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetWeaponDIYIconPath(struct FString PlayerUID, int WeaponID, struct FString PlanID, bool relativePath, int Width, int Height); // Offset: 0x10394b724 // Return & Params: Num(7) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.GetVolume
	// Flags: [Final|Native|Static|Public]
	int GetVolume(int InStreamType); // Offset: 0x10394b6a8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	bool GetUserVulkanSetting(); // Offset: 0x10394b674 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetUserTGPATapEnableFlag(); // Offset: 0x10394b640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetUObjectName
	// Flags: [Final|Native|Static|Public]
	struct FString GetUObjectName(struct UObject* uObj); // Offset: 0x10394b59c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetUnrealNetworkStatus
	// Flags: [Final|Native|Static|Public]
	struct FString GetUnrealNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394b4f8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetUIRectOffset(); // Offset: 0x10394b494 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394b3e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetTimeInMiliSeconds
	// Flags: [Final|Native|Static|Public]
	float GetTimeInMiliSeconds(); // Offset: 0x10394b3ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTGPATapDeviceSupportFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetTGPATapDeviceSupportFlag(); // Offset: 0x10394b378 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTelecomSvr
	// Flags: [Final|Native|Static|Public]
	struct FString GetTelecomSvr(); // Offset: 0x10394b314 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetTCDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetTCDeviceLevel(); // Offset: 0x10394b2e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTableCount
	// Flags: [Final|Native|Static|Public]
	int GetTableCount(struct FString tableName); // Offset: 0x10394b248 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetSystemLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetSystemLanguage_LuaState(); // Offset: 0x10394b230 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSubsideFeatureLevel
	// Flags: [Final|Native|Static|Public]
	uint32_t GetSubsideFeatureLevel(); // Offset: 0x10394b1fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSrcVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetSrcVersion(); // Offset: 0x10394b198 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x10394b134 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSpecialData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSpecialData(); // Offset: 0x10394b0d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	int GetSoundEffectQuality(); // Offset: 0x10394b09c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetShaderPrecompileProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetShaderPrecompileProgress(); // Offset: 0x10394b068 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetServerDelay
	// Flags: [Final|Native|Static|Public]
	int GetServerDelay(struct FString ServerAddress); // Offset: 0x10394afd0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidthForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidthForWebview(); // Offset: 0x10394af9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidth(); // Offset: 0x10394af68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHight(); // Offset: 0x10394af34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHeightForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHeightForWebview(); // Offset: 0x10394af00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenDensity
	// Flags: [Final|Native|Static|Public]
	int GetScreenDensity(); // Offset: 0x10394aecc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRuntimeProfileData
	// Flags: [Final|Native|Static|Public]
	struct FString GetRuntimeProfileData(); // Offset: 0x10394ae68 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetRingMode
	// Flags: [Final|Native|Static|Public]
	int GetRingMode(); // Offset: 0x10394ae34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGIDWithObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGIDWithObj(struct UObject* Obj, struct FString gid, struct FString PlayerName); // Offset: 0x10394ac98 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGID(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString PlayerName); // Offset: 0x10394aafc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRegisterChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetRegisterChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10394aa48 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetRedFlameSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetRedFlameSwitch(); // Offset: 0x10394aa14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetRedBloodSwitch(); // Offset: 0x10394a9e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitResult
	// Flags: [Final|Native|Static|Public]
	bool GetPufferInitResult(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394a964 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitErrCode
	// Flags: [Final|Native|Static|Public]
	uint32_t GetPufferInitErrCode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394a8e8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x10394a884 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPublicKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPublicKey(struct FString cli_pri_key); // Offset: 0x10394a7a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetPUBGModuleBaseAddr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPUBGModuleBaseAddr(struct FString ParamModuleName); // Offset: 0x10394a6bc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetPrivateKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPrivateKey(); // Offset: 0x10394a658 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportInfo(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394a5b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportData
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportData(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394a510 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhysicalFileTime
	// Flags: [Final|Native|Static|Public]
	int64_t GetPhysicalFileTime(struct FString InPath); // Offset: 0x10394a454 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneType
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneType(); // Offset: 0x10394a3f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneDeviceID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneDeviceID(); // Offset: 0x10394a38c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneAdvertisingID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneAdvertisingID(); // Offset: 0x10394a328 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPackChannel
	// Flags: [Final|Native|Static|Public]
	struct FString GetPackChannel(); // Offset: 0x10394a2c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetOSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetOSVersion(); // Offset: 0x10394a260 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetODPaksFileUseTime
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetODPaksFileUseTime(struct FString DumpFilename); // Offset: 0x10394a17c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotificationExtraDataString
	// Flags: [Final|Native|Static|Public]
	struct FString GetNotificationExtraDataString(struct FString Key); // Offset: 0x10394a0bc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotchSize
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetNotchSize(); // Offset: 0x10394a058 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNetWorkType
	// Flags: [Final|Native|Static|Public]
	struct FString GetNetWorkType(); // Offset: 0x103949ff4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativeVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativeVersion(); // Offset: 0x103949f90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativePackageTag
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativePackageTag(); // Offset: 0x103949f2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetMyFriendObservers
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetMyFriendObservers(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103949e88 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPF_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPF_LuaState(); // Offset: 0x103949e70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPayChannel_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPayChannel_LuaState(); // Offset: 0x103949e58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemoryStats_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMemoryStats_LuaState(); // Offset: 0x103949e40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemorySize
	// Flags: [Final|Native|Static|Public]
	int GetMemorySize(); // Offset: 0x103949e0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetLuaRootDir
	// Flags: [Final|Native|Static|Public]
	struct FString GetLuaRootDir(); // Offset: 0x103949da8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetLoginChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int GetLoginChannel(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103949d1c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetLoadGameSlotCrashInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetLoadGameSlotCrashInfo(); // Offset: 0x103949cb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetLaunchLocalNotificationID
	// Flags: [Final|Native|Static|Public]
	struct FString GetLaunchLocalNotificationID(); // Offset: 0x103949c54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetKnownMissingPackage(struct FString PackageName, struct FString DumpFilename); // Offset: 0x103949af8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	int GetiTOPLbsDelay(); // Offset: 0x103949ac4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetITopGameId
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetITopGameId(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103949a10 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIsSecretVersion
	// Flags: [Final|Native|Static|Public]
	int GetIsSecretVersion(); // Offset: 0x1039499dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIsPlayerUsingVPN
	// Flags: [Final|Native|Static|Public]
	bool GetIsPlayerUsingVPN(); // Offset: 0x1039499a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetIsOpenBattlePlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetIsOpenBattlePlayback(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394992c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetIPRegion
	// Flags: [Final|Native|Static|Public]
	int GetIPRegion(); // Offset: 0x1039498f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddrByHost
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddrByHost(struct FString Host); // Offset: 0x103949838 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddr
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddr(); // Offset: 0x1039497d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetInstallChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetInstallChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103949720 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public]
	int GetIMSDKEnv(); // Offset: 0x1039496ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetH5CacheStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetH5CacheStatus(struct FString ModuleName); // Offset: 0x103949654 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.GetGvoiceReconnectInfo
	// Flags: [Final|Native|Static|Public]
	void GetGvoiceReconnectInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x10394955c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetGroupInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FGroupInfoWrapper GetGroupInfo(struct TScriptInterface<Class>& ClientNetInterface, int SnsAction); // Offset: 0x103949460 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GetGoogleServiceVersionCode
	// Flags: [Final|Native|Static|Public]
	int GetGoogleServiceVersionCode(); // Offset: 0x10394942c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetGLVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLVersion(); // Offset: 0x1039493c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGLType
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLType(); // Offset: 0x103949364 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGameStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039492c0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameModeID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameModeID(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394921c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameMasterGUID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameMasterGUID(); // Offset: 0x1039491b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFrameCounter
	// Flags: [Final|Native|Static|Public]
	int64_t GetFrameCounter(); // Offset: 0x103949184 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetFPS
	// Flags: [Final|Native|Static|Public]
	float GetFPS(); // Offset: 0x103949150 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetFireBaseFCMToken
	// Flags: [Final|Native|Static|Public]
	struct FString GetFireBaseFCMToken(); // Offset: 0x1039490ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDiskBytes
	// Flags: [Final|Native|Static|Public]
	int64_t GetFileSizeOnDiskBytes(struct FString FilePath); // Offset: 0x103949030 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDisk
	// Flags: [Final|Native|Static|Public]
	uint32_t GetFileSizeOnDisk(struct FString FilePath); // Offset: 0x103948f74 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeCompressed
	// Flags: [Final|Native|Static|Public]
	uint64 GetFileSizeCompressed(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x103948e78 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFileDirPath
	// Flags: [Final|Native|Static|Public]
	struct FString GetFileDirPath(struct FString FilePath); // Offset: 0x103948d94 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFBFriendsUnregistered
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GetFBFriendsUnregistered(struct TScriptInterface<Class>& ClientNetInterface, uint32_t page, uint32_t Count, uint32_t Type, struct FString extend); // Offset: 0x103948c04 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetExactDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetExactDeviceLevel(); // Offset: 0x103948bd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetEncodeUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEncodeUrl(struct FString URL); // Offset: 0x103948aec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetEmulatorName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEmulatorName(); // Offset: 0x103948a88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetDSVersion(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039489e4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDownLoadLanguageName(); // Offset: 0x103948980 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public]
	int GetDeviceQualityLevel(); // Offset: 0x10394894c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDevicePlatformName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDevicePlatformName(); // Offset: 0x1039488e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceName(); // Offset: 0x103948884 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceModel
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceModel(); // Offset: 0x103948820 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceMaxSupportSoundEffect
	// Flags: [Final|Native|Static|Public]
	int GetDeviceMaxSupportSoundEffect(); // Offset: 0x1039487ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceMake
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceMake(); // Offset: 0x103948788 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceInfo(); // Offset: 0x103948724 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceFreeSpace
	// Flags: [Final|Native|Static|Public]
	uint64 GetDeviceFreeSpace(); // Offset: 0x1039486f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentRHILevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCurrentRHILevel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10394864c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetCurrentLanguage_LuaState(); // Offset: 0x103948634 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentChannel
	// Flags: [Final|Native|Static|Public]
	int GetCurrentChannel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039485b8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetCpuType
	// Flags: [Final|Native|Static|Public]
	struct FString GetCpuType(); // Offset: 0x103948554 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetCDNUpdateInfo
	// Flags: [Final|Native|Static|Public]
	void GetCDNUpdateInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x10394845c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetBuildVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetBuildVersion(); // Offset: 0x1039483f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetBattleKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetBattleKey(struct FString svr_pub_key, struct FString cli_pri_key); // Offset: 0x10394829c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAreaIPNo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAreaIPNo(); // Offset: 0x103948238 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAppVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetAppVersion(); // Offset: 0x1039481d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetApplicationVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetApplicationVersion(); // Offset: 0x103948170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAOSSHOP
	// Flags: [Final|Native|Static|Public]
	struct FString GetAOSSHOP(); // Offset: 0x10394810c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetAndroidVersion(); // Offset: 0x1039480a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSysInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAndroidSysInfo(); // Offset: 0x103948044 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSOVersion
	// Flags: [Final|Native|Static|Public]
	int GetAndroidSOVersion(); // Offset: 0x103948010 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxStackSize
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxStackSize(); // Offset: 0x103947fdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxFDNum(); // Offset: 0x103947fa8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidCurrentFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidCurrentFDNum(); // Offset: 0x103947f74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidBuildForArm
	// Flags: [Final|Native|Static|Public]
	int GetAndroidBuildForArm(); // Offset: 0x103947f40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAllLocalNotificationIDs
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetAllLocalNotificationIDs(); // Offset: 0x103947edc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAllFilesInDir
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetAllFilesInDir(struct FString Dir, struct FString Pattern); // Offset: 0x103947dc8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAccountRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAccountRegion(); // Offset: 0x103947d64 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAccessToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetAccessToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103947cb0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GenerateQRImage
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateQRImage(struct TScriptInterface<Class>& ClientNetInterface, int Tag, int Size, struct FString Content, struct FString logoPath); // Offset: 0x103947b04 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportSubEvent
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GEMReportSubEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct FString SubEventName, struct TArray<struct FString>& eventParams); // Offset: 0x103947980 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportShaderPrecompileEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportShaderPrecompileEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x103947848 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct TMap<struct FString, struct FString> eventParams); // Offset: 0x1039476d4 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEnterLobbyEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEnterLobbyEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x10394759c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigStartOnce
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigStartOnce(); // Offset: 0x103947588 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigSetUrl
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigSetUrl(struct FString InRemoteConfigUrl); // Offset: 0x1039474f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetString
	// Flags: [Final|Native|Static|Public]
	struct FString GCloudRemoteConfigGetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x1039473e4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetInt
	// Flags: [Final|Native|Static|Public]
	int GCloudRemoteConfigGetInt(struct FString InKey, int InDefaultValue); // Offset: 0x10394730c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetBool
	// Flags: [Final|Native|Static|Public]
	bool GCloudRemoteConfigGetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x10394722c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigClear
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigClear(); // Offset: 0x103947218 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUserInfo
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUserInfo(struct FString InPaidInfo, struct FString InUserToken, struct FString InAppId); // Offset: 0x1039470e0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUsableRegion
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUsableRegion(struct FString InRegion); // Offset: 0x103947050 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUdpEchoPort
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUdpEchoPort(int InPort); // Offset: 0x103946fdc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetOnlyWifiAccel
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetOnlyWifiAccel(bool InOn); // Offset: 0x103946f60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetFreeFlowUser
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetFreeFlowUser(int InType); // Offset: 0x103946eec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterOnNetDelay
	// Flags: [Final|Native|Static|Public]
	void GameMasterOnNetDelay(int InMillis); // Offset: 0x103946e78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterIsAccelOpened
	// Flags: [Final|Native|Static|Public]
	bool GameMasterIsAccelOpened(); // Offset: 0x103946e44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterInit
	// Flags: [Final|Native|Static|Public]
	int GameMasterInit(int InHookType, struct FString InGuid, struct FString InLibs, int InEchoPort); // Offset: 0x103946cdc // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetWebUIUrl
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetWebUIUrl(int InType); // Offset: 0x103946c38 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetVIPValidTime
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetVIPValidTime(); // Offset: 0x103946bd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetUserID
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetUserID(); // Offset: 0x103946b70 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetAccelerationStatus
	// Flags: [Final|Native|Static|Public]
	int GameMasterGetAccelerationStatus(); // Offset: 0x103946b3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterClearAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterClearAccelAddr(); // Offset: 0x103946b28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterBeginRound
	// Flags: [Final|Native|Static|Public]
	void GameMasterBeginRound(struct FString InOpenId, struct FString InPvpId); // Offset: 0x103946a44 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddNewArenaAddress
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddNewArenaAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x103946920 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddAccelAddr(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x1039467fc // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameJoySwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySwitchOn(int isOn); // Offset: 0x103946788 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStopManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStopManualRecord(); // Offset: 0x103946774 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartMomentsRecord(); // Offset: 0x103946760 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartManualRecord(); // Offset: 0x10394674c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetVideoQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetVideoQuality(int Quality); // Offset: 0x1039466d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetMomentRecordSwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetMomentRecordSwitchOn(int isOn); // Offset: 0x103946664 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetLuaguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetLuaguage(); // Offset: 0x103946650 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetCurrentRecorderPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetCurrentRecorderPosition(float X, float Y); // Offset: 0x1039465a4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GameJoyIsSDKFeatureSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GameJoyIsSDKFeatureSupport(); // Offset: 0x103946570 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameJoyGenerateMomentsVideo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyGenerateMomentsVideo(struct TArray<struct FTimeStamp> shortVideosTimeStampList, struct TArray<struct FTimeStamp> largeVideosTimeStampList, struct FString Title, struct TMap<struct FString, struct FString> ExtraInfo); // Offset: 0x103946304 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.GameJoyEndMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyEndMomentsRecord(); // Offset: 0x1039462f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyClearMomentsVideo
	// Flags: [Final|Native|Static|Public]
	void GameJoyClearMomentsVideo(); // Offset: 0x1039462dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FullPathFileExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool FullPathFileExist(struct FString Filename); // Offset: 0x103946244 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.FlushKnownMissingPackageRefObject
	// Flags: [Final|Native|Static|Public]
	void FlushKnownMissingPackageRefObject(); // Offset: 0x103946230 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FinishPufferUpdateInDolphin
	// Flags: [Final|Native|Static|Public]
	void FinishPufferUpdateInDolphin(struct UGameFrontendHUD* GameFrontendHUD, bool IsFinished); // Offset: 0x103946178 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.FindFilesRecursiveSkipPakPlatform
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> FindFilesRecursiveSkipPakPlatform(struct FString Dir, struct FString Pattern); // Offset: 0x103946064 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.FindFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int FindFiles_LuaState(); // Offset: 0x10394604c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.FileSystemTesting
	// Flags: [Final|Native|Static|Public]
	void FileSystemTesting(uint32_t Count); // Offset: 0x103945fd8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ExitGameForSafety
	// Flags: [Final|Native|Static|Public]
	void ExitGameForSafety(); // Offset: 0x103945fc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ExitGame
	// Flags: [Final|Native|Static|Public]
	void ExitGame(); // Offset: 0x103945fb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnterLoading
	// Flags: [Final|Native|Static|Public]
	void EnterLoading(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103945f3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.EnterFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnterFightChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid); // Offset: 0x103945e48 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.EnterBattleStandAlone
	// Flags: [Final|Native|Static|Public]
	void EnterBattleStandAlone(struct UGameFrontendHUD* GameFrontendHUD, struct FString MapPath, uint32_t PlayerKey, struct FString PlayerName); // Offset: 0x103945c98 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EnterBattle
	// Flags: [Final|Native|Static|Public]
	void EnterBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString HostnameOrIP, uint32_t Port, uint32_t PlayerKey, struct FString PlayerName, struct FString PacketKey, uint64 GameID, bool IsObserver, struct TMap<int, struct FString> AdvConfig, int WaterType, uint32_t WaterUserID, uint32_t ModeID, uint32_t ModeType); // Offset: 0x103945808 // Return & Params: Num(13) Size(0xb0)

	// Object Name: Function Client.ScriptHelperClient.EncryptUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString EncryptUID(struct FString sUid, struct FString sKey); // Offset: 0x1039456ac // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EncryptItemData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void EncryptItemData(struct TArray<int>& EncryptionItemList); // Offset: 0x10394560c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.EnableUseOldInterface
	// Flags: [Final|Native|Static|Public]
	void EnableUseOldInterface(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103945554 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableTxtCheck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableTxtCheck(); // Offset: 0x103945540 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnableShaderGroup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableShaderGroup(struct FString GroupName); // Offset: 0x1039454a8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.EnableReportGVoiceEvent
	// Flags: [Final|Native|Static|Public]
	void EnableReportGVoiceEvent(struct UGameFrontendHUD* GameFrontendHUD, bool GVoiceInitGVoiceComponentReportEnable, bool GVoiceJoinRoomReportEnable, bool GVoiceQuitRoomReportEnable, bool GVoiceJoinLbsRoomReportEnable, bool GVoiceQuitLbsRoomReportEnable, bool GVoiceOnJoinTeamRoomReportEnable, bool GVoiceOnJoinLbsRoomReportEnable); // Offset: 0x103945240 // Return & Params: Num(8) Size(0xf)

	// Object Name: Function Client.ScriptHelperClient.EnableLocalizationStatus
	// Flags: [Final|Native|Static|Public]
	void EnableLocalizationStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x103945188 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableIosStuckWork
	// Flags: [Final|Native|Static|Public]
	void EnableIosStuckWork(struct UGameFrontendHUD* GameFrontendHUD, bool bEnable); // Offset: 0x1039450d0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoiceGemReport
	// Flags: [Final|Native|Static|Public]
	void EnableGvoiceGemReport(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103945018 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103944f60 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableCampGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableCampGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103944ea8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableAutoObjectRefreshStage
	// Flags: [Final|Native|Static|Public]
	void EnableAutoObjectRefreshStage(bool bEnable); // Offset: 0x103944e2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.EnableAudioRouteChangedNotify
	// Flags: [Final|Native|Static|Public]
	void EnableAudioRouteChangedNotify(bool Enable); // Offset: 0x103944db0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DumpPackageMemInfo
	// Flags: [Final|Native|Static|Public]
	struct FString DumpPackageMemInfo(struct TArray<struct FString> AssetList); // Offset: 0x103944ca8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.DumpOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void DumpOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, struct FString DumpFilename); // Offset: 0x103944bb4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.DumpLogFile
	// Flags: [Final|Native|Static|Public]
	void DumpLogFile(bool backup); // Offset: 0x103944b38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.Disconnect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Disconnect(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103944ab4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DisableRepairResource
	// Flags: [Final|Native|Static|Public]
	void DisableRepairResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103944a40 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.DirectToSetting
	// Flags: [Final|Native|Static|Public]
	void DirectToSetting(); // Offset: 0x103944a2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.DestroyConnector
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void DestroyConnector(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039449a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x103944910 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.DeleteDirectory
	// Flags: [Final|Native|Static|Public]
	void DeleteDirectory(struct FString FilePath); // Offset: 0x10394485c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DelayToSetAutoInitFacebookLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToSetAutoInitFacebookLog(bool IsAutoInit); // Offset: 0x1039447e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DelayToInitFacebookSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToInitFacebookSDK(bool IsAutoInit, bool WithLaunchOption); // Offset: 0x103944720 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.ScriptHelperClient.DelayInitThirdPartSDK
	// Flags: [Final|Native|Static|Public]
	void DelayInitThirdPartSDK(); // Offset: 0x10394470c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CreateHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CreateHapticsEngine(DelegateProperty Callback); // Offset: 0x103944684 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForWrite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForWrite(struct FString FilePath); // Offset: 0x1039445c4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForRead
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForRead(struct FString FilePath); // Offset: 0x103944504 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertTMap2JsonStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString ConvertTMap2JsonStr(struct TMap<struct FString, struct FString>& mapData); // Offset: 0x103944430 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.ConvertRelativePathToFull
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertRelativePathToFull(struct FString InPath); // Offset: 0x10394434c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertGamePathToRelativeFilePath
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertGamePathToRelativeFilePath(struct FString Path); // Offset: 0x10394428c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConsoleCommand
	// Flags: [Final|Native|Static|Public]
	struct FString ConsoleCommand(struct UGameFrontendHUD* GameFrontendHUD, struct FString Command); // Offset: 0x103944190 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ConnectToURL
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ConnectToURL(struct TScriptInterface<Class>& ClientNetInterface, struct FString URL, int ConnectTimeOutSeconds); // Offset: 0x10394404c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.ComputerName
	// Flags: [Final|Native|Static|Public]
	struct FString ComputerName(); // Offset: 0x103943fe8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.CloseWebView
	// Flags: [Final|Native|Static|Public]
	void CloseWebView(); // Offset: 0x103943fd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVLink
	// Flags: [Final|Native|Static|Public]
	void CloseVLink(); // Offset: 0x103943fc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseVideoListDialog(); // Offset: 0x103943fac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseH5WebView(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103943f38 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClipBoardCopy
	// Flags: [Final|Native|Static|Public]
	void ClipBoardCopy(struct FString Text); // Offset: 0x103943e84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClientKickPlayerFromGame
	// Flags: [Final|Native|Static|Public]
	void ClientKickPlayerFromGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103943e10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientEnterWarMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClientEnterWarMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103943d9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmReturnToGame
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmReturnToGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103943d28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmMisKill
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmMisKill(struct UGameFrontendHUD* GameFrontendHUD, int bConfirm); // Offset: 0x103943c78 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ClearUpdatedSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearUpdatedSoPatch(); // Offset: 0x103943c64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearNotifications(); // Offset: 0x103943c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotice
	// Flags: [Final|Native|Static|Public]
	void ClearNotice(); // Offset: 0x103943c3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearIGProxyData
	// Flags: [Final|Native|Static|Public]
	void ClearIGProxyData(); // Offset: 0x103943c28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearHasLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	void ClearHasLoadGameSlotCrashFlag(); // Offset: 0x103943c14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ClearChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103943b90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClearAllLocalNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearAllLocalNotifications(); // Offset: 0x103943b7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckRegisterGestureConflictWithZoom
	// Flags: [Final|Native|Static|Public]
	void CheckRegisterGestureConflictWithZoom(); // Offset: 0x103943b68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckLocalizationExist
	// Flags: [Final|Native|Static|Public]
	bool CheckLocalizationExist(); // Offset: 0x103943b34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.CheckFilesInPak
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<struct FString> CheckFilesInPak(struct TArray<struct FString>& Files); // Offset: 0x103943a64 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.CheckBeforeInitPuffer
	// Flags: [Final|Native|Static|Public]
	void CheckBeforeInitPuffer(); // Offset: 0x103943a50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ChangeLocalizationReleaseTestStatus
	// Flags: [Final|Native|Static|Public]
	void ChangeLocalizationReleaseTestStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x103943998 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.CanUseHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CanUseHapticsEngine(); // Offset: 0x103943964 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.CancelLocalNotification
	// Flags: [Final|Native|Static|Public]
	void CancelLocalNotification(int NotificationID); // Offset: 0x1039438f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.CallIngameFirstTimeTips
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CallIngameFirstTimeTips(struct UGameFrontendHUD* GameFrontendHUD, struct FString tableName, struct FString FunctionName); // Offset: 0x1039437d0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.CallEngineGC
	// Flags: [Final|Native|Static|Public]
	void CallEngineGC(); // Offset: 0x1039437bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CacheH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CacheH5WebView(struct FString ModuleName); // Offset: 0x10394372c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.BuglySetAppVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglySetAppVersion(struct TScriptInterface<Class>& ClientNetInterface, struct FString Version); // Offset: 0x103943628 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.BuglyPutUserData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPutUserData(struct TScriptInterface<Class>& ClientNetInterface, struct FString Key, struct FString Value); // Offset: 0x1039434ac // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.BuglyPostExceptionFull
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPostExceptionFull(struct TScriptInterface<Class>& ClientNetInterface, int Category, struct FString Name, struct FString Msg, struct FString stack); // Offset: 0x103943278 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.BuglyPostException
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPostException(struct TScriptInterface<Class>& ClientNetInterface, int Category, struct FString Reason); // Offset: 0x103943134 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.BuglyLog
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyLog(struct TScriptInterface<Class>& ClientNetInterface, int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x103942f28 // Return & Params: Num(5) Size(0x39)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForUIWithName
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForUIWithName(struct FString UIName); // Offset: 0x103942e98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForSecond
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForSecond(int sec); // Offset: 0x103942e24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForJumpPlane
	// Flags: [Final|Native|Static|Public]
	bool AutoTestWaitForJumpPlane(); // Offset: 0x103942df0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVehicleDriverShoot
	// Flags: [Final|Native|Static|Public]
	void AutoTestVehicleDriverShoot(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103942d7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVaultWall
	// Flags: [Final|Native|Static|Public]
	void AutoTestVaultWall(); // Offset: 0x103942d68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUsePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUsePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103942cf4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID); // Offset: 0x103942c44 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItem(int ItemID); // Offset: 0x103942bd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUpgradePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUpgradePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID); // Offset: 0x103942b20 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestToggleVehicleSync
	// Flags: [Final|Native|Static|Public]
	void AutoTestToggleVehicleSync(struct UGameFrontendHUD* GameFrontendHUD, bool Val); // Offset: 0x103942a68 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoomOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoomOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SkillID); // Offset: 0x1039429b8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoom
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoom(int SkillID); // Offset: 0x103942944 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchWeapon
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchWeapon(int WeaponType); // Offset: 0x1039428d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchMode
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchMode(struct FString FunName); // Offset: 0x103942840 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchGameStatus
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchGameStatus(struct UGameFrontendHUD* GameFrontendHUD, struct FName GameStatus, struct FString Options); // Offset: 0x10394270c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStopRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStopRecordStats(); // Offset: 0x1039426f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartRecordStats(struct FString FileStr); // Offset: 0x103942668 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFireOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFireOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z, int sec); // Offset: 0x10394250c // Return & Params: Num(5) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFire
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFire(int X, int Y, int Z, int sec); // Offset: 0x1039423ec // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpecating
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpecating(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x10394233c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpawnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpawnVehicle(struct FString ResPath); // Offset: 0x103942288 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpawnAI
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpawnAI(int ID, float PosiX, float PosiY, float PosiZ); // Offset: 0x103942164 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetVehicleRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetVehicleRotation(int X, int Y, int Z); // Offset: 0x10394207c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetRecordFrequency
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetRecordFrequency(uint32_t Frequency); // Offset: 0x103942008 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorRotation(float Rate, float Speed); // Offset: 0x103941f5c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorPitch
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorPitch(float Rate); // Offset: 0x103941ee8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorFacePoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorFacePoint(int X, int Y, int Z); // Offset: 0x103941e00 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSendBuffertoSvr
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void AutoTestSendBuffertoSvr(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103941d7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestReloadOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestReloadOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103941d08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItemOnlyClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItemOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103941c88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItem
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItem(int ItemID); // Offset: 0x103941c08 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenTraceRPC(); // Offset: 0x103941bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenScope
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenScope(bool bOpenScope); // Offset: 0x103941b78 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenDoorOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenDoorOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int bOpen); // Offset: 0x103941ac8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMustDie
	// Flags: [Final|Native|Static|Public]
	void AutoTestMustDie(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x103941a18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveVehicleForward
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveVehicleForward(float Speed, float Rate, float sec); // Offset: 0x103941930 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveToPoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveToPoint(int X, int Y, int Z); // Offset: 0x103941848 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJumpPlane
	// Flags: [Final|Native|Static|Public]
	void AutoTestJumpPlane(int sec); // Offset: 0x1039417d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJump
	// Flags: [Final|Native|Static|Public]
	void AutoTestJump(); // Offset: 0x1039417c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsOnVehicle
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsOnVehicle(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103941744 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsDriver
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsDriver(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039416c8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsCurrentCommandFinished
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsCurrentCommandFinished(); // Offset: 0x103941694 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestInputMovement
	// Flags: [Final|Native|Static|Public]
	void AutoTestInputMovement(float Rate); // Offset: 0x103941620 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMVehicleMoveAndTowardClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMVehicleMoveAndTowardClientEx(struct UGameFrontendHUD* GameFrontendHUD, float X, float Y, float Z, float X1, float Y1, float Z1); // Offset: 0x103941450 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGotoClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGotoClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z); // Offset: 0x10394132c // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGoto
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGoto(int X, int Y, int Z); // Offset: 0x103941244 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMCommand(struct FString Command); // Offset: 0x1039411b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103941134 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocation(); // Offset: 0x1039410fc // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRuntimeStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRuntimeStats(); // Offset: 0x1039410e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRenderTimeDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRenderTimeDetail(); // Offset: 0x1039410d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetPrimitivesDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetPrimitivesDetail(); // Offset: 0x1039410c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOnVehicle(int SeatType); // Offset: 0x10394104c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOffVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOffVehicle(); // Offset: 0x103941038 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetNearVehiclePos
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetNearVehiclePos(); // Offset: 0x103941000 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMemoryDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetMemoryDetail(); // Offset: 0x103940fec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMapName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetMapName(); // Offset: 0x103940f88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetGameModeState
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetGameModeState(); // Offset: 0x103940f24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetFrameInfo
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetFrameInfo(); // Offset: 0x103940eec // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDrawCallDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetDrawCallDetail(); // Offset: 0x103940ed8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDis2D
	// Flags: [Final|Native|Static|Public]
	int AutoTestGetDis2D(int X, int Y, int Z, int x2, int y2, int z2); // Offset: 0x103940d38 // Return & Params: Num(7) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetCircleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetCircleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103940cb8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetAvailableDeadBoxItem
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> AutoTestGetAvailableDeadBoxItem(); // Offset: 0x103940c54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetActorName(); // Offset: 0x103940bf0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocationListClientEx
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FVector> AutoTestGetActorLocationListClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ActorType, float RangeRadius); // Offset: 0x103940ad4 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetActorLocation(struct FString PlayerName); // Offset: 0x103940a34 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestForceVehiclePosPullClientEx
	// Flags: [Final|Native|Static|Public]
	float AutoTestForceVehiclePosPullClientEx(struct UGameFrontendHUD* GameFrontendHUD, bool bNext); // Offset: 0x103940974 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestForceDeleteCmdAnim
	// Flags: [Final|Native|Static|Public]
	void AutoTestForceDeleteCmdAnim(); // Offset: 0x103940960 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestEnableUITest
	// Flags: [Final|Native|Static|Public]
	void AutoTestEnableUITest(); // Offset: 0x10394094c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestDropItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestDropItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID, int nCount); // Offset: 0x103940864 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestContinuousMoveTo
	// Flags: [Final|Native|Static|Public]
	void AutoTestContinuousMoveTo(float X, float Y, float Z); // Offset: 0x10394077c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestConsoleCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestConsoleCommand(struct FString Command); // Offset: 0x1039406ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestCloseTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestCloseTraceRPC(); // Offset: 0x1039406d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestClickButton
	// Flags: [Final|Native|Static|Public]
	void AutoTestClickButton(struct FString ButtonName); // Offset: 0x103940648 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID, int nCount); // Offset: 0x103940560 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItem(int ItemID, int nCount); // Offset: 0x1039404b4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoMoveToTargetPosClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	void AutoMoveToTargetPosClientEx(struct UGameFrontendHUD* GameFrontendHUD, struct FVector targetPos); // Offset: 0x103940404 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AskForNotificationPermission
	// Flags: [Final|Native|Static|Public]
	void AskForNotificationPermission(); // Offset: 0x1039403f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AndroidShouldShowPermissionRationale
	// Flags: [Final|Native|Static|Public]
	bool AndroidShouldShowPermissionRationale(); // Offset: 0x1039403bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AndroidCheckPermission
	// Flags: [Final|Native|Static|Public]
	bool AndroidCheckPermission(); // Offset: 0x103940388 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadInitBank(); // Offset: 0x103940374 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadAllFilePackages
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadAllFilePackages(); // Offset: 0x103940360 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_StopAllSounds
	// Flags: [Final|Native|Static|Public]
	void AkAudio_StopAllSounds(bool bShouldStopUISounds); // Offset: 0x1039402e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_LoadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_LoadInitBank(); // Offset: 0x1039402d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_Flush
	// Flags: [Final|Native|Static|Public]
	void AkAudio_Flush(struct UWorld* WorldToFlush); // Offset: 0x10394025c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_ClearBanks
	// Flags: [Final|Native|Static|Public]
	void AkAudio_ClearBanks(); // Offset: 0x103940248 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AddMemoryLogSize
	// Flags: [Final|Native|Static|Public]
	int AddMemoryLogSize(int b_size); // Offset: 0x1039401cc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x103940090 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.AddCrashContextData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddCrashContextData(int Key, struct FString Val, bool bAppendTimeStamp, int reportLevel); // Offset: 0x10393ff3c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AddAttachFileString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddAttachFileString(struct FString Type, bool bClear, struct FString& strinfo); // Offset: 0x10393fdd4 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.ScriptHelperEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperEngine : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Decompress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Decompress(struct TArray<char>& Source, bool bEnable); // Offset: 0x10396be30 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Compress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Compress(struct TArray<char>& Source); // Offset: 0x10396bd60 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperEngine.ReplaceEmoji
	// Flags: [Final|Native|Static|Public]
	struct FString ReplaceEmoji(struct FString Content, int MaxEmojiNum, struct FString SpecialCharacter); // Offset: 0x10396bc0c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperEngine.IsLowMemoryDevice
	// Flags: [Final|Native|Static|Public]
	bool IsLowMemoryDevice(); // Offset: 0x10396bbd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedVirtualInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedVirtualInKB(); // Offset: 0x10396bba4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedPhysicalInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedPhysicalInKB(); // Offset: 0x10396bb70 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.SDKCallbackHelper
// Size: 0x88 // Inherited bytes: 0x28
struct USDKCallbackHelper : UObject {
	// Fields
	struct FScriptMulticastDelegate SDKCallbackDelegate; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x50]; // Offset: 0x38 // Size: 0x50

	// Functions

	// Object Name: Function Client.SDKCallbackHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x10396c3b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SDKCallbackHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USDKCallbackHelper* GetInstance(); // Offset: 0x10396c37c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.SettingSubsystem
// Size: 0x270 // Inherited bytes: 0x30
struct USettingSubsystem : UGameInstanceSubsystem {
	// Fields
	bool bUseRegisterDelegateOptimize; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TMap<struct FString, bool> CacheRegisterProperties_Bool; // Offset: 0x38 // Size: 0x50
	struct TMap<struct FString, int> CacheRegisterProperties_Int; // Offset: 0x88 // Size: 0x50
	struct TMap<struct FString, float> CacheRegisterProperties_Float; // Offset: 0xd8 // Size: 0x50
	struct FString CachedSaveGameName; // Offset: 0x128 // Size: 0x10
	struct TArray<struct FCustomSettingSaveGame> CustomSettingSaveGames; // Offset: 0x138 // Size: 0x10
	DelegateProperty GetUserSettingsDelegate; // Offset: 0x148 // Size: 0x10
	struct UEffectSettingMgr* EffectSettingMgrInstace; // Offset: 0x158 // Size: 0x08
	struct USaveGame* UserSettings; // Offset: 0x160 // Size: 0x08
	struct UObject* UserSettingsClass; // Offset: 0x168 // Size: 0x08
	struct FString UserSettingsClassName; // Offset: 0x170 // Size: 0x10
	struct FString ActiveSaveGameName; // Offset: 0x180 // Size: 0x10
	char pad_0x190[0x8]; // Offset: 0x190 // Size: 0x08
	struct FString LanguageSettingsClassName; // Offset: 0x198 // Size: 0x10
	struct FString LanguageSaveGameName; // Offset: 0x1a8 // Size: 0x10
	char pad_0x1B8[0x60]; // Offset: 0x1b8 // Size: 0x60
	struct TMap<struct FString, bool> LanguageMap; // Offset: 0x218 // Size: 0x50
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08

	// Functions

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_String(struct FString PropertyName, struct FString Val); // Offset: 0x10396d76c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Int(struct FString PropertyName, int Value); // Offset: 0x10396d684 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Float(struct FString PropertyName, float Value); // Offset: 0x10396d59c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Bool(struct FString PropertyName, bool Value, bool IngoreSave); // Offset: 0x10396d464 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Int(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x10396d378 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Float(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x10396d28c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Bool(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x10396d1a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x10396d110 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.SettingSubsystem.GetUserSettingsByDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettingsByDelegate(struct FString LayoutName); // Offset: 0x10396d068 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserSettings_String(struct FString PropertyName); // Offset: 0x10396cf98 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetUserSettings_Int(struct FString PropertyName); // Offset: 0x10396cef0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetUserSettings_Float(struct FString PropertyName); // Offset: 0x10396ce48 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetUserSettings_Bool(struct FString PropertyName); // Offset: 0x10396cda0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x10396cd6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetUserLanguageSettingsProperty_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserLanguageSettingsProperty_String(struct FString PropertyName); // Offset: 0x10396cc9c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x10396cc68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetCustomSetting(struct FString InSlotName); // Offset: 0x10396cbc0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x10396cbac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.CheckLocalizationLanguage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckLocalizationLanguage(); // Offset: 0x10396cb98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.CheckChangeWithCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CheckChangeWithCache(struct UObject* Source, struct UProperty* Property, struct FString PropertyName); // Offset: 0x10396ca50 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function Client.SettingSubsystem.CacheRegisterValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CacheRegisterValue(struct UObject* Source, struct UProperty* Property, struct FString PropertyName); // Offset: 0x10396c910 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x10396c8fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.AddCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCustomSetting(struct FString InSlotName, struct USaveGame* InSaveGame); // Offset: 0x10396c824 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.STExtraClientUtils
// Size: 0x28 // Inherited bytes: 0x28
struct USTExtraClientUtils : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.STExtraClientUtils.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetWidgetHandleAsyncWithCallBack(struct UObject* WorldContext, struct FString ModuleName, struct FString WidgetKey, DelegateProperty Callback); // Offset: 0x10396e32c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.STExtraClientUtils.GetDynamicWidgetHandle
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	struct UUAEUserWidget* GetDynamicWidgetHandle(struct UObject* WorldContext, struct FString ModuleName, struct FString WidetKey); // Offset: 0x10396e1f4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.STExtraClientUtils.GetBPUtils
	// Flags: [Final|Native|Static|Public]
	struct USTExtraClientUIBPUtils* GetBPUtils(); // Offset: 0x10396e1c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.STExtraClientUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x10396e0d4 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.STExtraClientUIBPUtils
// Size: 0x148 // Inherited bytes: 0x28
struct USTExtraClientUIBPUtils : UObject {
	// Fields
	char pad_0x28[0xd0]; // Offset: 0x28 // Size: 0xd0
	struct TMap<int, struct FAssetAsyncRequest> PendingAsyncAssetRequests; // Offset: 0xf8 // Size: 0x50

	// Functions

	// Object Name: Function Client.STExtraClientUIBPUtils.OnAsyncAssetLoaded
	// Flags: [Final|Native|Public|HasDefaults]
	void OnAsyncAssetLoaded(struct FSoftObjectPath InSoftPath, int RequestIdx); // Offset: 0x10396e7b4 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.STExtraClientUIBPUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Public]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x10396e6b8 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.Translator
// Size: 0x138 // Inherited bytes: 0x28
struct UTranslator : UObject {
	// Fields
	struct FString SubscriptionKey; // Offset: 0x28 // Size: 0x10
	struct FString StoredAccessToken; // Offset: 0x38 // Size: 0x10
	DelegateProperty OnGetAccessTokenDelegate; // Offset: 0x48 // Size: 0x10
	DelegateProperty OnDetectDelegate; // Offset: 0x58 // Size: 0x10
	DelegateProperty OnTranslateDelegate; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x98]; // Offset: 0x78 // Size: 0x98
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x20]; // Offset: 0x118 // Size: 0x20

	// Functions

	// Object Name: Function Client.Translator.TranslateV2
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TranslateV2(int Channel, int ID, struct FString Text); // Offset: 0x10396f80c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.Translator.Translate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Translate(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10396f64c // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.Translator.PostMsg
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostMsg(struct FString URL, struct FString Content); // Offset: 0x10396f560 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.Translator.OnTranslateV2
	// Flags: [Final|Native|Private]
	void OnTranslateV2(bool Success, struct FString Data); // Offset: 0x10396f47c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnTranslate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnTranslate__DelegateSignature(bool IsSuccess, struct FString LanguageFrom, struct FString Translation); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnTranslate
	// Flags: [Final|Native|Private]
	void OnTranslate(bool Success, struct FString Data); // Offset: 0x10396f398 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessTokenV2
	// Flags: [Final|Native|Private]
	void OnGetAccessTokenV2(bool Success, struct FString Data); // Offset: 0x10396f2b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnGetAccessToken__DelegateSignature
	// Flags: [Public|Delegate]
	void OnGetAccessToken__DelegateSignature(bool IsSuccess, struct FString Token); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessToken
	// Flags: [Final|Native|Private]
	void OnGetAccessToken(bool Success, struct FString Data); // Offset: 0x10396f1d0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnDetectV2
	// Flags: [Final|Native|Private]
	void OnDetectV2(bool Success, struct FString Data); // Offset: 0x10396f0ec // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnDetect__DelegateSignature
	// Flags: [Public|Delegate]
	void OnDetect__DelegateSignature(bool IsSuccess, struct FString from, struct FString to); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnDetect
	// Flags: [Final|Native|Private]
	void OnDetect(bool Success, struct FString Data); // Offset: 0x10396f008 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.HasTranslating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasTranslating(); // Offset: 0x10396efd4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.Translator.GetAccessToken
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAccessToken(bool bForceGet, struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10396edc8 // Return & Params: Num(5) Size(0x88)

	// Object Name: Function Client.Translator.Detect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Detect(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10396ec08 // Return & Params: Num(4) Size(0x80)
};

// Object Name: Class Client.TssManager
// Size: 0x60 // Inherited bytes: 0x28
struct UTssManager : UObject {
	// Fields
	struct FString TssHostInfo; // Offset: 0x28 // Size: 0x10
	struct FString TssCDNHostInfo; // Offset: 0x38 // Size: 0x10
	struct FString TssBuildInIpInfo; // Offset: 0x48 // Size: 0x10
	int TssLocal; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04

	// Functions

	// Object Name: Function Client.TssManager.SendSkdData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendSkdData_LuaState(); // Offset: 0x10396feb4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SendEigeninfoData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendEigeninfoData_LuaState(); // Offset: 0x10396fe9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SaveSendEigeninfoCode_LuaState
	// Flags: [Final|Native|Static|Public]
	uint32_t SaveSendEigeninfoCode_LuaState(); // Offset: 0x10396fe84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.OnRecvData_LuaState
	// Flags: [Final|Native|Static|Public]
	int OnRecvData_LuaState(); // Offset: 0x10396fe6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.InvokeSDKIoctl
	// Flags: [Final|Native|Static|Public]
	uint32_t InvokeSDKIoctl(int Command, struct FString InCmdData); // Offset: 0x10396fd98 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Client.TssManager.GetUserTag4Lua_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetUserTag4Lua_LuaState(); // Offset: 0x10396fd80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.GetDeviceFeature_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetDeviceFeature_LuaState(); // Offset: 0x10396fd68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.EigenArrayObfuscationVerify_LuaState
	// Flags: [Final|Native|Static|Public]
	int EigenArrayObfuscationVerify_LuaState(); // Offset: 0x10396fd50 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.UAEClientGameMode
// Size: 0x490 // Inherited bytes: 0x490
struct AUAEClientGameMode : AGameMode {
};

// Object Name: Class Client.UAELobbyGameMode
// Size: 0x490 // Inherited bytes: 0x490
struct AUAELobbyGameMode : AUAEClientGameMode {
};

// Object Name: Class Client.UAELobbyPlayerController
// Size: 0x728 // Inherited bytes: 0x728
struct AUAELobbyPlayerController : APlayerController {
};

// Object Name: Class Client.UTRichTextBlock
// Size: 0xb08 // Inherited bytes: 0x100
struct UUTRichTextBlock : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FScriptMulticastDelegate OnHyperlinkClicked; // Offset: 0x108 // Size: 0x10
	struct FString ContentText; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x138 // Size: 0x58
	bool bSupportHyLink; // Offset: 0x190 // Size: 0x01
	bool bSupportImage; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x2]; // Offset: 0x192 // Size: 0x02
	struct FLinearColor TextColor; // Offset: 0x194 // Size: 0x10
	enum class ETextJustify Justification; // Offset: 0x1a4 // Size: 0x01
	enum class ETextVerticalJustify TextVerticalJustification; // Offset: 0x1a5 // Size: 0x01
	bool AutoWrapText; // Offset: 0x1a6 // Size: 0x01
	char pad_0x1A7[0x1]; // Offset: 0x1a7 // Size: 0x01
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x1a8 // Size: 0x680
	struct FMargin HScrollBarPadding; // Offset: 0x828 // Size: 0x10
	struct FMargin VScrollBarPadding; // Offset: 0x838 // Size: 0x10
	float WrapTextAt; // Offset: 0x848 // Size: 0x04
	struct FMargin Margin; // Offset: 0x84c // Size: 0x10
	float LineHeightPercentage; // Offset: 0x85c // Size: 0x04
	struct FString HyperlinkDecoratorTag; // Offset: 0x860 // Size: 0x10
	struct FString HyperlinkCallBackFunctionName; // Offset: 0x870 // Size: 0x10
	struct FString HyperlinkCallBackTableName; // Offset: 0x880 // Size: 0x10
	char pad_0x890[0x270]; // Offset: 0x890 // Size: 0x270
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb00 // Size: 0x08

	// Functions

	// Object Name: Function Client.UTRichTextBlock.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x1039706fc // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.UTRichTextBlock.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103970680 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.UTRichTextBlock.OnHyperlinkClickedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnHyperlinkClickedEvent__DelegateSignature(struct FMetaDataHolder& MetaDataHolder); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.UTRichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10397061c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class Client.AEVarButton
// Size: 0x550 // Inherited bytes: 0x118
struct UAEVarButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x118 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x120 // Size: 0x338
	struct FLinearColor ColorAndOpacity; // Offset: 0x458 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x468 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x478 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x479 // Size: 0x01
	bool IsFocusable; // Offset: 0x47a // Size: 0x01
	bool IsPassMouseEvent; // Offset: 0x47b // Size: 0x01
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct FString ButtonVar; // Offset: 0x480 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonClicked; // Offset: 0x490 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonPressed; // Offset: 0x4a0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonReleased; // Offset: 0x4b0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonHovered; // Offset: 0x4c0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonUnhovered; // Offset: 0x4d0 // Size: 0x10
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x4e0 // Size: 0x10
	char pad_0x4F0[0x10]; // Offset: 0x4f0 // Size: 0x10
	struct FScriptMulticastDelegate OnClicked; // Offset: 0x500 // Size: 0x10
	struct FScriptMulticastDelegate OnPressed; // Offset: 0x510 // Size: 0x10
	struct FScriptMulticastDelegate OnReleased; // Offset: 0x520 // Size: 0x10
	struct FScriptMulticastDelegate OnHovered; // Offset: 0x530 // Size: 0x10
	struct FScriptMulticastDelegate OnUnhovered; // Offset: 0x540 // Size: 0x10

	// Functions

	// Object Name: Function Client.AEVarButton.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x103970cd4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x103970c20 // Return & Params: Num(1) Size(0x338)

	// Object Name: Function Client.AEVarButton.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x103970ba4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x103970b28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x103970aac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x103970a78 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.ReuseFallC
// Size: 0xf08 // Inherited bytes: 0x260
struct UReuseFallC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnBeforeNewItem; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnAfterNewItem; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnRefreshItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnItemCreated; // Offset: 0x290 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchFinish; // Offset: 0x2a0 // Size: 0x10
	struct FScriptMulticastDelegate OnOverscrollState; // Offset: 0x2b0 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x2c0 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x5a8 // Size: 0x01
	char pad_0x5A9[0x7]; // Offset: 0x5a9 // Size: 0x07
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x5b0 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xc30 // Size: 0x01
	char pad_0xC31[0x3]; // Offset: 0xc31 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xc34 // Size: 0x08
	int ColumnNum; // Offset: 0xc3c // Size: 0x04
	int ItemHeight; // Offset: 0xc40 // Size: 0x04
	int ItemPaddingX; // Offset: 0xc44 // Size: 0x04
	int ItemPaddingY; // Offset: 0xc48 // Size: 0x04
	float OverscrollLength; // Offset: 0xc4c // Size: 0x04
	struct UUserWidget* ItemClass; // Offset: 0xc50 // Size: 0x08
	struct TMap<struct FString, struct UUserWidget*> OtherItemClass; // Offset: 0xc58 // Size: 0x50
	int PreviewCount; // Offset: 0xca8 // Size: 0x04
	int ItemPoolMaxNum; // Offset: 0xcac // Size: 0x04
	int TopSpaceReserved; // Offset: 0xcb0 // Size: 0x04
	int BottomSpaceReserved; // Offset: 0xcb4 // Size: 0x04
	char pad_0xCB8[0x38]; // Offset: 0xcb8 // Size: 0x38
	struct UUserWidget* CurItemClass; // Offset: 0xcf0 // Size: 0x08
	char pad_0xCF8[0x210]; // Offset: 0xcf8 // Size: 0x210

	// Functions

	// Object Name: Function Client.ReuseFallC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x1039716f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetItemSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemSize(int __Idx, float __Size); // Offset: 0x103971638 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ReuseFallC.SetItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemFullStyle(int idx); // Offset: 0x1039715bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetCurItemClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurItemClass(struct FString StrName); // Offset: 0x103971514 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReuseFallC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x103971500 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x1039714ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ResetCurItemClassToDefault
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCurItemClassToDefault(); // Offset: 0x1039714d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x10397145c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x1039713e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x1039713cc // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnTouchFinishDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTouchFinishDelegate__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.OnTouchFinishCallback
	// Flags: [Final|Native|Protected]
	void OnTouchFinishCallback(); // Offset: 0x1039713b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnOverscrollStateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOverscrollStateDelegate__DelegateSignature(enum class EReuseFallOverscrollState State); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReuseFallC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnBeforeNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforeNewItemDelegate__DelegateSignature(int idx); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReuseFallC.OnAfterNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAfterNewItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ReuseFallC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx, bool bImmedia); // Offset: 0x1039712fc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseFallC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x1039712e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x1039712ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.GetOverscrollState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EReuseFallOverscrollState GetOverscrollState(); // Offset: 0x103971290 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseFallC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x103971274 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.ClearItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearItemFullStyle(); // Offset: 0x103971260 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x10397124c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReuseListC
// Size: 0xd30 // Inherited bytes: 0x260
struct UReuseListC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItemParam; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnScrollItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x290 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x2a0 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x588 // Size: 0x01
	enum class ESlateVisibility ScrollBoxVisibility; // Offset: 0x589 // Size: 0x01
	char pad_0x58A[0x6]; // Offset: 0x58a // Size: 0x06
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x590 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xc10 // Size: 0x01
	char pad_0xC11[0x3]; // Offset: 0xc11 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xc14 // Size: 0x08
	int ItemWidth; // Offset: 0xc1c // Size: 0x04
	int ItemHeight; // Offset: 0xc20 // Size: 0x04
	int PaddingX; // Offset: 0xc24 // Size: 0x04
	int PaddingY; // Offset: 0xc28 // Size: 0x04
	int TitleSize; // Offset: 0xc2c // Size: 0x04
	int TitlePadding; // Offset: 0xc30 // Size: 0x04
	bool AutoTitleSize; // Offset: 0xc34 // Size: 0x01
	enum class EReuseListStyle Style; // Offset: 0xc35 // Size: 0x01
	char pad_0xC36[0x2]; // Offset: 0xc36 // Size: 0x02
	struct UUserWidget* ItemClass; // Offset: 0xc38 // Size: 0x08
	int PreviewCount; // Offset: 0xc40 // Size: 0x04
	enum class EReuseListNotFullAlignStyle NotFullAlignStyle; // Offset: 0xc44 // Size: 0x01
	bool NotFullScrollBoxHitTestInvisible; // Offset: 0xc45 // Size: 0x01
	bool UpdateForceLayoutPrepass; // Offset: 0xc46 // Size: 0x01
	char pad_0xC47[0x1]; // Offset: 0xc47 // Size: 0x01
	int ItemCacheNum; // Offset: 0xc48 // Size: 0x04
	int DelayUpdateTimeLimitMS; // Offset: 0xc4c // Size: 0x04
	char pad_0xC50[0xe0]; // Offset: 0xc50 // Size: 0xe0

	// Functions

	// Object Name: Function Client.ReuseListC.SetTitleSlotAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSlotAutoSize(bool as); // Offset: 0x103972894 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseListC.SetTitleSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSize(int SZ); // Offset: 0x103972818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x10397279c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x103972788 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x103972774 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(struct UUserWidget* __ItemClass, enum class EReuseListStyle __Style, int __ItemWidth, int __ItemHeight, int __PaddingX, int __PaddingY); // Offset: 0x1039725d4 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function Client.ReuseListC.Reload
	// Flags: [Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x103972550 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.RefreshParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshParam(struct FString _Param); // Offset: 0x1039724b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.RefreshOneParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOneParam(int __Idx, struct FString _Param); // Offset: 0x1039723e4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ReuseListC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x103972368 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x103972354 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemParamDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemParamDelegate__DelegateSignature(struct UUserWidget* Widget, int idx, struct FString Param); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x20)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseListC.OnScrollItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScrollItemDelegate__DelegateSignature(int BeginIdx, int EndIdx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction Client.ReuseListC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.JumpByIdxStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdxStyle(int __Idx, enum class EReuseListJumpStyle __Style); // Offset: 0x10397229c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseListC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx); // Offset: 0x103972220 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x103972204 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x1039721d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingY(); // Offset: 0x1039721b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingX(); // Offset: 0x103972198 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidthAndPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidthAndPaddingX(); // Offset: 0x103972174 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidth(); // Offset: 0x103972158 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeightAndPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeightAndPaddingY(); // Offset: 0x103972134 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeight(); // Offset: 0x103972118 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x1039720fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetAllWidgetItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetItems(struct TArray<struct UUserWidget*>& ResultItemList); // Offset: 0x103972054 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.FindItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUserWidget* FindItem(int idx); // Offset: 0x103971fc8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ReuseListC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x103971fa8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReusePageC
// Size: 0x398 // Inherited bytes: 0x260
struct UReusePageC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnPageChanged; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginDrag; // Offset: 0x290 // Size: 0x10
	struct FScriptMulticastDelegate OnEndDrag; // Offset: 0x2a0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndScroll; // Offset: 0x2b0 // Size: 0x10
	struct UUserWidget* ItemClass; // Offset: 0x2c0 // Size: 0x08
	char IsLoopPage : 1; // Offset: 0x2c8 // Size: 0x01
	char IsVertical : 1; // Offset: 0x2c8 // Size: 0x01
	char CanDrag : 1; // Offset: 0x2c8 // Size: 0x01
	char pad_0x2C8_3 : 5; // Offset: 0x2c8 // Size: 0x01
	char pad_0x2C9[0x3]; // Offset: 0x2c9 // Size: 0x03
	int CanDragLimit; // Offset: 0x2cc // Size: 0x04
	float AutoPlayRate; // Offset: 0x2d0 // Size: 0x04
	int ShowPageNum; // Offset: 0x2d4 // Size: 0x04
	int DragPageNum; // Offset: 0x2d8 // Size: 0x04
	float DChgPageParam; // Offset: 0x2dc // Size: 0x04
	float ScrollInertial; // Offset: 0x2e0 // Size: 0x04
	float ScrollRate; // Offset: 0x2e4 // Size: 0x04
	char pad_0x2E8[0xb0]; // Offset: 0x2e8 // Size: 0xb0

	// Functions

	// Object Name: Function Client.ReusePageC.SetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlayRate(float Rate); // Offset: 0x103975704 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.SelectPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectPage(int __Idx); // Offset: 0x103975688 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __Count); // Offset: 0x10397560c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(bool bPlay); // Offset: 0x103975588 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReusePageC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReusePageC.OnPageChangedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPageChangedDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndScrollDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndScrollDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndDragDelegate__DelegateSignature(int PageIdx); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.ReusePageC.OnBeginDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeginDragDelegate__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MovePrePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MovePrePage(); // Offset: 0x103975574 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MoveNextPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MoveNextPage(); // Offset: 0x103975560 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.IsDraging
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDraging(); // Offset: 0x103975540 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReusePageC.GetPageCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPageCount(); // Offset: 0x103975524 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetPage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPage(); // Offset: 0x103975508 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetOffset(); // Offset: 0x1039754ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAutoPlayRate(); // Offset: 0x1039754d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAllItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllItems(struct TArray<struct UUserWidget*>& ResultItemList, bool OnlyVisible); // Offset: 0x1039753d4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReusePageC.ClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCache(); // Offset: 0x1039753c0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.UDPPingCollector
// Size: 0x138 // Inherited bytes: 0x28
struct UUDPPingCollector : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct TMap<struct FString, struct FPingServerInfo> mUDPPingInfoMap; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x20]; // Offset: 0xa8 // Size: 0x20
	struct FScriptMulticastDelegate UDPPingShadowResultToLuaDelegate; // Offset: 0xc8 // Size: 0x10
	char pad_0xD8[0x60]; // Offset: 0xd8 // Size: 0x60

	// Functions

	// Object Name: Function Client.UDPPingCollector.TickUDPPing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TickUDPPing(float DeltaTime); // Offset: 0x1039763d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.setUDPPingServerAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	void setUDPPingServerAddress(struct FString ServerIP, struct FString ServerPort, int ZoneID, int WaterMarkType); // Offset: 0x103976228 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.UDPPingCollector.PingServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PingServer(struct FString address, float Timeout, int WaterMarkType); // Offset: 0x1039760ec // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction Client.UDPPingCollector.OnPingServerResultDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPingServerResultDelegate__DelegateSignature(struct FString address, int IsSuccess, float Time); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.UDPPingCollector.IsChooingZoneAccess
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsChooingZoneAccess(); // Offset: 0x1039760b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.isAllZoneHasPingValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool isAllZoneHasPingValue(); // Offset: 0x103976084 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(float MinPingintervalTime, float pingintervalTime, float pingTimeoutSecond, float normalDelayMilliSecond, float maxAutoChooseZoneDelayMilliSecond); // Offset: 0x103975f20 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetZoneServerDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetZoneServerDelay(struct FString ServerAddress); // Offset: 0x103975e54 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetMinDealyAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetMinDealyAddress(); // Offset: 0x103975e20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.ChoosingZone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChoosingZone(int ZoneID, struct FString AddrIP); // Offset: 0x103975d24 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.ViberateEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UViberateEngine : UObject {
};

// Object Name: Class Client.VibrateSystemManager
// Size: 0x498 // Inherited bytes: 0x30
struct UVibrateSystemManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
	struct FString ClassPath; // Offset: 0x40 // Size: 0x10
	struct FString VibrateAssetTablePath; // Offset: 0x50 // Size: 0x10
	int MaxAmplitude; // Offset: 0x60 // Size: 0x04
	int GroundSpesificMatVibrationMinGrear; // Offset: 0x64 // Size: 0x04
	float VehicleBreakingMinSpeedThreshold; // Offset: 0x68 // Size: 0x04
	float VehicleGearMinSpeedThreshold; // Offset: 0x6c // Size: 0x04
	struct TArray<int> TriggerVehicleVibrateGroundPhysicMatList; // Offset: 0x70 // Size: 0x10
	float TriggerVehicleVibrateMinSlip; // Offset: 0x80 // Size: 0x04
	float TriggerVehicleVibrateMinSuspensionRaisePercent; // Offset: 0x84 // Size: 0x04
	float VehicleRaiseSuspensionVibrateInerval; // Offset: 0x88 // Size: 0x04
	int InitAssetProccessNumFrames; // Offset: 0x8c // Size: 0x04
	struct FString LoopTime; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x50]; // Offset: 0xa0 // Size: 0x50
	struct TMap<int, enum class EVibrateTriggerEventType> LoadedVibrateAssetIDAndEventTypeMap; // Offset: 0xf0 // Size: 0x50
	struct TMap<enum class EVibrateStrengthLevel, float> VibrateStrengthLevelModifireMap; // Offset: 0x140 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> VibrateEventMinIntervalMap; // Offset: 0x190 // Size: 0x50
	struct TArray<enum class EVibrateTriggerEventType> CharacterVibrateEventList; // Offset: 0x1e0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> WeaponVibrateEventList; // Offset: 0x1f0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleVibrateEventList; // Offset: 0x200 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> SoundUIVibrateEventList; // Offset: 0x210 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> CharacterBeHitVibrateEventList; // Offset: 0x220 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleEngineVibrateEventList; // Offset: 0x230 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleBeHitVibrateEventList; // Offset: 0x240 // Size: 0x10
	bool bEntireVibrationSwitch; // Offset: 0x250 // Size: 0x01
	bool bCharacterVibrationSwitch; // Offset: 0x251 // Size: 0x01
	bool bWeaponVibrationSwitch; // Offset: 0x252 // Size: 0x01
	bool bVehicleVibrationSwitch; // Offset: 0x253 // Size: 0x01
	bool bSoundUIVibrationSwitch; // Offset: 0x254 // Size: 0x01
	char pad_0x255[0x3]; // Offset: 0x255 // Size: 0x03
	int CharacterVibrationLevel; // Offset: 0x258 // Size: 0x04
	int WeaponVibrationLevel; // Offset: 0x25c // Size: 0x04
	int VehicleVibrationLevel; // Offset: 0x260 // Size: 0x04
	int SoundUIVibrationLevel; // Offset: 0x264 // Size: 0x04
	int EntireVibrationLevel; // Offset: 0x268 // Size: 0x04
	bool bCharacterVibrate; // Offset: 0x26c // Size: 0x01
	bool bWeaponVibrate; // Offset: 0x26d // Size: 0x01
	bool bVehicleVibrate; // Offset: 0x26e // Size: 0x01
	bool bSoundUIVibrate; // Offset: 0x26f // Size: 0x01
	bool bCharacterBeHitVibrate; // Offset: 0x270 // Size: 0x01
	bool bCharacterClimbVibrate; // Offset: 0x271 // Size: 0x01
	bool bCharacterFallVibrate; // Offset: 0x272 // Size: 0x01
	bool bCharacterSwimVibrate; // Offset: 0x273 // Size: 0x01
	bool bAutoWeaponVibrate; // Offset: 0x274 // Size: 0x01
	bool bSemiAutoWeaponVibrate; // Offset: 0x275 // Size: 0x01
	bool bBoltWeaponVibrate; // Offset: 0x276 // Size: 0x01
	bool bOtherWeaponVibrate; // Offset: 0x277 // Size: 0x01
	bool bVehicleEngineVibrate; // Offset: 0x278 // Size: 0x01
	bool bVehicleBeHitVibrate; // Offset: 0x279 // Size: 0x01
	bool bVehicleCrashVibrate; // Offset: 0x27a // Size: 0x01
	bool bFootstepSoundUIVibrate; // Offset: 0x27b // Size: 0x01
	bool bFireShotSoundUIVibrate; // Offset: 0x27c // Size: 0x01
	bool bGlassBrokenSoundUIVibrate; // Offset: 0x27d // Size: 0x01
	bool bVehicleSoundUIVibrate; // Offset: 0x27e // Size: 0x01
	char pad_0x27F[0x1]; // Offset: 0x27f // Size: 0x01
	struct FTimerHandle StopVibrateHandle; // Offset: 0x280 // Size: 0x08
	int CurPlayingVibrateAssetIndex; // Offset: 0x288 // Size: 0x04
	int CurLoopPlayingVibrateAssetIndex; // Offset: 0x28c // Size: 0x04
	int DeviceSupportVibrateType; // Offset: 0x290 // Size: 0x04
	bool bInGameVibration; // Offset: 0x294 // Size: 0x01
	bool bIsHandBreaking; // Offset: 0x295 // Size: 0x01
	char pad_0x296[0x52]; // Offset: 0x296 // Size: 0x52
	bool bHasLastVehicle; // Offset: 0x2e8 // Size: 0x01
	char pad_0x2E9[0x3]; // Offset: 0x2e9 // Size: 0x03
	int LastVehicleGear; // Offset: 0x2ec // Size: 0x04
	bool bIsLastVehicleBreaking; // Offset: 0x2f0 // Size: 0x01
	bool bIsLastVehicleSlipping; // Offset: 0x2f1 // Size: 0x01
	char pad_0x2F2[0x2]; // Offset: 0x2f2 // Size: 0x02
	int LastVehicleGroundContactMaterialSurfaceType; // Offset: 0x2f4 // Size: 0x04
	struct TMap<int, bool> LastVehicleGearVibrateCache; // Offset: 0x2f8 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> LastVibrateEventTimeMap; // Offset: 0x348 // Size: 0x50
	float CurVehicleRaiseSuspensionVibrateCD; // Offset: 0x398 // Size: 0x04
	char pad_0x39C[0x7c]; // Offset: 0x39c // Size: 0x7c
	struct TArray<struct FVibrateEntity> CacheVibrateEntityList; // Offset: 0x418 // Size: 0x10
	struct TMap<struct FString, struct FString> VibratePath2Json; // Offset: 0x428 // Size: 0x50
	char pad_0x478[0x20]; // Offset: 0x478 // Size: 0x20

	// Functions

	// Object Name: Function Client.VibrateSystemManager.StopVibrate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopVibrate(); // Offset: 0x103978830 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.SetVibrationLoopTime
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void SetVibrationLoopTime(struct FString InLoopTime); // Offset: 0x103978790 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerActionDirectly
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerActionDirectly(int SpesifyID, int Amplitude); // Offset: 0x1039786d4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerAction
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerAction(struct FVibrateTriggerAction& Action, bool bCheckGate, bool bCheckInterval, int SpesifyID); // Offset: 0x103978528 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.VibrateSystemManager.PlayVibrateEntity
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void PlayVibrateEntity(struct FVibrateEntity& Entity); // Offset: 0x103978460 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationSwitch(bool Val); // Offset: 0x1039783d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationLevel(int InVal); // Offset: 0x103978350 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationSwitch(bool Val); // Offset: 0x1039782c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationLevel(int InVal); // Offset: 0x103978240 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleSoundUIVibrateSetting(bool Val); // Offset: 0x1039781b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleEngineVibrationSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleEngineVibrationSetting(bool Val); // Offset: 0x103978128 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleCrashVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleCrashVibrateSetting(bool Val); // Offset: 0x10397809c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleBeHitVibrateSetting(bool Val); // Offset: 0x103978010 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationSwitch(bool Val); // Offset: 0x103977f84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationLevel(int InVal); // Offset: 0x103977f00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifySemiAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySemiAutoWeaponVibrateSetting(bool Val); // Offset: 0x103977e74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyOtherWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyOtherWeaponVibrateSetting(bool Val); // Offset: 0x103977de8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyGlassBrokenSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyGlassBrokenSoundUIVibrateSetting(bool Val); // Offset: 0x103977d5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFootstepSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFootstepSoundUIVibrateSetting(bool Val); // Offset: 0x103977cd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFireShotSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFireShotSoundUIVibrateSetting(bool Val); // Offset: 0x103977c44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyEntireVibrationSwitch(bool Val); // Offset: 0x103977bb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyEntireVibrationLevel(int InValue); // Offset: 0x103977b3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationSwitch(bool Val); // Offset: 0x103977ab0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationLevel(int InVal); // Offset: 0x103977a2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterSwimVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterSwimVibrateSetting(bool Val); // Offset: 0x1039779a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterFallVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterFallVibrateSetting(bool Val); // Offset: 0x103977914 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterClimbVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterClimbVibrateSetting(bool Val); // Offset: 0x103977888 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterBeHitVibrateSetting(bool Val); // Offset: 0x1039777fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyBoltWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyBoltWeaponVibrateSetting(bool Val); // Offset: 0x103977770 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyAutoWeaponVibrateSetting(bool Val); // Offset: 0x1039776e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.LoadUserSettingData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void LoadUserSettingData(int inCharacterVibrationLevel, int inWeaponVibrationLevel, int inVehicleVibrationLevel, int inSoundUIVibrationLevel, bool binCharacterBeHitVibrate, bool binCharacterClimbVibrate, bool binCharacterFallVibrate, bool binCharacterSwimVibrate, bool binVehicleEngineVibrate, bool binVehicleBeHitVibrate, bool binVehicleCrashVibrate, bool binFootstepSoundUIVibrate, bool binFireShotSoundUIVibrate, bool binGlassBrokenSoundUIVibrate, bool binVehicleSoundUIVibrate, int inEntireVibrationLevel, bool binAutoWeaponVibrate, bool binSemiAutoWeaponVibrate, bool binBoltWeaponVibrate, bool binOtherWeaponVibrate); // Offset: 0x1039770f8 // Return & Params: Num(20) Size(0x24)

	// Object Name: Function Client.VibrateSystemManager.InvalidateVibrateEntityByEventType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateVibrateEntityByEventType(enum class EVibrateTriggerEventType EventType); // Offset: 0x10397707c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.InitUserSetting
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitUserSetting(); // Offset: 0x103977060 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.InitSystem
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitSystem(); // Offset: 0x103977044 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillTerminate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillTerminate(); // Offset: 0x103977028 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillEnterBackground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillEnterBackground(); // Offset: 0x10397700c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillDeactivate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillDeactivate(); // Offset: 0x103976ff0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasReactivated
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasReactivated(); // Offset: 0x103976fd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasEnteredForeground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasEnteredForeground(); // Offset: 0x103976fb8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVibrateSystemManager* GetInstance(struct UObject* WorldContext, bool bAutoCreate); // Offset: 0x103976ef8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.VibrateSystemManager.GetEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetEntireVibrationLevel(); // Offset: 0x103976ec4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.GetCurrentPlayingVibrationDebugInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetCurrentPlayingVibrationDebugInfo(); // Offset: 0x103976e60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.GetAmplitudeByAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAmplitudeByAlpha(float Alpha); // Offset: 0x103976dcc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ClearVibratePath2Json
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ClearVibratePath2Json(); // Offset: 0x103976db8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.ClearAllVibration
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ClearAllVibration(); // Offset: 0x103976d9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.CheckShootWeaponTypeVibrateGate
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool CheckShootWeaponTypeVibrateGate(struct ASTExtraWeapon* Weapon); // Offset: 0x103976d08 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.VibrateSystemManager.CheckAndCopyFilesToSavedDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CheckAndCopyFilesToSavedDir(struct UVibrateSystemManager* Mgr); // Offset: 0x103976c94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ActiveInGameVibration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActiveInGameVibration(bool Inactive); // Offset: 0x103976c10 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.WINSDKFBWebLogin
// Size: 0x130 // Inherited bytes: 0x100
struct UWINSDKFBWebLogin : UWidget {
	// Fields
	struct FScriptMulticastDelegate OnUrlChanged; // Offset: 0x100 // Size: 0x10
	struct FScriptMulticastDelegate OnHttpResponed; // Offset: 0x110 // Size: 0x10
	struct FString InitialURL; // Offset: 0x120 // Size: 0x10

	// Functions

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnWINSDKHttpResponed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnWINSDKHttpResponed__DelegateSignature(bool requestSucc, struct FString txtContent); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnUrlChanged__DelegateSignature(struct FText& Text); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.WINSDKFBWebLogin.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadURL(struct FString NewURL); // Offset: 0x10397a240 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.WINSDKFBWebLogin.DoHttpRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoHttpRequest(struct FString URL); // Offset: 0x10397a1a8 // Return & Params: Num(1) Size(0x10)
};

