#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct NiagaraCore.NiagaraCompileHash
// Size: 0x10 // Inherited bytes: 0x00
struct FNiagaraCompileHash {
	// Fields
	struct TArray<char> DataHash; // Offset: 0x00 // Size: 0x10
};

