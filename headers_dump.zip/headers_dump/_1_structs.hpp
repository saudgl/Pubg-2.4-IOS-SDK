#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_Headportrait_type.BP_STRUCT_Headportrait_type
// Size: 0xb0 // Inherited bytes: 0x00
struct FBP_STRUCT_Headportrait_type {
	// Fields
	struct FString Desc_0_400BFEE6409617111ABD269F7FF07B5B; // Offset: 0x00 // Size: 0x10
	int Quality_1_67881EA24F1E186A2AF389BBB7C62995; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Icon_2_40CD80EB45CBE4311BB919A7C7DAC3AF; // Offset: 0x18 // Size: 0x10
	struct FString IconBig_3_2BDFF0024A49C5707263E986F0AB826B; // Offset: 0x28 // Size: 0x10
	int ID_4_E5F66BB44E8FF9988F28C38D370137DF; // Offset: 0x38 // Size: 0x04
	int UnlockType_5_FA4BE0754F644CE090DF7388DEBEFF9F; // Offset: 0x3c // Size: 0x04
	struct FString UnlockDesc_6_1033BFE2476FB300BD448E86EEC3F4C7; // Offset: 0x40 // Size: 0x10
	int UnlockParam_7_550F64A04DD9EAED9924FF98E01B12EB; // Offset: 0x50 // Size: 0x04
	bool isShow_8_E33D5FA9430ABBA58D44C881AECC498E; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	struct FString Name_9_F16C3B4F4884A591B5397DA34A668E9D; // Offset: 0x58 // Size: 0x10
	int DefaultDisplay_10_4C6C4600503520F476BB02F609D7B029; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString ShowTime_11_59E76B406521918521EF4BAE0879B025; // Offset: 0x70 // Size: 0x10
	struct FString JumpUrl_12_1EA4330028ACEF420C12695609350CAC; // Offset: 0x80 // Size: 0x10
	struct FString DynamicIcon_13_3DAAD2C042DD4FDB2321F49103E48D6E; // Offset: 0x90 // Size: 0x10
	struct FString DynamicIconBig_14_7A4B57403D3E961F79C0C0D408D716B7; // Offset: 0xa0 // Size: 0x10
};

