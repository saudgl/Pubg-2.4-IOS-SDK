#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AkAudio.AkAmbSoundCheckpointRecord
// Size: 0x01 // Inherited bytes: 0x00
struct FAkAmbSoundCheckpointRecord {
	// Fields
	bool bCurrentlyPlaying; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AKAreaVolumeArray
// Size: 0x10 // Inherited bytes: 0x00
struct FAKAreaVolumeArray {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AKErrorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAKErrorInfo {
	// Fields
	char AKRESULT_ID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAKFunctionInfo> DetailInfo; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AKFunctionInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAKFunctionInfo {
	// Fields
	struct FString FunctionName; // Offset: 0x00 // Size: 0x10
	struct FString StrParam; // Offset: 0x10 // Size: 0x10
	int NumParam; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkPoly
// Size: 0x10 // Inherited bytes: 0x00
struct FAkPoly {
	// Fields
	struct UAkAcousticTexture* Texture; // Offset: 0x00 // Size: 0x08
	bool EnableSurface; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AudioOfflineVisualBeatData
// Size: 0x18 // Inherited bytes: 0x00
struct FAudioOfflineVisualBeatData {
	// Fields
	float BeatTime; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<float> Intensity; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 // Inherited bytes: 0x00
struct FAkAudioEventTrackKey {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x08 // Size: 0x08
	struct FString EventName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioEventSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioRTPCSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioRTPCSectionData
// Size: 0x80 // Inherited bytes: 0x00
struct FMovieSceneAkAudioRTPCSectionData {
	// Fields
	struct FString RTPCName; // Offset: 0x00 // Size: 0x10
	struct FRichCurve RTPCCurve; // Offset: 0x10 // Size: 0x70
};

