#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PlayerPrefs.PlayerPrefs_C
// Size: 0x64c // Inherited bytes: 0x28
struct UPlayerPrefs_C : USaveGame {
	// Fields
	int LoginCount; // Offset: 0x28 // Size: 0x04
	int LoginTime; // Offset: 0x2c // Size: 0x04
	bool FirstInLobby; // Offset: 0x30 // Size: 0x01
	bool GuestWarningAccepted; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	int YXXYRedPoint; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FString> NearByNewTipsList; // Offset: 0x38 // Size: 0x10
	struct TSet<struct FString> CloseLocationList; // Offset: 0x48 // Size: 0x50
	bool QuestionDone; // Offset: 0x98 // Size: 0x01
	bool ServerListClicked; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x2]; // Offset: 0x9a // Size: 0x02
	int MysteryLastTime; // Offset: 0x9c // Size: 0x04
	bool notFirstEnterMall; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x3]; // Offset: 0xa1 // Size: 0x03
	int CoprsShopLevelRedPoint; // Offset: 0xa4 // Size: 0x04
	struct TArray<int> StoreBoxList; // Offset: 0xa8 // Size: 0x10
	struct TMap<int, bool> HasSeeShopItemDict; // Offset: 0xb8 // Size: 0x50
	int NewsIds; // Offset: 0x108 // Size: 0x04
	int LobbyNoticeID; // Offset: 0x10c // Size: 0x04
	int UserAgreementAcceptedVersion; // Offset: 0x110 // Size: 0x04
	int PrivacyPolicyAcceptedVersion; // Offset: 0x114 // Size: 0x04
	int ClickTimeNotBind; // Offset: 0x118 // Size: 0x04
	int ClickTimeBind; // Offset: 0x11c // Size: 0x04
	struct TMap<struct FString, int> UidClickTimeNotBind; // Offset: 0x120 // Size: 0x50
	struct TMap<struct FString, int> UidClickTimeBind; // Offset: 0x170 // Size: 0x50
	struct TArray<int> StoreGiftBoxList; // Offset: 0x1c0 // Size: 0x10
	bool AchievementInitialized; // Offset: 0x1d0 // Size: 0x01
	char pad_0x1D1[0x3]; // Offset: 0x1d1 // Size: 0x03
	int Mystery2LastTime; // Offset: 0x1d4 // Size: 0x04
	struct TMap<struct FString, struct FString> ConfigStringMap; // Offset: 0x1d8 // Size: 0x50
	struct TMap<struct FString, int> ConfigIntMap; // Offset: 0x228 // Size: 0x50
	struct TMap<struct FString, float> ConfigFloatMap; // Offset: 0x278 // Size: 0x50
	struct TMap<struct FString, bool> ConfigBoolMap; // Offset: 0x2c8 // Size: 0x50
	struct TMap<struct FString, int> UidAirDropTime; // Offset: 0x318 // Size: 0x50
	int LoginFrequency; // Offset: 0x368 // Size: 0x04
	int CurrentDay; // Offset: 0x36c // Size: 0x04
	struct TArray<struct FString> SecondLanguage; // Offset: 0x370 // Size: 0x10
	struct FDateTime ShowSwitchSecondLanguageNextTime; // Offset: 0x380 // Size: 0x08
	struct TMap<struct FString, bool> HasClickUPassAct; // Offset: 0x388 // Size: 0x50
	struct TMap<struct FString, bool> HasClickInviteTeamAct; // Offset: 0x3d8 // Size: 0x50
	int CursorFaceInfoID; // Offset: 0x428 // Size: 0x04
	char pad_0x42C[0x4]; // Offset: 0x42c // Size: 0x04
	struct TMap<struct FString, struct FString> FaceInfoClickedIDAndTime; // Offset: 0x430 // Size: 0x50
	bool LanguagePromptState; // Offset: 0x480 // Size: 0x01
	bool HasTipLeagueGameSign; // Offset: 0x481 // Size: 0x01
	char pad_0x482[0x6]; // Offset: 0x482 // Size: 0x06
	struct TMap<struct FString, int> ClickTimeHalloweenVehicle; // Offset: 0x488 // Size: 0x50
	struct TMap<struct FString, bool> HasClickHalloweenExchange; // Offset: 0x4d8 // Size: 0x50
	struct FString primeClicktimestamp; // Offset: 0x528 // Size: 0x10
	bool isVNGadult; // Offset: 0x538 // Size: 0x01
	char pad_0x539[0x7]; // Offset: 0x539 // Size: 0x07
	struct TMap<struct FString, int> ClickTimeIceLucky; // Offset: 0x540 // Size: 0x50
	bool IsFirstTimeShowPrime; // Offset: 0x590 // Size: 0x01
	char pad_0x591[0x7]; // Offset: 0x591 // Size: 0x07
	struct TMap<struct FString, bool> HasCliickVehicleAcitivtyGuide; // Offset: 0x598 // Size: 0x50
	struct TMap<struct FString, int> ClickTimeAnniversary; // Offset: 0x5e8 // Size: 0x50
	int DecomposeTriggerTime; // Offset: 0x638 // Size: 0x04
	bool haveClickGuaranteeTips; // Offset: 0x63c // Size: 0x01
	char pad_0x63D[0x3]; // Offset: 0x63d // Size: 0x03
	int LastEnterExcitingTourTimeSec; // Offset: 0x640 // Size: 0x04
	bool IfHasShowExcitingTourTips; // Offset: 0x644 // Size: 0x01
	char pad_0x645[0x3]; // Offset: 0x645 // Size: 0x03
	int PrivacyPolicyPopupVersion; // Offset: 0x648 // Size: 0x04

	// Functions

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetPopupPolicyVersion
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPopupPolicyVersion(int PolicyVersion); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetGuaranteeFlag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetGuaranteeFlag(bool clicked); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetGuaranteeClickFlag
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetGuaranteeClickFlag(bool& clicked); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetDecomposeIndexTriggerTime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetDecomposeIndexTriggerTime(int& DecomposeTriggerTim); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetDecomposeIndexTriggerTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDecomposeIndexTriggerTime(int TimeStamp); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetClickTimeAnniversary
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClickTimeAnniversary(struct FString UId, int Time); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetClickTimeAnniversary
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetClickTimeAnniversary(struct FString UId, int& Value); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetCliickVehicleAcitivtyGuideExchange
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCliickVehicleAcitivtyGuideExchange(struct FString Key, bool& hasClick); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetCliickVehicleAcitivtyGuideExchange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCliickVehicleAcitivtyGuideExchange(struct FString Key, bool isClick); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetClickTimeIceLucky
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClickTimeIceLucky(int Time, struct FString UUID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetClickTimeIceLucky
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetClickTimeIceLucky(struct FString UUID, int& Value); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetIsVNGAdult
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsVNGAdult(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetIsFirstTimeShowPrime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetIsFirstTimeShowPrime(bool& IsfirstTimeOpenPrime); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetIsFirstTimeShowPrime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsFirstTimeShowPrime(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetHasClickHalloweenExchange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHasClickHalloweenExchange(bool isClick, struct FString UUID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetHasClickHalloweenExchange
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetHasClickHalloweenExchange(struct FString UUID, bool& hasClick); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetClickTimeHalloweenVehicle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClickTimeHalloweenVehicle(int Time, struct FString UUID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetClickTimeHalloweenVehicle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetClickTimeHalloweenVehicle(struct FString UUID, int& Value); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetFaceInfoClickedIDAndTime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetFaceInfoClickedIDAndTime(struct FString faceid, struct FString& TimeStamp); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetFaceInfoClickedIDAndTime
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetFaceInfoClickedIDAndTime(struct FString faceid); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetCursorFaceInfoID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetCursorFaceInfoID(int& CursorFaceInfoID); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetCursorFaceInfoID
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCursorFaceInfoID(int LastFace); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetHasClickInviteTeamAct
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHasClickInviteTeamAct(bool isClick, struct FString UUID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetHasClickInviteTeamAct
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetHasClickInviteTeamAct(struct FString UUID, bool& hasClick); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetHasClickUPassAct
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetHasClickUPassAct(struct FString UUID, bool& hasClick); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetHasClickUPassAct
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHasClickUPassAct(bool isClick, struct FString UUID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetShowSwitchSecondLanguageNextTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetShowSwitchSecondLanguageNextTime(struct FDateTime DateTime); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetShowSwitchSecondLanguageNextTime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetShowSwitchSecondLanguageNextTime(struct FDateTime& DateTime); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetLoginFrequency
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetLoginFrequency(int& loginfreq); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetLoginFrequency
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLoginFrequency(int CurrentDay); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetAirDropTime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetAirDropTime(struct FString UId, int& outAirDropTime); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetAirDropTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAirDropTime(int InTime, struct FString UId); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetMystery2LastTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetMystery2LastTime(int Time); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetStoreGiftBoxList
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetStoreGiftBoxList(struct TArray<int>& BoxList); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.GetClickTimeAboutBind
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetClickTimeAboutBind(struct FString UId, int& TimeNotBind, int& TimeBind); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetClickTimeAboutBind
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClickTimeAboutBind(int TimeNotBind, int TimeBind, struct FString UId); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.IsEqualCurID
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void IsEqualCurID(int ids, bool& Has); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetNewsIds
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetNewsIds(int ids); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetMallSeeDict
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetMallSeeDict(struct TMap<int, bool> Dict); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetStoreBosList
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetStoreBosList(struct TArray<int>& BoxList); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetFirstEnterMall
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFirstEnterMall(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetMysteryLastTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetMysteryLastTime(int Time); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.RejectUserAgreement
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RejectUserAgreement(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.AcceptUserAgreement
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AcceptUserAgreement(int newVersion); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.ServerListClick
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ServerListClick(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.HasCloseLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void HasCloseLocation(bool UId, bool& Has); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetCloseLocation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCloseLocation(bool CloseLocation, struct FString UId); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.HasNearByNewTips
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void HasNearByNewTips(struct FString UId, bool& Has); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetNearByNewTipsRead
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetNearByNewTipsRead(struct FString UId); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetYXXYRedPoint
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetYXXYRedPoint(int isRed); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.AcceptGuestWarning
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AcceptGuestWarning(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.RejectPolicy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RejectPolicy(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.AcceptPolicy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AcceptPolicy(int newVersion); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetFirstInLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFirstInLobby(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTime(int arg); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.ClearCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ClearCount(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SetCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCount(int Count); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.LoadData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct USaveGame* LoadData(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PlayerPrefs.PlayerPrefs_C.SaveData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SaveData(bool& SaveDataState); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)
};

