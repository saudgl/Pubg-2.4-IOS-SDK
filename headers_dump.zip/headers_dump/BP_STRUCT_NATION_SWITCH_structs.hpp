#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_NATION_SWITCH.BP_STRUCT_NATION_SWITCH
// Size: 0x04 // Inherited bytes: 0x00
struct FBP_STRUCT_NATION_SWITCH {
	// Fields
	bool NationRankSwitch_0_90EC58964A07013E18D9C4A0C24C6D72; // Offset: 0x00 // Size: 0x01
	bool NationAllSwitch_1_FFDC7E7C4281022AAE40A5B03DD5CE4A; // Offset: 0x01 // Size: 0x01
	bool NationBattleSwitch_2_DCD8C0084AAD46192D3CA48FD5FCC651; // Offset: 0x02 // Size: 0x01
	bool Updated_3_5B3974684ED721353E91AA966D7347A5; // Offset: 0x03 // Size: 0x01
};

