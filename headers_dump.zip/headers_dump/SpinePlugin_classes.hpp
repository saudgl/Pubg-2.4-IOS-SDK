#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SpinePlugin.SpineAtlasAsset
// Size: 0x58 // Inherited bytes: 0x28
struct USpineAtlasAsset : UObject {
	// Fields
	struct TArray<struct UTexture2D*> atlasPages; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FString rawData; // Offset: 0x40 // Size: 0x10
	struct FName atlasFileName; // Offset: 0x50 // Size: 0x08
};

// Object Name: Class SpinePlugin.SpineBoneDriverComponent
// Size: 0x300 // Inherited bytes: 0x2d0
struct USpineBoneDriverComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x2d0 // Size: 0x08
	struct FString BoneName; // Offset: 0x2d8 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x2e8 // Size: 0x01
	bool UsePosition; // Offset: 0x2e9 // Size: 0x01
	bool UseRotation; // Offset: 0x2ea // Size: 0x01
	bool UseScale; // Offset: 0x2eb // Size: 0x01
	char pad_0x2EC[0x14]; // Offset: 0x2ec // Size: 0x14

	// Functions

	// Object Name: Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform
	// Flags: [Final|Native|Protected]
	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton); // Offset: 0x1022be65c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class SpinePlugin.SpineBoneFollowerComponent
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct USpineBoneFollowerComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x2d0 // Size: 0x08
	struct FString BoneName; // Offset: 0x2d8 // Size: 0x10
	bool UseComponentTransform; // Offset: 0x2e8 // Size: 0x01
	bool UsePosition; // Offset: 0x2e9 // Size: 0x01
	bool UseRotation; // Offset: 0x2ea // Size: 0x01
	bool UseScale; // Offset: 0x2eb // Size: 0x01
	char pad_0x2EC[0x4]; // Offset: 0x2ec // Size: 0x04
};

// Object Name: Class SpinePlugin.TrackEntry
// Size: 0x90 // Inherited bytes: 0x28
struct UTrackEntry : UObject {
	// Fields
	struct FScriptMulticastDelegate animationStart; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x58 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x68 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackTime(float trackTime); // Offset: 0x1022bf6e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrackEnd(float trackEnd); // Offset: 0x1022bf66c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x1022bf5f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixTime(float mixTime); // Offset: 0x1022bf574 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMixDuration(float mixDuration); // Offset: 0x1022bf4f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLoop(bool Loop); // Offset: 0x1022bf474 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.SetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventThreshold(float eventThreshold); // Offset: 0x1022bf3f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDrawOrderThreshold(float drawOrderThreshold); // Offset: 0x1022bf37c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelay(float Delay); // Offset: 0x1022bf300 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachmentThreshold(float attachmentThreshold); // Offset: 0x1022bf284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationStart(float animationStart); // Offset: 0x1022bf208 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationLast(float animationLast); // Offset: 0x1022bf18c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimationEnd(float animationEnd); // Offset: 0x1022bf110 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlpha(float Alpha); // Offset: 0x1022bf094 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.isValidAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool isValidAnimation(); // Offset: 0x1022bf070 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackTime(); // Offset: 0x1022bf03c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetTrackIndex(); // Offset: 0x1022bf008 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTrackEnd(); // Offset: 0x1022befd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x1022befa0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixTime(); // Offset: 0x1022bef6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMixDuration(); // Offset: 0x1022bef38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetLoop(); // Offset: 0x1022bef04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.TrackEntry.GetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetEventThreshold(); // Offset: 0x1022beed0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDrawOrderThreshold(); // Offset: 0x1022bee9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetDelay(); // Offset: 0x1022bee68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAttachmentThreshold(); // Offset: 0x1022bee34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationStart(); // Offset: 0x1022bee00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getAnimationName(); // Offset: 0x1022bed9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationLast(); // Offset: 0x1022bed68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAnimationEnd(); // Offset: 0x1022bed34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(); // Offset: 0x1022bed00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.TrackEntry.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetAlpha(); // Offset: 0x1022beccc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class SpinePlugin.SpineSkeletonComponent
// Size: 0x168 // Inherited bytes: 0x110
struct USpineSkeletonComponent : UActorComponent {
	// Fields
	struct USpineAtlasAsset* Atlas; // Offset: 0x110 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x118 // Size: 0x08
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // Offset: 0x130 // Size: 0x10
	char pad_0x140[0x28]; // Offset: 0x140 // Size: 0x28

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x1022c1a88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x1022c1a74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x1022c1a60 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSlotColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSlotColor(struct FString SlotName, struct FColor Color); // Offset: 0x1022c1968 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool SetSkins(struct TArray<struct FString>& SkinNames); // Offset: 0x1022c18b0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x1022c17e4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x1022c1768 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x1022c16ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position); // Offset: 0x1022c1608 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x1022c15f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName); // Offset: 0x1022c14b0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x1022c13e4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x1022c1318 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x1022c124c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x1022c1180 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x1022c10d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x1022c1030 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x1022c0ffc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x1022c0fc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct FTransform GetBoneWorldTransform(struct FString BoneName); // Offset: 0x1022c0f08 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x1022c0e60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x1022c0db8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x1022c0cec // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class SpinePlugin.SpineSkeletonAnimationComponent
// Size: 0x268 // Inherited bytes: 0x168
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent {
	// Fields
	struct FScriptMulticastDelegate animationStart; // Offset: 0x168 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x178 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x188 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x198 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x1a8 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x1b8 // Size: 0x10
	struct FString PreviewAnimation; // Offset: 0x1c8 // Size: 0x10
	struct FString PreviewSkin; // Offset: 0x1d8 // Size: 0x10
	char pad_0x1E8[0x8]; // Offset: 0x1e8 // Size: 0x08
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x1f0 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x240 // Size: 0x01
	char pad_0x241[0x27]; // Offset: 0x241 // Size: 0x27

	// Functions

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x1022c07d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x1022c0718 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration); // Offset: 0x1022c0650 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x1022c05cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x1022c0478 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x1022c0444 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int TrackIndex); // Offset: 0x1022c03b8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x1022c03a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int TrackIndex); // Offset: 0x1022c0328 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay); // Offset: 0x1022c0228 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x1022c0094 // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class SpinePlugin.SpineSkeletonDataAsset
// Size: 0xf8 // Inherited bytes: 0x28
struct USpineSkeletonDataAsset : UObject {
	// Fields
	float DefaultMix; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FSpineAnimationStateMixData> MixData; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> Bones; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> Slots; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FString> Skins; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FString> Animations; // Offset: 0x70 // Size: 0x10
	struct TArray<struct FString> Events; // Offset: 0x80 // Size: 0x10
	struct TArray<char> rawData; // Offset: 0x90 // Size: 0x10
	struct FName skeletonDataFileName; // Offset: 0xa0 // Size: 0x08
	char pad_0xA8[0x50]; // Offset: 0xa8 // Size: 0x50
};

// Object Name: Class SpinePlugin.SpineSkeletonRendererComponent
// Size: 0xbb0 // Inherited bytes: 0x7f0
struct USpineSkeletonRendererComponent : UProceduralMeshComponent {
	// Fields
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x7f0 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x7f8 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x800 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x808 // Size: 0x08
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x810 // Size: 0x10
	char pad_0x820[0x50]; // Offset: 0x820 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x870 // Size: 0x10
	char pad_0x880[0x50]; // Offset: 0x880 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x8d0 // Size: 0x10
	char pad_0x8E0[0x50]; // Offset: 0x8e0 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x930 // Size: 0x10
	char pad_0x940[0x50]; // Offset: 0x940 // Size: 0x50
	float DepthOffset; // Offset: 0x990 // Size: 0x04
	char pad_0x994[0x4]; // Offset: 0x994 // Size: 0x04
	struct FName TextureParameterName; // Offset: 0x998 // Size: 0x08
	struct FLinearColor Color; // Offset: 0x9a0 // Size: 0x10
	bool bCreateCollision; // Offset: 0x9b0 // Size: 0x01
	char pad_0x9B1[0x1ff]; // Offset: 0x9b1 // Size: 0x1ff
};

// Object Name: Class SpinePlugin.SpineWidget
// Size: 0x6a8 // Inherited bytes: 0x100
struct USpineWidget : UWidget {
	// Fields
	float Scale; // Offset: 0x100 // Size: 0x04
	char pad_0x104[0x4]; // Offset: 0x104 // Size: 0x04
	struct FString InitialSkin; // Offset: 0x108 // Size: 0x10
	struct USpineAtlasAsset* Atlas; // Offset: 0x118 // Size: 0x08
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x120 // Size: 0x08
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x128 // Size: 0x08
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x130 // Size: 0x08
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x138 // Size: 0x08
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x140 // Size: 0x08
	struct FName TextureParameterName; // Offset: 0x148 // Size: 0x08
	float DepthOffset; // Offset: 0x150 // Size: 0x04
	struct FLinearColor Color; // Offset: 0x154 // Size: 0x10
	char pad_0x164[0x4]; // Offset: 0x164 // Size: 0x04
	struct FSlateBrush Brush; // Offset: 0x168 // Size: 0xb8
	struct FScriptMulticastDelegate BeforeUpdateWorldTransform; // Offset: 0x220 // Size: 0x10
	struct FScriptMulticastDelegate AfterUpdateWorldTransform; // Offset: 0x230 // Size: 0x10
	struct FScriptMulticastDelegate animationStart; // Offset: 0x240 // Size: 0x10
	struct FScriptMulticastDelegate AnimationInterrupt; // Offset: 0x250 // Size: 0x10
	struct FScriptMulticastDelegate AnimationEvent; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate AnimationComplete; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate animationEnd; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate AnimationDispose; // Offset: 0x290 // Size: 0x10
	char pad_0x2A0[0x40]; // Offset: 0x2a0 // Size: 0x40
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x2e0 // Size: 0x10
	char pad_0x2F0[0x50]; // Offset: 0x2f0 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x340 // Size: 0x10
	char pad_0x350[0x50]; // Offset: 0x350 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x3a0 // Size: 0x10
	char pad_0x3B0[0x50]; // Offset: 0x3b0 // Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x400 // Size: 0x10
	char pad_0x410[0x240]; // Offset: 0x410 // Size: 0x240
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x650 // Size: 0x50
	bool bAutoPlaying; // Offset: 0x6a0 // Size: 0x01
	char pad_0x6A1[0x7]; // Offset: 0x6a1 // Size: 0x07

	// Functions

	// Object Name: Function SpinePlugin.SpineWidget.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateWorldTransform(); // Offset: 0x1022c39a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Tick(float DeltaTime, bool CallDelegates); // Offset: 0x1022c38e4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToSetupPose(); // Offset: 0x1022c38d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeScale(float TimeScale); // Offset: 0x1022c3854 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotsToSetupPose(); // Offset: 0x1022c3840 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool SetSkins(struct TArray<struct FString>& SkinNames); // Offset: 0x1022c3788 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetSkin(struct FString SkinName); // Offset: 0x1022c36bc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleY(float ScaleY); // Offset: 0x1022c3640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScaleX(float ScaleX); // Offset: 0x1022c35c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetScale
	// Flags: [Native|Protected|BlueprintCallable]
	void SetScale(float InScale); // Offset: 0x1022c3540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Offset: 0x1022c3480 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function SpinePlugin.SpineWidget.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetEmptyAnimation(int TrackIndex, float mixDuration); // Offset: 0x1022c33b8 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetColor
	// Flags: [Native|Protected|HasDefaults|BlueprintCallable]
	void SetColor(struct FLinearColor InColor); // Offset: 0x1022c3334 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBonesToSetupPose(); // Offset: 0x1022c3320 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlay(bool bInAutoPlays); // Offset: 0x1022c329c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SpinePlugin.SpineWidget.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetAttachment(struct FString SlotName, struct FString AttachmentName); // Offset: 0x1022c3158 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SpinePlugin.SpineWidget.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* SetAnimation(int TrackIndex, struct FString AnimationName, bool Loop); // Offset: 0x1022c3004 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function SpinePlugin.SpineWidget.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSlot(struct FString SlotName); // Offset: 0x1022c2f38 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasSkin(struct FString SkinName); // Offset: 0x1022c2e6c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasBone(struct FString BoneName); // Offset: 0x1022c2da0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnimation(struct FString AnimationName); // Offset: 0x1022c2cd4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function SpinePlugin.SpineWidget.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetTimeScale(); // Offset: 0x1022c2ca0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSlots(struct TArray<struct FString>& Slots); // Offset: 0x1022c2bf8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetSkins(struct TArray<struct FString>& Skins); // Offset: 0x1022c2b50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleY(); // Offset: 0x1022c2b1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScaleX(); // Offset: 0x1022c2ae8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetScale
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	float GetScale(); // Offset: 0x1022c2ab4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* GetCurrent(int TrackIndex); // Offset: 0x1022c2a28 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetColor
	// Flags: [Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetColor(); // Offset: 0x1022c29e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetBones(struct TArray<struct FString>& Bones); // Offset: 0x1022c2940 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void GetAnimations(struct TArray<struct FString>& Animations); // Offset: 0x1022c2898 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SpinePlugin.SpineWidget.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	float getAnimationDuration(struct FString AnimationName); // Offset: 0x1022c27cc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTracks(); // Offset: 0x1022c27b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SpinePlugin.SpineWidget.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearTrack(int TrackIndex); // Offset: 0x1022c273c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SpinePlugin.SpineWidget.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddEmptyAnimation(int TrackIndex, float mixDuration, float Delay); // Offset: 0x1022c263c // Return & Params: Num(4) Size(0x18)

	// Object Name: Function SpinePlugin.SpineWidget.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTrackEntry* AddAnimation(int TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Offset: 0x1022c24a8 // Return & Params: Num(5) Size(0x28)
};

