#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptBlueprintGeneratedClass bp_global.bp_global_C
// Size: 0x510 // Inherited bytes: 0x428
struct Abp_global_C : ALuaClassObj {
	// Fields
	struct UScriptContextComponent* Generated_ScriptContext; // Offset: 0x428 // Size: 0x08
	bool BP_EUChatRestriction; // Offset: 0x430 // Size: 0x01
	char pad_0x431[0x3]; // Offset: 0x431 // Size: 0x03
	int BP_Platform; // Offset: 0x434 // Size: 0x04
	bool BP_IOS_CHECK; // Offset: 0x438 // Size: 0x01
	bool BP_IS_EXTERNAL_CHANNEL; // Offset: 0x439 // Size: 0x01
	bool BP_HadPlayAnimation; // Offset: 0x43a // Size: 0x01
	bool BP_Global_IsAnniversaryNeedShow; // Offset: 0x43b // Size: 0x01
	bool BP_Global_AndroidKey_IsValid; // Offset: 0x43c // Size: 0x01
	char pad_0x43D[0x3]; // Offset: 0x43d // Size: 0x03
	struct FString BP_Global_Url; // Offset: 0x440 // Size: 0x10
	struct FString BP_GEM_REPORT_SUBEVENT; // Offset: 0x450 // Size: 0x10
	int BP_BA_REASON; // Offset: 0x460 // Size: 0x04
	char pad_0x464[0x4]; // Offset: 0x464 // Size: 0x04
	struct FString BP_GEM_REPORT_PARA2; // Offset: 0x468 // Size: 0x10
	int BP_ChatBan; // Offset: 0x478 // Size: 0x04
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct FString BP_GLOBAL_USE_ITEM; // Offset: 0x480 // Size: 0x10
	struct FBP_STRUCT_NATION_SWITCH BP_STRUCT_NATION_SWITCH; // Offset: 0x490 // Size: 0x04
	int BP_BA_BUTTON_TYPE; // Offset: 0x494 // Size: 0x04
	int BP_CurSceneCameraIndex; // Offset: 0x498 // Size: 0x04
	int BP_Global_Cur_Lobby_Skin_Id; // Offset: 0x49c // Size: 0x04
	bool BP_Global_IsResidentEvilNeedShow; // Offset: 0x4a0 // Size: 0x01
	bool BP_Global_IsChristmasNeedShow; // Offset: 0x4a1 // Size: 0x01
	bool BP_IsAppleAudit; // Offset: 0x4a2 // Size: 0x01
	char pad_0x4A3[0x1]; // Offset: 0x4a3 // Size: 0x01
	int BP_Share_Platform; // Offset: 0x4a4 // Size: 0x04
	bool BP_CHECK_MENU_OPEN_RESULT; // Offset: 0x4a8 // Size: 0x01
	bool BP_ShouldRequestChatPrivacy; // Offset: 0x4a9 // Size: 0x01
	char pad_0x4AA[0x2]; // Offset: 0x4aa // Size: 0x02
	int BP_StartUpType; // Offset: 0x4ac // Size: 0x04
	int BP_GlobalSwitchCameraIndex; // Offset: 0x4b0 // Size: 0x04
	int BP_played_cg; // Offset: 0x4b4 // Size: 0x04
	int BP_Global_PreviewItemId; // Offset: 0x4b8 // Size: 0x04
	char pad_0x4BC[0x4]; // Offset: 0x4bc // Size: 0x04
	struct FString BP_Global_TouchTitleString; // Offset: 0x4c0 // Size: 0x10
	int BP_Global_AvatarPreviewTarget; // Offset: 0x4d0 // Size: 0x04
	int BP_CHECK_MENU_OPEN_ID; // Offset: 0x4d4 // Size: 0x04
	struct FString BP_GEM_REPORT_PARA1; // Offset: 0x4d8 // Size: 0x10
	struct FString BP_Global_SelfUID; // Offset: 0x4e8 // Size: 0x10
	int BP_Global_BackpackAvatarPreviewID; // Offset: 0x4f8 // Size: 0x04
	bool BP_Global_AdvertiseNeedShowtask; // Offset: 0x4fc // Size: 0x01
	char pad_0x4FD[0x3]; // Offset: 0x4fd // Size: 0x03
	int BP_GameGender; // Offset: 0x500 // Size: 0x04
	char pad_0x504[0x4]; // Offset: 0x504 // Size: 0x04
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x508 // Size: 0x08

	// Functions

	// Object Name: Function bp_global.bp_global_C.EventFetchInfo_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchInfo
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchInfo(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetInfo_Push_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSetInfo_Push
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSetInfo_Push(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSlapJumpUrl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSlapJumpUrl_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSlapJumpUrl
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSlapJumpUrl(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchNationSwitch_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventFetchNationSwitch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventFetchNationSwitch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendClickGemReport_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendClickGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendClickGemReport(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickLobbyEventGemReport_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventClickLobbyEventGemReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventClickLobbyEventGemReport(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendBAReport_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendBAReport_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSendBAReport
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSendBAReport(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalCloseItemTips_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalCloseItemTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalCloseItemTips(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatQQStartup_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatQQStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatQQStartup(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatIconTips_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatIconTips
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatIconTips(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatWXStartup_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventShowPlatWXStartup
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventShowPlatWXStartup(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalUseItem_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGlobalUseItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGlobalUseItem(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSwitchLobbySkinCompleted_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSwitchLobbySkinCompleted_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventSwitchLobbySkinCompleted
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventSwitchLobbySkinCompleted(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventAndroidQuitGame_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventAndroidQuitGame
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventAndroidQuitGame(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventJumpUrl_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventJumpUrl_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventJumpUrl
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventJumpUrl(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckEUChatRestriction_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckEUChatRestriction_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckEUChatRestriction
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckEUChatRestriction(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewPress_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewPress_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewPress
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewPress(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckIfMenuOpen_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventCheckIfMenuOpen
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventCheckIfMenuOpen(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewClick_NoFetch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewClick_NoFetch(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.EventGotoItemPreviewClick
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventGotoItemPreviewClick(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function bp_global.bp_global_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

