#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CommonUIWidget.CommonInputBox
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UCommonInputBox : ULuaUserWidget {
};

// Object Name: Class CommonUIWidget.CommonPopupBox
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UCommonPopupBox : ULuaUserWidget {
};

// Object Name: Class CommonUIWidget.CommonSearchBox
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UCommonSearchBox : ULuaUserWidget {
};

