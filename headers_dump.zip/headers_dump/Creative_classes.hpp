#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Creative.CreativeAbilitySystemComponent
// Size: 0x1270 // Inherited bytes: 0x11b8
struct UCreativeAbilitySystemComponent : USAbilitySystemComponent {
	// Fields
	char pad_0x11B8[0x48]; // Offset: 0x11b8 // Size: 0x48
	float BuildDistance; // Offset: 0x1200 // Size: 0x04
	char pad_0x1204[0x20]; // Offset: 0x1204 // Size: 0x20
	bool bOpenLandPosCheckDebug; // Offset: 0x1224 // Size: 0x01
	bool bSnapTransValid; // Offset: 0x1225 // Size: 0x01
	bool bSnapGridEnable; // Offset: 0x1226 // Size: 0x01
	char pad_0x1227[0x1]; // Offset: 0x1227 // Size: 0x01
	struct FRotator BuildingRotation; // Offset: 0x1228 // Size: 0x0c
	struct FRotator RelativeRotation; // Offset: 0x1234 // Size: 0x0c
	struct FVector RelativeLocation; // Offset: 0x1240 // Size: 0x0c
	struct FVector BuildingScale; // Offset: 0x124c // Size: 0x0c
	struct FVector RelativeScale; // Offset: 0x1258 // Size: 0x0c
	char pad_0x1264[0xc]; // Offset: 0x1264 // Size: 0x0c

	// Functions

	// Object Name: Function Creative.CreativeAbilitySystemComponent.UpdateGhostBuildingTransform
	// Flags: [Final|Native|Private]
	void UpdateGhostBuildingTransform(); // Offset: 0x1021c63b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetSnapTargetTransform
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void SetSnapTargetTransform(struct FTransform& SnapTargetTransform); // Offset: 0x1021c6310 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformScale
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformScale(float X, float Y, float Z); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformRotation
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformRotation(float Roll, float Yaw, float Pitch); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.SetLuaGhostBuildingTransformLocation
	// Flags: [Event|Public|BlueprintEvent]
	void SetLuaGhostBuildingTransformLocation(float X, float Y, float Z); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.ReceiveGetSnapTargetTransform
	// Flags: [Event|Public|BlueprintEvent]
	bool ReceiveGetSnapTargetTransform(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetSnappedLocAxis
	// Flags: [Event|Public|BlueprintEvent]
	float GetSnappedLocAxis(float Value); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetSetupBuildingID
	// Flags: [Event|Public|BlueprintEvent]
	int GetSetupBuildingID(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetGhostBuildingTransform
	// Flags: [Final|Native|Public|HasDefaults]
	struct FTransform GetGhostBuildingTransform(); // Offset: 0x1021c62c8 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Creative.CreativeAbilitySystemComponent.GetBuildingInstanceID
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetBuildingInstanceID(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeActorInteractionComponent
// Size: 0x218 // Inherited bytes: 0x1d8
struct UCreativeModeActorInteractionComponent : ULuaActorComponent {
	// Fields
	bool bCrossHairCheckEnabled; // Offset: 0x1d1 // Size: 0x01
	float CrossHairCheckCD; // Offset: 0x1d4 // Size: 0x04
	bool bSectorCheckEnabled; // Offset: 0x1d8 // Size: 0x01
	float SectorCheckCD; // Offset: 0x1dc // Size: 0x04
	bool bTransformCrossHairCheckEnabled; // Offset: 0x1e0 // Size: 0x01
	char pad_0x1E3[0x1]; // Offset: 0x1e3 // Size: 0x01
	float TransformCrossHairCheckCD; // Offset: 0x1e4 // Size: 0x04
	char pad_0x1E8[0x30]; // Offset: 0x1e8 // Size: 0x30

	// Functions

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SortCanEditParamsObjs
	// Flags: [Event|Protected|BlueprintEvent]
	void SortCanEditParamsObjs(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SetCrossHairTransformObj
	// Flags: [Event|Protected|BlueprintEvent]
	void SetCrossHairTransformObj(struct UObject* uTargetActor); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.SetCrossHairSelectedObj
	// Flags: [Event|Protected|BlueprintEvent]
	void SetCrossHairSelectedObj(struct UObject* uTargetActor); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckIntervalCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckIntervalCfg(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckDistance
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckDistance(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetSectorCheckAngle
	// Flags: [Event|Protected|BlueprintEvent]
	float GetSectorCheckAngle(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetPlayerHalfHeight
	// Flags: [Event|Protected|BlueprintEvent]
	float GetPlayerHalfHeight(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetCrossHairCheckIntervalCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetCrossHairCheckIntervalCfg(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.GetCrossHairCheckDistanceCfg
	// Flags: [Event|Protected|BlueprintEvent]
	float GetCrossHairCheckDistanceCfg(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.ClearCanEditParamsObjs
	// Flags: [Event|Protected|BlueprintEvent]
	void ClearCanEditParamsObjs(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeActorInteractionComponent.AddCanEditObject
	// Flags: [Event|Protected|BlueprintEvent]
	void AddCanEditObject(struct UObject* uCanEditObject, float Angle, float Distance); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x10)
};

// Object Name: Class Creative.CreativeModeManagerBase
// Size: 0x108 // Inherited bytes: 0x108
struct UCreativeModeManagerBase : USTExtraManagerBase {
};

// Object Name: Class Creative.CreativeModeAssetManager
// Size: 0x160 // Inherited bytes: 0x108
struct UCreativeModeAssetManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x108[0x8]; // Offset: 0x108 // Size: 0x08
	struct TMap<int, struct FCreativeObjectStaticMeshConfigInfo> AssetStaticMeshConfigMap; // Offset: 0x110 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeAssetManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeAssetManager.ReceiveInitAssetStaticMeshConfig
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveInitAssetStaticMeshConfig(int AssetId); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeAssetManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Public]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1021c7280 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeAssetManager.GetAssetLandGroundType
	// Flags: [Event|Public|BlueprintEvent]
	int GetAssetLandGroundType(int AssetId); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Creative.CreativeModeAssetManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeAssetManager* Get(struct UObject* WorldContext); // Offset: 0x1021c7204 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeAssetManager.AddAssetStaticMeshConfig
	// Flags: [Final|Native|Public|HasOutParms]
	void AddAssetStaticMeshConfig(int AssetId, struct FCreativeObjectStaticMeshConfigInfo& ObjectStaticMeshConfigInfo); // Offset: 0x1021c7120 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Creative.CreativeModeBackpackUtils
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeBackpackUtils : UBackpackUtils {
	// Functions

	// Object Name: Function Creative.CreativeModeBackpackUtils.ResCanAddToBackpackNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int ResCanAddToBackpackNum(struct UBackpackComponent* BackpackComponent, int resID, int AddNum); // Offset: 0x1021c7598 // Return & Params: Num(4) Size(0x14)
};

// Object Name: Class Creative.CreativeModeBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetStaticMeshMobility
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetStaticMeshMobility(struct UStaticMeshComponent* StaticMeshComponent, enum class EComponentMobility NewMobility); // Offset: 0x1021c8fb8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetSpeedOverLimit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetSpeedOverLimit(struct AActor* Actor); // Offset: 0x1021c8f44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetInstanceValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetInstanceValue(struct UObject* WorldContextObject, struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x1021c8d60 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SetEditorActorTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool SetEditorActorTransform(struct UObject* WorldContextObject, struct FString InstanceID, struct FTransform NewTransform); // Offset: 0x1021c8bfc // Return & Params: Num(4) Size(0x51)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.SaveAssetStringToFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveAssetStringToFile(struct FString String, struct FString Filename); // Offset: 0x1021c8b18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.ProjectSavedDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ProjectSavedDir(); // Offset: 0x1021c8ab4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.MinAreaRectangle
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void MinAreaRectangle(struct UObject* WorldContextObject, struct TArray<struct FVector>& InPoints, struct FVector& SampleSurfaceNormal, struct FVector& OutRectCenter, struct FRotator& OutRectRotation, float& OutRectLengthX, float& OutRectLengthY, bool bDebugDraw, struct TArray<int>& PolyVertIndices); // Offset: 0x1021c8774 // Return & Params: Num(9) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.LoadAssetFileToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LoadAssetFileToString(struct FString Filename); // Offset: 0x1021c86b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.IgnoreClientMovementErrorChecksAndCorrection
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IgnoreClientMovementErrorChecksAndCorrection(struct ACharacter* Charcter, bool bIsIgnore); // Offset: 0x1021c85fc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetObjectMap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TMap<struct FString, struct UObject*> GetObjectMap(struct UObject* WorldContextObject); // Offset: 0x1021c8558 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetGameTypeAsString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameTypeAsString(enum class ECreativeModeGameType GameType); // Offset: 0x1021c84b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GetActorMeshBoundsByTag
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetActorMeshBoundsByTag(struct AActor* Actor, struct FVector& Origin, struct FVector& BoxExtent, struct FString IgnoreTag, struct FString IncludeTag); // Offset: 0x1021c82f4 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.GenerateGuid
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GenerateGuid(); // Offset: 0x1021c8290 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLine(struct FPaintContext& InContext, struct FVector2D& Start, struct FVector2D& End, struct FLinearColor& LineColor, int LayerOffset, float LineThickness, bool bAntiAlias); // Offset: 0x1021c8064 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawGrids
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawGrids(struct FPaintContext& InContext, float CellSize, int CellCountX, int CellCountY, float PosOffsetX, float PosOffsetY, struct FLinearColor& LineColor, float LineThickness, bool bAntiAlias, int LayerOffset); // Offset: 0x1021c7dac // Return & Params: Num(10) Size(0x60)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DrawGridCell
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawGridCell(struct FPaintContext& InContext, float CellSize, int CellIndexX, int CellIndexY, float PosOffsetX, float PosOffsetY, struct FLinearColor& LineColor, int LayerOffset); // Offset: 0x1021c7b74 // Return & Params: Num(8) Size(0x58)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString DestroyInstance(struct UObject* WorldContextObject, struct FString InstanceID); // Offset: 0x1021c7a50 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeBlueprintLibrary.BoxOverlapActors
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool BoxOverlapActors(struct UObject* WorldContextObject, struct FVector BoxPos, struct FVector BoxExtent, struct TArray<int>& ObjectTypes, struct UObject* ActorClassFilter, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct AActor*>& OutActors); // Offset: 0x1021c77dc // Return & Params: Num(8) Size(0x59)
};

// Object Name: Class Creative.CreativeModeCheatManager
// Size: 0x148 // Inherited bytes: 0x148
struct UCreativeModeCheatManager : UGMCheatManager {
	// Functions

	// Object Name: Function Creative.CreativeModeCheatManager.SetInstanceValue
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void SetInstanceValue(struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x1021c977c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeCheatManager.SetCurrentGameType
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1021c9700 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeCheatManager.DestroyInstance
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	void DestroyInstance(struct FString InstanceID); // Offset: 0x1021c9644 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeLiteComponent
// Size: 0x100 // Inherited bytes: 0x40
struct UCreativeModeLiteComponent : ULiteComponent {
	// Fields
	char pad_0x40[0x60]; // Offset: 0x40 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0xa0 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0xf0 // Size: 0x10
};

// Object Name: Class Creative.CreativeModeGameModeBaseComponent
// Size: 0x110 // Inherited bytes: 0x100
struct UCreativeModeGameModeBaseComponent : UCreativeModeLiteComponent {
	// Fields
	enum class ECreativeModeGameType GameType; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct UCreativeModeGameStateBaseComponent* GameStateComponent; // Offset: 0x108 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.SetGameStateComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameStateComponent(struct UCreativeModeGameStateBaseComponent* NewGameStateComponent); // Offset: 0x1021cb378 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.ReceivePostInitializeComponents
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostInitializeComponents(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.GetGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetGameType(); // Offset: 0x1021cb35c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ACreativeModeGameMode* GetGameMode(); // Offset: 0x1021cb328 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameModeBaseComponent.FindPlayerStartOverride
	// Flags: [Event|Public|BlueprintEvent]
	struct AActor* FindPlayerStartOverride(struct AController* Player, struct FString IncomingName); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class Creative.CreativeModeEditorModeComponent
// Size: 0x110 // Inherited bytes: 0x110
struct UCreativeModeEditorModeComponent : UCreativeModeGameModeBaseComponent {
};

// Object Name: Class Creative.CreativeModeEditorObject
// Size: 0x528 // Inherited bytes: 0x488
struct ACreativeModeEditorObject : ALuaActor {
	// Fields
	char pad_0x488[0x18]; // Offset: 0x488 // Size: 0x18
	enum class ECreativeModeActorState ActorState; // Offset: 0x4a0 // Size: 0x01
	char pad_0x4A1[0x7]; // Offset: 0x4a1 // Size: 0x07
	struct UMaterialInstance* PrefabMaterial; // Offset: 0x4a8 // Size: 0x08
	struct UMaterialInstance* PrefabCollisionMaterial; // Offset: 0x4b0 // Size: 0x08
	struct UMaterialInstance* InstanceSelectedMaterial; // Offset: 0x4b8 // Size: 0x08
	struct FEditorObjectLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x4c0 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x518 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeEditorObject.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021ca278 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeEditorObject.ShowSelectedEffect
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ShowSelectedEffect(bool ShowEff, struct FLinearColor OutlineColor, float OutlineThickness); // Offset: 0x1021ca174 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Creative.CreativeModeEditorObject.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x1021ca0f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.SetActorState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetActorState(enum class ECreativeModeActorState NewState); // Offset: 0x1021ca074 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021c9ff8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceivePostBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostBeginPlay(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeEditorObject.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeEditorObject.OnRepActorStateOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepActorStateOverride(enum class ECreativeModeActorState NewState); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.OnRep_ActorState
	// Flags: [Final|Native|Public]
	void OnRep_ActorState(enum class ECreativeModeActorState LastState); // Offset: 0x1021c9f7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.IsDedicatedServer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDedicatedServer(); // Offset: 0x1021c9f48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.HasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAuthority(); // Offset: 0x1021c9f14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.GetActorState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeActorState GetActorState(); // Offset: 0x1021c9ee0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeEditorObject.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x1021c9e54 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeEditorObject.CanEditParameters
	// Flags: [Event|Public|BlueprintEvent]
	bool CanEditParameters(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativeModeGameStateBaseComponent
// Size: 0x108 // Inherited bytes: 0x100
struct UCreativeModeGameStateBaseComponent : UCreativeModeLiteComponent {
	// Fields
	enum class ECreativeModeGameType GameType; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07

	// Functions

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.ReceivePostInitializeComponents
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePostInitializeComponents(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetPlayState
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x1021d0a80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetGameType(); // Offset: 0x1021d0a64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateBaseComponent.GetGameState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ACreativeModeGameState* GetGameState(); // Offset: 0x1021d0a30 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.CreativeModeEditorStateComponent
// Size: 0x108 // Inherited bytes: 0x108
struct UCreativeModeEditorStateComponent : UCreativeModeGameStateBaseComponent {
};

// Object Name: Class Creative.CreativeModeGameMode
// Size: 0x2450 // Inherited bytes: 0x2370
struct ACreativeModeGameMode : ABattleRoyaleGameModeTeam {
	// Fields
	struct UCreativeModeGameModeBaseComponent* CurrentModeComponent; // Offset: 0x2370 // Size: 0x08
	struct TArray<struct UCreativeModeGameModeBaseComponent*> GameModeComponentClassArray; // Offset: 0x2378 // Size: 0x10
	struct UCreativeModeGameModeComponent* GameModeComponentClass; // Offset: 0x2388 // Size: 0x08
	struct TMap<struct FString, struct FGameModeParam> MapPlaneRouteConfigs; // Offset: 0x2390 // Size: 0x50
	enum class ECreativeModeGameType EditorStartupGameType; // Offset: 0x23e0 // Size: 0x01
	char pad_0x23E1[0x7]; // Offset: 0x23e1 // Size: 0x07
	struct FGameModeLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x23e8 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x2440 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameMode.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021cade0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x1021cad5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.SetItemGenerate
	// Flags: [Native|Event|Public|BlueprintEvent]
	void SetItemGenerate(bool bIsOpen); // Offset: 0x1021cacd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.SetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1021cac54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameMode.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021cabd8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameMode.GetCurrentModeComponent
	// Flags: [Final|Native|Public]
	struct UCreativeModeGameModeBaseComponent* GetCurrentModeComponent(); // Offset: 0x1021cabbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameMode.GetCreativeModeRealTeamNum
	// Flags: [Final|Native|Public]
	int GetCreativeModeRealTeamNum(); // Offset: 0x1021cab88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGameMode.GetCreativeModeRealTeamIDs
	// Flags: [Final|Native|Public]
	struct TArray<int> GetCreativeModeRealTeamIDs(); // Offset: 0x1021cab24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameMode.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x1021caa98 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameMode.CreativeModeFindPlayerStart
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	struct AActor* CreativeModeFindPlayerStart(struct AController* Player, struct FString IncomingName); // Offset: 0x1021ca9b4 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class Creative.CreativeModeGameModeComponent
// Size: 0x130 // Inherited bytes: 0x110
struct UCreativeModeGameModeComponent : UCreativeModeGameModeBaseComponent {
	// Fields
	struct UCreativeModeRaceCheckPointLiteComponent* RaceCheckPointComponentClass; // Offset: 0x110 // Size: 0x08
	struct UCreativeModeRaceCheckPointLiteComponent* RaceCheckPointComponent; // Offset: 0x118 // Size: 0x08
	struct UCreativeOccupationAreaLiteComponent* OccupationAreaComponentClass; // Offset: 0x120 // Size: 0x08
	struct UCreativeOccupationAreaLiteComponent* OccupationAreaComponent; // Offset: 0x128 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeGameModeComponent.ReceiveCallPlayStateFunction
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveCallPlayStateFunction(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeGameObject
// Size: 0xc8 // Inherited bytes: 0x28
struct UCreativeModeGameObject : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78
	struct FString LuaFilePath; // Offset: 0xa0 // Size: 0x10
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0xb8 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameObject.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021cb8d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameObject.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021cb85c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameObject.ReceivePostBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceivePostBeginPlay(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameObject.IsDedicatedServer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDedicatedServer(); // Offset: 0x1021cb828 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameObject.HasAuthority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAuthority(); // Offset: 0x1021cb7f4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativeModeGameParameterManager
// Size: 0x1d8 // Inherited bytes: 0x108
struct UCreativeModeGameParameterManager : UCreativeModeManagerBase {
	// Fields
	struct FCreativeModeGameParameterContainer GameParameterContainer; // Offset: 0x108 // Size: 0xc8
	char pad_0x1D0[0x8]; // Offset: 0x1d0 // Size: 0x08

	// Functions

	// Object Name: Function Creative.CreativeModeGameParameterManager.RemoveGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveGameParameter(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x1021cc54c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGameParameterManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePreGameParameterRemove
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePreGameParameterRemove(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePostGameParameterChange
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePostGameParameterChange(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnReceivePostGameParameterAdd
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePostGameParameterAdd(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Protected]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1021cc4d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameParameterManager.GetSingleSerializeNum
	// Flags: [Event|Public|BlueprintEvent]
	int GetSingleSerializeNum(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGameParameterManager.GetGameParameterDesc
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameParameterDesc(struct FString ParameterKey, struct FString TemplateID); // Offset: 0x1021cc388 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeGameParameterManager* Get(struct UObject* WorldContext); // Offset: 0x1021cc30c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameParameterManager.ChangeGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangeGameParameter(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x1021cc1a8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGameParameterManager.AddGameParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddGameParameter(struct FString ParameterKey, struct FString TemplateID, struct FString Desc); // Offset: 0x1021cc044 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class Creative.CreativeModeGameState
// Size: 0x1348 // Inherited bytes: 0x12b0
struct ACreativeModeGameState : ASTExtraGameStateBase {
	// Fields
	enum class ECreativeModeGameType CurrentGameType; // Offset: 0x12b0 // Size: 0x01
	char pad_0x12B1[0x7]; // Offset: 0x12b1 // Size: 0x07
	struct UCreativeModeGameStateBaseComponent* CurrentStateComponent; // Offset: 0x12b8 // Size: 0x08
	struct UCreativeModeGameStateBaseComponent* LastStateComponent; // Offset: 0x12c0 // Size: 0x08
	struct TArray<struct UCreativeModeGameStateBaseComponent*> GameStateComponentClassArray; // Offset: 0x12c8 // Size: 0x10
	struct UCreativeModeGameStateComponent* GameStateComponentClass; // Offset: 0x12d8 // Size: 0x08
	struct FGameStateLiteComponentTickFunction LiteComponentActorTick; // Offset: 0x12e0 // Size: 0x58
	struct TArray<struct ULiteComponent*> LiteComponents; // Offset: 0x1338 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeGameState.UnregisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021cce60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.SetLiteComponentTickEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLiteComponentTickEnable(bool bEnabled); // Offset: 0x1021ccddc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.SetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentGameType(enum class ECreativeModeGameType NewGameType); // Offset: 0x1021ccd60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.RegisterLiteComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterLiteComponent(struct ULiteComponent* Component); // Offset: 0x1021ccce4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.ReceiveInitializeLiteComponent
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveInitializeLiteComponent(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameState.OnRep_CurrentStateComponent
	// Flags: [Final|Native|Protected]
	void OnRep_CurrentStateComponent(struct UCreativeModeGameStateBaseComponent* LastComponent); // Offset: 0x1021ccc68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.GetPlayState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x1021ccc34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsEditorMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsEditorMode(); // Offset: 0x1021ccc0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetIsCreative
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool GetIsCreative(); // Offset: 0x1021ccbd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.GetCurrentStateComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCreativeModeGameStateBaseComponent* GetCurrentStateComponent(); // Offset: 0x1021ccbb4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeGameState.GetCurrentGameType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECreativeModeGameType GetCurrentGameType(); // Offset: 0x1021ccb94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameState.FindLiteComponentByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULiteComponent* FindLiteComponentByClass(struct ULiteComponent* ComponentClass); // Offset: 0x1021ccb08 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGameState.ClearAndReImportInstance
	// Flags: [Final|Native|Protected]
	void ClearAndReImportInstance(); // Offset: 0x1021ccaf4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeGameStateComponent
// Size: 0x130 // Inherited bytes: 0x108
struct UCreativeModeGameStateComponent : UCreativeModeGameStateBaseComponent {
	// Fields
	struct UCreativeModeIntegralMechanismLiteComponent* IntegralMechanismComponentClass; // Offset: 0x108 // Size: 0x08
	struct UCreativeModeIntegralMechanismLiteComponent* IntegralMechanismComponent; // Offset: 0x110 // Size: 0x08
	struct ACreativeRuntimePlayerBattleDataObject* RuntimePlayerBattleDataObjectClass; // Offset: 0x118 // Size: 0x08
	struct ACreativeRuntimePlayerBattleDataObject* RuntimePlayerBattleDataObject; // Offset: 0x120 // Size: 0x08
	enum class ECreativeModePlayState CurPlayState; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x7]; // Offset: 0x129 // Size: 0x07

	// Functions

	// Object Name: Function Creative.CreativeModeGameStateComponent.SetPlayState
	// Flags: [Final|Native|Protected]
	void SetPlayState(enum class ECreativeModePlayState newPlayState); // Offset: 0x1021d0d8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_RuntimePlayerBattleDataObject
	// Flags: [Final|Native|Protected]
	void OnRep_RuntimePlayerBattleDataObject(); // Offset: 0x1021d0d78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_IntegralMechanismComponent
	// Flags: [Final|Native|Protected]
	void OnRep_IntegralMechanismComponent(); // Offset: 0x1021d0d64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.OnRep_CurPlayState
	// Flags: [Final|Native|Protected]
	void OnRep_CurPlayState(); // Offset: 0x1021d0d50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGameStateComponent.GetPlayState
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure]
	enum class ECreativeModePlayState GetPlayState(); // Offset: 0x1021d0d14 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Creative.CreativeModeGridLevelsManager
// Size: 0x480 // Inherited bytes: 0x108
struct UCreativeModeGridLevelsManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x108[0x40]; // Offset: 0x108 // Size: 0x40
	struct TArray<struct FString> GridLevelList; // Offset: 0x148 // Size: 0x10
	struct TMap<struct FString, struct FCreativeModeGridLevelConfig> GridLevelConfigs; // Offset: 0x158 // Size: 0x50
	struct TMap<struct FString, struct FCreativeModeGridLevelInfo> GridLevelsMap; // Offset: 0x1a8 // Size: 0x50
	struct TMap<struct FString, struct FIntVector> ObjectCellIndexMap; // Offset: 0x1f8 // Size: 0x50
	struct TArray<struct FString> AlwaysLoadLevel; // Offset: 0x248 // Size: 0x10
	bool bStaticMeshObjectBatchSwitch; // Offset: 0x258 // Size: 0x01
	bool bEditorBatchSwitch; // Offset: 0x259 // Size: 0x01
	char pad_0x25A[0x2]; // Offset: 0x25a // Size: 0x02
	float EditorModeUpdateTime; // Offset: 0x25c // Size: 0x04
	char pad_0x260[0x220]; // Offset: 0x260 // Size: 0x220

	// Functions

	// Object Name: Function Creative.CreativeModeGridLevelsManager.UpdateBatchActorInstances
	// Flags: [Final|Native|Public]
	void UpdateBatchActorInstances(struct FString GridName, int AssetId, int MaterialID); // Offset: 0x1021d2e1c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.UnLoadGridLevelsBatchActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void UnLoadGridLevelsBatchActor(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x1021d2d38 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.RemoveObject
	// Flags: [Final|Native|Public]
	bool RemoveObject(struct FString InstanceID); // Offset: 0x1021d2c90 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveDelayUpdateBatchActorInstances
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveDelayUpdateBatchActorInstances(struct FString GridName, int AssetId, int MaterialID); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ReceiveClearAllData
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveClearAllData(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ObjectAddToGridCellMap
	// Flags: [Final|Native|Public|HasDefaults]
	void ObjectAddToGridCellMap(struct FString GridName, struct FIntVector Index, struct FString InstanceID); // Offset: 0x1021d2b30 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.LoadGridLevelsBatchActor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void LoadGridLevelsBatchActor(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x1021d2a4c // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.IsCreativeEidtMode
	// Flags: [Final|Native|Private]
	bool IsCreativeEidtMode(); // Offset: 0x1021d2a18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GridCellMapRemoveObject
	// Flags: [Final|Native|Public|HasDefaults]
	void GridCellMapRemoveObject(struct FString GridName, struct FIntVector Index, struct FString InstanceID); // Offset: 0x1021d28b8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetStaticMeshBatchActorPath
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetStaticMeshBatchActorPath(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetRelieveBatchDistance
	// Flags: [Event|Public|BlueprintEvent]
	float GetRelieveBatchDistance(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetReBatchDistance
	// Flags: [Event|Public|BlueprintEvent]
	float GetReBatchDistance(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetOnCellIndex
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FIntVector GetOnCellIndex(struct FString GridName, struct FVector& Location); // Offset: 0x1021d27b8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectTransform
	// Flags: [Final|Native|Private|HasDefaults]
	struct FTransform GetObjectTransform(struct FString ID); // Offset: 0x1021d26f8 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectStreamingType
	// Flags: [Final|Native|Private]
	enum class ECreativeModeActorStreamingType GetObjectStreamingType(struct FString ID); // Offset: 0x1021d2650 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectRuntimeGrid
	// Flags: [Final|Native|Public]
	struct FString GetObjectRuntimeGrid(struct FString ID); // Offset: 0x1021d2580 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectMaterialID
	// Flags: [Event|Public|BlueprintEvent]
	int GetObjectMaterialID(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectIsPrefab
	// Flags: [Final|Native|Private]
	bool GetObjectIsPrefab(struct FString ID); // Offset: 0x1021d24d8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetObjectAssetID
	// Flags: [Final|Native|Private]
	int GetObjectAssetID(struct FString ID); // Offset: 0x1021d2430 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetGridLoadingRange
	// Flags: [Final|Native|Public]
	float GetGridLoadingRange(struct FString GridName); // Offset: 0x1021d2388 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetGridList
	// Flags: [Final|Native|Public]
	struct TArray<struct FString> GetGridList(); // Offset: 0x1021d2324 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetDefaultGridName
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetDefaultGridName(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetCellWidthHeight
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector2D GetCellWidthHeight(struct FString GridName); // Offset: 0x1021d2274 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetCellCenterLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FVector GetCellCenterLocation(struct FString GridName, struct FIntVector& CellIndex); // Offset: 0x1021d2178 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.GetAxisIndex
	// Flags: [Final|Native|Public|Const]
	int GetAxisIndex(float pos, float BlockLenght); // Offset: 0x1021d20b4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeGridLevelsManager* Get(struct UObject* WorldContext); // Offset: 0x1021d2038 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckObjectCanBatch
	// Flags: [Event|Public|BlueprintEvent]
	bool CheckObjectCanBatch(struct FString InstanceID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckObjectBeRelieveBatch
	// Flags: [Final|Native|Private]
	bool CheckObjectBeRelieveBatch(struct FString ID); // Offset: 0x1021d1f90 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckObjectBeBatch
	// Flags: [Final|Native|Public]
	bool CheckObjectBeBatch(struct FString ID); // Offset: 0x1021d1ee8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckAndRemoveObjectForBatchData
	// Flags: [Final|Native|Public]
	bool CheckAndRemoveObjectForBatchData(struct FString ID); // Offset: 0x1021d1e40 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.CheckAndAddObjectToBatchData
	// Flags: [Final|Native|Public]
	bool CheckAndAddObjectToBatchData(struct FString ID); // Offset: 0x1021d1d98 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectTransform
	// Flags: [Final|Native|Public]
	bool ChangeObjectTransform(struct FString InstanceID); // Offset: 0x1021d1cf0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectStreamingType
	// Flags: [Final|Native|Public]
	bool ChangeObjectStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType NewStremaingType); // Offset: 0x1021d1c08 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.ChangeObjectMaterialId
	// Flags: [Final|Native|Public]
	bool ChangeObjectMaterialId(struct FString InstanceID, int MaterialID); // Offset: 0x1021d1b20 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Creative.CreativeModeGridLevelsManager.AddObjectToGridLevels
	// Flags: [Final|Native|Public]
	bool AddObjectToGridLevels(struct FString InstanceID); // Offset: 0x1021d1a78 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Creative.CreativeModeInGameManagerCenter
// Size: 0x408 // Inherited bytes: 0x3c0
struct ACreativeModeInGameManagerCenter : AActor {
	// Fields
	char pad_0x3C0[0x10]; // Offset: 0x3c0 // Size: 0x10
	struct TArray<struct USTExtraManagerBase*> ManagerArray; // Offset: 0x3d0 // Size: 0x10
	struct TArray<struct USTExtraManagerBase*> ManagerClassArray; // Offset: 0x3e0 // Size: 0x10
	char pad_0x3F0[0x18]; // Offset: 0x3f0 // Size: 0x18
};

// Object Name: Class Creative.CreativeModeInstanceManager
// Size: 0x1e8 // Inherited bytes: 0x108
struct UCreativeModeInstanceManager : UCreativeModeManagerBase {
	// Fields
	struct FCreativeModeNodeContainer InstanceContainer; // Offset: 0x108 // Size: 0xc8
	struct TArray<struct FCreativeModeNode> PrefabInstances; // Offset: 0x1d0 // Size: 0x10
	char pad_0x1E0[0x4]; // Offset: 0x1e0 // Size: 0x04
	int SingleSerializeNum; // Offset: 0x1e4 // Size: 0x04

	// Functions

	// Object Name: Function Creative.CreativeModeInstanceManager.SetInstanceValue
	// Flags: [Event|Public|BlueprintEvent]
	bool SetInstanceValue(struct FString InstanceID, struct FString Key, struct FString Value); // Offset: 0x103e03170 // Return & Params: Num(4) Size(0x31)

	// Object Name: Function Creative.CreativeModeInstanceManager.SetInstanceTransform
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void SetInstanceTransform(struct FString InstanceID, struct FTransform Transform); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeInstanceManager.RemoveInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveInstance(struct FString ID); // Offset: 0x1021d47c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.ReceiveOnGameStateBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePreInstanceRemove
	// Flags: [Event|Public|BlueprintEvent]
	void OnReceivePreInstanceRemove(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePostInstanceChange
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostInstanceChange(struct FString ID, struct TArray<char>& Content); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReceivePostInstanceAdd
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnReceivePostInstanceAdd(struct FString ID, struct TArray<char>& Content); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnReadyToAddInstance
	// Flags: [Final|Native|Public]
	void OnReadyToAddInstance(); // Offset: 0x1021d47b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnGameTypeChanged
	// Flags: [Final|Native|Public]
	void OnGameTypeChanged(char LastGameType, char CurrentGameType); // Offset: 0x1021d46f8 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Creative.CreativeModeInstanceManager.OnGameStateBeginPlay
	// Flags: [Final|Native|Public]
	void OnGameStateBeginPlay(struct AGameStateBase* GameState); // Offset: 0x1021d467c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Creative.CreativeModeInstanceManager.HasReadyToAddInstance
	// Flags: [Final|Native|Public|Const]
	bool HasReadyToAddInstance(); // Offset: 0x1021d465c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetSingleSerializeNum
	// Flags: [Event|Public|BlueprintEvent]
	int GetSingleSerializeNum(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetObjectStreamingType
	// Flags: [Event|Public|BlueprintEvent]
	enum class ECreativeModeActorStreamingType GetObjectStreamingType(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetObjectRuntimeGrid
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetObjectRuntimeGrid(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetObjectAssetPath
	// Flags: [Event|Public|BlueprintEvent]
	struct FString GetObjectAssetPath(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetInstanceTransform
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	struct FTransform GetInstanceTransform(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetInstanceIsPrefab
	// Flags: [Event|Public|BlueprintEvent]
	bool GetInstanceIsPrefab(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeInstanceManager.GetInstanceAssetID
	// Flags: [Event|Public|BlueprintEvent]
	int GetInstanceAssetID(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeInstanceManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeInstanceManager* Get(struct UObject* WorldContext); // Offset: 0x1021d45e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeInstanceManager.DestroyInstance
	// Flags: [Event|Public|BlueprintEvent]
	struct FString DestroyInstance(struct FString InstanceID); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.ChangeInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeInstance(struct FString ID, struct TArray<char>& Content); // Offset: 0x1021d44e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeInstanceManager.AddInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddInstance(struct FString ID, struct TArray<char>& Content); // Offset: 0x1021d43e8 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Creative.CreativeModeIntegralMechanismComponent
// Size: 0x1e8 // Inherited bytes: 0x1d8
struct UCreativeModeIntegralMechanismComponent : ULuaActorComponent {
	// Fields
	struct TArray<struct FPlayerIntegralInfo> PlayerIntegrals; // Offset: 0x1d8 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.SetPlayerIntegral
	// Flags: [Final|Native|Protected]
	bool SetPlayerIntegral(struct FString UId, int TeamID, int curIntegral, int curStageIntegral, int integralAddSeq); // Offset: 0x1021d503c // Return & Params: Num(6) Size(0x21)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.OnRepPlayerIntegralsOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepPlayerIntegralsOverride(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.OnRep_PlayerIntegrals
	// Flags: [Final|Native|Protected]
	void OnRep_PlayerIntegrals(); // Offset: 0x1021d5028 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismComponent.ClearPlayerIntegrals
	// Flags: [Final|Native|Protected]
	void ClearPlayerIntegrals(); // Offset: 0x1021d5014 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeIntegralMechanismLiteComponent
// Size: 0x118 // Inherited bytes: 0x100
struct UCreativeModeIntegralMechanismLiteComponent : UCreativeModeLiteComponent {
	// Fields
	struct TArray<struct FPlayerIntegralInfo> PlayerIntegrals; // Offset: 0x100 // Size: 0x10
	int TestIndex; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04

	// Functions

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.SetPlayerIntegral
	// Flags: [Final|Native|Protected]
	bool SetPlayerIntegral(struct FString UId, int TeamID, int curIntegral, int curStageIntegral, int integralAddSeq); // Offset: 0x1021d5500 // Return & Params: Num(6) Size(0x21)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRepPlayerIntegralsOverride
	// Flags: [Event|Protected|BlueprintEvent]
	void OnRepPlayerIntegralsOverride(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRep_TestIndex
	// Flags: [Final|Native|Protected]
	void OnRep_TestIndex(int LastIndex); // Offset: 0x1021d5484 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.OnRep_PlayerIntegrals
	// Flags: [Final|Native|Protected]
	void OnRep_PlayerIntegrals(); // Offset: 0x1021d5470 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeIntegralMechanismLiteComponent.ClearPlayerIntegrals
	// Flags: [Final|Native|Protected]
	void ClearPlayerIntegrals(); // Offset: 0x1021d545c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeItemGeneratorComponent
// Size: 0xa28 // Inherited bytes: 0x9d0
struct UCreativeItemGeneratorComponent : UItemGeneratorComponent {
	// Fields
	char pad_0x9D0[0x58]; // Offset: 0x9d0 // Size: 0x58

	// Functions

	// Object Name: Function Creative.CreativeItemGeneratorComponent.SetWeightMul
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetWeightMul(struct TMap<struct FString, int>& Weight); // Offset: 0x1021d59b4 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Creative.CreativeItemGeneratorComponent.SetAddSpotPercentMul
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAddSpotPercentMul(float percent); // Offset: 0x1021d5938 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeItemGeneratorComponent.ClearWeightMul
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWeightMul(); // Offset: 0x1021d5924 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Creative.CreativeModeModDataCheckManager
// Size: 0x108 // Inherited bytes: 0x108
struct UCreativeModeModDataCheckManager : UCreativeModeManagerBase {
	// Functions

	// Object Name: Function Creative.CreativeModeModDataCheckManager.ReceiveOnPreAddInstance
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPreAddInstance(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.ReceiveOnPostAddInstance
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPostAddInstance(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.OnPreAddInstance
	// Flags: [Final|Native|Public]
	void OnPreAddInstance(); // Offset: 0x1021d5ea8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.OnPostAddInstance
	// Flags: [Final|Native|Public]
	void OnPostAddInstance(); // Offset: 0x1021d5e94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeModDataCheckManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeModDataCheckManager* Get(struct UObject* WorldContext); // Offset: 0x1021d5e18 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeModeStaticMeshBatchActor
// Size: 0x520 // Inherited bytes: 0x488
struct ACreativeModeStaticMeshBatchActor : ALuaActor {
	// Fields
	char pad_0x488[0x98]; // Offset: 0x488 // Size: 0x98

	// Functions

	// Object Name: Function Creative.CreativeModeStaticMeshBatchActor.SetISMStaticMeshAndMaterials
	// Flags: [Event|Public|BlueprintEvent]
	void SetISMStaticMeshAndMaterials(struct UInstancedStaticMeshComponent* InstancedStaticMeshComponent, int AssetId, int StaticMeshIndex, int MaterialID); // Offset: 0x103e03170 // Return & Params: Num(4) Size(0x14)
};

// Object Name: Class Creative.CreativeModeNavigationManager
// Size: 0x158 // Inherited bytes: 0x108
struct UCreativeModeNavigationManager : UCreativeModeManagerBase {
	// Fields
	struct TSet<struct AActor*> CachedActors; // Offset: 0x108 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeNavigationManager.SetDynamicModeEnable
	// Flags: [Final|Native|Public]
	void SetDynamicModeEnable(bool bEnable); // Offset: 0x1021d6b44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeNavigationManager.ReceiveOnUnInit
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnUnInit(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ReceiveOnInit
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnInit(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.RebuildDynamicTiles
	// Flags: [Final|Native|Public|HasOutParms]
	void RebuildDynamicTiles(struct TArray<struct AActor*>& Actors); // Offset: 0x1021d6a9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.GetDynamicTilesCount
	// Flags: [Final|Native|Public]
	int GetDynamicTilesCount(); // Offset: 0x1021d6a68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeNavigationManager.GetAllAssociateActors
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct AActor*> GetAllAssociateActors(); // Offset: 0x1021d6a04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeNavigationManager* Get(struct UObject* WorldContext); // Offset: 0x1021d6988 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearDynamicOctreeData
	// Flags: [Final|Native|Public]
	void ClearDynamicOctreeData(); // Offset: 0x1021d6974 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearDynamicNavMesh
	// Flags: [Final|Native|Public]
	void ClearDynamicNavMesh(); // Offset: 0x1021d6960 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.ClearAssociateActors
	// Flags: [Final|Native|Public]
	void ClearAssociateActors(); // Offset: 0x1021d694c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeNavigationManager.CalSamplePointsInBox
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct TArray<struct FVector> CalSamplePointsInBox(struct FVector& BoxMin, struct FVector& BoxMax, float StepSize, int MaxPoints); // Offset: 0x1021d67bc // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Creative.CreativeModeNavigationManager.CalSamplePoints
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct TArray<struct FVector> CalSamplePoints(struct FVector& StartPos, float StepSize, int MaxPoints); // Offset: 0x1021d6680 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Creative.CreativeModeNavigationManager.AddNavAffectedObjects
	// Flags: [Final|Native|Public|HasOutParms]
	void AddNavAffectedObjects(struct TArray<struct AActor*>& Actors); // Offset: 0x1021d65d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeNavigationManager.AddNavAffectedObject
	// Flags: [Final|Native|Public]
	void AddNavAffectedObject(struct AActor* Actor); // Offset: 0x1021d655c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Creative.CreativeModeObjectFuncComponent
// Size: 0x100 // Inherited bytes: 0x100
struct UCreativeModeObjectFuncComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativeModeObjectInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UCreativeModeObjectInterface : UInterface {
	// Functions

	// Object Name: Function Creative.CreativeModeObjectInterface.ReceiveOnPostSetInstanceId
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveOnPostSetInstanceId(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeObjectInterface.GetInstanceId
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	struct FString GetInstanceId(); // Offset: 0x1021d7168 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectInterface.GetAssetComponent
	// Flags: [Event|Public|BlueprintEvent]
	void GetAssetComponent(struct FString ComponentName); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeObjectManager
// Size: 0x158 // Inherited bytes: 0x108
struct UCreativeModeObjectManager : UCreativeModeManagerBase {
	// Fields
	struct TMap<struct FString, struct UObject*> ObjectMap; // Offset: 0x108 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObjectForStreaming
	// Flags: [Final|Native|Public]
	void SpawnObjectForStreaming(struct FString InstanceID); // Offset: 0x1021dc9b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObjectForBatchManager
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SpawnObjectForBatchManager(struct FString& InstanceID, struct FTransform& SpawnTransform); // Offset: 0x1021dc89c // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeObjectManager.SpawnObject
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	struct UObject* SpawnObject(struct FString InstanceID, struct FString Path, struct FTransform SpawnTransform); // Offset: 0x1021dc6f0 // Return & Params: Num(4) Size(0x58)

	// Object Name: Function Creative.CreativeModeObjectManager.SetObjectTempStreamingType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetObjectTempStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType TempStreamingType); // Offset: 0x1021dc608 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeObjectManager.ResetObjectStreamingType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ResetObjectStreamingType(struct FString InstanceID); // Offset: 0x1021dc560 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.RemoveObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveObject(struct FString InstanceID); // Offset: 0x1021dc494 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveUnregisterObject
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveUnregisterObject(struct FString InstanceID, struct UObject* NewObject); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveRegisterObject
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveRegisterObject(struct FString InstanceID, struct UObject* NewObject); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.ReceiveClearAllObjects
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveClearAllObjects(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModeObjectManager.OnObjectSpawnComplete
	// Flags: [Event|Public|BlueprintEvent]
	void OnObjectSpawnComplete(struct FString ID); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectTransform
	// Flags: [Final|Native|Public|HasDefaults]
	struct FTransform GetObjectTransform(struct FString ID); // Offset: 0x1021dc3d4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectNum
	// Flags: [Final|Native|Public|Const]
	uint32_t GetObjectNum(); // Offset: 0x1021dc3a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TMap<struct FString, struct UObject*> GetObjectMap(); // Offset: 0x1021dc33c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObjectAssetPath
	// Flags: [Final|Native|Public]
	struct FString GetObjectAssetPath(struct FString ID); // Offset: 0x1021dc26c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModeObjectManager.GetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UObject* GetObject(struct FString InstanceID); // Offset: 0x1021dc1a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeObjectManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeObjectManager* Get(struct UObject* WorldContext); // Offset: 0x1021dc124 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeObjectManager.DestroyObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool DestroyObject(struct FString InstanceID); // Offset: 0x1021dc058 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.CheckObjectBeBatch
	// Flags: [Final|Native|Public]
	bool CheckObjectBeBatch(struct FString ID); // Offset: 0x1021dbfb0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeObjectManager.ChangeObjectTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool ChangeObjectTransform(struct FString InstanceID, struct FTransform Transform); // Offset: 0x1021dbe7c // Return & Params: Num(3) Size(0x41)

	// Object Name: Function Creative.CreativeModeObjectManager.AddObject
	// Flags: [Final|Native|Public]
	bool AddObject(struct FString InstanceID, struct FCreativeModeStreamingParameters StreamingParameters); // Offset: 0x1021dbce8 // Return & Params: Num(3) Size(0x61)
};

// Object Name: Class Creative.CreativeOccupationAreaLiteComponent
// Size: 0x100 // Inherited bytes: 0x100
struct UCreativeOccupationAreaLiteComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativeModePlayerState
// Size: 0x1990 // Inherited bytes: 0x1978
struct ACreativeModePlayerState : ASTExtraPlayerState {
	// Fields
	bool bEnableAutoPickUp; // Offset: 0x1978 // Size: 0x01
	char pad_0x1979[0x7]; // Offset: 0x1979 // Size: 0x07
	struct FString PrefabInstanceId; // Offset: 0x1980 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModePlayerState.SetPrefabInstanceId
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPrefabInstanceId(struct FString bNewInstanceId); // Offset: 0x1021dd544 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModePlayerState.ServerSetInstanceTransfrom
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|HasDefaults|NetValidate]
	void ServerSetInstanceTransfrom(struct FString InstanceID, struct FTransform InstanceTransform); // Offset: 0x1021dd400 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Creative.CreativeModePlayerState.ServerAddInstance
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerAddInstance(struct FString InstanceID, struct TArray<char> Content); // Offset: 0x1021dd2e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Creative.CreativeModePlayerState.OnRep_PrefabInstanceId
	// Flags: [Final|Native|Public]
	void OnRep_PrefabInstanceId(); // Offset: 0x1021dd2cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Creative.CreativeModePlayerState.GetPrefabInstanceId
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetPrefabInstanceId(); // Offset: 0x1021dd268 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Creative.CreativeModeRaceCheckPointComponent
// Size: 0x1d8 // Inherited bytes: 0x1d8
struct UCreativeModeRaceCheckPointComponent : ULuaActorComponent {
};

// Object Name: Class Creative.CreativeModeRaceCheckPointLiteComponent
// Size: 0x100 // Inherited bytes: 0x100
struct UCreativeModeRaceCheckPointLiteComponent : UCreativeModeLiteComponent {
};

// Object Name: Class Creative.CreativeRuntimePlayerBattleDataObject
// Size: 0x690 // Inherited bytes: 0x488
struct ACreativeRuntimePlayerBattleDataObject : ALuaActor {
	// Fields
	struct FRuntimePlayerBattleDataInfo DefaultPlayerBattleDataInfo; // Offset: 0x488 // Size: 0x58
	struct FRuntimeCacheRoundBattleDataInfoContainer RuntimeOldCacheRoundBattleDataContainer; // Offset: 0x4e0 // Size: 0xc8
	struct FRuntimeBattleDataInfoContainer RuntimeCurRoundBattleDataInfoContainer; // Offset: 0x5a8 // Size: 0xc8
	struct FRuntimeCacheRoundBattleDataInfo DefaultCacheRoundBattleDataInfo; // Offset: 0x670 // Size: 0x20

	// Functions

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.SetPlayerBattleData
	// Flags: [Final|Native|Protected|HasOutParms]
	bool SetPlayerBattleData(uint64 UId, struct FRuntimePlayerBattleDataInfo& playerBattleData, bool bPropagateToChildren); // Offset: 0x1021de1e4 // Return & Params: Num(4) Size(0x62)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.OnRepCurRoundPlayerBattleDataInfo
	// Flags: [Final|Native|Public]
	void OnRepCurRoundPlayerBattleDataInfo(uint64 PlayerUID, int ChangeTeamID); // Offset: 0x1021de12c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCurRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetCurRoundPlayerBattleData(uint64 PlayerUID); // Offset: 0x1021de078 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCurRoundAllPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct TArray<struct FRuntimePlayerBattleDataInfo> GetCurRoundAllPlayerBattleData(); // Offset: 0x1021de014 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCacheRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetCacheRoundPlayerBattleData(int RoundIndex, uint64 PlayerUID); // Offset: 0x1021ddf24 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetCacheRoundBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimeCacheRoundBattleDataInfo GetCacheRoundBattleData(int RoundIndex); // Offset: 0x1021dde90 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.GetAllRoundPlayerBattleData
	// Flags: [Final|Native|Protected]
	struct FRuntimePlayerBattleDataInfo GetAllRoundPlayerBattleData(uint64 PlayerUID); // Offset: 0x1021dddd8 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Creative.CreativeRuntimePlayerBattleDataObject.CacheCurRoundBattleData
	// Flags: [Final|Native|Protected]
	void CacheCurRoundBattleData(int RoundIndex); // Offset: 0x1021ddd5c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Creative.CreativeModeSoftComponentManager
// Size: 0x158 // Inherited bytes: 0x108
struct UCreativeModeSoftComponentManager : UCreativeModeManagerBase {
	// Fields
	char pad_0x108[0x50]; // Offset: 0x108 // Size: 0x50

	// Functions

	// Object Name: Function Creative.CreativeModeSoftComponentManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeSoftComponentManager* Get(struct UObject* WorldContext); // Offset: 0x1021de650 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Creative.CreativeModeStreamingManager
// Size: 0x270 // Inherited bytes: 0x108
struct UCreativeModeStreamingManager : UCreativeModeManagerBase {
	// Fields
	bool bStreamingManagerEnable; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x47]; // Offset: 0x109 // Size: 0x47
	struct TMap<struct FString, struct FCreativeModeStreamingParameters> ObjectStreamingStateMap; // Offset: 0x150 // Size: 0x50
	struct TArray<struct FString> ObjectStreamingStateKeyList; // Offset: 0x1a0 // Size: 0x10
	struct TMap<struct FString, bool> ObjectSpawnStateChangeMaps; // Offset: 0x1b0 // Size: 0x50
	char pad_0x200[0x50]; // Offset: 0x200 // Size: 0x50
	struct TArray<struct AActor*> OuterStreamingSources; // Offset: 0x250 // Size: 0x10
	char pad_0x260[0x10]; // Offset: 0x260 // Size: 0x10

	// Functions

	// Object Name: Function Creative.CreativeModeStreamingManager.StreamingManagerEnable
	// Flags: [Final|Native|Public]
	bool StreamingManagerEnable(); // Offset: 0x1021df28c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Creative.CreativeModeStreamingManager.RemoveStreamingObject
	// Flags: [Final|Native|Public]
	bool RemoveStreamingObject(struct FString InstanceID); // Offset: 0x1021df1c0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetStreamingTickFrequency
	// Flags: [Event|Public|BlueprintEvent]
	float GetStreamingTickFrequency(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetOnGridCellIndex
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	struct FIntVector GetOnGridCellIndex(struct FString GridName, struct FVector& Location); // Offset: 0x1021df0c0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridLoadingRange
	// Flags: [Final|Native|Public]
	float GetGridLoadingRange(struct FString GridName); // Offset: 0x1021df018 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridList
	// Flags: [Final|Native|Public]
	struct TArray<struct FString> GetGridList(); // Offset: 0x1021defb4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetGridCellWidthHeight
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector2D GetGridCellWidthHeight(struct FString GridName); // Offset: 0x1021def04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetDestroyExtendDistance
	// Flags: [Event|Public|BlueprintEvent]
	float GetDestroyExtendDistance(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeStreamingManager.GetDelayDestroyTime
	// Flags: [Event|Public|BlueprintEvent]
	float GetDelayDestroyTime(); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Creative.CreativeModeStreamingManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCreativeModeStreamingManager* Get(struct UObject* WorldContext); // Offset: 0x1021dee88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Creative.CreativeModeStreamingManager.ChangeStreamingObjectTransform
	// Flags: [Final|Native|Public|HasDefaults]
	bool ChangeStreamingObjectTransform(struct FString InstanceID, struct FTransform Transform); // Offset: 0x1021ded54 // Return & Params: Num(3) Size(0x41)

	// Object Name: Function Creative.CreativeModeStreamingManager.ChangeStreamingObjectStreamingType
	// Flags: [Final|Native|Public]
	enum class ECreativeModeActorStreamingType ChangeStreamingObjectStreamingType(struct FString InstanceID, enum class ECreativeModeActorStreamingType NewStremaingType); // Offset: 0x1021dec48 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Creative.CreativeModeStreamingManager.AddStreamingObject
	// Flags: [Final|Native|Public]
	bool AddStreamingObject(struct FString InstanceID, struct FCreativeModeStreamingParameters StreamingParameters); // Offset: 0x1021deab4 // Return & Params: Num(3) Size(0x61)
};

// Object Name: Class Creative.CreativeWorldSubSystem
// Size: 0x38 // Inherited bytes: 0x30
struct UCreativeWorldSubSystem : UWorldSubsystem {
	// Fields
	struct AActor* ManagerCenter; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class Creative.GameModeStateActive_CreativeMode
// Size: 0x58 // Inherited bytes: 0x58
struct UGameModeStateActive_CreativeMode : UGameModeStateActive {
};

// Object Name: Class Creative.GameModeStateFighting_CreativeMode
// Size: 0x68 // Inherited bytes: 0x68
struct UGameModeStateFighting_CreativeMode : UGameModeStateFightingTeam {
};

// Object Name: Class Creative.GameModeStateFinished_CreativeMode
// Size: 0x50 // Inherited bytes: 0x50
struct UGameModeStateFinished_CreativeMode : UGameModeStateFinishedTeam {
};

// Object Name: Class Creative.GameModeStateReady_CreativeMode
// Size: 0x90 // Inherited bytes: 0x90
struct UGameModeStateReady_CreativeMode : UGameModeStateReady {
};

// Object Name: Class Creative.SoftStaticMeshComponent
// Size: 0x8c0 // Inherited bytes: 0x890
struct USoftStaticMeshComponent : UStaticMeshComponent {
	// Fields
	struct UStaticMesh* SoftStaticMesh; // Offset: 0x890 // Size: 0x28
	char bAsyncLoad : 1; // Offset: 0x8b8 // Size: 0x01
	char pad_0x8B8_1 : 7; // Offset: 0x8b8 // Size: 0x01
	char pad_0x8B9[0x7]; // Offset: 0x8b9 // Size: 0x07

	// Functions

	// Object Name: Function Creative.SoftStaticMeshComponent.SetSoftStaticMesh
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSoftStaticMesh(struct UStaticMesh* NewMesh, bool bSetStaticMesh); // Offset: 0x1021dfd80 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Creative.SoftStaticMeshComponent.OnClientAsyncLoaded
	// Flags: [Final|Native|Public|HasDefaults]
	void OnClientAsyncLoaded(struct FSoftObjectPath SoftObjectPath); // Offset: 0x1021dfcb4 // Return & Params: Num(1) Size(0x18)
};

