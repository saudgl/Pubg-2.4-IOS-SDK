#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Landscape.ControlPointMeshComponent
// Size: 0x890 // Inherited bytes: 0x890
struct UControlPointMeshComponent : UStaticMeshComponent {
};

// Object Name: Class Landscape.LandscapeProxy
// Size: 0x850 // Inherited bytes: 0x3c0
struct ALandscapeProxy : AActor {
	// Fields
	struct ULandscapeSplinesComponent* SplineComponent; // Offset: 0x3c0 // Size: 0x08
	struct FGuid LandscapeGuid; // Offset: 0x3c8 // Size: 0x10
	struct FGuid BoundingGuid; // Offset: 0x3d8 // Size: 0x10
	struct FIntPoint LandscapeSectionOffset; // Offset: 0x3e8 // Size: 0x08
	int MaxLODLevel; // Offset: 0x3f0 // Size: 0x04
	float LODDistanceFactor; // Offset: 0x3f4 // Size: 0x04
	enum class ELandscapeLODFalloff LODFalloff; // Offset: 0x3f8 // Size: 0x01
	bool bUseScreenSizeLOD; // Offset: 0x3f9 // Size: 0x01
	char pad_0x3FA[0x2]; // Offset: 0x3fa // Size: 0x02
	float LOD0DistributionSetting; // Offset: 0x3fc // Size: 0x04
	float LODDistributionSetting; // Offset: 0x400 // Size: 0x04
	char NearMaxLOD_Baked; // Offset: 0x404 // Size: 0x01
	char pad_0x405[0x3]; // Offset: 0x405 // Size: 0x03
	float NearFactor_Baked; // Offset: 0x408 // Size: 0x04
	float NearExtent_Baked; // Offset: 0x40c // Size: 0x04
	float FarFactor_Baked; // Offset: 0x410 // Size: 0x04
	float LandscapeRoughness; // Offset: 0x414 // Size: 0x04
	bool EnableImproveLOD; // Offset: 0x418 // Size: 0x01
	char pad_0x419[0x7]; // Offset: 0x419 // Size: 0x07
	struct TArray<float> ImproveLODValues; // Offset: 0x420 // Size: 0x10
	char NearMaxLOD; // Offset: 0x430 // Size: 0x01
	char pad_0x431[0x3]; // Offset: 0x431 // Size: 0x03
	float NearFactor; // Offset: 0x434 // Size: 0x04
	float NearExtent; // Offset: 0x438 // Size: 0x04
	float FarFactor; // Offset: 0x43c // Size: 0x04
	int StaticLightingLOD; // Offset: 0x440 // Size: 0x04
	char pad_0x444[0x4]; // Offset: 0x444 // Size: 0x04
	struct UPhysicalMaterial* DefaultPhysMaterial; // Offset: 0x448 // Size: 0x08
	float StreamingDistanceMultiplier; // Offset: 0x450 // Size: 0x04
	char bCacheHeightData : 1; // Offset: 0x454 // Size: 0x01
	char pad_0x454_1 : 7; // Offset: 0x454 // Size: 0x01
	char pad_0x455[0x3]; // Offset: 0x455 // Size: 0x03
	struct UMaterialInterface* LandscapeMaterial; // Offset: 0x458 // Size: 0x08
	struct UMaterialInterface* LandscapeHoleMaterial; // Offset: 0x460 // Size: 0x08
	struct TMap<struct FName, struct UMaterialInterface*> OtherMaterials; // Offset: 0x468 // Size: 0x50
	char bOverrideGrassTypes : 1; // Offset: 0x4b8 // Size: 0x01
	char pad_0x4B8_1 : 7; // Offset: 0x4b8 // Size: 0x01
	char pad_0x4B9[0x7]; // Offset: 0x4b9 // Size: 0x07
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // Offset: 0x4c0 // Size: 0x10
	float MinGrassWeightThreshold; // Offset: 0x4d0 // Size: 0x04
	float NegativeZBoundsExtension; // Offset: 0x4d4 // Size: 0x04
	float PositiveZBoundsExtension; // Offset: 0x4d8 // Size: 0x04
	char pad_0x4DC[0x4]; // Offset: 0x4dc // Size: 0x04
	struct UTexture2D* GrassColor_WorldMaskNoiseTexture; // Offset: 0x4e0 // Size: 0x08
	struct FVector2D GrassColor_UVScale_WorldMaskNoise; // Offset: 0x4e8 // Size: 0x08
	struct FVector2D GrassColor_Center_WorldMaskNoise; // Offset: 0x4f0 // Size: 0x08
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // Offset: 0x4f8 // Size: 0x10
	struct ULandscapeAOTextureDataAsset* LandscapeAOTextureDataAsset; // Offset: 0x508 // Size: 0x08
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // Offset: 0x510 // Size: 0x10
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // Offset: 0x520 // Size: 0x10
	char pad_0x530[0x60]; // Offset: 0x530 // Size: 0x60
	bool bHasLandscapeGrass; // Offset: 0x590 // Size: 0x01
	char pad_0x591[0x3]; // Offset: 0x591 // Size: 0x03
	float StaticLightingResolution; // Offset: 0x594 // Size: 0x04
	char bCastStaticShadow : 1; // Offset: 0x598 // Size: 0x01
	char bCastShadowAsTwoSided : 1; // Offset: 0x598 // Size: 0x01
	char bCastFarShadow : 1; // Offset: 0x598 // Size: 0x01
	char pad_0x598_3 : 5; // Offset: 0x598 // Size: 0x01
	struct FLightingChannels LightingChannels; // Offset: 0x599 // Size: 0x01
	char bUseMaterialPositionOffsetInStaticLighting : 1; // Offset: 0x59a // Size: 0x01
	char bRenderCustomDepth : 1; // Offset: 0x59a // Size: 0x01
	char pad_0x59A_2 : 6; // Offset: 0x59a // Size: 0x01
	char pad_0x59B[0x1]; // Offset: 0x59b // Size: 0x01
	int CustomDepthStencilValue; // Offset: 0x59c // Size: 0x04
	struct FLightmassPrimitiveSettings LightmassSettings; // Offset: 0x5a0 // Size: 0x18
	int CollisionMipLevel; // Offset: 0x5b8 // Size: 0x04
	int SimpleCollisionMipLevel; // Offset: 0x5bc // Size: 0x04
	float CollisionThickness; // Offset: 0x5c0 // Size: 0x04
	char pad_0x5C4[0x4]; // Offset: 0x5c4 // Size: 0x04
	struct FBodyInstance BodyInstance; // Offset: 0x5c8 // Size: 0x180
	char bGenerateOverlapEvents : 1; // Offset: 0x748 // Size: 0x01
	char bBakeMaterialPositionOffsetIntoCollision : 1; // Offset: 0x748 // Size: 0x01
	char bUseHoleConsistent : 1; // Offset: 0x748 // Size: 0x01
	char pad_0x748_3 : 5; // Offset: 0x748 // Size: 0x01
	char pad_0x749[0x3]; // Offset: 0x749 // Size: 0x03
	int ComponentSizeQuads; // Offset: 0x74c // Size: 0x04
	int SubsectionSizeQuads; // Offset: 0x750 // Size: 0x04
	int NumSubsections; // Offset: 0x754 // Size: 0x04
	char bUsedForNavigation : 1; // Offset: 0x758 // Size: 0x01
	char bMobileMultiLayers : 1; // Offset: 0x758 // Size: 0x01
	char pad_0x758_2 : 6; // Offset: 0x758 // Size: 0x01
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // Offset: 0x759 // Size: 0x01
	bool bUseLandscapeForCullingInvisibleHLODVertices; // Offset: 0x75a // Size: 0x01
	char pad_0x75B[0xf5]; // Offset: 0x75b // Size: 0xf5

	// Functions

	// Object Name: Function Landscape.LandscapeProxy.EditorApplySpline
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer); // Offset: 0x10477b3a8 // Return & Params: Num(11) Size(0x30)

	// Object Name: Function Landscape.LandscapeProxy.ChangeLODDistributionSettingConsoleVariable
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeLODDistributionSettingConsoleVariable(); // Offset: 0x10477b38c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeLODDistanceFactor(float InLODDistanceFactor); // Offset: 0x10477b308 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Landscape.LandscapeProxy.ChangeLOD0DistributionSettingConsoleVariable
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeLOD0DistributionSettingConsoleVariable(); // Offset: 0x10477b2ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Landscape.LandscapeProxy.ChangebUseScreenSizeLOD
	// Flags: [Native|Public|BlueprintCallable]
	void ChangebUseScreenSizeLOD(bool InbUseScreenSizeLOD); // Offset: 0x10477b260 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Landscape.Landscape
// Size: 0x8f0 // Inherited bytes: 0x850
struct ALandscape : ALandscapeProxy {
	// Fields
	char pad_0x850[0xa0]; // Offset: 0x850 // Size: 0xa0
};

// Object Name: Class Landscape.SimpleMeshComponent
// Size: 0x7c0 // Inherited bytes: 0x790
struct USimpleMeshComponent : UMeshComponent {
	// Fields
	struct TArray<struct FSimpleMeshSection> MeshSections; // Offset: 0x788 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x798 // Size: 0x1c
	char pad_0x7BC[0x4]; // Offset: 0x7bc // Size: 0x04
};

// Object Name: Class Landscape.LandscapeComponent
// Size: 0xb40 // Inherited bytes: 0x760
struct ULandscapeComponent : UPrimitiveComponent {
	// Fields
	int SectionBaseX; // Offset: 0x760 // Size: 0x04
	int SectionBaseY; // Offset: 0x764 // Size: 0x04
	int ComponentSizeQuads; // Offset: 0x768 // Size: 0x04
	int SubsectionSizeQuads; // Offset: 0x76c // Size: 0x04
	int NumSubsections; // Offset: 0x770 // Size: 0x04
	char pad_0x774[0x4]; // Offset: 0x774 // Size: 0x04
	struct UMaterialInterface* OverrideMaterial; // Offset: 0x778 // Size: 0x08
	struct UMaterialInterface* OverrideHoleMaterial; // Offset: 0x780 // Size: 0x08
	struct TMap<struct FName, struct UMaterialInterface*> OverrideOtherMaterials; // Offset: 0x788 // Size: 0x50
	struct FOverridePhyxMaterial OverridePhyxMaterial; // Offset: 0x7d8 // Size: 0x20
	char bOverrideGrassTypes : 1; // Offset: 0x7f8 // Size: 0x01
	char pad_0x7F8_1 : 7; // Offset: 0x7f8 // Size: 0x01
	char pad_0x7F9[0x7]; // Offset: 0x7f9 // Size: 0x07
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // Offset: 0x800 // Size: 0x10
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // Offset: 0x810 // Size: 0x10
	struct TMap<struct FName, struct UMaterialInstanceConstant*> OtherMaterialInstances; // Offset: 0x820 // Size: 0x50
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // Offset: 0x870 // Size: 0x10
	struct TArray<struct UTexture2D*> WeightmapTextures; // Offset: 0x880 // Size: 0x10
	int VisibilityLayerChannel; // Offset: 0x890 // Size: 0x04
	char pad_0x894[0x4]; // Offset: 0x894 // Size: 0x04
	struct UTexture2D* XYOffsetmapTexture; // Offset: 0x898 // Size: 0x08
	struct FVector4 WeightmapScaleBias; // Offset: 0x8a0 // Size: 0x10
	float WeightmapSubsectionOffset; // Offset: 0x8b0 // Size: 0x04
	char pad_0x8B4[0xc]; // Offset: 0x8b4 // Size: 0x0c
	struct FVector4 HeightmapScaleBias; // Offset: 0x8c0 // Size: 0x10
	struct UTexture2D* HeightmapTexture; // Offset: 0x8d0 // Size: 0x08
	struct TMap<struct FString, struct FVisibilityData> MultiVisibilityTextureData; // Offset: 0x8d8 // Size: 0x50
	struct FString VisibleVisibilityLayer; // Offset: 0x928 // Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x938 // Size: 0x1c
	struct TLazyObjectPtr<struct ULandscapeHeightfieldCollisionComponent> CollisionComponent; // Offset: 0x954 // Size: 0x1c
	struct FGuid MapBuildDataId; // Offset: 0x970 // Size: 0x10
	struct TArray<struct FGuid> IrrelevantLights; // Offset: 0x980 // Size: 0x10
	int CollisionMipLevel; // Offset: 0x990 // Size: 0x04
	int SimpleCollisionMipLevel; // Offset: 0x994 // Size: 0x04
	float NegativeZBoundsExtension; // Offset: 0x998 // Size: 0x04
	float PositiveZBoundsExtension; // Offset: 0x99c // Size: 0x04
	float StaticLightingResolution; // Offset: 0x9a0 // Size: 0x04
	int ForcedLOD; // Offset: 0x9a4 // Size: 0x04
	int LODBias; // Offset: 0x9a8 // Size: 0x04
	int MobileVertexHoleMaxLOD; // Offset: 0x9ac // Size: 0x04
	char pad_0x9B0[0x10]; // Offset: 0x9b0 // Size: 0x10
	struct TArray<float> LODDeltaVertex; // Offset: 0x9c0 // Size: 0x10
	float MaxDeltaVertex; // Offset: 0x9d0 // Size: 0x04
	struct FGuid StateID; // Offset: 0x9d4 // Size: 0x10
	struct FGuid BakedTextureMaterialGuid; // Offset: 0x9e4 // Size: 0x10
	char pad_0x9F4[0x4]; // Offset: 0x9f4 // Size: 0x04
	struct UTexture2D* GIBakedBaseColorTexture; // Offset: 0x9f8 // Size: 0x08
	struct UStaticMesh* OccluderMesh; // Offset: 0xa00 // Size: 0x08
	char MobileBlendableLayerMask; // Offset: 0xa08 // Size: 0x01
	char pad_0xA09[0x7]; // Offset: 0xa09 // Size: 0x07
	struct UMaterialInterface* MobileMaterialInterface; // Offset: 0xa10 // Size: 0x08
	struct TMap<struct FName, struct UMaterialInterface*> OtherMobileMaterialInterfaces; // Offset: 0xa18 // Size: 0x50
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // Offset: 0xa68 // Size: 0x10
	struct UTexture2D* MobileWeightNormalmapTexture; // Offset: 0xa78 // Size: 0x08
	char bMobileMultiLayers : 1; // Offset: 0xa80 // Size: 0x01
	char pad_0xA80_1 : 7; // Offset: 0xa80 // Size: 0x01
	char pad_0xA81[0x7]; // Offset: 0xa81 // Size: 0x07
	struct TArray<uint16_t> CachedHeightData; // Offset: 0xa88 // Size: 0x10
	char pad_0xA98[0x68]; // Offset: 0xa98 // Size: 0x68
	bool bHasROCData; // Offset: 0xb00 // Size: 0x01
	char pad_0xB01[0x17]; // Offset: 0xb01 // Size: 0x17
	struct FName UsedOtherMaterialName; // Offset: 0xb18 // Size: 0x08
	char pad_0xB20[0x20]; // Offset: 0xb20 // Size: 0x20
};

// Object Name: Class Landscape.LandscapeGeometryAsset
// Size: 0x198 // Inherited bytes: 0x30
struct ULandscapeGeometryAsset : UDataAsset {
	// Fields
	struct TArray<struct FVector> Vertex; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FVector2D> UV; // Offset: 0x50 // Size: 0x10
	struct TArray<int> Indices; // Offset: 0x60 // Size: 0x10
	struct TMap<struct FIntPoint, int> ComponentIndexOffset; // Offset: 0x70 // Size: 0x50
	int ComponentIndexCount; // Offset: 0xc0 // Size: 0x04
	int ComponentVertexCount; // Offset: 0xc4 // Size: 0x04
	struct TMap<struct FString, struct FLevelComponentMapValue> SubLevelComponentMap; // Offset: 0xc8 // Size: 0x50
	struct UStaticMesh* HighQualityMesh; // Offset: 0x118 // Size: 0x28
	float HighQualityMeshDestroyHight; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct TMap<struct FIntPoint, int> ComponentVertexIndexOffset; // Offset: 0x148 // Size: 0x50
};

// Object Name: Class Landscape.LandscapeGizmoActor
// Size: 0x3c0 // Inherited bytes: 0x3c0
struct ALandscapeGizmoActor : AActor {
};

// Object Name: Class Landscape.LandscapeGizmoActiveActor
// Size: 0x410 // Inherited bytes: 0x3c0
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	// Fields
	char pad_0x3C0[0x50]; // Offset: 0x3c0 // Size: 0x50
};

// Object Name: Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x760 // Inherited bytes: 0x760
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Object Name: Class Landscape.LandscapeGrassType
// Size: 0x58 // Inherited bytes: 0x28
struct ULandscapeGrassType : UObject {
	// Fields
	struct TArray<struct FGrassVariety> GrassVarieties; // Offset: 0x28 // Size: 0x10
	struct UStaticMesh* GrassMesh; // Offset: 0x38 // Size: 0x08
	float GrassDensity; // Offset: 0x40 // Size: 0x04
	float PlacementJitter; // Offset: 0x44 // Size: 0x04
	int StartCullDistance; // Offset: 0x48 // Size: 0x04
	int EndCullDistance; // Offset: 0x4c // Size: 0x04
	bool RandomRotation; // Offset: 0x50 // Size: 0x01
	bool AlignToSurface; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06
};

// Object Name: Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0x840 // Inherited bytes: 0x760
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // Offset: 0x760 // Size: 0x10
	int SectionBaseX; // Offset: 0x770 // Size: 0x04
	int SectionBaseY; // Offset: 0x774 // Size: 0x04
	int CollisionSizeQuads; // Offset: 0x778 // Size: 0x04
	float CollisionScale; // Offset: 0x77c // Size: 0x04
	int SimpleCollisionSizeQuads; // Offset: 0x780 // Size: 0x04
	char pad_0x784[0x4]; // Offset: 0x784 // Size: 0x04
	struct TArray<char> CollisionQuadFlags; // Offset: 0x788 // Size: 0x10
	struct FGuid HeightfieldGuid; // Offset: 0x798 // Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x7a8 // Size: 0x1c
	struct TLazyObjectPtr<struct ULandscapeComponent> RenderComponent; // Offset: 0x7c4 // Size: 0x1c
	char pad_0x7E0[0x10]; // Offset: 0x7e0 // Size: 0x10
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // Offset: 0x7f0 // Size: 0x10
	char pad_0x800[0x40]; // Offset: 0x800 // Size: 0x40
};

// Object Name: Class Landscape.IdeaGrassFieldFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UIdeaGrassFieldFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureTrample
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IdeaGrassRenderForceTextureTrample(struct FIdeaGrassFieldData GrassFieldData); // Offset: 0x10477a2b4 // Return & Params: Num(1) Size(0x90)

	// Object Name: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureSkill
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IdeaGrassRenderForceTextureSkill(struct FIdeaGrassFieldData GrassFieldData); // Offset: 0x10477a1b8 // Return & Params: Num(1) Size(0x90)

	// Object Name: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTextureFade
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IdeaGrassRenderForceTextureFade(struct FIdeaGrassFieldData GrassFieldData); // Offset: 0x10477a0bc // Return & Params: Num(1) Size(0x90)

	// Object Name: Function Landscape.IdeaGrassFieldFunctionLibrary.IdeaGrassRenderForceTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IdeaGrassRenderForceTexture(struct FIdeaGrassFieldData GrassFieldData); // Offset: 0x104779fc0 // Return & Params: Num(1) Size(0x90)
};

// Object Name: Class Landscape.LandscapeInfo
// Size: 0x3f0 // Inherited bytes: 0x28
struct ULandscapeInfo : UObject {
	// Fields
	struct TLazyObjectPtr<struct ALandscape> LandscapeActor; // Offset: 0x28 // Size: 0x1c
	struct FGuid LandscapeGuid; // Offset: 0x44 // Size: 0x10
	int ComponentSizeQuads; // Offset: 0x54 // Size: 0x04
	int SubsectionSizeQuads; // Offset: 0x58 // Size: 0x04
	int ComponentNumSubsections; // Offset: 0x5c // Size: 0x04
	struct FVector DrawScale; // Offset: 0x60 // Size: 0x0c
	char pad_0x6C[0x244]; // Offset: 0x6c // Size: 0x244
	struct TSet<struct ALandscapeStreamingProxy*> Proxies; // Offset: 0x2b0 // Size: 0x50
	char pad_0x300[0xf0]; // Offset: 0x300 // Size: 0xf0
};

// Object Name: Class Landscape.LandscapeInfoMap
// Size: 0x80 // Inherited bytes: 0x28
struct ULandscapeInfoMap : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 // Size: 0x58
};

// Object Name: Class Landscape.LandscapeLayerInfoObject
// Size: 0x50 // Inherited bytes: 0x28
struct ULandscapeLayerInfoObject : UObject {
	// Fields
	struct FName LayerName; // Offset: 0x28 // Size: 0x08
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0x30 // Size: 0x08
	float Hardness; // Offset: 0x38 // Size: 0x04
	struct FLinearColor LayerUsageDebugColor; // Offset: 0x3c // Size: 0x10
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x220 // Inherited bytes: 0x218
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	// Fields
	char bIsLayerThumbnail : 1; // Offset: 0x218 // Size: 0x01
	char bDisableTessellation : 1; // Offset: 0x218 // Size: 0x01
	char pad_0x218_2 : 6; // Offset: 0x218 // Size: 0x01
	char pad_0x219[0x7]; // Offset: 0x219 // Size: 0x07
};

// Object Name: Class Landscape.LandscapeMeshCollisionComponent
// Size: 0x860 // Inherited bytes: 0x840
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	// Fields
	struct FGuid MeshGuid; // Offset: 0x840 // Size: 0x10
	char pad_0x850[0x10]; // Offset: 0x850 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeMeshProxyActor
// Size: 0x3c8 // Inherited bytes: 0x3c0
struct ALandscapeMeshProxyActor : AActor {
	// Fields
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // Offset: 0x3c0 // Size: 0x08
};

// Object Name: Class Landscape.LandscapeMeshProxyComponent
// Size: 0x8c0 // Inherited bytes: 0x890
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	// Fields
	struct FGuid LandscapeGuid; // Offset: 0x890 // Size: 0x10
	struct TArray<struct FIntPoint> ProxyComponentBases; // Offset: 0x8a0 // Size: 0x10
	uint8_t ProxyLOD; // Offset: 0x8b0 // Size: 0x01
	char pad_0x8B1[0xf]; // Offset: 0x8b1 // Size: 0x0f
};

// Object Name: Class Landscape.LandscapeSplinesComponent
// Size: 0x790 // Inherited bytes: 0x760
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // Offset: 0x760 // Size: 0x10
	struct TArray<struct ULandscapeSplineSegment*> Segments; // Offset: 0x770 // Size: 0x10
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // Offset: 0x780 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeSplineControlPoint
// Size: 0x98 // Inherited bytes: 0x28
struct ULandscapeSplineControlPoint : UObject {
	// Fields
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x34 // Size: 0x0c
	float Width; // Offset: 0x40 // Size: 0x04
	float SideFalloff; // Offset: 0x44 // Size: 0x04
	float EndFalloff; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x60 // Size: 0x10
	struct FBox Bounds; // Offset: 0x70 // Size: 0x1c
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct UControlPointMeshComponent* LocalMeshComponent; // Offset: 0x90 // Size: 0x08
};

// Object Name: Class Landscape.LandscapeSplineSegment
// Size: 0xb0 // Inherited bytes: 0x28
struct ULandscapeSplineSegment : UObject {
	// Fields
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // Offset: 0x28 // Size: 0x30
	struct FInterpCurveVector SplineInfo; // Offset: 0x58 // Size: 0x18
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x70 // Size: 0x10
	struct FBox Bounds; // Offset: 0x80 // Size: 0x1c
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // Offset: 0xa0 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeStreamingProxy
// Size: 0x870 // Inherited bytes: 0x850
struct ALandscapeStreamingProxy : ALandscapeProxy {
	// Fields
	struct TLazyObjectPtr<struct ALandscape> LandscapeActor; // Offset: 0x850 // Size: 0x1c
	bool bLandscapeProxyUseSceenSizeLOD; // Offset: 0x86c // Size: 0x01
	char pad_0x86D[0x3]; // Offset: 0x86d // Size: 0x03
};

// Object Name: Class Landscape.MaterialExpressionLandscapeFlattenCoords
// Size: 0x98 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeFlattenCoords : UMaterialExpression {
	// Fields
	struct FExpressionInput UVScaleBias; // Offset: 0x60 // Size: 0x38
};

// Object Name: Class Landscape.MaterialExpressionLandscapeFlattenTexture
// Size: 0x98 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeFlattenTexture : UMaterialExpression {
	// Fields
	struct FExpressionInput Coordinates; // Offset: 0x60 // Size: 0x38
};

// Object Name: Class Landscape.MaterialExpressionLandscapeFlattenBaseColor
// Size: 0x98 // Inherited bytes: 0x98
struct UMaterialExpressionLandscapeFlattenBaseColor : UMaterialExpressionLandscapeFlattenTexture {
};

// Object Name: Class Landscape.MaterialExpressionLandscapeFlattenNormal
// Size: 0x98 // Inherited bytes: 0x98
struct UMaterialExpressionLandscapeFlattenNormal : UMaterialExpressionLandscapeFlattenTexture {
};

// Object Name: Class Landscape.MaterialExpressionLandscapeFlattenRSM
// Size: 0x98 // Inherited bytes: 0x98
struct UMaterialExpressionLandscapeFlattenRSM : UMaterialExpressionLandscapeFlattenTexture {
};

// Object Name: Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x70 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	// Fields
	struct TArray<struct FGrassInput> GrassTypes; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x80 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	// Fields
	struct TArray<struct FLayerBlendInput> Layers; // Offset: 0x60 // Size: 0x10
	struct FGuid ExpressionGUID; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0xb0 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	// Fields
	enum class ETerrainCoordMappingType MappingType; // Offset: 0x60 // Size: 0x01
	enum class ELandscapeCustomizedCoordType CustomUVType; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0x6]; // Offset: 0x62 // Size: 0x06
	struct FExpressionInput MappingScaleOverride; // Offset: 0x68 // Size: 0x38
	float MappingScale; // Offset: 0xa0 // Size: 0x04
	float MappingRotation; // Offset: 0xa4 // Size: 0x04
	float MappingPanU; // Offset: 0xa8 // Size: 0x04
	float MappingPanV; // Offset: 0xac // Size: 0x04
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x80 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	// Fields
	struct FName ParameterName; // Offset: 0x60 // Size: 0x08
	float PreviewWeight; // Offset: 0x68 // Size: 0x04
	struct FGuid ExpressionGUID; // Offset: 0x6c // Size: 0x10
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0xf0 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	// Fields
	struct FExpressionInput LayerUsed; // Offset: 0x60 // Size: 0x38
	struct FExpressionInput LayerNotUsed; // Offset: 0x98 // Size: 0x38
	struct FName ParameterName; // Offset: 0xd0 // Size: 0x08
	char PreviewUsed : 1; // Offset: 0xd8 // Size: 0x01
	char pad_0xD8_1 : 7; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x3]; // Offset: 0xd9 // Size: 0x03
	struct FGuid ExpressionGUID; // Offset: 0xdc // Size: 0x10
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0xf8 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	// Fields
	struct FExpressionInput Base; // Offset: 0x60 // Size: 0x38
	struct FExpressionInput Layer; // Offset: 0x98 // Size: 0x38
	struct FName ParameterName; // Offset: 0xd0 // Size: 0x08
	float PreviewWeight; // Offset: 0xd8 // Size: 0x04
	struct FVector ConstBase; // Offset: 0xdc // Size: 0x0c
	struct FGuid ExpressionGUID; // Offset: 0xe8 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x70 // Inherited bytes: 0x60
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
	// Fields
	struct FGuid ExpressionGUID; // Offset: 0x60 // Size: 0x10
};

