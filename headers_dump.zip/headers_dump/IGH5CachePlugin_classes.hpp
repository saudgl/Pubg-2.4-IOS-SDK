#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class IGH5CachePlugin.IGH5CachePluginSettings
// Size: 0x38 // Inherited bytes: 0x28
struct UIGH5CachePluginSettings : UObject {
	// Fields
	struct FString Html5Url; // Offset: 0x28 // Size: 0x10
};

