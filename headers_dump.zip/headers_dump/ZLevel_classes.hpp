#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ZLevel.ZLevelData
// Size: 0x4b0 // Inherited bytes: 0x3c0
struct AZLevelData : AActor {
	// Fields
	struct FGameLevelDesc LevelDesc; // Offset: 0x3c0 // Size: 0x18
	struct TArray<struct FString> TargetClassPaths; // Offset: 0x3d8 // Size: 0x10
	struct FString LeveDirectorFilePath; // Offset: 0x3e8 // Size: 0x10
	enum class ELevelEndCondType EndCondType; // Offset: 0x3f8 // Size: 0x01
	char pad_0x3F9[0x7]; // Offset: 0x3f9 // Size: 0x07
	struct FString EndCondPar; // Offset: 0x400 // Size: 0x10
	bool IsLastLevel; // Offset: 0x410 // Size: 0x01
	char pad_0x411[0x3]; // Offset: 0x411 // Size: 0x03
	int DiffcultPerc; // Offset: 0x414 // Size: 0x04
	struct TArray<struct UZPVECircle*> PVECircleConfigs; // Offset: 0x418 // Size: 0x10
	struct TArray<struct UZPVERelifePoint*> PVERelifePoints; // Offset: 0x428 // Size: 0x10
	struct TArray<struct UZMonsterSpotGroup*> MonsterSpotGroups; // Offset: 0x438 // Size: 0x10
	struct TArray<struct FVector> TaskPointLocations; // Offset: 0x448 // Size: 0x10
	struct TArray<struct FRelifePoint> PVERelifePointsInfo; // Offset: 0x458 // Size: 0x10
	struct TArray<struct FPVECircle> PVECircleInfo; // Offset: 0x468 // Size: 0x10
	struct TArray<struct FMonsterWave> MonsterWaveCfg; // Offset: 0x478 // Size: 0x10
	struct TArray<struct FLevelData> CfgList; // Offset: 0x488 // Size: 0x10
	struct TArray<struct FLevelObjets> LevelAddObjs; // Offset: 0x498 // Size: 0x10
	int CurComponentNameIndex; // Offset: 0x4a8 // Size: 0x04
	char pad_0x4AC[0x4]; // Offset: 0x4ac // Size: 0x04

	// Functions

	// Object Name: Function ZLevel.ZLevelData.ReBindLevelDataComponent
	// Flags: [Final|Native|Public]
	void ReBindLevelDataComponent(); // Offset: 0x10550ed5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ZLevel.ZLevelData.CheckMonsterSpotIsOnLand
	// Flags: [Final|Native|Public]
	void CheckMonsterSpotIsOnLand(struct UZMonsterSpot* MonsterSpot, struct UZMonsterSpotGroup* SpotGroup); // Offset: 0x10550ec40 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class ZLevel.ZSpotSceneComponent
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UZSpotSceneComponent : USceneComponent {
};

// Object Name: Class ZLevel.ZMonsterRoadPoint
// Size: 0x2e0 // Inherited bytes: 0x2d0
struct UZMonsterRoadPoint : UZSpotSceneComponent {
	// Fields
	int ID; // Offset: 0x2cc // Size: 0x04
	int Radius; // Offset: 0x2d0 // Size: 0x04
	char pad_0x2D8[0x8]; // Offset: 0x2d8 // Size: 0x08
};

// Object Name: Class ZLevel.ZMonsterSpot
// Size: 0x300 // Inherited bytes: 0x2d0
struct UZMonsterSpot : UZSpotSceneComponent {
	// Fields
	struct FString Desc; // Offset: 0x2d0 // Size: 0x10
	char MonsterSpotType; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E1[0x7]; // Offset: 0x2e1 // Size: 0x07
	struct TArray<struct UZMonsterRoadPoint*> RoadPointList; // Offset: 0x2e8 // Size: 0x10
	char SpotRadius; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x7]; // Offset: 0x2f9 // Size: 0x07
};

// Object Name: Class ZLevel.ZMonsterSpotGroup
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UZMonsterSpotGroup : USceneComponent {
	// Fields
	struct FString Desc; // Offset: 0x2d0 // Size: 0x10
	struct TArray<struct UZMonsterSpot*> SpotList; // Offset: 0x2e0 // Size: 0x10
};

// Object Name: Class ZLevel.ZPVECircle
// Size: 0x2f0 // Inherited bytes: 0x2d0
struct UZPVECircle : UZSpotSceneComponent {
	// Fields
	int CircleID; // Offset: 0x2cc // Size: 0x04
	struct FVector2D targetPos; // Offset: 0x2d0 // Size: 0x08
	float Radius; // Offset: 0x2d8 // Size: 0x04
	float MoveTime; // Offset: 0x2dc // Size: 0x04
	float Pain; // Offset: 0x2e0 // Size: 0x04
	char pad_0x2E8[0x8]; // Offset: 0x2e8 // Size: 0x08
};

// Object Name: Class ZLevel.ZPVERelifePoint
// Size: 0x2e0 // Inherited bytes: 0x2d0
struct UZPVERelifePoint : UZSpotSceneComponent {
	// Fields
	int ID; // Offset: 0x2cc // Size: 0x04
	bool IsActivePoint; // Offset: 0x2d0 // Size: 0x01
	char pad_0x2D5[0xb]; // Offset: 0x2d5 // Size: 0x0b
};

