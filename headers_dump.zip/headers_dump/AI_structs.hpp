#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AI.CacheSoundState
// Size: 0x18 // Inherited bytes: 0x00
struct FCacheSoundState {
	// Fields
	struct FSoundState SoundState; // Offset: 0x00 // Size: 0x14
	float Time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AI.SoundState
// Size: 0x14 // Inherited bytes: 0x00
struct FSoundState {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Location; // Offset: 0x04 // Size: 0x0c
	uint32_t ID; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AI.AIStateXYZ
// Size: 0x0c // Inherited bytes: 0x00
struct FAIStateXYZ {
	// Fields
	float X; // Offset: 0x00 // Size: 0x04
	float Y; // Offset: 0x04 // Size: 0x04
	float Z; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AI.CacheNearbyItemState
// Size: 0x20 // Inherited bytes: 0x00
struct FCacheNearbyItemState {
	// Fields
	struct TArray<struct FItemStateData> States; // Offset: 0x00 // Size: 0x10
	struct FVector Position; // Offset: 0x10 // Size: 0x0c
	bool IsDirty; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AI.ItemStateData
// Size: 0x20 // Inherited bytes: 0x00
struct FItemStateData {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	int ID; // Offset: 0x08 // Size: 0x04
	int UId; // Offset: 0x0c // Size: 0x04
	float Durability; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct AI.TriggeredCustomDamageEvent
// Size: 0xf0 // Inherited bytes: 0x00
struct FTriggeredCustomDamageEvent {
	// Fields
	struct FCustomDamageEventRow Event; // Offset: 0x00 // Size: 0xe8
	float TimeTriggered; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
};

// Object Name: ScriptStruct AI.CustomDamageEventRow
// Size: 0xe8 // Inherited bytes: 0x08
struct FCustomDamageEventRow : FTableRowBase {
	// Fields
	bool bProcessedLocally; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FGuid EventId; // Offset: 0x0c // Size: 0x10
	bool bEnabled; // Offset: 0x1c // Size: 0x01
	bool bClientOnly; // Offset: 0x1d // Size: 0x01
	bool bReplicate; // Offset: 0x1e // Size: 0x01
	bool bOnlyReplicateWhenRelevant; // Offset: 0x1f // Size: 0x01
	char EventTriggerType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float TriggerCooldown; // Offset: 0x24 // Size: 0x04
	float HealthPercentageThreshold; // Offset: 0x28 // Size: 0x04
	bool bTriggerWhenDead; // Offset: 0x2c // Size: 0x01
	char EventReactionType; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	struct UClass* ActorClassToSpawn; // Offset: 0x30 // Size: 0x28
	bool bTriggersGlobalCooldown; // Offset: 0x58 // Size: 0x01
	bool bLockedByGlobalCooldown; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
	struct UClass* OnCooldownActorClassToSpawn; // Offset: 0x60 // Size: 0x28
	bool bDestroySpawnedParticlesWithOwner; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
	struct FName AttachComponentTag; // Offset: 0x90 // Size: 0x08
	struct FName SpawnSocketName; // Offset: 0x98 // Size: 0x08
	struct FName CustomSpawnTransformTag; // Offset: 0xa0 // Size: 0x08
	bool bSpawnAtRandomPointInBoundingBox; // Offset: 0xa8 // Size: 0x01
	bool bUseCustomSpawnRotation; // Offset: 0xa9 // Size: 0x01
	char MinToSpawn; // Offset: 0xaa // Size: 0x01
	char MaxToSpawn; // Offset: 0xab // Size: 0x01
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FName ActorSpawnTag; // Offset: 0xb0 // Size: 0x08
	struct FName MeshComponentTag; // Offset: 0xb8 // Size: 0x08
	int MeshInstanceIndex; // Offset: 0xc0 // Size: 0x04
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	struct FName BoneName; // Offset: 0xc8 // Size: 0x08
	struct FName PhysicsAssetProfileName; // Offset: 0xd0 // Size: 0x08
	struct FName CollisionPrimitiveTag; // Offset: 0xd8 // Size: 0x08
	char pad_0xE0[0x8]; // Offset: 0xe0 // Size: 0x08
};

// Object Name: ScriptStruct AI.DebugAIParamConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FDebugAIParamConfig {
	// Fields
	int DistMin; // Offset: 0x00 // Size: 0x04
	int DistMax; // Offset: 0x04 // Size: 0x04
	struct FString NameAndDegree; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AI.TLogAIShootInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FTLogAIShootInfo {
	// Fields
	int TargetDistance; // Offset: 0x00 // Size: 0x04
	int TargetType; // Offset: 0x04 // Size: 0x04
	int WeaponID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoBase
// Size: 0x10 // Inherited bytes: 0x00
struct FDiffStateInfoBase {
	// Fields
	struct TArray<struct FString> IgnoreNames; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAIStateInfo
// Size: 0x420 // Inherited bytes: 0x10
struct FDiffAIStateInfo : FDiffStateInfoBase {
	// Fields
	struct FDiffAIPlayerState State; // Offset: 0x10 // Size: 0x88
	struct FAIHeardSound Sound; // Offset: 0x98 // Size: 0x10
	struct FDiffCameraState Camera; // Offset: 0xa8 // Size: 0x38
	struct FDiffAIPlayerWeapon Weapon; // Offset: 0xe0 // Size: 0x30
	struct FDiffPlayerBackpack BackPack; // Offset: 0x110 // Size: 0x30
	struct FDiffAIPlayerEquipment equipment; // Offset: 0x140 // Size: 0x30
	struct FDiffProgressBarState progress_bar; // Offset: 0x170 // Size: 0x18
	struct FDiffAINearbyPlayers nearby_player; // Offset: 0x188 // Size: 0x30
	struct FDiffItemStateDatas nearby_item; // Offset: 0x1b8 // Size: 0x30
	struct TArray<struct FObstacleState> nearby_obstacle; // Offset: 0x1e8 // Size: 0x10
	struct TArray<struct FAINearbyThrown> nearby_thrown; // Offset: 0x1f8 // Size: 0x10
	struct FDiffSafetyAreaState safety_area; // Offset: 0x208 // Size: 0x40
	struct FDiffAIGameState Game; // Offset: 0x248 // Size: 0x18
	struct TArray<struct FDoorState> nearby_door; // Offset: 0x260 // Size: 0x10
	struct FDiffRedZoneState red_zone; // Offset: 0x270 // Size: 0x28
	struct FAIDamageSources damage_sources; // Offset: 0x298 // Size: 0x30
	uint32_t Key; // Offset: 0x2c8 // Size: 0x04
	char pad_0x2CC[0x4]; // Offset: 0x2cc // Size: 0x04
	struct TArray<struct FItemStateData> nearby_box_item; // Offset: 0x2d0 // Size: 0x10
	struct FDiffVehicleState vehicle_state; // Offset: 0x2e0 // Size: 0x90
	struct FDiffVehicleStates nearby_vehicles; // Offset: 0x370 // Size: 0x30
	struct TArray<struct FAIRecipients> recipients; // Offset: 0x3a0 // Size: 0x10
	struct FAIPlayerHitInfo player_hit_info; // Offset: 0x3b0 // Size: 0x14
	char pad_0x3C4[0x4]; // Offset: 0x3c4 // Size: 0x04
	struct FAIBulletHoles bullet_holes; // Offset: 0x3c8 // Size: 0x20
	struct FDiffSpecialZone special_zone; // Offset: 0x3e8 // Size: 0x30
	uint32_t ai_style; // Offset: 0x418 // Size: 0x04
	char pad_0x41C[0x4]; // Offset: 0x41c // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffSpecialZone
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffSpecialZone : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffSpecialZoneState> State; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffSpecialZoneState
// Size: 0x48 // Inherited bytes: 0x10
struct FDiffSpecialZoneState : FDiffStateInfoBase {
	// Fields
	uint32_t ID; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoVector Center; // Offset: 0x14 // Size: 0x0c
	struct FDiffStateInfoFloat Radius; // Offset: 0x20 // Size: 0x04
	struct FDiffStateInfoUInt32 Type; // Offset: 0x24 // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x28 // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x34 // Size: 0x0c
	struct FDiffStateInfoInt32 custom_state; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoInt32
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoInt32 {
	// Fields
	int Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoVector
// Size: 0x0c // Inherited bytes: 0x00
struct FDiffStateInfoVector {
	// Fields
	struct FDiffStateInfoFloat X; // Offset: 0x00 // Size: 0x04
	struct FDiffStateInfoFloat Y; // Offset: 0x04 // Size: 0x04
	struct FDiffStateInfoFloat Z; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoFloat
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoFloat {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoUInt32
// Size: 0x04 // Inherited bytes: 0x00
struct FDiffStateInfoUInt32 {
	// Fields
	uint32_t Value; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AI.AIBulletHoles
// Size: 0x20 // Inherited bytes: 0x00
struct FAIBulletHoles {
	// Fields
	struct TArray<struct FAIStateXYZ> hole_pos; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAIStateXYZ> hole_source_pos; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIPlayerHitInfo
// Size: 0x14 // Inherited bytes: 0x00
struct FAIPlayerHitInfo {
	// Fields
	int fire_count; // Offset: 0x00 // Size: 0x04
	int hit_count; // Offset: 0x04 // Size: 0x04
	int hit_head_count; // Offset: 0x08 // Size: 0x04
	int hit_count_filter; // Offset: 0x0c // Size: 0x04
	int hit_head_filter; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AI.AIRecipients
// Size: 0x1c // Inherited bytes: 0x00
struct FAIRecipients {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	uint32_t team_id; // Offset: 0x04 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x08 // Size: 0x0c
	float HP; // Offset: 0x14 // Size: 0x04
	uint32_t Type; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffVehicleStates
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffVehicleStates : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffVehicleState> vehicle_states; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffVehicleState
// Size: 0x90 // Inherited bytes: 0x10
struct FDiffVehicleState : FDiffStateInfoBase {
	// Fields
	uint32_t ID; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x14 // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x20 // Size: 0x0c
	struct FDiffStateInfoFloat HP; // Offset: 0x2c // Size: 0x04
	struct FDiffStateInfoFloat gas; // Offset: 0x30 // Size: 0x04
	struct FDiffStateInfoVector Speed; // Offset: 0x34 // Size: 0x0c
	struct FDiffStateInfoUInt32 damaged_num; // Offset: 0x40 // Size: 0x04
	struct FDiffStateInfoUInt32 Category; // Offset: 0x44 // Size: 0x04
	struct FDiffStateInfoBool is_reverse; // Offset: 0x48 // Size: 0x01
	struct FDiffStateInfoBool has_player; // Offset: 0x49 // Size: 0x01
	struct FDiffStateInfoBool is_full; // Offset: 0x4a // Size: 0x01
	char pad_0x4B[0x5]; // Offset: 0x4b // Size: 0x05
	struct FDiffCameraState Camera; // Offset: 0x50 // Size: 0x38
	struct FDiffStateInfoInt32 location_state; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffCameraState
// Size: 0x38 // Inherited bytes: 0x10
struct FDiffCameraState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoVector Position; // Offset: 0x10 // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x1c // Size: 0x0c
	struct FDiffStateInfoVector view_position; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffStateInfoBool
// Size: 0x01 // Inherited bytes: 0x00
struct FDiffStateInfoBool {
	// Fields
	bool Value; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct AI.AIDamageSources
// Size: 0x30 // Inherited bytes: 0x00
struct FAIDamageSources {
	// Fields
	struct TArray<struct FAIStateXYZ> damage_source; // Offset: 0x00 // Size: 0x10
	struct TArray<int> damage_type; // Offset: 0x10 // Size: 0x10
	struct TArray<int> damage_weapon_type; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffRedZoneState
// Size: 0x28 // Inherited bytes: 0x10
struct FDiffRedZoneState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoVector Center; // Offset: 0x10 // Size: 0x0c
	struct FDiffStateInfoFloat Radius; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoFloat remain_time; // Offset: 0x20 // Size: 0x04
	struct FDiffStateInfoFloat start_time; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AI.DoorState
// Size: 0x38 // Inherited bytes: 0x00
struct FDoorState {
	// Fields
	struct FAIStateXYZ Position; // Offset: 0x00 // Size: 0x0c
	int State; // Offset: 0x0c // Size: 0x04
	uint32_t ID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FString> IgnoreNames; // Offset: 0x18 // Size: 0x10
	struct FAIStateXYZ Rotation; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffAIGameState
// Size: 0x18 // Inherited bytes: 0x10
struct FDiffAIGameState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoBool is_over; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FDiffStateInfoInt32 alive_player_count; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffSafetyAreaState
// Size: 0x40 // Inherited bytes: 0x10
struct FDiffSafetyAreaState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 State; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoVector Center; // Offset: 0x14 // Size: 0x0c
	struct FDiffStateInfoFloat Radius; // Offset: 0x20 // Size: 0x04
	struct FDiffStateInfoVector next_center; // Offset: 0x24 // Size: 0x0c
	struct FDiffStateInfoFloat next_radius; // Offset: 0x30 // Size: 0x04
	struct FDiffStateInfoInt32 Time; // Offset: 0x34 // Size: 0x04
	struct FDiffStateInfoInt32 total_time; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AI.AINearbyThrown
// Size: 0x38 // Inherited bytes: 0x10
struct FAINearbyThrown : FDiffStateInfoBase {
	// Fields
	int Type; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x14 // Size: 0x0c
	float remain_time; // Offset: 0x20 // Size: 0x04
	float explode_time; // Offset: 0x24 // Size: 0x04
	bool is_own; // Offset: 0x28 // Size: 0x01
	bool is_held; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	uint32_t ActorId; // Offset: 0x2c // Size: 0x04
	uint32_t sourceid; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct AI.ObstacleState
// Size: 0x28 // Inherited bytes: 0x00
struct FObstacleState {
	// Fields
	int Type; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	float HP; // Offset: 0x08 // Size: 0x04
	float max_hp; // Offset: 0x0c // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x10 // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x1c // Size: 0x0c
};

// Object Name: ScriptStruct AI.DiffItemStateDatas
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffItemStateDatas : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffItemStateData> Items; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffItemStateData
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffItemStateData : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Type; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 Category; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoUInt32 ID; // Offset: 0x18 // Size: 0x04
	int UId; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x20 // Size: 0x0c
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffAINearbyPlayers
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAINearbyPlayers : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAINearbyPlayer> Players; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAINearbyPlayer
// Size: 0xf8 // Inherited bytes: 0x10
struct FDiffAINearbyPlayer : FDiffStateInfoBase {
	// Fields
	struct FDiffAIPlayerState State; // Offset: 0x10 // Size: 0x88
	struct FDiffAIPlayerWeapon Weapon; // Offset: 0x98 // Size: 0x30
	struct FDiffAIPlayerEquipment equipment; // Offset: 0xc8 // Size: 0x30
};

// Object Name: ScriptStruct AI.DiffAIPlayerEquipment
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAIPlayerEquipment : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIEquipmentInfo> equipment_item; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAIEquipmentInfo
// Size: 0x20 // Inherited bytes: 0x10
struct FDiffAIEquipmentInfo : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Category; // Offset: 0x10 // Size: 0x04
	uint32_t ID; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoFloat Durability; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffAIPlayerWeapon
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffAIPlayerWeapon : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIWeaponStateInfo> player_weapon; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAIWeaponStateInfo
// Size: 0x38 // Inherited bytes: 0x10
struct FDiffAIWeaponStateInfo : FDiffStateInfoBase {
	// Fields
	uint32_t slot_id; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 Category; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoInt32 Type; // Offset: 0x18 // Size: 0x04
	struct FDiffStateInfoInt32 Bullet; // Offset: 0x1c // Size: 0x04
	struct FDiffStateInfoFloat remain_reloading; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int> attachments; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAIPlayerState
// Size: 0x88 // Inherited bytes: 0x10
struct FDiffAIPlayerState : FDiffStateInfoBase {
	// Fields
	uint32_t ID; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoInt32 actor_id; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoInt32 team_id; // Offset: 0x18 // Size: 0x04
	struct FDiffStateInfoVector Position; // Offset: 0x1c // Size: 0x0c
	struct FDiffStateInfoVector Rotation; // Offset: 0x28 // Size: 0x0c
	struct FDiffStateInfoVector Speed; // Offset: 0x34 // Size: 0x0c
	struct FDiffStateInfoFloat HP; // Offset: 0x40 // Size: 0x04
	struct FDiffStateInfoFloat Energy; // Offset: 0x44 // Size: 0x04
	struct FDiffStateInfoFloat dying_hp; // Offset: 0x48 // Size: 0x04
	struct FDiffStateInfoFloat oxygen; // Offset: 0x4c // Size: 0x04
	struct FDiffStateInfoInt32 active_weapon_slot; // Offset: 0x50 // Size: 0x04
	struct FDiffStateInfoInt32 weapon_status; // Offset: 0x54 // Size: 0x04
	struct FDiffStateInfoBool is_switching; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	struct FDiffStateInfoInt32 alive_state; // Offset: 0x5c // Size: 0x04
	struct FDiffStateInfoInt32 kill_count; // Offset: 0x60 // Size: 0x04
	struct FDiffStateInfoInt32 Damages; // Offset: 0x64 // Size: 0x04
	struct FDiffStateInfoBool is_running; // Offset: 0x68 // Size: 0x01
	struct FDiffStateInfoBool is_aiming; // Offset: 0x69 // Size: 0x01
	struct FDiffStateInfoBool is_left_probe; // Offset: 0x6a // Size: 0x01
	struct FDiffStateInfoBool is_right_probe; // Offset: 0x6b // Size: 0x01
	struct FDiffStateInfoBool is_floating; // Offset: 0x6c // Size: 0x01
	struct FDiffStateInfoBool is_diving; // Offset: 0x6d // Size: 0x01
	struct FDiffStateInfoBool is_vehicle_probe; // Offset: 0x6e // Size: 0x01
	struct FDiffStateInfoBool is_in_vehicle; // Offset: 0x6f // Size: 0x01
	struct FDiffStateInfoBool is_firing; // Offset: 0x70 // Size: 0x01
	struct FDiffStateInfoBool is_holding; // Offset: 0x71 // Size: 0x01
	struct FDiffStateInfoBool is_pose_acting; // Offset: 0x72 // Size: 0x01
	struct FDiffStateInfoBool is_picking; // Offset: 0x73 // Size: 0x01
	struct FDiffStateInfoInt32 body_state; // Offset: 0x74 // Size: 0x04
	struct FDiffStateInfoInt32 location_state; // Offset: 0x78 // Size: 0x04
	struct FDiffStateInfoBool has_smoke; // Offset: 0x7c // Size: 0x01
	char pad_0x7D[0x3]; // Offset: 0x7d // Size: 0x03
	struct FDiffStateInfoInt32 vehicle_role; // Offset: 0x80 // Size: 0x04
	struct FDiffStateInfoInt32 player_type; // Offset: 0x84 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffProgressBarState
// Size: 0x18 // Inherited bytes: 0x10
struct FDiffProgressBarState : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Type; // Offset: 0x10 // Size: 0x04
	struct FDiffStateInfoFloat remain_time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AI.DiffPlayerBackpack
// Size: 0x30 // Inherited bytes: 0x10
struct FDiffPlayerBackpack : FDiffStateInfoBase {
	// Fields
	struct TArray<struct FDiffAIBackpackItem> backpack_item; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> item_state; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.DiffAIBackpackItem
// Size: 0x20 // Inherited bytes: 0x10
struct FDiffAIBackpackItem : FDiffStateInfoBase {
	// Fields
	struct FDiffStateInfoInt32 Category; // Offset: 0x10 // Size: 0x04
	uint32_t ID; // Offset: 0x14 // Size: 0x04
	struct FDiffStateInfoUInt32 Count; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AI.AIHeardSound
// Size: 0x10 // Inherited bytes: 0x00
struct FAIHeardSound {
	// Fields
	struct TArray<struct FSoundState> heard_sound; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIStateInfo
// Size: 0x308 // Inherited bytes: 0x00
struct FAIStateInfo {
	// Fields
	struct FAIPlayerState State; // Offset: 0x00 // Size: 0x80
	struct FAIHeardSound Sound; // Offset: 0x80 // Size: 0x10
	struct FAIDamageSources damage_sources; // Offset: 0x90 // Size: 0x30
	struct FAIPlayerInteractInfo player_interact_info; // Offset: 0xc0 // Size: 0x30
	struct FCameraState Camera; // Offset: 0xf0 // Size: 0x24
	char pad_0x114[0x4]; // Offset: 0x114 // Size: 0x04
	struct FAIPlayerWeapon Weapon; // Offset: 0x118 // Size: 0x10
	struct FAIPlayerBackpack BackPack; // Offset: 0x128 // Size: 0x10
	struct FAIPlayerEquipment equipment; // Offset: 0x138 // Size: 0x10
	struct FProgressBarState progress_bar; // Offset: 0x148 // Size: 0x20
	struct TArray<struct FAINearbyPlayer> nearby_player; // Offset: 0x168 // Size: 0x10
	struct TArray<struct FItemStateData> nearby_item; // Offset: 0x178 // Size: 0x10
	struct TArray<struct FObstacleState> nearby_obstacle; // Offset: 0x188 // Size: 0x10
	struct TArray<struct FAINearbyThrown> nearby_thrown; // Offset: 0x198 // Size: 0x10
	struct TArray<struct FDoorState> nearby_door; // Offset: 0x1a8 // Size: 0x10
	struct FAIPlayerHitInfo player_hit_info; // Offset: 0x1b8 // Size: 0x14
	struct FSafetyAreaState safety_area; // Offset: 0x1cc // Size: 0x2c
	struct FRedZoneState red_zone; // Offset: 0x1f8 // Size: 0x18
	struct FAIGameState Game; // Offset: 0x210 // Size: 0x10
	uint32_t Key; // Offset: 0x220 // Size: 0x04
	uint32_t deliver_target_id; // Offset: 0x224 // Size: 0x04
	struct FVehicleState vehicle_state; // Offset: 0x228 // Size: 0x78
	struct TArray<struct FVehicleState> nearby_vehicles; // Offset: 0x2a0 // Size: 0x10
	struct FAIBulletHoles bullet_holes; // Offset: 0x2b0 // Size: 0x20
	struct TArray<struct FAIRecipients> recipients; // Offset: 0x2d0 // Size: 0x10
	struct TArray<struct FSpecialZoneState> special_zones; // Offset: 0x2e0 // Size: 0x10
	uint32_t ai_style; // Offset: 0x2f0 // Size: 0x04
	char pad_0x2F4[0x4]; // Offset: 0x2f4 // Size: 0x04
	struct TArray<struct FString> IgnoreNames; // Offset: 0x2f8 // Size: 0x10
};

// Object Name: ScriptStruct AI.SpecialZoneState
// Size: 0x34 // Inherited bytes: 0x00
struct FSpecialZoneState {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Center; // Offset: 0x04 // Size: 0x0c
	float Radius; // Offset: 0x10 // Size: 0x04
	uint32_t Type; // Offset: 0x14 // Size: 0x04
	int custom_state; // Offset: 0x18 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x1c // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x28 // Size: 0x0c
};

// Object Name: ScriptStruct AI.VehicleState
// Size: 0x78 // Inherited bytes: 0x00
struct FVehicleState {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x04 // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x10 // Size: 0x0c
	float HP; // Offset: 0x1c // Size: 0x04
	float gas; // Offset: 0x20 // Size: 0x04
	struct FAIStateXYZ Speed; // Offset: 0x24 // Size: 0x0c
	uint32_t damaged_num; // Offset: 0x30 // Size: 0x04
	uint32_t Category; // Offset: 0x34 // Size: 0x04
	bool is_reverse; // Offset: 0x38 // Size: 0x01
	bool has_player; // Offset: 0x39 // Size: 0x01
	bool is_full; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x1]; // Offset: 0x3b // Size: 0x01
	struct FCameraState Camera; // Offset: 0x3c // Size: 0x24
	int location_state; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<float> wheels_hp; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct AI.CameraState
// Size: 0x24 // Inherited bytes: 0x00
struct FCameraState {
	// Fields
	struct FAIStateXYZ Position; // Offset: 0x00 // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x0c // Size: 0x0c
	struct FAIStateXYZ view_position; // Offset: 0x18 // Size: 0x0c
};

// Object Name: ScriptStruct AI.AIGameState
// Size: 0x10 // Inherited bytes: 0x00
struct FAIGameState {
	// Fields
	bool is_over; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int alive_player_count; // Offset: 0x04 // Size: 0x04
	int Stage; // Offset: 0x08 // Size: 0x04
	uint32_t mode_map; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AI.RedZoneState
// Size: 0x18 // Inherited bytes: 0x00
struct FRedZoneState {
	// Fields
	struct FAIStateXYZ Center; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
	float remain_time; // Offset: 0x10 // Size: 0x04
	float start_time; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AI.SafetyAreaState
// Size: 0x2c // Inherited bytes: 0x00
struct FSafetyAreaState {
	// Fields
	int State; // Offset: 0x00 // Size: 0x04
	struct FAIStateXYZ Center; // Offset: 0x04 // Size: 0x0c
	float Radius; // Offset: 0x10 // Size: 0x04
	struct FAIStateXYZ next_center; // Offset: 0x14 // Size: 0x0c
	float next_radius; // Offset: 0x20 // Size: 0x04
	int Time; // Offset: 0x24 // Size: 0x04
	int total_time; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct AI.AINearbyPlayer
// Size: 0xa0 // Inherited bytes: 0x00
struct FAINearbyPlayer {
	// Fields
	struct FAIPlayerState State; // Offset: 0x00 // Size: 0x80
	struct FAIPlayerWeapon Weapon; // Offset: 0x80 // Size: 0x10
	struct FAIPlayerEquipment equipment; // Offset: 0x90 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIPlayerEquipment
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerEquipment {
	// Fields
	struct TArray<struct FAIEquipmentInfo> equipment_item; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIEquipmentInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FAIEquipmentInfo {
	// Fields
	int Category; // Offset: 0x00 // Size: 0x04
	int ID; // Offset: 0x04 // Size: 0x04
	float Durability; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AI.AIPlayerWeapon
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerWeapon {
	// Fields
	struct TArray<struct FAIWeaponStateInfo> player_weapon; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIWeaponStateInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FAIWeaponStateInfo {
	// Fields
	int slot_id; // Offset: 0x00 // Size: 0x04
	int Category; // Offset: 0x04 // Size: 0x04
	int Type; // Offset: 0x08 // Size: 0x04
	int Bullet; // Offset: 0x0c // Size: 0x04
	int bullet_in_backpak; // Offset: 0x10 // Size: 0x04
	float remain_reloading; // Offset: 0x14 // Size: 0x04
	struct TArray<int> attachments; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FString> IgnoreNames; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIPlayerState
// Size: 0x80 // Inherited bytes: 0x00
struct FAIPlayerState {
	// Fields
	uint32_t ID; // Offset: 0x00 // Size: 0x04
	uint32_t actor_id; // Offset: 0x04 // Size: 0x04
	int team_id; // Offset: 0x08 // Size: 0x04
	struct FAIStateXYZ Position; // Offset: 0x0c // Size: 0x0c
	struct FAIStateXYZ Rotation; // Offset: 0x18 // Size: 0x0c
	struct FAIStateXYZ Speed; // Offset: 0x24 // Size: 0x0c
	float HP; // Offset: 0x30 // Size: 0x04
	float Energy; // Offset: 0x34 // Size: 0x04
	float dying_hp; // Offset: 0x38 // Size: 0x04
	float oxygen; // Offset: 0x3c // Size: 0x04
	int active_weapon_slot; // Offset: 0x40 // Size: 0x04
	int weapon_status; // Offset: 0x44 // Size: 0x04
	bool is_switching; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	int alive_state; // Offset: 0x4c // Size: 0x04
	int kill_count; // Offset: 0x50 // Size: 0x04
	int Damages; // Offset: 0x54 // Size: 0x04
	bool is_running; // Offset: 0x58 // Size: 0x01
	bool is_aiming; // Offset: 0x59 // Size: 0x01
	bool is_left_probe; // Offset: 0x5a // Size: 0x01
	bool is_right_probe; // Offset: 0x5b // Size: 0x01
	bool is_floating; // Offset: 0x5c // Size: 0x01
	bool is_diving; // Offset: 0x5d // Size: 0x01
	bool is_vehicle_probe; // Offset: 0x5e // Size: 0x01
	bool is_in_vehicle; // Offset: 0x5f // Size: 0x01
	bool is_firing; // Offset: 0x60 // Size: 0x01
	bool is_holding; // Offset: 0x61 // Size: 0x01
	bool is_pose_acting; // Offset: 0x62 // Size: 0x01
	bool is_picking; // Offset: 0x63 // Size: 0x01
	bool is_weapon_near_wall; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	int body_state; // Offset: 0x68 // Size: 0x04
	int location_state; // Offset: 0x6c // Size: 0x04
	bool has_smoke; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x3]; // Offset: 0x71 // Size: 0x03
	int vehicle_role; // Offset: 0x74 // Size: 0x04
	int player_type; // Offset: 0x78 // Size: 0x04
	int ai_level; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct AI.ProgressBarState
// Size: 0x20 // Inherited bytes: 0x10
struct FProgressBarState : FDiffStateInfoBase {
	// Fields
	int Type; // Offset: 0x10 // Size: 0x04
	float remain_time; // Offset: 0x14 // Size: 0x04
	uint32_t targetid; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct AI.AIPlayerBackpack
// Size: 0x10 // Inherited bytes: 0x00
struct FAIPlayerBackpack {
	// Fields
	struct TArray<struct FAIBackpackItem> backpack_item; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIBackpackItem
// Size: 0x0c // Inherited bytes: 0x00
struct FAIBackpackItem {
	// Fields
	int Category; // Offset: 0x00 // Size: 0x04
	int ID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AI.AIPlayerInteractInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FAIPlayerInteractInfo {
	// Fields
	struct TArray<struct FAIDamageInfo> active_damage; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAIDamageInfo> passive_damage; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> kill_list; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AI.AIDamageInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAIDamageInfo {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	float Damage; // Offset: 0x04 // Size: 0x04
	int damage_type; // Offset: 0x08 // Size: 0x04
	int damage_weapon_type; // Offset: 0x0c // Size: 0x04
	uint32_t damage_part; // Offset: 0x10 // Size: 0x04
	float damage_before_cal_armor; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AI.BulletHole
// Size: 0x18 // Inherited bytes: 0x00
struct FBulletHole {
	// Fields
	struct FVector ImpactPoint; // Offset: 0x00 // Size: 0x0c
	struct FVector SourcePoint; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct AI.BulletHoleRecordInfo
// Size: 0x20 // Inherited bytes: 0x18
struct FBulletHoleRecordInfo : FBulletHole {
	// Fields
	struct APawn* ShootPawn; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AI.AIWinnerState
// Size: 0x18 // Inherited bytes: 0x10
struct FAIWinnerState : FDiffStateInfoBase {
	// Fields
	int team_id; // Offset: 0x10 // Size: 0x04
	int player_id; // Offset: 0x14 // Size: 0x04
};

