#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LoginRes_type.BP_STRUCT_LoginRes_type
// Size: 0x68 // Inherited bytes: 0x00
struct FBP_STRUCT_LoginRes_type {
	// Fields
	struct FString BeginTime_0_61E8AB401E0B8B054798D4B700EA1325; // Offset: 0x00 // Size: 0x10
	struct FString EndTime_1_75DE77C05915E9FF6F6F79DB0FE48785; // Offset: 0x10 // Size: 0x10
	int ID_2_500551805D3D3EB8005C1DB60AD29B84; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString ResPath_3_6DF67C00770BC06671BECC720D654108; // Offset: 0x28 // Size: 0x10
	struct FString BGMPath_4_459C2700734E2FA214B5EDF7032F4118; // Offset: 0x38 // Size: 0x10
	struct FString TexPath_5_02397DC0325EB369387098470F604108; // Offset: 0x48 // Size: 0x10
	struct FString VideoPath_6_2D0C0F403824D91B0A97369A07ADC1F8; // Offset: 0x58 // Size: 0x10
};

