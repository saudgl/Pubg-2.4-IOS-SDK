#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ProceduralMeshComponent.ProceduralMeshComponent
// Size: 0x7f0 // Inherited bytes: 0x790
struct UProceduralMeshComponent : UMeshComponent {
	// Fields
	bool bUseComplexAsSimpleCollision; // Offset: 0x790 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x791 // Size: 0x01
	char pad_0x792[0x6]; // Offset: 0x792 // Size: 0x06
	struct UBodySetup* ProcMeshBodySetup; // Offset: 0x798 // Size: 0x08
	struct TArray<struct FProcMeshSection> ProcMeshSections; // Offset: 0x7a0 // Size: 0x10
	struct TArray<struct FKConvexElem> CollisionConvexElems; // Offset: 0x7b0 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x7c0 // Size: 0x1c
	char pad_0x7DC[0x4]; // Offset: 0x7dc // Size: 0x04
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x7e0 // Size: 0x10

	// Functions

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection_LinearColor(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1022cff08 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1022cfc74 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility); // Offset: 0x1022cfbb8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionVisible(int SectionIndex); // Offset: 0x1022cfb2c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumSections(); // Offset: 0x1022cfaf8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection_LinearColor(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x1022cf7a4 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x1022cf450 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshSection(int SectionIndex); // Offset: 0x1022cf3d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCollisionConvexMeshes(); // Offset: 0x1022cf3c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshSections(); // Offset: 0x1022cf3ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts); // Offset: 0x1022cf2c8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ProceduralMeshComponent.KismetProceduralMeshLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UKismetProceduralMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.SliceProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SliceProceduralMesh(struct UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, struct UProceduralMeshComponent*& OutOtherHalfProcMesh, enum class EProcMeshSliceCapOption CapOption, struct UMaterialInterface* CapMaterial); // Offset: 0x1022ceb70 // Return & Params: Num(7) Size(0x40)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int LODIndex, int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1022ce870 // Return & Params: Num(8) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GenerateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GenerateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1022ce5e4 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, struct TArray<int>& Triangles); // Offset: 0x1022ce488 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CopyProceduralMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CopyProceduralMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComponent, int LODIndex, struct UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision); // Offset: 0x1022ce358 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConvertQuadToTriangles(struct TArray<int>& Triangles, int Vert0, int Vert1, int Vert2, int Vert3); // Offset: 0x1022ce1bc // Return & Params: Num(5) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1022cdf6c // Return & Params: Num(5) Size(0x50)
};

