#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Creative.CreativeObjectStaticMeshConfigInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FCreativeObjectStaticMeshConfigInfo {
	// Fields
	struct TArray<struct FCreativeStaticMeshConfigInfo> StaticMeshes; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshConfigInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeStaticMeshConfigInfo {
	// Fields
	struct FString MeshPath; // Offset: 0x00 // Size: 0x10
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
	struct TArray<struct FString> MaterialPaths; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct Creative.EditorObjectLiteComponentTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FEditorObjectLiteComponentTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct Creative.GameModeLiteComponentTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FGameModeLiteComponentTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct Creative.CreativeModeGameParameterContainer
// Size: 0xc8 // Inherited bytes: 0xb0
struct FCreativeModeGameParameterContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FCreativeModeGameParameter> Nodes; // Offset: 0xb0 // Size: 0x10
	struct UCreativeModeGameParameterManager* GameParameterManager; // Offset: 0xc0 // Size: 0x08
};

// Object Name: ScriptStruct Creative.CreativeModeGameParameter
// Size: 0x40 // Inherited bytes: 0x0c
struct FCreativeModeGameParameter : FFastArraySerializerItem {
	// Fields
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString ParameterKey; // Offset: 0x10 // Size: 0x10
	struct FString TemplateID; // Offset: 0x20 // Size: 0x10
	struct FString Desc; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Creative.GameStateLiteComponentTickFunction
// Size: 0x58 // Inherited bytes: 0x50
struct FGameStateLiteComponentTickFunction : FTickFunction {
	// Fields
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct Creative.CreativeGridLevelsActivationInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeGridLevelsActivationInfo {
	// Fields
	struct TMap<struct FIntVector, bool> LevelsActivationMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshObjectBatchInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeStaticMeshObjectBatchInfo {
	// Fields
	struct TMap<struct FString, struct FCreativeStaticMeshObjectBatchInfo_Grid> GridDataMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshObjectBatchInfo_Grid
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeStaticMeshObjectBatchInfo_Grid {
	// Fields
	struct TMap<struct FIntVector, struct FCreativeStaticMeshObjectBatchInfo_Cell> CellDataMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshObjectBatchInfo_Cell
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeStaticMeshObjectBatchInfo_Cell {
	// Fields
	struct TMap<int, struct FCreativeStaticMeshObjectBatchInfo_Asset> AssetDataMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshObjectBatchInfo_Asset
// Size: 0x60 // Inherited bytes: 0x00
struct FCreativeStaticMeshObjectBatchInfo_Asset {
	// Fields
	struct FCreativeObjectStaticMeshConfigInfo StaticMeshConfig; // Offset: 0x00 // Size: 0x10
	struct TMap<int, struct FCreativeStaticMeshObjectBatchInfo_Material> MaterialDataMap; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeStaticMeshObjectBatchInfo_Material
// Size: 0x10 // Inherited bytes: 0x00
struct FCreativeStaticMeshObjectBatchInfo_Material {
	// Fields
	struct TArray<struct FString> InstanceIds; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Creative.CreativeObjectBatchSignInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FCreativeObjectBatchSignInfo {
	// Fields
	struct FIntVector CellIndex; // Offset: 0x00 // Size: 0x0c
	int CurMaterialId; // Offset: 0x0c // Size: 0x04
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct Creative.CreativeModeGridLevelInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeModeGridLevelInfo {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeModeGridLevelConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FCreativeModeGridLevelConfig {
	// Fields
	struct FVector2D CellWidthHeight; // Offset: 0x00 // Size: 0x08
	float LoadingRange; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Creative.CreativeModeNodeContainer
// Size: 0xc8 // Inherited bytes: 0xb0
struct FCreativeModeNodeContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FCreativeModeNode> Nodes; // Offset: 0xb0 // Size: 0x10
	struct UCreativeModeInstanceManager* InstanceManager; // Offset: 0xc0 // Size: 0x08
};

// Object Name: ScriptStruct Creative.CreativeModeNode
// Size: 0x30 // Inherited bytes: 0x0c
struct FCreativeModeNode : FFastArraySerializerItem {
	// Fields
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString ID; // Offset: 0x10 // Size: 0x10
	struct TArray<char> NodeContent; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Creative.PlayerIntegralInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FPlayerIntegralInfo {
	// Fields
	int nCurIntegral; // Offset: 0x00 // Size: 0x04
	int nCurStageIntegral; // Offset: 0x04 // Size: 0x04
	int nIntegralAddSeq; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString UId; // Offset: 0x10 // Size: 0x10
	int TeamID; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Creative.CreativeBatchInstancedStaticMesh
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeBatchInstancedStaticMesh {
	// Fields
	struct TMap<int, struct FCreativeBatchInstancedStaticMesh_AssetID> MaterialISMMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeBatchInstancedStaticMesh_AssetID
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeBatchInstancedStaticMesh_AssetID {
	// Fields
	struct TMap<int, struct FCreativeBatchInstancedStaticMesh_MaterialId> AllISMMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Creative.CreativeBatchInstancedStaticMesh_MaterialId
// Size: 0xa0 // Inherited bytes: 0x00
struct FCreativeBatchInstancedStaticMesh_MaterialId {
	// Fields
	struct TMap<int, struct UInstancedStaticMeshComponent*> ISMMap; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FString, int> CurLoadedInstances; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct Creative.RuntimeCacheRoundBattleDataInfoContainer
// Size: 0xc8 // Inherited bytes: 0xb0
struct FRuntimeCacheRoundBattleDataInfoContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FRuntimeCacheRoundBattleDataInfo> OldRoundCacheTeamRuntimeDataList; // Offset: 0xb0 // Size: 0x10
	struct ACreativeRuntimePlayerBattleDataObject* BattleDataObject; // Offset: 0xc0 // Size: 0x08
};

// Object Name: ScriptStruct Creative.RuntimeCacheRoundBattleDataInfo
// Size: 0x20 // Inherited bytes: 0x0c
struct FRuntimeCacheRoundBattleDataInfo : FFastArraySerializerItem {
	// Fields
	int RoundIndex; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FRuntimePlayerBattleDataInfo> PlayerBattleDataList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Creative.RuntimePlayerBattleDataInfo
// Size: 0x58 // Inherited bytes: 0x0c
struct FRuntimePlayerBattleDataInfo : FFastArraySerializerItem {
	// Fields
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	uint64 UId; // Offset: 0x10 // Size: 0x08
	int TeamID; // Offset: 0x18 // Size: 0x04
	int WinningRoundNum; // Offset: 0x1c // Size: 0x04
	int AIKillCount; // Offset: 0x20 // Size: 0x04
	int KillCount; // Offset: 0x24 // Size: 0x04
	int MonsterKillCount; // Offset: 0x28 // Size: 0x04
	int AssistCount; // Offset: 0x2c // Size: 0x04
	enum class ExtraPlayerLiveState PlayerLiveState; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	float SurvivalTime; // Offset: 0x34 // Size: 0x04
	int DeadCount; // Offset: 0x38 // Size: 0x04
	float CauseTotalDamage; // Offset: 0x3c // Size: 0x04
	float CauseMonsterTotalDamage; // Offset: 0x40 // Size: 0x04
	float CauseRoleTotalDamage; // Offset: 0x44 // Size: 0x04
	float TakeTotalDamage; // Offset: 0x48 // Size: 0x04
	float TakeRoleTotalDamage; // Offset: 0x4c // Size: 0x04
	float TakeMonsterTotalDamage; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct Creative.RuntimeBattleDataInfoContainer
// Size: 0xc8 // Inherited bytes: 0xb0
struct FRuntimeBattleDataInfoContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FRuntimePlayerBattleDataInfo> CurRuntimePlayerBattleDataList; // Offset: 0xb0 // Size: 0x10
	struct ACreativeRuntimePlayerBattleDataObject* BattleDataObject; // Offset: 0xc0 // Size: 0x08
};

// Object Name: ScriptStruct Creative.CreativeModeGridCellChangeInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FCreativeModeGridCellChangeInfo {
	// Fields
	struct FIntVector CellIndex; // Offset: 0x00 // Size: 0x0c
	bool LoadState; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct Creative.CreativeModeStreamingParameters
// Size: 0x50 // Inherited bytes: 0x00
struct FCreativeModeStreamingParameters {
	// Fields
	enum class ECreativeModeActorStreamingType StreamingType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0xf]; // Offset: 0x01 // Size: 0x0f
	struct FTransform Transform; // Offset: 0x10 // Size: 0x30
	int Distance; // Offset: 0x40 // Size: 0x04
	bool bSpawnState; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0xb]; // Offset: 0x45 // Size: 0x0b
};

