#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SkillPropsBPTable_type.BP_STRUCT_SkillPropsBPTable_type
// Size: 0x34 // Inherited bytes: 0x00
struct FBP_STRUCT_SkillPropsBPTable_type {
	// Fields
	struct FString Path_0_7125AC0045061D844040043E0816E498; // Offset: 0x00 // Size: 0x10
	struct FString CName_1_638079C0129E37EF7ABD58DE018085B5; // Offset: 0x10 // Size: 0x10
	struct FString Wrapper_2_17D6010032F6D6462C8642BA064BF7A2; // Offset: 0x20 // Size: 0x10
	int ID_3_3E5DCC006BF812EC2517437F0C381754; // Offset: 0x30 // Size: 0x04
};

