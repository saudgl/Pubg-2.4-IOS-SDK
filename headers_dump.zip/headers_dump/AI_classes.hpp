#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AI.AESpawnSubsystem
// Size: 0x1a0 // Inherited bytes: 0x130
struct UAESpawnSubsystem : USTSpawnSubsystem {
	// Fields
	struct FMonsterParams CacheMobParams; // Offset: 0x130 // Size: 0x58
	struct FFakePlayerParams CacheFPParams; // Offset: 0x188 // Size: 0x10
	char pad_0x198[0x8]; // Offset: 0x198 // Size: 0x08

	// Functions

	// Object Name: Function AI.AESpawnSubsystem.SpawnUnit
	// Flags: [Native|Protected|BlueprintCallable]
	struct AActor* SpawnUnit(struct FSTSpawnParam SpawnParam); // Offset: 0x103af8f44 // Return & Params: Num(2) Size(0xa8)

	// Object Name: Function AI.AESpawnSubsystem.PreCheck
	// Flags: [Native|Protected|BlueprintCallable]
	bool PreCheck(); // Offset: 0x103af8f08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawnSubsystem.GetUnitConfigID
	// Flags: [Native|Protected|BlueprintCallable|BlueprintPure|Const]
	int GetUnitConfigID(struct AActor* Unit); // Offset: 0x103af8e74 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class AI.AESpawner
// Size: 0x540 // Inherited bytes: 0x510
struct AAESpawner : ASTSpawnerBase {
	// Fields
	char bEnableTeamAI : 1; // Offset: 0x50c // Size: 0x01
	struct TArray<struct UActorComponent*> TeamAIClasses; // Offset: 0x510 // Size: 0x10
	int SpawnerCampItemID; // Offset: 0x520 // Size: 0x04
	int SpawnerTeamID; // Offset: 0x524 // Size: 0x04
	enum class EBotCategray SpeciesCategory; // Offset: 0x528 // Size: 0x01
	char pad_0x529_1 : 7; // Offset: 0x529 // Size: 0x01
	char pad_0x52A[0x6]; // Offset: 0x52a // Size: 0x06
	struct TArray<struct UActorComponent*> TeamAIComponents; // Offset: 0x530 // Size: 0x10

	// Functions

	// Object Name: Function AI.AESpawner.SwitchTeamAI
	// Flags: [Final|Native|Public]
	void SwitchTeamAI(bool bEnable); // Offset: 0x103af9b4c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.OnUnitSpawned
	// Flags: [Native|Public]
	void OnUnitSpawned(uint32_t InSpawnerID, struct APawn* AIPawn, int ConfigId); // Offset: 0x103af9a50 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AI.AESpawner.OnSpawnTimingRipe
	// Flags: [Native|Protected]
	void OnSpawnTimingRipe(bool IsRipe); // Offset: 0x103af99c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.OnOwnedMobDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	void OnOwnedMobDead(struct ASTExtraSimpleCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType); // Offset: 0x103af97f4 // Return & Params: Num(6) Size(0xb8)

	// Object Name: Function AI.AESpawner.OnOwnedFakePlayerDead
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	void OnOwnedFakePlayerDead(struct ASTExtraBaseCharacter* DeadCharacter, struct AController* Killer, struct AActor* DamageCauser, struct FHitResult& KillingHitInfo, struct FVector KillingHitImpulseDir, struct UDamageType* KillingHitDamageType); // Offset: 0x103af9624 // Return & Params: Num(6) Size(0xb8)

	// Object Name: Function AI.AESpawner.GetSpeciesCategory
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EBotCategray GetSpeciesCategory(); // Offset: 0x103af9608 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AESpawner.GenerateParamID
	// Flags: [Event|Public|BlueprintEvent]
	int GenerateParamID(int ConfigId, int BaseParamID); // Offset: 0x103e03170 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AESpawner.DeactivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void DeactivateSpawner(); // Offset: 0x103af95ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AESpawner.BPOnUnitSpawned
	// Flags: [Event|Public|BlueprintEvent]
	void BPOnUnitSpawned(struct APawn* AIPawn, int ConfigId); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AI.AESpawner.ActivateSpawner
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateSpawner(); // Offset: 0x103af95d0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.AIActionExecutionComponent
// Size: 0x1f0 // Inherited bytes: 0x1d8
struct UAIActionExecutionComponent : ULuaActorComponent {
	// Fields
	struct ANewFakePlayerAIController* MyController; // Offset: 0x1d8 // Size: 0x08
	struct ASTExtraBaseCharacter* MyPlayerPawn; // Offset: 0x1e0 // Size: 0x08
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0x1e8 // Size: 0x08

	// Functions

	// Object Name: Function AI.AIActionExecutionComponent.SetFocusRotation
	// Flags: [Final|Native|Public]
	void SetFocusRotation(float InPitch, float InYaw, float InRoll); // Offset: 0x103afad50 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AIActionExecutionComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103afad1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIActionExecutionComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103afac90 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionMove
	// Flags: [Final|Native|Public]
	void DoActionMove(bool IsRun, float DirectionX, float DirectionY, float DirectionZ); // Offset: 0x103afab54 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103afaa18 // Return & Params: Num(4) Size(0x10)
};

// Object Name: Class AI.AISoundCollectionComponent
// Size: 0x2f8 // Inherited bytes: 0x1d8
struct UAISoundCollectionComponent : ULuaActorComponent {
	// Fields
	struct TMap<uint32_t, struct FCacheSoundState> CacheStepSounds; // Offset: 0x1d8 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheWeaponSounds; // Offset: 0x228 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheVehicleSounds; // Offset: 0x278 // Size: 0x50
	char pad_0x2C8[0x18]; // Offset: 0x2c8 // Size: 0x18
	float ClearStepSoundTime; // Offset: 0x2e0 // Size: 0x04
	float ClearWeaponSoundTime; // Offset: 0x2e4 // Size: 0x04
	float ClearVehicleSoundTime; // Offset: 0x2e8 // Size: 0x04
	int StepSoundMaxNum; // Offset: 0x2ec // Size: 0x04
	int WeaponSoundMaxNum; // Offset: 0x2f0 // Size: 0x04
	int VehicleSoundMaxNum; // Offset: 0x2f4 // Size: 0x04

	// Functions

	// Object Name: Function AI.AISoundCollectionComponent.OnCollectionHearSound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void OnCollectionHearSound(enum class ESoundType soundType, struct FVector& InPos, struct AActor* InSourceActor); // Offset: 0x103afb53c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AISoundCollectionComponent.GetCollectSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetCollectSoundInfo(); // Offset: 0x103afb4d8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AI.AIStateInfoComponent
// Size: 0xac8 // Inherited bytes: 0x110
struct UAIStateInfoComponent : UActorComponent {
	// Fields
	struct TMap<int, int> ProgressSkillConfig; // Offset: 0x110 // Size: 0x50
	struct TMap<int, bool> AvailableBackpacItemTypes; // Offset: 0x160 // Size: 0x50
	struct TMap<int, int> GrenadeTypeConfig; // Offset: 0x1b0 // Size: 0x50
	float VisibleAngle; // Offset: 0x200 // Size: 0x04
	struct FVector HeadOffset; // Offset: 0x204 // Size: 0x0c
	float NearByEnemyRange; // Offset: 0x210 // Size: 0x04
	float FogWeatherRangeScale; // Offset: 0x214 // Size: 0x04
	int NearByEnemyMaxNum; // Offset: 0x218 // Size: 0x04
	bool IsSearchNearItem; // Offset: 0x21c // Size: 0x01
	char pad_0x21D[0x3]; // Offset: 0x21d // Size: 0x03
	int NearbyItemMaxNum; // Offset: 0x220 // Size: 0x04
	int NearbyMaxBoxNum; // Offset: 0x224 // Size: 0x04
	float NearbyAirDropBoxRangeInner; // Offset: 0x228 // Size: 0x04
	float NearbyAirDropBoxRangeOuter; // Offset: 0x22c // Size: 0x04
	float NearbyDeathBoxRange; // Offset: 0x230 // Size: 0x04
	float NearbyPickUpWrapperRange; // Offset: 0x234 // Size: 0x04
	float CacheNearbyItemRangeCoefficient; // Offset: 0x238 // Size: 0x04
	float NearbyFindBuildingRange; // Offset: 0x23c // Size: 0x04
	float ItemStateChangedRange; // Offset: 0x240 // Size: 0x04
	bool IsItemVisiable; // Offset: 0x244 // Size: 0x01
	bool IsUseItemSpotLoc; // Offset: 0x245 // Size: 0x01
	char pad_0x246[0x2]; // Offset: 0x246 // Size: 0x02
	float NearbyObstacleRange; // Offset: 0x248 // Size: 0x04
	float NearbyThrownRange; // Offset: 0x24c // Size: 0x04
	int NearbyThrownMaxNum; // Offset: 0x250 // Size: 0x04
	char pad_0x254[0x4]; // Offset: 0x254 // Size: 0x04
	int NearbyDoorMaxNum; // Offset: 0x258 // Size: 0x04
	int NearbyVehicleRange; // Offset: 0x25c // Size: 0x04
	int NearbyVehicleMaxNum; // Offset: 0x260 // Size: 0x04
	float NearbyBulletHoleRange; // Offset: 0x264 // Size: 0x04
	int NearbyBulletHoleMaxNum; // Offset: 0x268 // Size: 0x04
	char pad_0x26C[0x4]; // Offset: 0x26c // Size: 0x04
	struct FAIStateInfo CacheAIStateInfo; // Offset: 0x270 // Size: 0x308
	struct FDiffAIStateInfo CacheDiffAIStateInfo; // Offset: 0x578 // Size: 0x420
	struct FRedZoneState CacheRedZoneInfo; // Offset: 0x998 // Size: 0x18
	float AirAttackTotalTime; // Offset: 0x9b0 // Size: 0x04
	bool IsTouchedPlayer; // Offset: 0x9b4 // Size: 0x01
	bool bIgnoreTreeAIWhenNoPlayerAround; // Offset: 0x9b5 // Size: 0x01
	char pad_0x9B6[0x2]; // Offset: 0x9b6 // Size: 0x02
	float IgnoreTreeAIRadius; // Offset: 0x9b8 // Size: 0x04
	bool bSendPlayerSimpleInfo; // Offset: 0x9bc // Size: 0x01
	char pad_0x9BD[0x3]; // Offset: 0x9bd // Size: 0x03
	uint32_t FrameNo; // Offset: 0x9c0 // Size: 0x04
	char pad_0x9C4[0x4]; // Offset: 0x9c4 // Size: 0x04
	struct UAirAttackComponent* AirAttackComp; // Offset: 0x9c8 // Size: 0x08
	struct APawn* MyOwnerPawn; // Offset: 0x9d0 // Size: 0x08
	struct ABattleRoyaleGameModeBase* MyGameMode; // Offset: 0x9d8 // Size: 0x08
	char pad_0x9E0[0x60]; // Offset: 0x9e0 // Size: 0x60
	struct TMap<int, struct APickUpWrapperActor*> CacheAINearByItem; // Offset: 0xa40 // Size: 0x50
	struct FCacheNearbyItemState CacheNearbyItemState; // Offset: 0xa90 // Size: 0x20
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0xab0 // Size: 0x08
	uint32_t CacheModeMapId; // Offset: 0xab8 // Size: 0x04
	char pad_0xABC[0xc]; // Offset: 0xabc // Size: 0x0c

	// Functions

	// Object Name: Function AI.AIStateInfoComponent.QueryItemStates
	// Flags: [Final|Native|Public]
	struct TArray<struct FItemStateData> QueryItemStates(int MaxBoxNum, int MaxItemNum, float AirDropBoxRangeInner, float AirDropBoxRangeOuter, float DeathBoxRange, float PickUpWrapperRange, float FindBuildingRange, bool InIsUseItemSpotLoc); // Offset: 0x103afd50c // Return & Params: Num(9) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103afd490 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.OnAirAttackInfo
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnAirAttackInfo(enum class EAirAttackInfo airattacktype, int waveIndex, struct FAirAttackOrder& InAirAttackOrder, struct FVector& InAirAttackArea); // Offset: 0x103afd2f4 // Return & Params: Num(4) Size(0x64)

	// Object Name: Function AI.AIStateInfoComponent.IsAvailableBackpacItemType
	// Flags: [Final|Native|Public|Const]
	bool IsAvailableBackpacItemType(struct FItemDefineID DefineID); // Offset: 0x103afd258 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function AI.AIStateInfoComponent.HasPlayerAround
	// Flags: [Final|Native|Private]
	bool HasPlayerAround(); // Offset: 0x103afd224 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIStateInfoComponent.GetViewForwardVector
	// Flags: [Final|Native|Private|HasDefaults]
	struct FVector GetViewForwardVector(struct ACharacter* InCharacter); // Offset: 0x103afd194 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AI.AIStateInfoComponent.GetVehicleStatus
	// Flags: [Final|Native|Public]
	struct FVehicleState GetVehicleStatus(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraBaseCharacter* PawnInCar); // Offset: 0x103afd0a4 // Return & Params: Num(3) Size(0x88)

	// Object Name: Function AI.AIStateInfoComponent.GetTLogAIShootInfo
	// Flags: [Final|Native|Public]
	struct FTLogAIShootInfo GetTLogAIShootInfo(); // Offset: 0x103afd06c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.GetSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetSoundInfo(); // Offset: 0x103afd008 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetProgressBarState
	// Flags: [Final|Native|Public]
	struct FProgressBarState GetProgressBarState(); // Offset: 0x103afcfa4 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function AI.AIStateInfoComponent.GetPlayerInteractInfo
	// Flags: [Final|Native|Public]
	struct FAIPlayerInteractInfo GetPlayerInteractInfo(); // Offset: 0x103afcf40 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103afceb4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetObstaclesState
	// Flags: [Final|Native|Public]
	struct TArray<struct FObstacleState> GetObstaclesState(float Range); // Offset: 0x103afce00 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetNearbyVehicles
	// Flags: [Final|Native|Public]
	struct TArray<struct FVehicleState> GetNearbyVehicles(struct ASTExtraBaseCharacter* InPawn); // Offset: 0x103afcd4c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetFrameNo
	// Flags: [Final|Native|Private]
	uint32_t GetFrameNo(); // Offset: 0x103afcd30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.AIStateInfoComponent.GetDoorsState
	// Flags: [Final|Native|Public]
	struct TArray<struct FDoorState> GetDoorsState(float Range, int MaxNum); // Offset: 0x103afcc40 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetDiffAIStateInfo
	// Flags: [Final|Native|Public]
	struct FDiffAIStateInfo GetDiffAIStateInfo(); // Offset: 0x103afcbdc // Return & Params: Num(1) Size(0x420)

	// Object Name: Function AI.AIStateInfoComponent.GetDamageSources
	// Flags: [Final|Native|Public]
	struct FAIDamageSources GetDamageSources(); // Offset: 0x103afcb78 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetCameraState
	// Flags: [Final|Native|Public]
	struct FCameraState GetCameraState(struct ASTExtraBaseCharacter* InCharacter); // Offset: 0x103afcadc // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function AI.AIStateInfoComponent.GetAllPlayerStateInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FAIStateInfo> GetAllPlayerStateInfo(); // Offset: 0x103afca78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfoInternal
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfoInternal(); // Offset: 0x103afca14 // Return & Params: Num(1) Size(0x308)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfo
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfo(); // Offset: 0x103afc9b0 // Return & Params: Num(1) Size(0x308)

	// Object Name: Function AI.AIStateInfoComponent.GetAIPlayerBackpackItems
	// Flags: [Final|Native|Public]
	struct TArray<struct FAIBackpackItem> GetAIPlayerBackpackItems(struct ABaseAIController* InController); // Offset: 0x103afc8fc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetAINearbyThrownState
	// Flags: [Final|Native|Public]
	struct TArray<struct FAINearbyThrown> GetAINearbyThrownState(struct ASTExtraBaseCharacter* InCharacter, float InRange, float InCheckAngle, int MaxNum); // Offset: 0x103afc798 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function AI.AIStateInfoComponent.ClearPlayerInteractInfo
	// Flags: [Final|Native|Public]
	void ClearPlayerInteractInfo(); // Offset: 0x103afc784 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIStateInfoComponent.ClearDamageSources
	// Flags: [Final|Native|Public]
	void ClearDamageSources(); // Offset: 0x103afc770 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.CustomDamageEventComponent
// Size: 0x310 // Inherited bytes: 0x1d8
struct UCustomDamageEventComponent : ULuaActorComponent {
	// Fields
	struct FScriptMulticastDelegate OnSpawnActor; // Offset: 0x1d8 // Size: 0x10
	struct UDataTable* EventDataTable; // Offset: 0x1e8 // Size: 0x28
	float ActorSpawnGlobalCooldown; // Offset: 0x210 // Size: 0x04
	char pad_0x214[0x4]; // Offset: 0x214 // Size: 0x04
	struct FScriptMulticastDelegate OnThrowBox; // Offset: 0x218 // Size: 0x10
	char pad_0x228[0x4]; // Offset: 0x228 // Size: 0x04
	float OwnerHealthPercentage; // Offset: 0x22c // Size: 0x04
	char pad_0x230[0x10]; // Offset: 0x230 // Size: 0x10
	struct TArray<struct FTriggeredCustomDamageEvent> ClientEvents; // Offset: 0x240 // Size: 0x10
	char pad_0x250[0x70]; // Offset: 0x250 // Size: 0x70
	struct TMap<struct FName, struct UObject*> CacheUObjectMap; // Offset: 0x2c0 // Size: 0x50

	// Functions

	// Object Name: Function AI.CustomDamageEventComponent.OnRep_ClientEvents
	// Flags: [Final|Native|Protected]
	void OnRep_ClientEvents(); // Offset: 0x103affd5c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.CharacterCustomDamageEventComponent
// Size: 0x318 // Inherited bytes: 0x310
struct UCharacterCustomDamageEventComponent : UCustomDamageEventComponent {
	// Fields
	char pad_0x310[0x8]; // Offset: 0x310 // Size: 0x08

	// Functions

	// Object Name: Function AI.CharacterCustomDamageEventComponent.OnTakeDamageEvent
	// Flags: [Final|Native|Public|HasOutParms]
	void OnTakeDamageEvent(float Damage, struct FDamageEvent& DamageEvent, struct AActor* Victim, struct AActor* Causer); // Offset: 0x103aff48c // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class AI.MLAIControllerComponent
// Size: 0x258 // Inherited bytes: 0x110
struct UMLAIControllerComponent : UActorComponent {
	// Fields
	struct UActorComponent* AIActionExcutionCompClass; // Offset: 0x110 // Size: 0x08
	struct UActorComponent* AISoundCollectCompClass; // Offset: 0x118 // Size: 0x08
	struct UActorComponent* AIStateInfoCompClass; // Offset: 0x120 // Size: 0x08
	struct UAIActionExecutionComponent* AIActionExecutionComp; // Offset: 0x128 // Size: 0x08
	struct UAIStateInfoComponent* AIStateInfoComp; // Offset: 0x130 // Size: 0x08
	struct UAISoundCollectionComponent* AISoundCollectComp; // Offset: 0x138 // Size: 0x08
	float HearRadius; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct TMap<enum class ESTEPoseState, struct FCameraViewPitchLimitData> CameraViewPitchLimitDataMap; // Offset: 0x148 // Size: 0x50
	struct FVector PrePos; // Offset: 0x198 // Size: 0x0c
	float PreTickTime; // Offset: 0x1a4 // Size: 0x04
	struct ANewFakePlayerAIController* MyController; // Offset: 0x1a8 // Size: 0x08
	char pad_0x1B0[0x14]; // Offset: 0x1b0 // Size: 0x14
	float FindNavLocationRadius; // Offset: 0x1c4 // Size: 0x04
	int MaxNavLocationFindTimes; // Offset: 0x1c8 // Size: 0x04
	bool bUseLerpRotation; // Offset: 0x1cc // Size: 0x01
	char pad_0x1CD[0x3]; // Offset: 0x1cd // Size: 0x03
	float LerpRotationThreshold; // Offset: 0x1d0 // Size: 0x04
	bool IsForceTargetRotation; // Offset: 0x1d4 // Size: 0x01
	char pad_0x1D5[0x3]; // Offset: 0x1d5 // Size: 0x03
	float FirstLerpRotationDeltaTime; // Offset: 0x1d8 // Size: 0x04
	float FreeCameraTurnVelocity; // Offset: 0x1dc // Size: 0x04
	char pad_0x1E0[0x4]; // Offset: 0x1e0 // Size: 0x04
	bool IsModifyDamageLuaOverride; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E5[0x3]; // Offset: 0x1e5 // Size: 0x03
	float RatingDamageScaleLuaOverride; // Offset: 0x1e8 // Size: 0x04
	bool bShouldSendVehicleInfo; // Offset: 0x1ec // Size: 0x01
	char pad_0x1ED[0x6b]; // Offset: 0x1ed // Size: 0x6b

	// Functions

	// Object Name: Function AI.MLAIControllerComponent.UnBindDelegates
	// Flags: [Final|Native|Public]
	void UnBindDelegates(bool IsEndPlay); // Offset: 0x103b00ae4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.SetLuaAIParamConfigString
	// Flags: [Final|Native|Public]
	void SetLuaAIParamConfigString(struct FString InAIParamConfigString); // Offset: 0x103b00a28 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.RestartFightBehaviorTree
	// Flags: [Final|Native|Public]
	void RestartFightBehaviorTree(); // Offset: 0x103b00a14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAIControllerComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103b009e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults]
	struct FRotator GetViewRotation(); // Offset: 0x103b009a8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetViewForwardVector
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector GetViewForwardVector(); // Offset: 0x103b00970 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetAIStateInfoComp
	// Flags: [Final|Native|Public|Const]
	struct UAIStateInfoComponent* GetAIStateInfoComp(); // Offset: 0x103b00954 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.GetAIActionExecutionComp
	// Flags: [Final|Native|Public|Const]
	struct UAIActionExecutionComponent* GetAIActionExecutionComp(); // Offset: 0x103b00938 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103b007fc // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.CheckCameraViewPitchLimit
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool CheckCameraViewPitchLimit(struct FRotator& InOutTargetRot); // Offset: 0x103b00764 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function AI.MLAIControllerComponent.BindDelegates
	// Flags: [Final|Native|Public]
	void BindDelegates(); // Offset: 0x103b00750 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAISubSystem
// Size: 0x1b0 // Inherited bytes: 0x30
struct UMLAISubSystem : UWorldSubsystem {
	// Fields
	struct TMap<uint32_t, struct FAIPlayerState> CacheAIPlayerStates; // Offset: 0x30 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerWeapon> CacheAIPlayerWeapons; // Offset: 0x80 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerEquipment> CacheAIPlayerEquipments; // Offset: 0xd0 // Size: 0x50
	struct TArray<struct UAIStateInfoComponent*> AIStateInfoComps; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FBulletHoleRecordInfo> CacheBulletHoles; // Offset: 0x130 // Size: 0x10
	struct TArray<struct FSpecialZoneState> CacheSpecialZones; // Offset: 0x140 // Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
	struct TMap<struct AActor*, struct ASpecialZoneActor*> CacheSpecialZoneParents; // Offset: 0x160 // Size: 0x50

	// Functions

	// Object Name: Function AI.MLAISubSystem.StartRequestCache
	// Flags: [Final|Native|Public]
	void StartRequestCache(); // Offset: 0x103b0d828 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAISubSystem.SetSpecialZoneCustomState
	// Flags: [Final|Native|Public]
	void SetSpecialZoneCustomState(struct AActor* InParent, int InCustomState); // Offset: 0x103b0d770 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AI.MLAISubSystem.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103b0d6f4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAISubSystem.IsAIBotGame
	// Flags: [Final|Native|Public]
	bool IsAIBotGame(); // Offset: 0x103b0d6c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAISubSystem.EndRequestCache
	// Flags: [Final|Native|Public]
	void EndRequestCache(); // Offset: 0x103b0d6ac // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAITrainingComponent
// Size: 0x138 // Inherited bytes: 0x110
struct UMLAITrainingComponent : UActorComponent {
	// Fields
	bool IsBeginRequestAIState; // Offset: 0x110 // Size: 0x01
	bool IsEndRequestAIState; // Offset: 0x111 // Size: 0x01
	char pad_0x112[0x26]; // Offset: 0x112 // Size: 0x26

	// Functions

	// Object Name: Function AI.MLAITrainingComponent.StopRunnable
	// Flags: [Final|Native|Public]
	void StopRunnable(); // Offset: 0x103b0e844 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAITrainingComponent.SendAIStateRequest
	// Flags: [Final|Native|Public]
	void SendAIStateRequest(struct TArray<char> Packet); // Offset: 0x103b0e760 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAITrainingComponent.IsRequestAIState
	// Flags: [Final|Native|Public]
	bool IsRequestAIState(); // Offset: 0x103b0e72c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAITrainingComponent.InitRunnable
	// Flags: [Final|Native|Public]
	void InitRunnable(float InStartCollectingInterval, float InSendInterval, float InTimeOutInterval); // Offset: 0x103b0e63c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.MLAITrainingComponent.EndRequestAIState
	// Flags: [Final|Native|Public]
	void EndRequestAIState(); // Offset: 0x103b0e628 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.STStrategySpecies_Candidate
// Size: 0x110 // Inherited bytes: 0x110
struct USTStrategySpecies_Candidate : USTStrategySpecies {
	// Functions

	// Object Name: Function AI.STStrategySpecies_Candidate.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x103b0edc0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AI.STStrategySpecies_Candidate.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x103b0ed3c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AI.STStrategySpecies_Lua
// Size: 0x110 // Inherited bytes: 0x110
struct USTStrategySpecies_Lua : USTStrategySpecies {
	// Functions

	// Object Name: Function AI.STStrategySpecies_Lua.Supply
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FUnitConfig> Supply(int ReferencedCount, struct TArray<struct FSpawnSpotInfo>& SpotSpecies); // Offset: 0x103b0f440 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AI.STStrategySpecies_Lua.LuaSupply
	// Flags: [Event|Public|BlueprintEvent]
	void LuaSupply(int ReferencedCount); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AI.STStrategyTiming_Event
// Size: 0x110 // Inherited bytes: 0xf0
struct USTStrategyTiming_Event : USTStrategyTiming {
	// Fields
	struct FString EventId; // Offset: 0xf0 // Size: 0x10
	struct FString EventName; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function AI.STStrategyTiming_Event.TickStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void TickStrategy(float DeltaTime); // Offset: 0x103b0fa60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.STStrategyTiming_Event.OnSpawnEventBroadcast
	// Flags: [Final|Native|Public]
	void OnSpawnEventBroadcast(); // Offset: 0x103b0fa4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.STStrategyTiming_Event.ActivateStrategy
	// Flags: [Native|Public|BlueprintCallable]
	void ActivateStrategy(struct ASTSpawnerBase* Owner); // Offset: 0x103b0f9c8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AI.SpecialZoneShapeComponent
// Size: 0x770 // Inherited bytes: 0x760
struct USpecialZoneShapeComponent : UPrimitiveComponent {
	// Fields
	float SphereRadius; // Offset: 0x760 // Size: 0x04
	char pad_0x764[0xc]; // Offset: 0x764 // Size: 0x0c
};

// Object Name: Class AI.SpecialZoneActor
// Size: 0x3e0 // Inherited bytes: 0x3c0
struct ASpecialZoneActor : AActor {
	// Fields
	int ZoneID; // Offset: 0x3c0 // Size: 0x04
	float Radius; // Offset: 0x3c4 // Size: 0x04
	int Type; // Offset: 0x3c8 // Size: 0x04
	int CustomState; // Offset: 0x3cc // Size: 0x04
	struct USpecialZoneShapeComponent* SpecialZoneShapeComponent; // Offset: 0x3d0 // Size: 0x08
	struct AActor* CacheParentActor; // Offset: 0x3d8 // Size: 0x08

	// Functions

	// Object Name: Function AI.SpecialZoneActor.UpdateCustomState
	// Flags: [Final|Native|Public]
	void UpdateCustomState(int InCustomState); // Offset: 0x103b100b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.SpecialZoneActor.GetSpecialZoneState
	// Flags: [Final|Native|Public]
	struct FSpecialZoneState GetSpecialZoneState(); // Offset: 0x103b1005c // Return & Params: Num(1) Size(0x34)
};

// Object Name: Class AI.VehicleAIUserComponent
// Size: 0x208 // Inherited bytes: 0x208
struct UVehicleAIUserComponent : UVehicleUserComponentBase {
	// Functions

	// Object Name: Function AI.VehicleAIUserComponent.ServerVehicleLeanOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerVehicleLeanOut(bool bLeanOut); // Offset: 0x103b11344 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.VehicleAIUserComponent.ServerExitVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerExitVehicle(); // Offset: 0x103b11330 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.ServerEnterVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerEnterVehicle(struct ASTExtraVehicleBase* InVehicle, char SeatType); // Offset: 0x103b11278 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AI.VehicleAIUserComponent.ServerChangeVehicleSeat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerChangeVehicleSeat(int InSeatIndex); // Offset: 0x103b111fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastExitVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastExitVehicle(); // Offset: 0x103b111e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastEnterVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastEnterVehicle(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraPlayerCharacter* Pawn, bool bSuccess, char SeatType, int SeatIndex); // Offset: 0x103b11060 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastChangeVehicleSeat
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastChangeVehicleSeat(int InSeatIndex); // Offset: 0x103b10fdc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AI.VehicleCustomDamageEventComponent
// Size: 0x318 // Inherited bytes: 0x310
struct UVehicleCustomDamageEventComponent : UCustomDamageEventComponent {
	// Fields
	char pad_0x310[0x8]; // Offset: 0x310 // Size: 0x08

	// Functions

	// Object Name: Function AI.VehicleCustomDamageEventComponent.OnVehicleHPFuelChanged
	// Flags: [Final|Native|Public]
	void OnVehicleHPFuelChanged(float HP, float Fuel); // Offset: 0x103b11994 // Return & Params: Num(2) Size(0x8)
};

