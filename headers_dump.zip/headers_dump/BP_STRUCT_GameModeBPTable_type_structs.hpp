#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_GameModeBPTable_type.BP_STRUCT_GameModeBPTable_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_GameModeBPTable_type {
	// Fields
	int ID_0_5A5311F84AF5AD63F284598DF413D62D; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CName_1_120D6DB74537DE28D87E4BAD2052E558; // Offset: 0x08 // Size: 0x10
	struct FString Path_2_D808EF6946A66B7E51F6318FC7CCE098; // Offset: 0x18 // Size: 0x10
};

