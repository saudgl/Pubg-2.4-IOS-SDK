#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class bp_plugin.bp_pluginBPLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct Ubp_pluginBPLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function bp_plugin.bp_pluginBPLibrary.bp_pluginTestEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void bp_pluginTestEvent(struct FString jsonEventCmd); // Offset: 0x1022ed15c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function bp_plugin.bp_pluginBPLibrary.bp_pluginSendEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void bp_pluginSendEvent(struct FString jsonEventCmd); // Offset: 0x1022ed0cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function bp_plugin.bp_pluginBPLibrary.bp_pluginLaunchMeemoFunction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float bp_pluginLaunchMeemoFunction(struct FString Param); // Offset: 0x1022ed034 // Return & Params: Num(2) Size(0x14)
};

