#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AvatarBPTable_type.BP_STRUCT_AvatarBPTable_type
// Size: 0x78 // Inherited bytes: 0x00
struct FBP_STRUCT_AvatarBPTable_type {
	// Fields
	struct FString CName_0_A4052DC94E7BDAA9FAD3B19A7B988D48; // Offset: 0x00 // Size: 0x10
	struct FString AvatarBPPath_1_891FA0534B751701E31560B16F286D8B; // Offset: 0x10 // Size: 0x10
	int ItemID_2_5414CFBB435533293B561394BF4A770E; // Offset: 0x20 // Size: 0x04
	int IsPackage_4_4347B95845DB19587DE29887A52E05D7; // Offset: 0x24 // Size: 0x04
	struct FString Wrapper_5_663E34007B103FC200DAC514020BE042; // Offset: 0x28 // Size: 0x10
	int TemplateID_6_2887AE005383C2E84A80675E0040CD54; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString LobbyPath_7_17C51D006376E0D618CF05350B08C778; // Offset: 0x40 // Size: 0x10
	int IsReuseWrapper_8_30F4A4006900D02E4EC7D5B60E3DD5A2; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString MaterialPath_9_66A36AC07FBB0355612D10BC0591FD48; // Offset: 0x58 // Size: 0x10
	struct FString MeshPath_10_2C6542406658161909A9383A04A40258; // Offset: 0x68 // Size: 0x10
};

