#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PetDressBlueprintTable_type.BP_STRUCT_PetDressBlueprintTable_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_PetDressBlueprintTable_type {
	// Fields
	int Slot_0_31125FC006688BBB2E6646B20FAFCD34; // Offset: 0x00 // Size: 0x04
	int ID_1_688F3A8033A7814C565560B30E5FAEF4; // Offset: 0x04 // Size: 0x04
	struct FString Path_2_51589A804E9002622E9485530FAF46F8; // Offset: 0x08 // Size: 0x10
};

