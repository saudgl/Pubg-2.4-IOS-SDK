#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass SettingConfig.SettingConfig_C
// Size: 0xd74 // Inherited bytes: 0x28
struct USettingConfig_C : USaveGame {
	// Fields
	int CrossHairColor; // Offset: 0x28 // Size: 0x04
	bool AimAssist; // Offset: 0x2c // Size: 0x01
	bool HitFeedBack; // Offset: 0x2d // Size: 0x01
	bool LeftRightShoot; // Offset: 0x2e // Size: 0x01
	bool IntelligentDrugs; // Offset: 0x2f // Size: 0x01
	int LeftHandFire; // Offset: 0x30 // Size: 0x04
	int Gyroscope; // Offset: 0x34 // Size: 0x04
	int ArtQuality; // Offset: 0x38 // Size: 0x04
	float ViewPercentage; // Offset: 0x3c // Size: 0x04
	int FireMode; // Offset: 0x40 // Size: 0x04
	int VehicleControlMode; // Offset: 0x44 // Size: 0x04
	bool JoystickLRSwitcher; // Offset: 0x48 // Size: 0x01
	bool ButtonLRSwitcher; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int CameraLensSensibility; // Offset: 0x4c // Size: 0x04
	float CamLensSenNoneSniper; // Offset: 0x50 // Size: 0x04
	float CamLensSenRedDotSniper; // Offset: 0x54 // Size: 0x04
	float CamLensSen2XSniper; // Offset: 0x58 // Size: 0x04
	float CamLensSen4XSniper; // Offset: 0x5c // Size: 0x04
	float CamLensSen8XSniper; // Offset: 0x60 // Size: 0x04
	int FireCameraLensSensibility; // Offset: 0x64 // Size: 0x04
	float FireCamLensSenNoneSniper; // Offset: 0x68 // Size: 0x04
	float FireCamLensSenRedDotSniper; // Offset: 0x6c // Size: 0x04
	float FireCamLensSen2XSniper; // Offset: 0x70 // Size: 0x04
	float FireCamLensSen4XSniper; // Offset: 0x74 // Size: 0x04
	float FireCamLensSen8XSniper; // Offset: 0x78 // Size: 0x04
	int GyroscopeSensibility; // Offset: 0x7c // Size: 0x04
	float GyroscopeSenNoneSniper; // Offset: 0x80 // Size: 0x04
	float GyroscopeSenRedDotSniper; // Offset: 0x84 // Size: 0x04
	float GyroscopeSen2XSniper; // Offset: 0x88 // Size: 0x04
	float GyroscopeSen4XSniper; // Offset: 0x8c // Size: 0x04
	float GyroscopeSen8XSniper; // Offset: 0x90 // Size: 0x04
	bool MainVolumSwitcher; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
	float MainVolumValue; // Offset: 0x98 // Size: 0x04
	bool EffectVolumSwitcher; // Offset: 0x9c // Size: 0x01
	char pad_0x9D[0x3]; // Offset: 0x9d // Size: 0x03
	float EffectVolumValue; // Offset: 0xa0 // Size: 0x04
	bool UIVolumSwitcher; // Offset: 0xa4 // Size: 0x01
	char pad_0xA5[0x3]; // Offset: 0xa5 // Size: 0x03
	float UIVolumValue; // Offset: 0xa8 // Size: 0x04
	bool BGMVolumSwitcher; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
	float BGMVolumValue; // Offset: 0xb0 // Size: 0x04
	bool VoiceSwitcher; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
	int VoiceChannel; // Offset: 0xb8 // Size: 0x04
	bool MicphoneVolumSwitcher; // Offset: 0xbc // Size: 0x01
	char pad_0xBD[0x3]; // Offset: 0xbd // Size: 0x03
	float MicphoneVolumValue; // Offset: 0xc0 // Size: 0x04
	bool SpeakerVolumSwitcher; // Offset: 0xc4 // Size: 0x01
	char pad_0xC5[0x3]; // Offset: 0xc5 // Size: 0x03
	float SocialIslandOtherVolume; // Offset: 0xc8 // Size: 0x04
	float SpeakerVolumValue; // Offset: 0xcc // Size: 0x04
	bool AutoPickUpSwitcher; // Offset: 0xd0 // Size: 0x01
	bool DisableAutoPickupSwitcher; // Offset: 0xd1 // Size: 0x01
	bool AkeyPickupSwitcher; // Offset: 0xd2 // Size: 0x01
	bool AutoPickupGun; // Offset: 0xd3 // Size: 0x01
	bool AutoPickupBullet; // Offset: 0xd4 // Size: 0x01
	bool AutoPickupPart; // Offset: 0xd5 // Size: 0x01
	bool AutoPickupShieldBag; // Offset: 0xd6 // Size: 0x01
	bool AutoPickupDrug; // Offset: 0xd7 // Size: 0x01
	bool BandageSwitcher; // Offset: 0xd8 // Size: 0x01
	bool MedicalSwitcher; // Offset: 0xd9 // Size: 0x01
	bool AnodyneSwitcher; // Offset: 0xda // Size: 0x01
	bool EnergyDrinksSwitcher; // Offset: 0xdb // Size: 0x01
	bool AdrenalineSwitcher; // Offset: 0xdc // Size: 0x01
	bool AutoPickupGrenade; // Offset: 0xdd // Size: 0x01
	bool ShouLiuDanSwitcher; // Offset: 0xde // Size: 0x01
	bool YanWuDanSwitcher; // Offset: 0xdf // Size: 0x01
	bool StunBombSwitcher; // Offset: 0xe0 // Size: 0x01
	bool FireBombSwitcher; // Offset: 0xe1 // Size: 0x01
	char pad_0xE2[0x2]; // Offset: 0xe2 // Size: 0x02
	int LimitBandage; // Offset: 0xe4 // Size: 0x04
	int LimitMedical; // Offset: 0xe8 // Size: 0x04
	int LimitAnodyne; // Offset: 0xec // Size: 0x04
	int LimitEnergyDrinks; // Offset: 0xf0 // Size: 0x04
	int LimitAdrenaline; // Offset: 0xf4 // Size: 0x04
	int LimitShouliudan; // Offset: 0xf8 // Size: 0x04
	int LimitYanwudan; // Offset: 0xfc // Size: 0x04
	int LimitZhenbaodan; // Offset: 0x100 // Size: 0x04
	int LimitRanshaodan; // Offset: 0x104 // Size: 0x04
	int LimitBullet9mm; // Offset: 0x108 // Size: 0x04
	int LimitBullet7_62mm; // Offset: 0x10c // Size: 0x04
	int Limit12koujing; // Offset: 0x110 // Size: 0x04
	int Limit45koujing; // Offset: 0x114 // Size: 0x04
	int Limit300magenandanyao; // Offset: 0x118 // Size: 0x04
	int Limitbolt; // Offset: 0x11c // Size: 0x04
	int LimitBullet5_57; // Offset: 0x120 // Size: 0x04
	bool 3DTouchSwitcher; // Offset: 0x124 // Size: 0x01
	char pad_0x125[0x3]; // Offset: 0x125 // Size: 0x03
	int FPSLevel; // Offset: 0x128 // Size: 0x04
	int ArtStyle; // Offset: 0x12c // Size: 0x04
	int RecordTipShowLastTime; // Offset: 0x130 // Size: 0x04
	char pad_0x134[0x4]; // Offset: 0x134 // Size: 0x04
	struct TMap<struct FString, struct FDateTime> XinyueLastClickTime; // Offset: 0x138 // Size: 0x50
	struct TMap<struct FString, struct FDateTime> HuatiLastClickTime; // Offset: 0x188 // Size: 0x50
	bool MomentSwitch; // Offset: 0x1d8 // Size: 0x01
	bool FreeModeSwitch; // Offset: 0x1d9 // Size: 0x01
	bool HDModeSwitch; // Offset: 0x1da // Size: 0x01
	char pad_0x1DB[0x5]; // Offset: 0x1db // Size: 0x05
	struct TMap<struct FString, struct FDateTime> CollectEquipClickTime; // Offset: 0x1e0 // Size: 0x50
	bool IsSimulatorFirstStartup; // Offset: 0x230 // Size: 0x01
	char pad_0x231[0x7]; // Offset: 0x231 // Size: 0x07
	struct TArray<int> DefaultPlayerChatQuickTextIDList; // Offset: 0x238 // Size: 0x10
	struct TArray<int> ChatOptiongList1; // Offset: 0x248 // Size: 0x10
	int LRShootMode; // Offset: 0x258 // Size: 0x04
	bool LRShootSniperSwitch; // Offset: 0x25c // Size: 0x01
	bool AutoOpenDoor; // Offset: 0x25d // Size: 0x01
	bool WallFeedBack; // Offset: 0x25e // Size: 0x01
	char pad_0x25F[0x1]; // Offset: 0x25f // Size: 0x01
	struct TArray<int> ChatOptiongList2; // Offset: 0x260 // Size: 0x10
	struct TArray<int> ChatOptiongList3; // Offset: 0x270 // Size: 0x10
	bool HaveShowActorHint; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x3]; // Offset: 0x281 // Size: 0x03
	int NewGetActorID; // Offset: 0x284 // Size: 0x04
	bool DeviceAutoAdapt; // Offset: 0x288 // Size: 0x01
	char pad_0x289[0x3]; // Offset: 0x289 // Size: 0x03
	float 3DTouchValue; // Offset: 0x28c // Size: 0x04
	bool AntiAliasingSwitch; // Offset: 0x290 // Size: 0x01
	char pad_0x291[0x3]; // Offset: 0x291 // Size: 0x03
	int ShotGunShootMode; // Offset: 0x294 // Size: 0x04
	int SingleShotWeaponShootMode; // Offset: 0x298 // Size: 0x04
	int isFirstOpenMicCheck; // Offset: 0x29c // Size: 0x04
	float VehicleEye; // Offset: 0x2a0 // Size: 0x04
	float ParachuteEye; // Offset: 0x2a4 // Size: 0x04
	struct FString ChatPrivacyAcceptedVersion; // Offset: 0x2a8 // Size: 0x10
	int RepeatingWeaponShootMode; // Offset: 0x2b8 // Size: 0x04
	int DrivingViewMode; // Offset: 0x2bc // Size: 0x04
	bool FPViewSwitch; // Offset: 0x2c0 // Size: 0x01
	char pad_0x2C1[0x3]; // Offset: 0x2c1 // Size: 0x03
	int FpViewValue; // Offset: 0x2c4 // Size: 0x04
	float CamFpFreeEye; // Offset: 0x2c8 // Size: 0x04
	float CamLensSenNoneSniperFP; // Offset: 0x2cc // Size: 0x04
	float FireCamLensSenNoneSniperFP; // Offset: 0x2d0 // Size: 0x04
	float GyroscopeSenNoneSniperFP; // Offset: 0x2d4 // Size: 0x04
	bool FirstTime_FPP_TPP; // Offset: 0x2d8 // Size: 0x01
	bool FirstTime_WarMode; // Offset: 0x2d9 // Size: 0x01
	char pad_0x2DA[0x2]; // Offset: 0x2da // Size: 0x02
	int DaliyWarmodeInfo; // Offset: 0x2dc // Size: 0x04
	struct FString currentLanguage; // Offset: 0x2e0 // Size: 0x10
	bool redBloodSwitch; // Offset: 0x2f0 // Size: 0x01
	bool ActorAnimationSwitch; // Offset: 0x2f1 // Size: 0x01
	char pad_0x2F2[0x6]; // Offset: 0x2f2 // Size: 0x06
	struct FString lastViewDayTime; // Offset: 0x2f8 // Size: 0x10
	struct FString lastViewWeekTime; // Offset: 0x308 // Size: 0x10
	bool DoblySwitch2; // Offset: 0x318 // Size: 0x01
	bool DoblySwitch1; // Offset: 0x319 // Size: 0x01
	bool openNewMusic; // Offset: 0x31a // Size: 0x01
	bool hasOpenedSound; // Offset: 0x31b // Size: 0x01
	float CamLensSen3XSniper; // Offset: 0x31c // Size: 0x04
	float CamLensSen6XSniper; // Offset: 0x320 // Size: 0x04
	float FireCamLensSen3XSniper; // Offset: 0x324 // Size: 0x04
	float FireCamLensSen6XSniper; // Offset: 0x328 // Size: 0x04
	float GyroscopeSen3XSniper; // Offset: 0x32c // Size: 0x04
	float GyroscopeSen6XSniper; // Offset: 0x330 // Size: 0x04
	bool ShadowSwitch; // Offset: 0x334 // Size: 0x01
	char pad_0x335[0x3]; // Offset: 0x335 // Size: 0x03
	int RedDotCHColor; // Offset: 0x338 // Size: 0x04
	int RedDotCHType; // Offset: 0x33c // Size: 0x04
	int HolographicCHColor; // Offset: 0x340 // Size: 0x04
	int HolographicCHType; // Offset: 0x344 // Size: 0x04
	int Sinper2xCHColor; // Offset: 0x348 // Size: 0x04
	int Sinper2xCHType; // Offset: 0x34c // Size: 0x04
	int Sniper3xCHColor; // Offset: 0x350 // Size: 0x04
	int Sniper3xCHType; // Offset: 0x354 // Size: 0x04
	bool AutoPickupLevel3Backpack; // Offset: 0x358 // Size: 0x01
	bool AutoPickupPistol; // Offset: 0x359 // Size: 0x01
	char pad_0x35A[0x6]; // Offset: 0x35a // Size: 0x06
	struct TMap<int, int> PickUpCountSetting; // Offset: 0x360 // Size: 0x50
	int LimitFirstAidKit; // Offset: 0x3b0 // Size: 0x04
	char pad_0x3B4[0x4]; // Offset: 0x3b4 // Size: 0x04
	struct FString XGLanguageTag; // Offset: 0x3b8 // Size: 0x10
	struct FString XGTimezoneTag; // Offset: 0x3c8 // Size: 0x10
	struct FString XGPushNightTag; // Offset: 0x3d8 // Size: 0x10
	struct FString XGPushDayTag; // Offset: 0x3e8 // Size: 0x10
	bool DeviceAutoAdaptEX; // Offset: 0x3f8 // Size: 0x01
	char pad_0x3F9[0x3]; // Offset: 0x3f9 // Size: 0x03
	int SelectUIElemIndex1; // Offset: 0x3fc // Size: 0x04
	int SelectUIElemIndex2; // Offset: 0x400 // Size: 0x04
	int SelectUIElemIndex3; // Offset: 0x404 // Size: 0x04
	bool VaultBtnSwitch; // Offset: 0x408 // Size: 0x01
	char pad_0x409[0x3]; // Offset: 0x409 // Size: 0x03
	int LimitSniper2X; // Offset: 0x40c // Size: 0x04
	int LimitSniper3X; // Offset: 0x410 // Size: 0x04
	int LimitSniper4X; // Offset: 0x414 // Size: 0x04
	int LimitSniper6X; // Offset: 0x418 // Size: 0x04
	int LimitSniper8X; // Offset: 0x41c // Size: 0x04
	bool LongPressSideSwitch; // Offset: 0x420 // Size: 0x01
	bool LongPressSniperSwitch; // Offset: 0x421 // Size: 0x01
	char pad_0x422[0x2]; // Offset: 0x422 // Size: 0x02
	int SidewaysMode; // Offset: 0x424 // Size: 0x04
	int OpenMirrorMode; // Offset: 0x428 // Size: 0x04
	bool CarMusicSwitch; // Offset: 0x42c // Size: 0x01
	bool OBS_TrackEffect; // Offset: 0x42d // Size: 0x01
	bool OBS_Perspective; // Offset: 0x42e // Size: 0x01
	bool OBS_BulletTrack; // Offset: 0x42f // Size: 0x01
	bool QuasiMirrorSwitch; // Offset: 0x430 // Size: 0x01
	char pad_0x431[0x3]; // Offset: 0x431 // Size: 0x03
	int LobbyStyleID; // Offset: 0x434 // Size: 0x04
	bool LobbyBgm; // Offset: 0x438 // Size: 0x01
	bool LobbyHallowma; // Offset: 0x439 // Size: 0x01
	bool SettingStyleRedPoint; // Offset: 0x43a // Size: 0x01
	bool SettingBgmRedPoint; // Offset: 0x43b // Size: 0x01
	float ScreenLightness; // Offset: 0x43c // Size: 0x04
	bool BloodStateSwitch; // Offset: 0x440 // Size: 0x01
	bool SettingBigHandOperateRedPoint; // Offset: 0x441 // Size: 0x01
	bool LobbyIsChristmas; // Offset: 0x442 // Size: 0x01
	bool MallShowGet10Animation; // Offset: 0x443 // Size: 0x01
	char pad_0x444[0x4]; // Offset: 0x444 // Size: 0x04
	struct FString FirstChargeVersion; // Offset: 0x448 // Size: 0x10
	struct FString RechargePosSave; // Offset: 0x458 // Size: 0x10
	bool FirstTime_PVEVPMode; // Offset: 0x468 // Size: 0x01
	bool IslandBroadCast; // Offset: 0x469 // Size: 0x01
	bool ResidentEvilNeedShow; // Offset: 0x46a // Size: 0x01
	bool AnniversaryNeedShow; // Offset: 0x46b // Size: 0x01
	char pad_0x46C[0x4]; // Offset: 0x46c // Size: 0x04
	struct TMap<int, int> PvePickUpCountSetting; // Offset: 0x470 // Size: 0x50
	int LimitViscidityBomb; // Offset: 0x4c0 // Size: 0x04
	int LimitZombieGrenade; // Offset: 0x4c4 // Size: 0x04
	bool AutoPickUpLevel3Backpack_pve; // Offset: 0x4c8 // Size: 0x01
	bool AutoPickUpPistol_pve; // Offset: 0x4c9 // Size: 0x01
	bool VNGMark; // Offset: 0x4ca // Size: 0x01
	char pad_0x4CB[0x1]; // Offset: 0x4cb // Size: 0x01
	int IngamePlayerInfo_OpenDate; // Offset: 0x4cc // Size: 0x04
	int SideMirrorMode; // Offset: 0x4d0 // Size: 0x04
	char pad_0x4D4[0x4]; // Offset: 0x4d4 // Size: 0x04
	struct TArray<int> DefaultPlayerWheelChatQuickTextIDList; // Offset: 0x4d8 // Size: 0x10
	bool OpenOthersPet; // Offset: 0x4e8 // Size: 0x01
	bool OpenMyPet; // Offset: 0x4e9 // Size: 0x01
	bool LobbyAnniversaryBgm; // Offset: 0x4ea // Size: 0x01
	bool FirstTime_SurvivalMode; // Offset: 0x4eb // Size: 0x01
	int LimitYeDanGrenade; // Offset: 0x4ec // Size: 0x04
	int LimitAntidote; // Offset: 0x4f0 // Size: 0x04
	bool QuickThrowSwitch; // Offset: 0x4f4 // Size: 0x01
	char pad_0x4F5[0x3]; // Offset: 0x4f5 // Size: 0x03
	struct TArray<int> ChatOptiongList4; // Offset: 0x4f8 // Size: 0x10
	bool OpenMyPetFPP; // Offset: 0x508 // Size: 0x01
	char pad_0x509[0x3]; // Offset: 0x509 // Size: 0x03
	int ScoreTips_TModeCnt; // Offset: 0x50c // Size: 0x04
	bool FirstTime_TMode; // Offset: 0x510 // Size: 0x01
	bool TurboEnable; // Offset: 0x511 // Size: 0x01
	char pad_0x512[0x2]; // Offset: 0x512 // Size: 0x02
	int FPPFireMode; // Offset: 0x514 // Size: 0x04
	int SelectUIElemIndexFPP1; // Offset: 0x518 // Size: 0x04
	int SelectUIElemIndexFPP2; // Offset: 0x51c // Size: 0x04
	int SelectUIElemIndexFPP3; // Offset: 0x520 // Size: 0x04
	enum class ERenderQuality TurboLastQuality; // Offset: 0x524 // Size: 0x01
	char pad_0x525[0x3]; // Offset: 0x525 // Size: 0x03
	struct TMap<struct FString, struct FString> PubgPlusGuideRecord; // Offset: 0x528 // Size: 0x50
	struct TMap<struct FString, struct FString> PubgPlusGuideConfig; // Offset: 0x578 // Size: 0x50
	struct TArray<int> UselessWeakGuidIDs; // Offset: 0x5c8 // Size: 0x10
	bool SettingOperateZombieLayout; // Offset: 0x5d8 // Size: 0x01
	bool HelicopterFreeCamera; // Offset: 0x5d9 // Size: 0x01
	bool HasShowHeavyWeaponFirsttimeTips; // Offset: 0x5da // Size: 0x01
	char pad_0x5DB[0x5]; // Offset: 0x5db // Size: 0x05
	struct TArray<int> ChatOptiongList5; // Offset: 0x5e0 // Size: 0x10
	struct TArray<int> ChatOptiongList6; // Offset: 0x5f0 // Size: 0x10
	bool FirstTime_TMode_Slid; // Offset: 0x600 // Size: 0x01
	char pad_0x601[0x3]; // Offset: 0x601 // Size: 0x03
	int TD_FireMode; // Offset: 0x604 // Size: 0x04
	int TD_FPPFireMode; // Offset: 0x608 // Size: 0x04
	bool TD_3DTouchSwitcher; // Offset: 0x60c // Size: 0x01
	char pad_0x60D[0x3]; // Offset: 0x60d // Size: 0x03
	float TD_3DTouchValue; // Offset: 0x610 // Size: 0x04
	bool FirstTime_TMode_HardPoint; // Offset: 0x614 // Size: 0x01
	bool ShovelSwitch; // Offset: 0x615 // Size: 0x01
	char pad_0x616[0x2]; // Offset: 0x616 // Size: 0x02
	int isFirstOpenMicCheckVehicleWar; // Offset: 0x618 // Size: 0x04
	bool VulkanEnable; // Offset: 0x61c // Size: 0x01
	char pad_0x61D[0x3]; // Offset: 0x61d // Size: 0x03
	int LimitSnowMan; // Offset: 0x620 // Size: 0x04
	bool AutoPickMirror; // Offset: 0x624 // Size: 0x01
	bool UniversalSignSwitch; // Offset: 0x625 // Size: 0x01
	bool OpenChatHorn; // Offset: 0x626 // Size: 0x01
	char pad_0x627[0x1]; // Offset: 0x627 // Size: 0x01
	int ColorBlindnessType; // Offset: 0x628 // Size: 0x04
	bool DeathPlaybackSwitch; // Offset: 0x62c // Size: 0x01
	bool UAVSingleOperate; // Offset: 0x62d // Size: 0x01
	bool UAVFreeCamera; // Offset: 0x62e // Size: 0x01
	char pad_0x62F[0x1]; // Offset: 0x62f // Size: 0x01
	float UAVSpeedPercent; // Offset: 0x630 // Size: 0x04
	float UAVScopePercent; // Offset: 0x634 // Size: 0x04
	bool OpenUAVHelicopter; // Offset: 0x638 // Size: 0x01
	bool FirstTime_ShowAutoGroupParachute; // Offset: 0x639 // Size: 0x01
	char pad_0x63A[0x2]; // Offset: 0x63a // Size: 0x02
	int SideMirrorType; // Offset: 0x63c // Size: 0x04
	int SideMirrorColor; // Offset: 0x640 // Size: 0x04
	bool AutoPickUpSideSight; // Offset: 0x644 // Size: 0x01
	bool AutoEquipAim; // Offset: 0x645 // Size: 0x01
	bool isCloudSensitivityUsed; // Offset: 0x646 // Size: 0x01
	char pad_0x647[0x1]; // Offset: 0x647 // Size: 0x01
	struct FString CloudSensitivityPlayerId; // Offset: 0x648 // Size: 0x10
	bool SettingHasOperateQuickSign; // Offset: 0x658 // Size: 0x01
	bool SettingSideSightFunctionRedPoint; // Offset: 0x659 // Size: 0x01
	bool SettingUploadSensibilityRedPoint; // Offset: 0x65a // Size: 0x01
	bool SettingClassicCopyRedPoint; // Offset: 0x65b // Size: 0x01
	bool SettingTDCopyRedPoint; // Offset: 0x65c // Size: 0x01
	bool SettingQuickSwitchRedPoint; // Offset: 0x65d // Size: 0x01
	bool SocialIslandCanAcceptDuel; // Offset: 0x65e // Size: 0x01
	bool RotateViewWithSniperSwitch; // Offset: 0x65f // Size: 0x01
	bool DisableAutoPickDropMirror; // Offset: 0x660 // Size: 0x01
	char pad_0x661[0x3]; // Offset: 0x661 // Size: 0x03
	int AutoPickClipType; // Offset: 0x664 // Size: 0x04
	struct TArray<int> QuickSignIDList; // Offset: 0x668 // Size: 0x10
	struct TArray<int> QuickSignWheelIDList; // Offset: 0x678 // Size: 0x10
	bool RotateViewWithPeekSwitch; // Offset: 0x688 // Size: 0x01
	bool DynamicHoldGun; // Offset: 0x689 // Size: 0x01
	bool SettingEffectRedPoint; // Offset: 0x68a // Size: 0x01
	char pad_0x68B[0x1]; // Offset: 0x68b // Size: 0x01
	int HitEffectColor; // Offset: 0x68c // Size: 0x04
	int HurtEffectColor; // Offset: 0x690 // Size: 0x04
	bool EnemyLocationMarkSwitch; // Offset: 0x694 // Size: 0x01
	bool bHasMapCBToES; // Offset: 0x695 // Size: 0x01
	char pad_0x696[0x2]; // Offset: 0x696 // Size: 0x02
	int ProfiledScreenSwitch; // Offset: 0x698 // Size: 0x04
	bool FirstTime_TMode_ArmsRace; // Offset: 0x69c // Size: 0x01
	bool bOpenSprHghQltyComparison; // Offset: 0x69d // Size: 0x01
	char pad_0x69E[0x2]; // Offset: 0x69e // Size: 0x02
	int BuildDoubleClick; // Offset: 0x6a0 // Size: 0x04
	float BuildDoubleClickDuration; // Offset: 0x6a4 // Size: 0x04
	float DoubleClickSpeed; // Offset: 0x6a8 // Size: 0x04
	int DoubleClickDistance; // Offset: 0x6ac // Size: 0x04
	bool ChangeSeatAccurately; // Offset: 0x6b0 // Size: 0x01
	char pad_0x6B1[0x3]; // Offset: 0x6b1 // Size: 0x03
	int BattleFPS; // Offset: 0x6b4 // Size: 0x04
	int BattleRenderStyle; // Offset: 0x6b8 // Size: 0x04
	int BattleRenderQuality; // Offset: 0x6bc // Size: 0x04
	int LobbyFPS; // Offset: 0x6c0 // Size: 0x04
	int LobbyRenderStyle; // Offset: 0x6c4 // Size: 0x04
	int LobbyRenderQuality; // Offset: 0x6c8 // Size: 0x04
	bool HasGraphicsSeparateConfig; // Offset: 0x6cc // Size: 0x01
	bool SettingOperateInfect; // Offset: 0x6cd // Size: 0x01
	bool FirstTime_Infect; // Offset: 0x6ce // Size: 0x01
	bool OBS_LogoShow; // Offset: 0x6cf // Size: 0x01
	bool OBS_HitFeedback; // Offset: 0x6d0 // Size: 0x01
	char pad_0x6D1[0x7]; // Offset: 0x6d1 // Size: 0x07
	struct TMap<int, int> BulletPickUpCountSetting_XT; // Offset: 0x6d8 // Size: 0x50
	struct TMap<int, int> Drug_PickUpCountSetting_XT; // Offset: 0x728 // Size: 0x50
	struct TMap<int, int> NormalInfilling_PickUpCountSetting_XT; // Offset: 0x778 // Size: 0x50
	struct TMap<int, int> HalloweenInfilling_PickUpCountSetting_XT; // Offset: 0x7c8 // Size: 0x50
	struct TMap<int, int> ThrowObj_PickUpCountSetting_XT; // Offset: 0x818 // Size: 0x50
	struct TMap<int, int> MultipleMirror_PickUpCountSetting_XT; // Offset: 0x868 // Size: 0x50
	bool RingThrowSwitch; // Offset: 0x8b8 // Size: 0x01
	bool isOtherCloudSensitivityUsed; // Offset: 0x8b9 // Size: 0x01
	bool IsCloudAndLocalSame; // Offset: 0x8ba // Size: 0x01
	bool RingThrowPressSwitch; // Offset: 0x8bb // Size: 0x01
	bool CarPreciseChangeSeat; // Offset: 0x8bc // Size: 0x01
	bool SettingSensibilityEnterTrainRedPoint; // Offset: 0x8bd // Size: 0x01
	bool SettingVehicleRedPoint; // Offset: 0x8be // Size: 0x01
	bool LRSwitcherGuide; // Offset: 0x8bf // Size: 0x01
	struct TMap<int, int> PickUpCountSetting_Drug; // Offset: 0x8c0 // Size: 0x50
	struct TMap<int, int> PickUpCountSetting_ThrowObj; // Offset: 0x910 // Size: 0x50
	struct TMap<int, int> PickUpCountSetting_MultipleMirror; // Offset: 0x960 // Size: 0x50
	struct TMap<int, int> PickUpCountSetting_FixConsumeItemMap; // Offset: 0x9b0 // Size: 0x50
	bool bTranslatePickupSettingToMap; // Offset: 0xa00 // Size: 0x01
	bool OBS_CustomKillInfo; // Offset: 0xa01 // Size: 0x01
	bool LocalHideHelmet; // Offset: 0xa02 // Size: 0x01
	bool SettingDisableAutoPickupDropMirrorRedPoint; // Offset: 0xa03 // Size: 0x01
	bool UseIngameLike; // Offset: 0xa04 // Size: 0x01
	bool ScreenShake; // Offset: 0xa05 // Size: 0x01
	char pad_0xA06[0x2]; // Offset: 0xa06 // Size: 0x02
	float CamLensSenShoulderTPP; // Offset: 0xa08 // Size: 0x04
	float CamLensSenShoulderFPP; // Offset: 0xa0c // Size: 0x04
	float FireCamLensSenShoulderTPP; // Offset: 0xa10 // Size: 0x04
	float GyroscopeSenShoulderTPP; // Offset: 0xa14 // Size: 0x04
	float FireCamLensSenShoulderFPP; // Offset: 0xa18 // Size: 0x04
	float GyroscopeSenShoulderFPP; // Offset: 0xa1c // Size: 0x04
	bool ShoulderEnable; // Offset: 0xa20 // Size: 0x01
	bool RotateViewWithShoulderSwitch; // Offset: 0xa21 // Size: 0x01
	char pad_0xA22[0x2]; // Offset: 0xa22 // Size: 0x02
	int ShoulderMode; // Offset: 0xa24 // Size: 0x04
	bool SettingHasOperatedShoulder; // Offset: 0xa28 // Size: 0x01
	bool SettingHasOperatedRotateWithShoulder; // Offset: 0xa29 // Size: 0x01
	bool OBS_SmokeGrenadeCountDown; // Offset: 0xa2a // Size: 0x01
	bool OBS_SmokeGrenadeAlpha; // Offset: 0xa2b // Size: 0x01
	bool bGunAccessoriesAddDefauleM4; // Offset: 0xa2c // Size: 0x01
	bool bGunAccessoriesGuidedRemoveSelect; // Offset: 0xa2d // Size: 0x01
	bool bGunAccessoriesGuidedAdd; // Offset: 0xa2e // Size: 0x01
	bool bGunAccessoriesGuidedSelect; // Offset: 0xa2f // Size: 0x01
	bool bGunAccessoriesGuidedEnter; // Offset: 0xa30 // Size: 0x01
	bool bAddedGunAccessories; // Offset: 0xa31 // Size: 0x01
	bool bGunSensitivityGuidedEnter; // Offset: 0xa32 // Size: 0x01
	bool bGunSensitivityGuidedAdd; // Offset: 0xa33 // Size: 0x01
	bool bGunSensitivityGuidedCopy; // Offset: 0xa34 // Size: 0x01
	char pad_0xA35[0x3]; // Offset: 0xa35 // Size: 0x03
	int GunSensitivitySingleTrainingGuideCount; // Offset: 0xa38 // Size: 0x04
	bool bGunSensitivitySingleTrainingGuideTiped; // Offset: 0xa3c // Size: 0x01
	bool OBS_ShowOwnWeaponKey; // Offset: 0xa3d // Size: 0x01
	bool isCloudSensitivityUsed_Custom; // Offset: 0xa3e // Size: 0x01
	char pad_0xA3F[0x1]; // Offset: 0xa3f // Size: 0x01
	struct FString CloudSensitivityPlayerId_Custom; // Offset: 0xa40 // Size: 0x10
	bool isOtherCloudSensitivityUsed_Custom; // Offset: 0xa50 // Size: 0x01
	bool IsCloudAndLocalSame_SensitivityCustom; // Offset: 0xa51 // Size: 0x01
	bool isCloudAccessoriesUsed_Custom; // Offset: 0xa52 // Size: 0x01
	char pad_0xA53[0x5]; // Offset: 0xa53 // Size: 0x05
	struct FString CloudAccessoriesPlayerId_Custom; // Offset: 0xa58 // Size: 0x10
	bool isOtherCloudAccessoriesUsed_Custom; // Offset: 0xa68 // Size: 0x01
	bool IsCloudAndLocalSame_AccessoriesCustom; // Offset: 0xa69 // Size: 0x01
	char pad_0xA6A[0x2]; // Offset: 0xa6a // Size: 0x02
	int TpViewValue; // Offset: 0xa6c // Size: 0x04
	bool bHasCloudCustomSensitivity; // Offset: 0xa70 // Size: 0x01
	char pad_0xA71[0x3]; // Offset: 0xa71 // Size: 0x03
	int PickUpListMode; // Offset: 0xa74 // Size: 0x04
	bool GyroReverse; // Offset: 0xa78 // Size: 0x01
	bool bHasCloudCustomAccessories; // Offset: 0xa79 // Size: 0x01
	char pad_0xA7A[0x2]; // Offset: 0xa7a // Size: 0x02
	float FireGyroscopeSenNoneSniper; // Offset: 0xa7c // Size: 0x04
	float FireGyroscopeSenRedDotSniper; // Offset: 0xa80 // Size: 0x04
	float FireGyroscopeSen2XSniper; // Offset: 0xa84 // Size: 0x04
	float FireGyroscopeSen4XSniper; // Offset: 0xa88 // Size: 0x04
	float FireGyroscopeSen8XSniper; // Offset: 0xa8c // Size: 0x04
	float FireGyroscopeSen3XSniper; // Offset: 0xa90 // Size: 0x04
	float FireGyroscopeSen6XSniper; // Offset: 0xa94 // Size: 0x04
	float FireGyroscopeSenNoneSniperFp; // Offset: 0xa98 // Size: 0x04
	bool AutoParachute; // Offset: 0xa9c // Size: 0x01
	bool MapMarkEnable; // Offset: 0xa9d // Size: 0x01
	char pad_0xA9E[0x2]; // Offset: 0xa9e // Size: 0x02
	float FireGyroscopeSenShoulderTPP; // Offset: 0xaa0 // Size: 0x04
	float FireGyroscopeSenShoulderFPP; // Offset: 0xaa4 // Size: 0x04
	bool FireGyroscopeRedPoint; // Offset: 0xaa8 // Size: 0x01
	bool HasOperateRingThrowSwitch; // Offset: 0xaa9 // Size: 0x01
	bool HasOperatedRingThrowPressSwitch; // Offset: 0xaaa // Size: 0x01
	bool SettingBasicGyroRverseRedPoint; // Offset: 0xaab // Size: 0x01
	bool bLbsNear; // Offset: 0xaac // Size: 0x01
	bool bLbsWarZone; // Offset: 0xaad // Size: 0x01
	bool AutoContinueHeal; // Offset: 0xaae // Size: 0x01
	bool FocalLengthModifySwitch; // Offset: 0xaaf // Size: 0x01
	bool FocalLengthModifySwitchRedPoint; // Offset: 0xab0 // Size: 0x01
	bool bRecordWonderfulReplayOpen; // Offset: 0xab1 // Size: 0x01
	char pad_0xAB2[0x2]; // Offset: 0xab2 // Size: 0x02
	int AntiAliasingValue; // Offset: 0xab4 // Size: 0x04
	bool OneKeyProneAndCrouchSwitch; // Offset: 0xab8 // Size: 0x01
	bool HasOperateOneKeyProneAndCrouch; // Offset: 0xab9 // Size: 0x01
	bool bLbsMain; // Offset: 0xaba // Size: 0x01
	bool bLbsChat; // Offset: 0xabb // Size: 0x01
	bool bOpenBattleNewBieAssist; // Offset: 0xabc // Size: 0x01
	bool bOpenLobbyNewBieAssist; // Offset: 0xabd // Size: 0x01
	char pad_0xABE[0x2]; // Offset: 0xabe // Size: 0x02
	int JoystickSprintSensitity; // Offset: 0xac0 // Size: 0x04
	bool bHideIngameUIAvailable; // Offset: 0xac4 // Size: 0x01
	bool bCloseHitHeadAudio; // Offset: 0xac5 // Size: 0x01
	char pad_0xAC6[0x2]; // Offset: 0xac6 // Size: 0x02
	int HightLightReshowAirLineTimes; // Offset: 0xac8 // Size: 0x04
	bool bHasSetWonderfulReplay; // Offset: 0xacc // Size: 0x01
	bool bIsShowedHideUIGuide; // Offset: 0xacd // Size: 0x01
	bool bAmericanCustomSettingGuide; // Offset: 0xace // Size: 0x01
	char pad_0xACF[0x1]; // Offset: 0xacf // Size: 0x01
	float CamLensSenNoneSniper_1; // Offset: 0xad0 // Size: 0x04
	float CamLensSenRedDotSniper_1; // Offset: 0xad4 // Size: 0x04
	float CamLensSen2XSniper_1; // Offset: 0xad8 // Size: 0x04
	float CamLensSen4XSniper_1; // Offset: 0xadc // Size: 0x04
	float CamLensSen8XSniper_1; // Offset: 0xae0 // Size: 0x04
	float FireCamLensSenNoneSniper_1; // Offset: 0xae4 // Size: 0x04
	float FireCamLensSenRedDotSniper_1; // Offset: 0xae8 // Size: 0x04
	float FireCamLensSen2XSniper_1; // Offset: 0xaec // Size: 0x04
	float FireCamLensSen4XSniper_1; // Offset: 0xaf0 // Size: 0x04
	float FireCamLensSen8XSniper_1; // Offset: 0xaf4 // Size: 0x04
	float GyroscopeSenNoneSniper_1; // Offset: 0xaf8 // Size: 0x04
	float GyroscopeSenRedDotSniper_1; // Offset: 0xafc // Size: 0x04
	float GyroscopeSen2XSniper_1; // Offset: 0xb00 // Size: 0x04
	float GyroscopeSen4XSniper_1; // Offset: 0xb04 // Size: 0x04
	float GyroscopeSen8XSniper_1; // Offset: 0xb08 // Size: 0x04
	float VehicleEye_1; // Offset: 0xb0c // Size: 0x04
	float ParachuteEye_1; // Offset: 0xb10 // Size: 0x04
	float CamFpFreeEye_1; // Offset: 0xb14 // Size: 0x04
	float CamLensSenNoneSniperFP_1; // Offset: 0xb18 // Size: 0x04
	float FireCamLensSenNoneSniperFP_1; // Offset: 0xb1c // Size: 0x04
	float GyroscopeSenNoneSniperFP_1; // Offset: 0xb20 // Size: 0x04
	float CamLensSen3XSniper_1; // Offset: 0xb24 // Size: 0x04
	float CamLensSen6XSniper_1; // Offset: 0xb28 // Size: 0x04
	float FireCamLensSen3XSniper_1; // Offset: 0xb2c // Size: 0x04
	float FireCamLensSen6XSniper_1; // Offset: 0xb30 // Size: 0x04
	float GyroscopeSen3XSniper_1; // Offset: 0xb34 // Size: 0x04
	float GyroscopeSen6XSniper_1; // Offset: 0xb38 // Size: 0x04
	float CamLensSenShoulderTPP_1; // Offset: 0xb3c // Size: 0x04
	float CamLensSenShoulderFPP_1; // Offset: 0xb40 // Size: 0x04
	float FireCamLensSenShoulderTPP_1; // Offset: 0xb44 // Size: 0x04
	float GyroscopeSenShoulderTPP_1; // Offset: 0xb48 // Size: 0x04
	float FireCamLensSenShoulderFPP_1; // Offset: 0xb4c // Size: 0x04
	float GyroscopeSenShoulderFPP_1; // Offset: 0xb50 // Size: 0x04
	float FireGyroscopeSenNoneSniper_1; // Offset: 0xb54 // Size: 0x04
	float FireGyroscopeSenRedDotSniper_1; // Offset: 0xb58 // Size: 0x04
	float FireGyroscopeSen2XSniper_1; // Offset: 0xb5c // Size: 0x04
	float FireGyroscopeSen4XSniper_1; // Offset: 0xb60 // Size: 0x04
	float FireGyroscopeSen8XSniper_1; // Offset: 0xb64 // Size: 0x04
	float FireGyroscopeSen3XSniper_1; // Offset: 0xb68 // Size: 0x04
	float FireGyroscopeSen6XSniper_1; // Offset: 0xb6c // Size: 0x04
	float FireGyroscopeSenNoneSniperFp_1; // Offset: 0xb70 // Size: 0x04
	float FireGyroscopeSenShoulderTPP_1; // Offset: 0xb74 // Size: 0x04
	float FireGyroscopeSenShoulderFPP_1; // Offset: 0xb78 // Size: 0x04
	bool bInitedCustomSensitivity; // Offset: 0xb7c // Size: 0x01
	bool bFireGyroSenUseGryo; // Offset: 0xb7d // Size: 0x01
	bool bFireCamSenUseCam; // Offset: 0xb7e // Size: 0x01
	bool AutoHitMark; // Offset: 0xb7f // Size: 0x01
	bool bResetDeathPlaybackSwitch; // Offset: 0xb80 // Size: 0x01
	bool SwitchSoundVisualization; // Offset: 0xb81 // Size: 0x01
	bool bConsumeThrow; // Offset: 0xb82 // Size: 0x01
	char pad_0xB83[0x5]; // Offset: 0xb83 // Size: 0x05
	struct TArray<int> MaxACCount; // Offset: 0xb88 // Size: 0x10
	struct TArray<int> DefaultACCount; // Offset: 0xb98 // Size: 0x10
	bool HasOperateSoundVisualization; // Offset: 0xba8 // Size: 0x01
	bool UseDisOrSpeedMove; // Offset: 0xba9 // Size: 0x01
	char pad_0xBAA[0x6]; // Offset: 0xbaa // Size: 0x06
	struct TMap<struct FString, int> OpenStoreTimes; // Offset: 0xbb0 // Size: 0x50
	struct TMap<int, int> setting_ver_info; // Offset: 0xc00 // Size: 0x50
	bool bIsBackpackExpand; // Offset: 0xc50 // Size: 0x01
	bool OpenMotivation; // Offset: 0xc51 // Size: 0x01
	char pad_0xC52[0x2]; // Offset: 0xc52 // Size: 0x02
	int HapticSwitch; // Offset: 0xc54 // Size: 0x04
	int HapticVoiceSwitch; // Offset: 0xc58 // Size: 0x04
	int HapticCharacterSwitch; // Offset: 0xc5c // Size: 0x04
	int HapticWeaponSwitch; // Offset: 0xc60 // Size: 0x04
	int HapticVehicleSwitch; // Offset: 0xc64 // Size: 0x04
	bool bHapticVoiceStep; // Offset: 0xc68 // Size: 0x01
	bool bHapticVoiceGrass; // Offset: 0xc69 // Size: 0x01
	bool bHapticVoiceGun; // Offset: 0xc6a // Size: 0x01
	bool bHapticVoiceVehicle; // Offset: 0xc6b // Size: 0x01
	bool bHapticCharacterBeGunAttack; // Offset: 0xc6c // Size: 0x01
	bool bHapticCharacterBeOtherAttack; // Offset: 0xc6d // Size: 0x01
	bool bHapticCharacterFall; // Offset: 0xc6e // Size: 0x01
	bool bHapticWeaponAttachment; // Offset: 0xc6f // Size: 0x01
	bool bHapticWeaponAuto; // Offset: 0xc70 // Size: 0x01
	bool bHapticWeaponSemiAuto; // Offset: 0xc71 // Size: 0x01
	bool bHapticWeaponSniper; // Offset: 0xc72 // Size: 0x01
	bool bHapticWeaponOther; // Offset: 0xc73 // Size: 0x01
	bool bHapticVehicleDrive; // Offset: 0xc74 // Size: 0x01
	bool bHapticVehicleBeAttack; // Offset: 0xc75 // Size: 0x01
	bool bHapticVehicleHit; // Offset: 0xc76 // Size: 0x01
	bool bIsOpenMapTaskUI; // Offset: 0xc77 // Size: 0x01
	bool AmmoRemain; // Offset: 0xc78 // Size: 0x01
	bool ReshowAirlineRouteBtnChecked; // Offset: 0xc79 // Size: 0x01
	bool OBMiniMap; // Offset: 0xc7a // Size: 0x01
	bool OBTeammateList; // Offset: 0xc7b // Size: 0x01
	bool OBPlayerInfo; // Offset: 0xc7c // Size: 0x01
	char pad_0xC7D[0x3]; // Offset: 0xc7d // Size: 0x03
	struct TArray<int> PlayerChatQuickTextIDList_2; // Offset: 0xc80 // Size: 0x10
	struct TArray<int> PlayerChatQuickTextIDList_3; // Offset: 0xc90 // Size: 0x10
	struct TArray<int> PlayerChatQuickTextIDList_4; // Offset: 0xca0 // Size: 0x10
	int PlayerChatIndex; // Offset: 0xcb0 // Size: 0x04
	char pad_0xCB4[0x4]; // Offset: 0xcb4 // Size: 0x04
	struct TArray<int> PlayerWheelChatQuickTextIDList_2; // Offset: 0xcb8 // Size: 0x10
	struct TArray<int> PlayerWheelChatQuickTextIDList_3; // Offset: 0xcc8 // Size: 0x10
	struct TArray<int> PlayerWheelChatQuickTextIDList_4; // Offset: 0xcd8 // Size: 0x10
	int PlayerChatActorID; // Offset: 0xce8 // Size: 0x04
	bool bHasCloudBasicSetting; // Offset: 0xcec // Size: 0x01
	bool isCloudSettingBasicUsed; // Offset: 0xced // Size: 0x01
	char pad_0xCEE[0x2]; // Offset: 0xcee // Size: 0x02
	struct FString NewbieGuideDailyLimit; // Offset: 0xcf0 // Size: 0x10
	int LastSaveSettingBasicTM; // Offset: 0xd00 // Size: 0x04
	bool OpenSilentChat; // Offset: 0xd04 // Size: 0x01
	bool DoubleIntimacyHint; // Offset: 0xd05 // Size: 0x01
	bool backgroundChat; // Offset: 0xd06 // Size: 0x01
	bool bCanMapLongPress; // Offset: 0xd07 // Size: 0x01
	float NoUIOpacity; // Offset: 0xd08 // Size: 0x04
	int OldMarkStyle; // Offset: 0xd0c // Size: 0x04
	struct TMap<struct FString, struct FString> PlayerFeatureVoiceCfg; // Offset: 0xd10 // Size: 0x50
	int SoundVisualizationType; // Offset: 0xd60 // Size: 0x04
	bool OBS_SwitchOBHttpComponent; // Offset: 0xd64 // Size: 0x01
	bool LocalHideMetroArmor; // Offset: 0xd65 // Size: 0x01
	char pad_0xD66[0x2]; // Offset: 0xd66 // Size: 0x02
	int TargetNameGuideTimes; // Offset: 0xd68 // Size: 0x04
	int DangerousGuideTimes; // Offset: 0xd6c // Size: 0x04
	int HunterTaskGuideTimes; // Offset: 0xd70 // Size: 0x04

	// Functions

	// Object Name: Function SettingConfig.SettingConfig_C.ConditionSetFireGyroData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ConditionSetFireGyroData(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SettingConfig.SettingConfig_C.Init
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

