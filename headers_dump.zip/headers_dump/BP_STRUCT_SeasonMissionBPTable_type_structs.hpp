#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SeasonMissionBPTable_type.BP_STRUCT_SeasonMissionBPTable_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_SeasonMissionBPTable_type {
	// Fields
	struct FString CName_0_3B02C7C021A8868F32F1BA220D295515; // Offset: 0x00 // Size: 0x10
	int ID_1_73B51A0066811C521281291A0132D224; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Path_2_746EFA0071EA42DC1C74470F02D39998; // Offset: 0x18 // Size: 0x10
	struct FString Wrapper_3_324A4F00599DC022161C6E8C019B5BF2; // Offset: 0x28 // Size: 0x10
};

