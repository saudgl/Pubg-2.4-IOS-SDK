#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Chat_UIBP.Lobby_Main_Chat_UIBP_C
// Size: 0x3d8 // Inherited bytes: 0x260
struct ULobby_Main_Chat_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_tipsopen; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* chatVoiceRoomLoop; // Offset: 0x268 // Size: 0x08
	struct UButton* btn_friend_redpoint; // Offset: 0x270 // Size: 0x08
	struct UButton* btn_open_chat; // Offset: 0x278 // Size: 0x08
	struct UButton* btn_quick_msg; // Offset: 0x280 // Size: 0x08
	struct UButton* btn_show_chat; // Offset: 0x288 // Size: 0x08
	struct UButton* Button_ChatRoom; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_4; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_ChatRoom; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Speaker; // Offset: 0x2a8 // Size: 0x08
	struct UUTRichTextBlock* chat_content; // Offset: 0x2b0 // Size: 0x08
	struct UVerticalBox* container_quick_msg; // Offset: 0x2b8 // Size: 0x08
	struct UCanvasPanel* GiftNotifyRoot; // Offset: 0x2c0 // Size: 0x08
	struct UOverlay* hover_root_anchor; // Offset: 0x2c8 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x2d0 // Size: 0x08
	struct UImage* Image_7; // Offset: 0x2d8 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x2e0 // Size: 0x08
	struct UImage* Image_25; // Offset: 0x2e8 // Size: 0x08
	struct ULobby_Main_Tips_ChatRoom_UIBP_C* Lobby_Main_Tips_ChatRoom_UIBP; // Offset: 0x2f0 // Size: 0x08
	struct UOverlay* NodeChatRoom; // Offset: 0x2f8 // Size: 0x08
	struct UOverlay* NodeClub; // Offset: 0x300 // Size: 0x08
	struct UOverlay* NodeCorps; // Offset: 0x308 // Size: 0x08
	struct UOverlay* NodeLocallanguage; // Offset: 0x310 // Size: 0x08
	struct UOverlay* NodePrivate; // Offset: 0x318 // Size: 0x08
	struct UCanvasPanel* NodeRoot; // Offset: 0x320 // Size: 0x08
	struct UOverlay* NodeSys; // Offset: 0x328 // Size: 0x08
	struct UOverlay* NodeTeam; // Offset: 0x330 // Size: 0x08
	struct UOverlay* NodeTopic; // Offset: 0x338 // Size: 0x08
	struct UOverlay* NodeWorld; // Offset: 0x340 // Size: 0x08
	struct UNamedSlot* normalFriendUnreadSlot; // Offset: 0x348 // Size: 0x08
	struct UNamedSlot* normalTagSlot; // Offset: 0x350 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_2; // Offset: 0x358 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_3; // Offset: 0x360 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_4; // Offset: 0x368 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_5; // Offset: 0x370 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_6; // Offset: 0x378 // Size: 0x08
	struct ULobbyChat_QuickChatItem_BP_C* quick_msg_item_7; // Offset: 0x380 // Size: 0x08
	struct UOverlay* RedPointRoot; // Offset: 0x388 // Size: 0x08
	struct UTextBlock* RedPointText; // Offset: 0x390 // Size: 0x08
	struct UCanvasPanel* Root; // Offset: 0x398 // Size: 0x08
	struct UCanvasPanel* SpeakerTips; // Offset: 0x3a0 // Size: 0x08
	struct UTextBlock* TextBlock_5; // Offset: 0x3a8 // Size: 0x08
	struct UTextBlock* TextBlock_6; // Offset: 0x3b0 // Size: 0x08
	struct UTextBlock* TextBlock_7; // Offset: 0x3b8 // Size: 0x08
	struct UTextBlock* TextBlock_8; // Offset: 0x3c0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x3c8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_2; // Offset: 0x3d0 // Size: 0x08
};

