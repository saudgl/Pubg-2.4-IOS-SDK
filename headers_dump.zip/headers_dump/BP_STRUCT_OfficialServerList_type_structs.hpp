#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_OfficialServerList_type.BP_STRUCT_OfficialServerList_type
// Size: 0x80 // Inherited bytes: 0x00
struct FBP_STRUCT_OfficialServerList_type {
	// Fields
	struct FString addr_0_27E398403D3B1D43701285EE0BD11912; // Offset: 0x00 // Size: 0x10
	struct FString channelInfo_1_5661AAC02746360902D4127A09BF3BCF; // Offset: 0x10 // Size: 0x10
	int ID_2_7F8F94C051EBFF7B33251B6503ABD3B4; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString name_3_68CC59C01B1A06ED702BBD6C0BD22595; // Offset: 0x28 // Size: 0x10
	struct FString Region_4_19A4AA806BF83A0041E1B64902E8758E; // Offset: 0x38 // Size: 0x10
	int status_5_68435A802C05658474376E0C00C92013; // Offset: 0x48 // Size: 0x04
	int tab_6_5DA8FF406C8D17B7224E85320ABD0C42; // Offset: 0x4c // Size: 0x04
	struct FString toleranceAddr_7_032DBF806D91048A01FA1C0709E10F32; // Offset: 0x50 // Size: 0x10
	struct FString Type_8_1804BA00239DD17873FACAF00BD2E3C5; // Offset: 0x60 // Size: 0x10
	struct FString SubArea_9_57199A400B20D43F297F8E5E0C8C3591; // Offset: 0x70 // Size: 0x10
};

