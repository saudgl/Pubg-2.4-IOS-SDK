#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SceneCaptureWidgetPlugin.WidgetCaptureComponent2D
// Size: 0x950 // Inherited bytes: 0x930
struct UWidgetCaptureComponent2D : USceneCaptureComponent2D {
	// Fields
	char pad_0x930[0x20]; // Offset: 0x930 // Size: 0x20
};

// Object Name: Class SceneCaptureWidgetPlugin.SceneCaptureCameraActor
// Size: 0x950 // Inherited bytes: 0x940
struct ASceneCaptureCameraActor : ACameraActor {
	// Fields
	struct UWidgetCaptureComponent2D* SceneCaptureComponent; // Offset: 0x940 // Size: 0x08
	char pad_0x948[0x8]; // Offset: 0x948 // Size: 0x08
};

// Object Name: Class SceneCaptureWidgetPlugin.SceneCaptureWidget
// Size: 0x1e0 // Inherited bytes: 0x100
struct USceneCaptureWidget : UWidget {
	// Fields
	struct FSlateBrush Brush; // Offset: 0x100 // Size: 0xb8
	struct ASceneCaptureCameraActor* SceneCaptureCameraActor; // Offset: 0x1b8 // Size: 0x08
	char pad_0x1C0[0x20]; // Offset: 0x1c0 // Size: 0x20

	// Functions

	// Object Name: Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSceneCaptureCameraActor(struct ASceneCaptureCameraActor* InSceneCaptureCameraActor); // Offset: 0x101fc6f50 // Return & Params: Num(1) Size(0x8)
};

