#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Skill.UTSkillHitInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillHitInfo {
	// Fields
	struct TArray<struct AActor*> ToPawn; // Offset: 0x00 // Size: 0x10
	struct AActor* FromPawn; // Offset: 0x10 // Size: 0x08
	int SkillID; // Offset: 0x18 // Size: 0x04
	int SkillPhaseID; // Offset: 0x1c // Size: 0x04
	bool Flag; // Offset: 0x20 // Size: 0x01
	bool IsHeadShot; // Offset: 0x21 // Size: 0x01
	enum class EPhysicalSurface HitSurfaceType; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
	struct FVector HitEnvLocation; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct Skill.ItemSkillsConfig
// Size: 0x28 // Inherited bytes: 0x00
struct FItemSkillsConfig {
	// Fields
	struct UClass* SkillTemplateClass; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct Skill.MultiSharedDelegateWrap
// Size: 0x20 // Inherited bytes: 0x00
struct FMultiSharedDelegateWrap {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UObject* Outer; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Skill.SharedDelegateWrap
// Size: 0x20 // Inherited bytes: 0x00
struct FSharedDelegateWrap {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct UObject* Outer; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillActionCreateData
// Size: 0x08 // Inherited bytes: 0x00
struct FUTSkillActionCreateData {
	// Fields
	enum class ESkillActionRole ActionRole; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DelayTime; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Skill.TeammateSkillCDRepData
// Size: 0x10 // Inherited bytes: 0x00
struct FTeammateSkillCDRepData {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	float CDStartTime; // Offset: 0x04 // Size: 0x04
	float CDEndTime; // Offset: 0x08 // Size: 0x04
	int UseCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Skill.SkillCDRepData
// Size: 0x18 // Inherited bytes: 0x00
struct FSkillCDRepData {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FUTSkillSyncData_CD> CDSyncDatas; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillSyncData_CD
// Size: 0x18 // Inherited bytes: 0x00
struct FUTSkillSyncData_CD {
	// Fields
	int SkillCDIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<char> SkillSyncDatas; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillBBUploadData
// Size: 0x10 // Inherited bytes: 0x00
struct FUTSkillBBUploadData {
	// Fields
	struct TArray<struct FUAEBlackboardKeySelector> KeySelectors; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Skill.SkillConditionWarpper
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillConditionWarpper {
	// Fields
	struct UUTSkillCondition* SkillCondition; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Skill.UTSkillInstance
// Size: 0xd0 // Inherited bytes: 0x00
struct FUTSkillInstance {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	int CurPhaseIndex; // Offset: 0x04 // Size: 0x04
	int LastPhaseIndex; // Offset: 0x08 // Size: 0x04
	int InstanceID; // Offset: 0x0c // Size: 0x04
	int SkillSlot; // Offset: 0x10 // Size: 0x04
	int Level; // Offset: 0x14 // Size: 0x04
	int ActiveState; // Offset: 0x18 // Size: 0x04
	int SkillCD; // Offset: 0x1c // Size: 0x04
	enum class UTSkillStopReason StopReason; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<enum class UTSkillEventType> EventCache; // Offset: 0x28 // Size: 0x10
	struct UUAEBlackboard* Blackboard; // Offset: 0x38 // Size: 0x08
	struct FUTSkillCreateData SkillBaseData; // Offset: 0x40 // Size: 0x70
	struct TWeakObjectPtr<struct AUTSkill> Skill; // Offset: 0xb0 // Size: 0x08
	struct TWeakObjectPtr<struct UUTSkillWidget> SkillWidget; // Offset: 0xb8 // Size: 0x08
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerComp; // Offset: 0xc0 // Size: 0x08
	bool bGsListener; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
};

// Object Name: ScriptStruct Skill.UTSkillCreateData
// Size: 0x70 // Inherited bytes: 0x00
struct FUTSkillCreateData {
	// Fields
	bool bSkillActived; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int SkillGroupIndex; // Offset: 0x04 // Size: 0x04
	float interval; // Offset: 0x08 // Size: 0x04
	float IntervalSincePrevFinish; // Offset: 0x0c // Size: 0x04
	struct FString CoolDownMessage; // Offset: 0x10 // Size: 0x10
	int CoolDownMessageID; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<struct UUTSkillPhase*> Phases; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UUTSkillCDBase*> SkillCDs; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
	struct TArray<struct FName> AsyncLoadingSkillUI; // Offset: 0x50 // Size: 0x10
	struct TArray<struct UUTSkillEventEffectMapForEditor*> EditorEventEffectMap; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct Skill.SkillParamater
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillParamater {
	// Fields
	bool bUseTag; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName SkillTag; // Offset: 0x08 // Size: 0x08
	enum class FSkillType SkillType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	float CDRecoveryScale; // Offset: 0x14 // Size: 0x04
	float SkillRuntimeScale; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Skill.SkillParamaterModifier
// Size: 0x20 // Inherited bytes: 0x20
struct FSkillParamaterModifier : FSkillParamater {
	// Fields
	enum class ESkillAttrOperator CDRecoveryScaleOP; // Offset: 0x1c // Size: 0x01
	enum class ESkillAttrOperator SkillRuntimeScaleOp; // Offset: 0x1d // Size: 0x01
};

// Object Name: ScriptStruct Skill.SkillClassIDData
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillClassIDData {
	// Fields
	struct FName SkillClassName; // Offset: 0x00 // Size: 0x08
	int SkillID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Skill.SkillDynamicRepData
// Size: 0x10 // Inherited bytes: 0x00
struct FSkillDynamicRepData {
	// Fields
	struct TArray<struct FSkillDynamicState> SkillData; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Skill.SkillDynamicState
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillDynamicState {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	bool bAdd; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Skill.SkillActiveRepData
// Size: 0x0c // Inherited bytes: 0x00
struct FSkillActiveRepData {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	int SkillLevel; // Offset: 0x04 // Size: 0x04
	bool bActive; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct Skill.UTSkillStateSyncData
// Size: 0x20 // Inherited bytes: 0x00
struct FUTSkillStateSyncData {
	// Fields
	struct FUTSkillStateSyncDataParam SyncParam; // Offset: 0x00 // Size: 0x02
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int SkillID; // Offset: 0x04 // Size: 0x04
	bool bSkillActive; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct TArray<struct FUTSkillSyncData_CD> CDSyncDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillStateSyncDataParam
// Size: 0x02 // Inherited bytes: 0x00
struct FUTSkillStateSyncDataParam {
	// Fields
	bool bSyncActive; // Offset: 0x00 // Size: 0x01
	bool bSyncCD; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct Skill.UTReplaceSkillData
// Size: 0x08 // Inherited bytes: 0x00
struct FUTReplaceSkillData {
	// Fields
	int OldSkillID; // Offset: 0x00 // Size: 0x04
	int NewSkillID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillSynSinglePhaseData
// Size: 0x0c // Inherited bytes: 0x00
struct FUTSkillSynSinglePhaseData {
	// Fields
	int CurSkillID; // Offset: 0x00 // Size: 0x04
	int CurSkillPhase; // Offset: 0x04 // Size: 0x04
	char UpdateFlag; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct Skill.UTMutilSkillSynData
// Size: 0x10 // Inherited bytes: 0x00
struct FUTMutilSkillSynData {
	// Fields
	int CurSkillID; // Offset: 0x00 // Size: 0x04
	int SynID; // Offset: 0x04 // Size: 0x04
	int PhaseIndexes; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillPhaseSynData
// Size: 0x08 // Inherited bytes: 0x00
struct FUTSkillPhaseSynData {
	// Fields
	int Index; // Offset: 0x00 // Size: 0x04
	int SynID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillHitEnvInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillHitEnvInfo {
	// Fields
	struct TArray<struct AActor*> ToPawn; // Offset: 0x00 // Size: 0x10
	struct AActor* FromPawn; // Offset: 0x10 // Size: 0x08
	int SkillID; // Offset: 0x18 // Size: 0x04
	int SkillPhaseID; // Offset: 0x1c // Size: 0x04
	enum class EPhysicalSurface HitSurfaceType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FVector HitEnvLocation; // Offset: 0x24 // Size: 0x0c
};

// Object Name: ScriptStruct Skill.UTSkillLastCastInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FUTSkillLastCastInfo {
	// Fields
	int SkillID; // Offset: 0x00 // Size: 0x04
	float LastCastTime; // Offset: 0x04 // Size: 0x04
	float LastCastFinishTime; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillAutoTriggerCondition
// Size: 0x28 // Inherited bytes: 0x00
struct FUTSkillAutoTriggerCondition {
	// Fields
	enum class ESkillConditionType Condition; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int Param_W; // Offset: 0x04 // Size: 0x04
	int Param_X; // Offset: 0x08 // Size: 0x04
	int Param_Y; // Offset: 0x0c // Size: 0x04
	int Param_Z; // Offset: 0x10 // Size: 0x04
	enum class ESkillEndConditionType EndCondition; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	int Param_A; // Offset: 0x18 // Size: 0x04
	int Param_B; // Offset: 0x1c // Size: 0x04
	int Param_C; // Offset: 0x20 // Size: 0x04
	int Param_D; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Skill.UTSkillPhaseCreateData
// Size: 0x88 // Inherited bytes: 0x00
struct FUTSkillPhaseCreateData {
	// Fields
	float PhaseDuration; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString TimeAdjustAttr; // Offset: 0x08 // Size: 0x10
	float AltPhaseDuration; // Offset: 0x18 // Size: 0x04
	float CacheMouseInputTime; // Offset: 0x1c // Size: 0x04
	bool bMustHasTarget; // Offset: 0x20 // Size: 0x01
	bool bCoolDown; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x2]; // Offset: 0x22 // Size: 0x02
	int CoolDownIndex; // Offset: 0x24 // Size: 0x04
	struct TArray<struct UUTSkillCondition*> PhaseConditions; // Offset: 0x28 // Size: 0x10
	struct UUTSkillPicker* Picker; // Offset: 0x38 // Size: 0x08
	struct TArray<struct UUTSkillEffect*> Actions; // Offset: 0x40 // Size: 0x10
	struct TArray<struct UUTSkillEffect*> HurtAppearances; // Offset: 0x50 // Size: 0x10
	enum class UTSkillPhaseType PhaseType; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3]; // Offset: 0x61 // Size: 0x03
	int JumpPhaseIndex; // Offset: 0x64 // Size: 0x04
	struct FString EnterPhaseTipString; // Offset: 0x68 // Size: 0x10
	struct TArray<struct UUTSkillEventEffectMapForEditor*> EditorEventEffectMap; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillEventActionMap
// Size: 0x30 // Inherited bytes: 0x00
struct FUTSkillEventActionMap {
	// Fields
	enum class UTSkillEventType SkillEventType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UUTSkillEffect* Action; // Offset: 0x08 // Size: 0x08
	struct TArray<struct UUTSkillCondition*> Conditions; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UUTSkillCondition*> TargetConditions; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Skill.UTSkillPickedTarget
// Size: 0x38 // Inherited bytes: 0x00
struct FUTSkillPickedTarget {
	// Fields
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x00 // Size: 0x08
	struct TWeakObjectPtr<struct UPrimitiveComponent> TargetComponent; // Offset: 0x08 // Size: 0x08
	bool IsHeadShot; // Offset: 0x10 // Size: 0x01
	char HitPos; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct FName BoneName; // Offset: 0x18 // Size: 0x08
	struct FVector HitEnvLocation; // Offset: 0x20 // Size: 0x0c
	float HitAngleCos; // Offset: 0x2c // Size: 0x04
	enum class EPhysicalSurface HitPhysMatType; // Offset: 0x30 // Size: 0x01
	bool IgnoreTakeDamage; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct Skill.UTSkillPickerCreateData
// Size: 0x20 // Inherited bytes: 0x00
struct FUTSkillPickerCreateData {
	// Fields
	enum class UTSkillPickerType PickerType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FUAEBlackboardKeySelector PickerOriginBlackboardKey; // Offset: 0x08 // Size: 0x08
	enum class UTPickerTargetType PickerTargetType; // Offset: 0x10 // Size: 0x01
	enum class UTSkillPickerRole PickerTargetRole; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	int PickerMaxCount; // Offset: 0x14 // Size: 0x04
	bool bIncludeOwner; // Offset: 0x18 // Size: 0x01
	bool bOnlyHero; // Offset: 0x19 // Size: 0x01
	bool bEnableTrace; // Offset: 0x1a // Size: 0x01
	bool bIsUsingViewRotation; // Offset: 0x1b // Size: 0x01
	bool bUseNewOffset; // Offset: 0x1c // Size: 0x01
	bool bIgnoreOwnerVehicleWhenTracePlayer; // Offset: 0x1d // Size: 0x01
	char pad_0x1E[0x2]; // Offset: 0x1e // Size: 0x02
};

// Object Name: ScriptStruct Skill.SkillFuncNameSelector
// Size: 0x08 // Inherited bytes: 0x00
struct FSkillFuncNameSelector {
	// Fields
	struct FName SelectedKeyName; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct Skill.SkillFlowExecutionStep
// Size: 0x70 // Inherited bytes: 0x00
struct FSkillFlowExecutionStep {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x00 // Size: 0x70
};

// Object Name: ScriptStruct Skill.SkillFlowStatsLog
// Size: 0x20 // Inherited bytes: 0x00
struct FSkillFlowStatsLog {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

