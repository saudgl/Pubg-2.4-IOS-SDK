#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C
// Size: 0x2c8 // Inherited bytes: 0x260
struct ULobby_Right_Content_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Open; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_MORE; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_4; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_9; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_RightBlockRoot; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_More; // Offset: 0x290 // Size: 0x08
	struct UScrollBox* ScrollBox_1; // Offset: 0x298 // Size: 0x08
	struct USpacer* Spacer_1; // Offset: 0x2a0 // Size: 0x08
	bool bShouldAutoScroll; // Offset: 0x2a8 // Size: 0x01
	char pad_0x2A9[0x7]; // Offset: 0x2a9 // Size: 0x07
	struct FTimerHandle AutoScrollDelayTimer; // Offset: 0x2b0 // Size: 0x08
	float AutoScrollRate; // Offset: 0x2b8 // Size: 0x04
	int autoScrollState; // Offset: 0x2bc // Size: 0x04
	struct FTimerHandle ScrollStateChangeTimer; // Offset: 0x2c0 // Size: 0x08

	// Functions

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.SetScrollBack
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetScrollBack(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.DelayStartAutoScroll
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void DelayStartAutoScroll(float DelayTime); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.StartAutoScroll
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StartAutoScroll(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.AutoScrollWhenUnTouched
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void AutoScrollWhenUnTouched(float DeltaTime); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103e03170 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.BndEvt__ScrollBox_0_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__ScrollBox_0_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature(float CurrentOffset); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_Right_Content_UIBP.Lobby_Right_Content_UIBP_C.ExecuteUbergraph_Lobby_Right_Content_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_Right_Content_UIBP(int EntryPoint); // Offset: 0x103e03170 // Return & Params: Num(1) Size(0x4)
};

