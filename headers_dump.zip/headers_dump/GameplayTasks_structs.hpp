#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GameplayTasks.GameplayResourceSet
// Size: 0x02 // Inherited bytes: 0x00
struct FGameplayResourceSet {
	// Fields
	char pad_0x0[0x2]; // Offset: 0x00 // Size: 0x02
};

