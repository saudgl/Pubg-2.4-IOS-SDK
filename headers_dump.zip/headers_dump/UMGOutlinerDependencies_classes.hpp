#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UMGOutlinerDependencies.UMGOutlinerBorderPanelWidget
// Size: 0x110 // Inherited bytes: 0x100
struct UUMGOutlinerBorderPanelWidget : UWidget {
	// Fields
	char pad_0x100[0x10]; // Offset: 0x100 // Size: 0x10
};

// Object Name: Class UMGOutlinerDependencies.UMGOutlinerBorderPanel
// Size: 0x268 // Inherited bytes: 0x260
struct UUMGOutlinerBorderPanel : UUserWidget {
	// Fields
	struct UUMGOutlinerBorderPanelWidget* BorderPanelWidget; // Offset: 0x260 // Size: 0x08
};

