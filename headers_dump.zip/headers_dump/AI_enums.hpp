#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum AI.EAISoundCollectType
enum class EAISoundCollectType : uint8 {
	AISoundCollectType_Step = 1,
	AISoundCollectType_Weapon = 2,
	AISoundCollectType_Vehicle = 3,
	AISoundCollectType_Horn = 4,
	AISoundCollectType_MAX = 5
};

// Object Name: Enum AI.ECustomDamageEventReactionType
enum class ECustomDamageEventReactionType : uint8 {
	SpawnActor = 0,
	ActiveParticles = 1,
	DetactiveParticles = 2,
	HideMesh = 3,
	HideMeshInstance = 4,
	HideBone = 5,
	ApplyPhysicalAnimationProfile = 6,
	SetCollisionEnabled = 7,
	ECustomDamageEventReactionType_MAX = 8
};

// Object Name: Enum AI.ECustomDamageEventTriggerType
enum class ECustomDamageEventTriggerType : uint8 {
	OnPassedDamageThreshold = 0,
	OnAnyDamage = 1,
	ECustomDamageEventTriggerType_MAX = 2
};

