#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LiveVideoPlugin.BP_LiveVideoLibrary
// Size: 0x68 // Inherited bytes: 0x28
struct UBP_LiveVideoLibrary : UBlueprintFunctionLibrary {
	// Fields
	struct FScriptMulticastDelegate m_PusherEventDelegate; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate m_PlayerEventDelegate; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate m_TcUploadEventDelegate; // Offset: 0x48 // Size: 0x10
	struct FScriptMulticastDelegate m_VideoEditerEventDelegate; // Offset: 0x58 // Size: 0x10

	// Functions

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UBP_LiveVideoLibrary* GetInstance(); // Offset: 0x101fc42c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_VideoEditerInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_VideoEditerInit(struct FString szLicenseUrl, struct FString szLicenseKey); // Offset: 0x101fc41e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_VideoEditerCallbackTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_VideoEditerCallbackTest(int nCode, int nParam1, int nParam2, struct FString strMessage); // Offset: 0x101fc40a4 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_TcUploadVideFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_TcUploadVideFile(struct FString strSignature, struct FString strVideoPath, struct FString strCoverPath, bool bEnableResume, bool bEnableHttps, struct FString strFileName); // Offset: 0x101fc3e78 // Return & Params: Num(7) Size(0x4c)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_TcUploadUnInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_TcUploadUnInit(); // Offset: 0x101fc3e44 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_TcUploadInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_TcUploadInit(); // Offset: 0x101fc3e10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_TcUploadCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_TcUploadCancel(int nSessionId); // Offset: 0x101fc3d94 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_SaveVideoToAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_SaveVideoToAlbum(struct FString strVideoPath); // Offset: 0x101fc3d04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_SaveImageToAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_SaveImageToAlbum(struct FString strImagePath); // Offset: 0x101fc3c74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_OpenVideoEditer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_OpenVideoEditer(struct FString szUrl); // Offset: 0x101fc3be4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherUnInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherUnInit(); // Offset: 0x101fc3bb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherStopRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherStopRecord(); // Offset: 0x101fc3b7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherStop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherStop(); // Offset: 0x101fc3b48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherStartRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherStartRecord(struct FString StrFilePath, int nWidth, int nHeight, int nFrameRate, int nBitRate, struct FString strThumbnailPath); // Offset: 0x101fc3964 // Return & Params: Num(7) Size(0x34)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherStart
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherStart(struct FString strUrl); // Offset: 0x101fc38cc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherSetOption
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherSetOption(struct FString strOption, int nVal); // Offset: 0x101fc37f4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherSaveVideoThumbnail
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherSaveVideoThumbnail(struct FString strThumbnailPath, struct FString strVideoPath, float fTime); // Offset: 0x101fc36c8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherResume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherResume(); // Offset: 0x101fc3694 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherPause
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherPause(); // Offset: 0x101fc3660 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherIsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_LivePusherIsRecord(); // Offset: 0x101fc362c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherIsPushing
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_LivePusherIsPushing(); // Offset: 0x101fc35f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherIsPush
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_LivePusherIsPush(); // Offset: 0x101fc35c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherInit(); // Offset: 0x101fc3590 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherGetVideoFileTotalTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float BP_LivePusherGetVideoFileTotalTime(struct FString strVideoPath); // Offset: 0x101fc34f8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherGetStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePusherGetStatus(); // Offset: 0x101fc34c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherGetCurRecordTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float BP_LivePusherGetCurRecordTime(); // Offset: 0x101fc3490 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherGetCurFreeStorage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float BP_LivePusherGetCurFreeStorage(); // Offset: 0x101fc345c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePusherGetAllStorage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float BP_LivePusherGetAllStorage(); // Offset: 0x101fc3428 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerUnInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerUnInit(); // Offset: 0x101fc33f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UTexture2D* BP_LivePlayerTexture(int nIndex); // Offset: 0x101fc3378 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerSeek
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerSeek(float fSeekTime); // Offset: 0x101fc32fc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerResume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerResume(); // Offset: 0x101fc32c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerPlayWithFd
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int BP_LivePlayerPlayWithFd(int& nFd, bool bLoopKey, bool bAutoPlayKey); // Offset: 0x101fc31ac // Return & Params: Num(4) Size(0xc)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerPlay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerPlay(struct FString strUrl, bool bLoopKey, bool bAutoPlayKey); // Offset: 0x101fc307c // Return & Params: Num(4) Size(0x18)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerPause
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerPause(); // Offset: 0x101fc3048 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerIsPlaying
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_LivePlayerIsPlaying(); // Offset: 0x101fc3014 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerIsPlay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_LivePlayerIsPlay(); // Offset: 0x101fc2fe0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerInit(); // Offset: 0x101fc2fac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerGetVideoTime
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_LivePlayerGetVideoTime(float& fCurTime, float& fTotalTime); // Offset: 0x101fc2edc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerGetStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerGetStatus(); // Offset: 0x101fc2ea8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerGetSolution
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_LivePlayerGetSolution(int& nWidth, int& nHeight); // Offset: 0x101fc2dd8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerGetSDKVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_LivePlayerGetSDKVersion(); // Offset: 0x101fc2dc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerGetformat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerGetformat(); // Offset: 0x101fc2d90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LivePlayerClose
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_LivePlayerClose(); // Offset: 0x101fc2d5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LiveLiveGetSavePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_LiveLiveGetSavePath(struct FString& strSavePath); // Offset: 0x101fc2cbc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LiveLiveGetFileSize
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BP_LiveLiveGetFileSize(struct FString strSavePath, float& fFileSize); // Offset: 0x101fc2bdc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_LiveLiveForceGarbageCollection
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BP_LiveLiveForceGarbageCollection(); // Offset: 0x101fc2bc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_IsOpenGLEs3
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool BP_IsOpenGLEs3(); // Offset: 0x101fc2b94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_ImageSizeCompres
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_ImageSizeCompres(struct FString strImagePath, struct FString strOutImagePath, int nNewWidth, int nNewHeight); // Offset: 0x101fc2a2c // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function LiveVideoPlugin.BP_LiveVideoLibrary.BP_CompressImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int BP_CompressImage(struct FString strImagePath, struct FString strOutImagePath, int nQuality); // Offset: 0x101fc2900 // Return & Params: Num(4) Size(0x28)
};

