#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HiggsBoson.FuzzyObject
// Size: 0x350 // Inherited bytes: 0x28
struct UFuzzyObject : UObject {
	// Fields
	char pad_0x28[0x320]; // Offset: 0x28 // Size: 0x320
	int Param1; // Offset: 0x348 // Size: 0x04
	char pad_0x34C[0x4]; // Offset: 0x34c // Size: 0x04

	// Functions

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt8ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt8ValueByName(struct FString Name, char Value); // Offset: 0x103b37b9c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt64ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt64ValueByName(struct FString Name, uint64 Value); // Offset: 0x103b37ab4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt32ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt32ValueByName(struct FString Name, uint32_t Value); // Offset: 0x103b379cc // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetUInt16ValueByName
	// Flags: [Final|Native|Public]
	bool SetUInt16ValueByName(struct FString Name, uint16_t Value); // Offset: 0x103b378e4 // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt8ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt8ValueByName(struct FString Name, uint8_t Value); // Offset: 0x103b377fc // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt64ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt64ValueByName(struct FString Name, int64_t Value); // Offset: 0x103b37714 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt32ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt32ValueByName(struct FString Name, int Value); // Offset: 0x103b3762c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetInt16ValueByName
	// Flags: [Final|Native|Public]
	bool SetInt16ValueByName(struct FString Name, int16_t Value); // Offset: 0x103b37544 // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.SetFloatValueByName
	// Flags: [Final|Native|Public]
	bool SetFloatValueByName(struct FString Name, float Value); // Offset: 0x103b3745c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.SetBoolValueByName
	// Flags: [Final|Native|Public]
	bool SetBoolValueByName(struct FString Name, bool Value); // Offset: 0x103b3736c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt8ValueByName(struct FString Name, char& OutValue); // Offset: 0x103b37274 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt64ValueByName(struct FString Name, uint64& OutValue); // Offset: 0x103b3717c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt32ValueByName(struct FString Name, uint32_t& OutValue); // Offset: 0x103b37084 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetUInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetUInt16ValueByName(struct FString Name, uint16_t& OutValue); // Offset: 0x103b36f8c // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt8ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt8ValueByName(struct FString Name, uint8_t& OutValue); // Offset: 0x103b36e94 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt64ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt64ValueByName(struct FString Name, int64_t& OutValue); // Offset: 0x103b36d9c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt32ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt32ValueByName(struct FString Name, int& OutValue); // Offset: 0x103b36ca4 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetInt16ValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetInt16ValueByName(struct FString Name, int16_t& OutValue); // Offset: 0x103b36bac // Return & Params: Num(3) Size(0x13)

	// Object Name: Function HiggsBoson.FuzzyObject.GetFloatValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetFloatValueByName(struct FString Name, float& OutValue); // Offset: 0x103b36ab4 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function HiggsBoson.FuzzyObject.GetBoolValueByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValueByName(struct FString Name, bool& OutValue); // Offset: 0x103b369bc // Return & Params: Num(3) Size(0x12)
};

// Object Name: Class HiggsBoson.SCoronaClientData
// Size: 0x350 // Inherited bytes: 0x350
struct USCoronaClientData : UFuzzyObject {
};

// Object Name: Class HiggsBoson.CamoyoHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UCamoyoHelper : UObject {
	// Functions

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeRectTu
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MakeRectTu(DelegateProperty CamoyoRetDelegate, struct FString Filename, int Quality, bool bShowUI); // Offset: 0x103b3883c // Return & Params: Num(4) Size(0x25)

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeMemPerform
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MakeMemPerform(int InbOpen); // Offset: 0x103b387c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.CamoyoHelper.MakeFitRectTu
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void MakeFitRectTu(DelegateProperty CamoyoRetDelegate, struct FVector4 InCutParam, int InTuType, bool isShowUI); // Offset: 0x103b3867c // Return & Params: Num(4) Size(0x25)
};

// Object Name: Class HiggsBoson.HiggsBosonComponent
// Size: 0xbd8 // Inherited bytes: 0x1d8
struct UHiggsBosonComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x110]; // Offset: 0x1d8 // Size: 0x110
	struct FString TraceData; // Offset: 0x2e8 // Size: 0x10
	struct FString GameTraceData; // Offset: 0x2f8 // Size: 0x10
	uint32_t HeartBreaks; // Offset: 0x308 // Size: 0x04
	char pad_0x30C[0x4]; // Offset: 0x30c // Size: 0x04
	struct FString HeartInfo; // Offset: 0x310 // Size: 0x10
	struct FScriptMulticastDelegate OnSwiftHawkDelegate; // Offset: 0x320 // Size: 0x10
	struct FScriptMulticastDelegate OnGlueHiaRayResult; // Offset: 0x330 // Size: 0x10
	struct ASTExtraBaseCharacter* CharacterOwner; // Offset: 0x340 // Size: 0x08
	struct ASTExtraPlayerController* PlayerController; // Offset: 0x348 // Size: 0x08
	bool bClientInfoReceived; // Offset: 0x350 // Size: 0x01
	char pad_0x351[0x7]; // Offset: 0x351 // Size: 0x07
	struct TArray<uint32_t> ClientInfoAsUInt32Array; // Offset: 0x358 // Size: 0x10
	struct TArray<char> IntegrityItemCheckResultAsBytes; // Offset: 0x368 // Size: 0x10
	char pad_0x378[0x40]; // Offset: 0x378 // Size: 0x40
	bool bRoofTouchActive; // Offset: 0x3b8 // Size: 0x01
	char pad_0x3B9[0xb]; // Offset: 0x3b9 // Size: 0x0b
	int RoofTouchStatus; // Offset: 0x3c4 // Size: 0x04
	char pad_0x3C8[0x738]; // Offset: 0x3c8 // Size: 0x738
	struct USCoronaClientData* SecurityCoronaLabClientDataPointer; // Offset: 0xb00 // Size: 0x08
	char pad_0xB08[0xd0]; // Offset: 0xb08 // Size: 0xd0

	// Functions

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SyncServerParam
	// Flags: [Final|Native|Public]
	void SyncServerParam(bool Param1); // Offset: 0x103b3ac68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void SwiftHawk(struct TArray<char> Hawks, uint32_t Magic); // Offset: 0x103b3ab5c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ShowSecurityAlertInDev
	// Flags: [Event|Public|BlueprintEvent]
	void ShowSecurityAlertInDev(struct FString Message, bool bIsClientShowWindow, bool bIsServerReportRobot, bool bIsSimilarMessageReportOnlyOnce); // Offset: 0x103e03170 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize
	// Flags: [Final|Native|Public]
	void SetSchemeForInitialize(int Index, uint32_t VerifyLen, struct TArray<char> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray); // Offset: 0x103b3a95c // Return & Params: Num(4) Size(0x28)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet
	// Flags: [Final|Native|Public]
	void SetSchemeForGet(int Index, uint32_t VerifyLen, struct TArray<char> VerifyHashArray, struct TArray<struct FPatchPoint> PatchPointArray); // Offset: 0x103b3a75c // Return & Params: Num(4) Size(0x28)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ServerPoPo
	// Flags: [Final|Native|Private|HasOutParms]
	void ServerPoPo(struct TArray<char>& Array); // Offset: 0x103b3a6b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_ServerGlueHiaPark(uint8_t HeShui, struct TArray<char> GlueHiaParkArr, uint32_t HiaStatus, struct TArray<char> GlueArg, struct TArray<char> GlueHiaParkArr2, uint32_t HiaStatus2); // Offset: 0x103b3a474 // Return & Params: Num(6) Size(0x44)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void RPC_ServerCapbo(uint8_t BoCapC, uint8_t InBoType, struct TArray<char> BoDataArr); // Offset: 0x103b3a32c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void RPC_ClientCoronaLab(char bAllSwitch, struct TArray<char> CoronaLab, uint32_t CoronaState); // Offset: 0x103b3a1e0 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput
	// Flags: [Final|Native|Public]
	void OnWeaponAimInput(float InDistToEnemy, float InYaw, float InPitch, float InRoll); // Offset: 0x103b3a0b8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnTouchInput
	// Flags: [Final|Native|Public]
	void OnTouchInput(float InYaw, float InPitch, float InRoll); // Offset: 0x103b39fc8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent
	// Flags: [Final|Native|Public]
	void OnStopFireEvent(); // Offset: 0x103b39fb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent
	// Flags: [Final|Native|Public]
	void OnStartFireEvent(); // Offset: 0x103b39fa0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual
	// Flags: [Final|Native|Public]
	void OnSkillInteruptVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103b39eec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual
	// Flags: [Final|Native|Public]
	void OnSkillEndVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103b39e38 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans
	// Flags: [Final|Native|Public]
	void OnSkillEndTrans(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103b39d84 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual
	// Flags: [Final|Native|Public]
	void OnSkillBeginVisual(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103b39cd0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans
	// Flags: [Final|Native|Public]
	void OnSkillBeginTrans(struct AActor* InTarget, struct AActor* InCauser); // Offset: 0x103b39c1c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut
	// Flags: [Final|Native|Public]
	void OnPlayerScopeOut(bool bBegan); // Offset: 0x103b39b98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn
	// Flags: [Final|Native|Public]
	void OnPlayerScopeIn(bool bBegan); // Offset: 0x103b39b14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn
	// Flags: [Final|Native|Public]
	void OnMyPawnRespawn(struct AUAEPlayerController* InPlayerController); // Offset: 0x103b39a98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent
	// Flags: [Final|Native|Public]
	void OnKillSomeOneEvent(struct AActor* InSomeOne); // Offset: 0x103b39a1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnGyroInput
	// Flags: [Final|Native|Public]
	void OnGyroInput(float InYaw, float InPitch, float InRoll); // Offset: 0x103b3992c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition
	// Flags: [Final|Native|Public|HasDefaults]
	void OnClientAdjustPosition(struct FVector NewLoc, enum class ECharacterMoveDragReason Reason); // Offset: 0x103b39874 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnCapboReturn
	// Flags: [Final|Native|Public|HasOutParms]
	void OnCapboReturn(int BoCapC, int InBoType, struct TArray<char>& RetData); // Offset: 0x103b39754 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent
	// Flags: [Final|Native|Public|HasOutParms]
	void OnBulletImpactEvent(struct AActor* InCauser, struct FHitResult& InImpactResult); // Offset: 0x103b39678 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect
	// Flags: [Final|Native|Public]
	void HandleClientReconnect(); // Offset: 0x103b39664 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.FlushGameEnd
	// Flags: [Final|Native|Public]
	void FlushGameEnd(); // Offset: 0x103b39650 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors
	// Flags: [Final|Native|Public]
	void EnableEnhancedDynamicActors(int Index); // Offset: 0x103b395d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem
	// Flags: [Final|Native|Public]
	void DispatchIntegrityCheckItem(uint32_t PlatID, uint32_t AreaID, uint32_t GameBits, uint32_t Index, int Offset, uint32_t Len, uint32_t Type); // Offset: 0x103b393fc // Return & Params: Num(7) Size(0x1c)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch
	// Flags: [Final|Native|Public]
	void ControlRoofTouch(int Switch); // Offset: 0x103b39380 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSwiftHawkWithParams(struct TArray<char> Hawks); // Offset: 0x103b392e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSwiftHawk(char Type, int SequenceID); // Offset: 0x103b39220 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx
	// Flags: [Final|Net|Native|Event|Private|NetClient|NetValidate]
	void ClientReceiveEx(struct TArray<char> RPCConstArray); // Offset: 0x103b39158 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HiggsBoson.HiggsBosonComponent.ClientDoJT
	// Flags: [Final|Native|Public]
	void ClientDoJT(bool bDelayUntilShot); // Offset: 0x103b390d4 // Return & Params: Num(1) Size(0x1)
};

