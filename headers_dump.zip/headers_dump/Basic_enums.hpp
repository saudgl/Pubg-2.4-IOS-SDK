#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Basic.EAttrOperator
enum class EAttrOperator : uint8 {
	Plus = 0,
	Multiply = 1,
	Set = 2,
	EAttrOperator_MAX = 3
};

// Object Name: Enum Basic.EAttrModifyRefType
enum class EAttrModifyRefType : uint8 {
	Val = 0,
	Rate = 1,
	Abs = 2,
	Set = 3,
	EAttrModifyRefType_MAX = 4
};

// Object Name: Enum Basic.EAttrVariableType
enum class EAttrVariableType : uint8 {
	Byte = 0,
	Int = 1,
	Float = 2,
	Num = 3,
	EAttrVariableType_MAX = 4
};

// Object Name: Enum Basic.EActorRegAttrTableType
enum class EActorRegAttrTableType : uint8 {
	EATY_NONE = 0,
	EATY_PLAYER = 1,
	EATY_ZOMBIE = 2,
	EATY_WEAPON = 3,
	EATY_VEHICLE = 4,
	EATY_MAX = 5
};

// Object Name: Enum Basic.EBattleItemDropReason
enum class EBattleItemDropReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	AutoEquipFailed = 3,
	CapacityExceeded = 4,
	UsedUp = 5,
	Force = 6,
	Replaced = 7,
	VehicleGroup = 8,
	Throwaway = 9,
	EBattleItemDropReason_MAX = 10
};

// Object Name: Enum Basic.EBattleItemUseReason
enum class EBattleItemUseReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoEquipAndDrop = 2,
	Swapped = 3,
	Initial = 4,
	EquipAndRecovery = 5,
	SwappedWithPackageWeapon = 6,
	EquipAndRecoveryToSafetyBox = 7,
	SkillUse = 8,
	EBattleItemUseReason_MAX = 9
};

// Object Name: Enum Basic.EItemStoreArea
enum class EItemStoreArea : uint8 {
	InBag = 0,
	InSafetyBox = 1,
	EItemStoreArea_MAX = 2
};

// Object Name: Enum Basic.EBattleItemAdditionalDataType
enum class EBattleItemAdditionalDataType : uint8 {
	None = 0,
	TargetLogicSocket = 1,
	Weapon_Durability_Backpack = 2,
	Weapon_BulletNum_Backpack = 3,
	Weapon_UpgradeInfo_Backpack = 4,
	RemainingDuability = 5,
	EquipmentAvatar = 6,
	WeaponAvatar = 7,
	CustomColor = 8,
	CustomPattern = 9,
	CurElectricty = 10,
	AutoUse = 11,
	LimitPlayerKey = 12,
	MaxElectricty = 14,
	ConsumeSpeed = 15,
	ChipSlot1 = 16,
	ChipSlot2 = 17,
	ChipSlot3 = 18,
	CustomNum = 21,
	AUTO_EQUIP_ARMOE_ATTACHMENT = 22,
	AUTO_EQUIP_WEAPON_ATTACHMENT = 23,
	RollOnDead = 24,
	AutoEquipFromBackpack = 25,
	BUsing = 26,
	IsEquiping = 27,
	AvatarItem = 28,
	Affix = 29,
	VehicleHPRatio = 30,
	VehicleFuelRatio = 31,
	VehicleEnergyRatio = 32,
	GunPoint = 100,
	Grip = 101,
	Magazine = 102,
	Gunstock = 103,
	OpticalSight = 104,
	MasterGun = 107,
	Ammo = 108,
	Pendant = 109,
	AngledOpticalSight = 110,
	ACCore = 111,
	EBattleItemAdditionalDataType_MAX = 112
};

// Object Name: Enum Basic.EBattleItemDisuseReason
enum class EBattleItemDisuseReason : uint8 {
	Manually = 0,
	Associated = 1,
	Excluded = 2,
	Swapped = 3,
	Dropped = 4,
	Force = 5,
	Replace = 6,
	VehicleGroup = 7,
	PutBack = 8,
	PutIntoSafetyBox = 9,
	ReplacedAndPutBack = 10,
	EBattleItemDisuseReason_MAX = 11
};

// Object Name: Enum Basic.EBattleItemPickupReason
enum class EBattleItemPickupReason : uint8 {
	Manually = 0,
	Associated = 1,
	AutoPickup = 2,
	Initial = 3,
	ForceIntoBackpack = 4,
	AutoPickupAttachment = 5,
	SplitStack = 6,
	EBattleItemPickupReason_MAX = 7
};

// Object Name: Enum Basic.EAnimLayerType
enum class EAnimLayerType : uint8 {
	EAnimLayer_Char = 0,
	EAnimLayer_Avatar = 1,
	EAnimLayer_Weapon = 2,
	EAnimLayer_WeaponAdditive = 3,
	EAnimLayer_WeaponAdditive2 = 4,
	EAnimLayer_Skill = 5,
	EAnimLayer_Max = 6
};

// Object Name: Enum Basic.EAttrModifyChannel
enum class EAttrModifyChannel : uint8 {
	SimulatedProxy = 1,
	AutonomousProxy = 2,
	Authority = 3,
	AllChannel = 10,
	EAttrModifyChannel_MAX = 11
};

// Object Name: Enum Basic.EBattleItemClientPickupType
enum class EBattleItemClientPickupType : uint8 {
	Defalut = 0,
	ForceIntoBackpack = 1,
	PickupIntoSafetyBox = 2,
	EBattleItemClientPickupType_MAX = 3
};

// Object Name: Enum Basic.EColdModeItemType
enum class EColdModeItemType : uint8 {
	firewood = 0,
	meat = 1,
	EColdModeItemType_MAX = 2
};

// Object Name: Enum Basic.EBattleItemPickupRule
enum class EBattleItemPickupRule : uint8 {
	All = 0,
	Self = 1,
	Team = 2,
	Group = 3,
	None = 99,
	EBattleItemPickupRule_MAX = 100
};

// Object Name: Enum Basic.EDataTag
enum class EDataTag : uint8 {
	EDefault = 0,
	EDamageQuery = 1,
	EDamageBuff = 2,
	EBulletImpactEffect = 3,
	EDataTag_MAX = 4
};

// Object Name: Enum Basic.EFeatureSetType
enum class EFeatureSetType : uint8 {
	DedicateServer = 0,
	Autonomous = 1,
	Simulate_Team = 2,
	Simulate_NonTeam = 3,
	DedicateServer_AI = 4,
	DedicateServer_MLAI = 5,
	Simulate_AI = 6,
	Standalone = 7,
	Standalone_AI = 8,
	Max = 9
};

// Object Name: Enum Basic.EItemAssociationType
enum class EItemAssociationType : uint8 {
	None = 0,
	Parent = 1,
	ChipSlot1 = 2,
	ChipSlot2 = 3,
	ChipSlot3 = 4,
	AssociationName = 5,
	Pendant = 6,
	Weapon_Durability_Backpack = 7,
	EItemAssociationType_MAX = 8
};

// Object Name: Enum Basic.ESkillPropSubType
enum class ESkillPropSubType : int32 {
	ESkillPropSubType_None = 1200,
	ESkillPropSubType_1202 = 1201,
	ESkillPropSubType_MAX = 1202
};

// Object Name: Enum Basic.ESimulateAddBuffRole
enum class ESimulateAddBuffRole : uint8 {
	AddBuffRole_None = 0,
	AddBuffRole_All = 1,
	AddBuffRole_Self = 2,
	AddBuffRole_Causer = 3,
	AddBuffRole_Firend = 4,
	AddBuffRole_Enermy = 5,
	AddBuffRole_MAX = 6
};

// Object Name: Enum Basic.EDeviceLevel
enum class EDeviceLevel : uint8 {
	DeviceLevel_Low = 0,
	DeviceLevel_Middle = 1,
	DeviceLevel_Hight = 2,
	DeviceLevel_MAX = 3
};

// Object Name: Enum Basic.EBuffEnabledRole
enum class EBuffEnabledRole : uint8 {
	ROLE_None = 0,
	ROLE_SimulatedProxy = 1,
	ROLE_AutonomousProxy = 2,
	ROLE_Authority = 3,
	ROLE_Client = 4,
	ROLE_MAX = 5
};

// Object Name: Enum Basic.EBuffClientSyncType
enum class EBuffClientSyncType : uint8 {
	None = 0,
	All = 1,
	Autonomous = 2,
	EBuffClientSyncType_MAX = 3
};

// Object Name: Enum Basic.EBuffConditionAndOr
enum class EBuffConditionAndOr : uint8 {
	And = 0,
	Or = 1,
	EBuffConditionAndOr_MAX = 2
};

// Object Name: Enum Basic.EBuffConditionExecuteTimeType
enum class EBuffConditionExecuteTimeType : uint8 {
	FirstTime = 0,
	EveryTime = 1,
	EBuffConditionExecuteTimeType_MAX = 2
};

// Object Name: Enum Basic.EBuffConditionFalseExecuteType
enum class EBuffConditionFalseExecuteType : uint8 {
	None = 0,
	Disabled = 1,
	DisabledEnd = 2,
	EBuffConditionFalseExecuteType_MAX = 3
};

// Object Name: Enum Basic.EBuffConditionTrueExecuteType
enum class EBuffConditionTrueExecuteType : uint8 {
	Enabled = 0,
	ReAction = 1,
	EBuffConditionTrueExecuteType_MAX = 2
};

// Object Name: Enum Basic.EBuffConditionInitializeType
enum class EBuffConditionInitializeType : uint8 {
	None = 0,
	Disabled = 1,
	EBuffConditionInitializeType_MAX = 2
};

// Object Name: Enum Basic.EBuffTargetSubType
enum class EBuffTargetSubType : uint8 {
	EBuffTargetSubType_Other = 0,
	EBuffTargetSubType_Rifle = 1,
	EBuffTargetSubType_SingleShotSniper = 2,
	EBuffTargetSubType_BurstShotSniper = 3,
	EBuffTargetSubType_Submachine = 4,
	EBuffTargetSubType_ShotGun = 5,
	EBuffTargetSubType_MachineGun = 6,
	EBuffTargetSubType_Pistol = 7,
	EBuffTargetSubType_Melee = 8,
	EBuffTargetSubType_Crossbow = 9,
	EBuffTargetSubType_All = 32,
	EBuffTargetSubType_MAX = 33
};

// Object Name: Enum Basic.EBuffTargetSocketType
enum class EBuffTargetSocketType : uint8 {
	Character = 0,
	Weapon = 1,
	World = 2,
	Vehicle = 3,
	EBuffTargetSocketType_MAX = 4
};

// Object Name: Enum Basic.EBuffTargetType
enum class EBuffTargetType : uint8 {
	Character = 0,
	Weapon = 1,
	Player = 2,
	Monster = 3,
	MonsterPlayer = 4,
	Vehicle = 5,
	EBuffTargetType_MAX = 6
};

// Object Name: Enum Basic.EBuffReActionType
enum class EBuffReActionType : uint8 {
	None = 0,
	OverWOrAddL = 1,
	ResetTime = 2,
	ResetLayer = 3,
	LayerChange = 4,
	InitWeapon = 5,
	EBuffReActionType_MAX = 6
};

// Object Name: Enum Basic.EBuffRefreshType
enum class EBuffRefreshType : uint8 {
	None = 0,
	ResetTime = 1,
	ResetTimeOnOverFlow = 2,
	ResetLayerOnOverFlow = 3,
	ResetAllOnOverFlow = 4,
	AppendTime = 5,
	EBuffRefreshType_MAX = 6
};

// Object Name: Enum Basic.EMultiSkillHandleType
enum class EMultiSkillHandleType : uint8 {
	UseNewer = 0,
	UseOlder = 1,
	StackEffect = 2,
	UseMaxPower = 3,
	RefreshOlder = 4,
	Coexist = 5,
	EMultiSkillHandleType_MAX = 6
};

// Object Name: Enum Basic.EMultiCauserHandleType
enum class EMultiCauserHandleType : uint8 {
	UseNewer = 0,
	UseOlder = 1,
	StackEffect = 2,
	UseMaxPower = 3,
	RefreshOlder = 4,
	Coexist = 5,
	EMultiCauserHandleType_MAX = 6
};

// Object Name: Enum Basic.EBuffTargetSourceType
enum class EBuffTargetSourceType : uint8 {
	Self = 0,
	PrevActionSet = 1,
	AreaOfTeammate = 2,
	AreaOfMonster = 3,
	Causer = 4,
	EBuffTargetSourceType_MAX = 5
};

// Object Name: Enum Basic.ESTExtraNetPriorityIssueID
enum class ESTExtraNetPriorityIssueID : uint8 {
	kNone = 0,
	kMove = 1,
	kStateChange = 2,
	ESTExtraNetPriorityIssueID_MAX = 3
};

// Object Name: Enum Basic.ESTExtraNetPriorityFlags
enum class ESTExtraNetPriorityFlags : uint8 {
	kPriority1 = 0,
	kPriority2 = 1,
	kPriority3 = 2,
	kPriority4 = 3,
	kMaxNum = 4,
	kPriorityNormal = 255,
	ESTExtraNetPriorityFlags_MAX = 256
};

// Object Name: Enum Basic.ENetMonitorType
enum class ENetMonitorType : uint8 {
	CLOSE = 0,
	REPORT = 1,
	REPORTANDPROFILE = 2,
	ENetMonitorType_MAX = 3
};

// Object Name: Enum Basic.ELostConnectionToDSReason
enum class ELostConnectionToDSReason : uint8 {
	LostConnectionToDSReason_None = 0,
	LostConnectionToDSReason_TravelFailure_Default = 1,
	LostConnectionToDSReason_LocalConnectionLost = 2,
	LostConnectionToDSReason_LocalDetectedTimeout = 3,
	LostConnectionToDSReason_NMTFailure_Default = 4,
	LostConnectionToDSReason_MAX = 5
};

// Object Name: Enum Basic.EAngleRotationDirectionType
enum class EAngleRotationDirectionType : uint8 {
	EAutoMinAngle = 0,
	ERight = 1,
	ELeft = 2,
	EAngleRotationDirectionType_MAX = 3
};

