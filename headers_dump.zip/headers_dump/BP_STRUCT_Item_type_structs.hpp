#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_Item_type.BP_STRUCT_Item_type
// Size: 0x198 // Inherited bytes: 0x00
struct FBP_STRUCT_Item_type {
	// Fields
	struct FString ItemBigIcon_0_733663734EEB8DD5D7FF41A6E96480D4; // Offset: 0x00 // Size: 0x10
	int MaxCount_1_D5BF33434E37E75739D213989C4FA372; // Offset: 0x10 // Size: 0x04
	int BPID_2_F73A5EF243D620CE49BBCAA8832C6AF9; // Offset: 0x14 // Size: 0x04
	int ItemType_3_4CBCE77A4D2A20BEBD861AADEF3B616B; // Offset: 0x18 // Size: 0x04
	bool AutoEquipAndDrop_4_144B885646B92B9836CE33923842AB1E; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	int ItemID_5_29F7B64741688A0A853FD281FAE4E28D; // Offset: 0x20 // Size: 0x04
	bool Consumable_7_B08070BD407AD029B7CDA7BDB341A342; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	struct FString ItemDesc_8_8ED919494479E8A62F11DBB9C7AD0F9A; // Offset: 0x28 // Size: 0x10
	struct FString ItemSmallIcon_9_B13D206C4A153C963FCE478A1B39C15F; // Offset: 0x38 // Size: 0x10
	struct FString ItemName_10_B257B36A422BB69651454E90EBC1323B; // Offset: 0x48 // Size: 0x10
	struct FString WardrobeTab_11_6562B47746AECB0B5C84BC9C96EACD9D; // Offset: 0x58 // Size: 0x10
	int ItemSubType_12_087F026E41DAB82F567758A4F56D72CF; // Offset: 0x68 // Size: 0x04
	bool Equippable_13_BB222DC04DCB195FCB3F29B89EA210CA; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	float UnitWeight_f_14_725EBB604F31443B93AF3597580ECAE4; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString ItemWhiteIcon_15_AA35FD8045790AA9F73F58829F202B94; // Offset: 0x78 // Size: 0x10
	int ItemQuality_16_3EF7461D45D14FC186EB3DBB70D01484; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FString KillWhiteIcon_27_16289384496FF361F9005580DEF9CAD1; // Offset: 0x90 // Size: 0x10
	int NeedShare_73_D9C0818D40A3C6AB07231BABA5477060; // Offset: 0xa0 // Size: 0x04
	int WeightforOrder_29_4373EFCD4D78E7DF4067FF9D3E213664; // Offset: 0xa4 // Size: 0x04
	struct FString Preview_32_1997D4634D3D3F8CC7360283D2AF4E6C; // Offset: 0xa8 // Size: 0x10
	struct FString ExTime_33_8299B7454C71BC6A899937AF00BFF0C5; // Offset: 0xb8 // Size: 0x10
	struct FString PickupDesc_36_D5D621864C55ED8C6ABE728B6F002D4E; // Offset: 0xc8 // Size: 0x10
	int WardrobeMainTab_38_D234FCBE4A19AAF3066394AD7C7D98DF; // Offset: 0xd8 // Size: 0x04
	int Durability_39_7B54DEB94CD411488438539500D225E1; // Offset: 0xdc // Size: 0x04
	bool IsBatchUse_40_88AB90DA48C707B0FE6DB18185C6253A; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x3]; // Offset: 0xe1 // Size: 0x03
	int AIFullVaule_43_6A3A6FC023E58D4B4FDDDF270E81E075; // Offset: 0xe4 // Size: 0x04
	int LongDescID_44_4E8350406652C05F7794F90804562904; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
	struct FString ItemSmallIcon2_46_6ED99A00141F4C900B45252101330012; // Offset: 0xf0 // Size: 0x10
	struct FString ItemBigIcon2_47_2C0E40404ED554873AD82D3A053DBC62; // Offset: 0x100 // Size: 0x10
	struct FString BackpackSimple_48_26F807C06BB149650FE17C280F83D985; // Offset: 0x110 // Size: 0x10
	struct FString ItemRegion_49_3899A60047215AA47D8652720D715E6E; // Offset: 0x120 // Size: 0x10
	int ShowSexInMall_56_0C9F0CC01B8DDF89290B2B7F0D9E026C; // Offset: 0x130 // Size: 0x04
	int AvatarID_68_319E644077E02FFF04B5C19B04157FD4; // Offset: 0x134 // Size: 0x04
	struct FString SpecialIcon_72_55E01BC05ADCEE1500E06C0F01021C3E; // Offset: 0x138 // Size: 0x10
	struct FString ValidRegionCodes_74_2EA4F9C02DC66B4573D87CB8064AB793; // Offset: 0x148 // Size: 0x10
	int ValidTimes_75_5BC6A5C03028B6616FF746180062B373; // Offset: 0x158 // Size: 0x04
	int RateType_77_176334C00292E359401D0B6600355865; // Offset: 0x15c // Size: 0x04
	struct FString QualityRate_78_5F4A46807D1C4B2C0A08E8F50F3EB745; // Offset: 0x160 // Size: 0x10
	int character_param_81_2F2A70804AD88C7E6E8F5B83071E93DD; // Offset: 0x170 // Size: 0x04
	int JKBPID_82_1FF3B64037160BBF09A6FDF60967EB24; // Offset: 0x174 // Size: 0x04
	int ItemSoundID_83_7010328028DE3D6841FCD9F407C46B04; // Offset: 0x178 // Size: 0x04
	int ResSeprateType_84_5349D1400501D3B166D23C1D0CBC9FE5; // Offset: 0x17c // Size: 0x04
	int CanIntoBag_85_416CF6C01FD7CDED0F5E477601A418C7; // Offset: 0x180 // Size: 0x04
	int ItemPickupRule_87_49300E005A58193E16239C7A00F80F05; // Offset: 0x184 // Size: 0x04
	struct FString SpecialIconSize_89_4BBF62802BA083E043328BD00C42A315; // Offset: 0x188 // Size: 0x10
};

