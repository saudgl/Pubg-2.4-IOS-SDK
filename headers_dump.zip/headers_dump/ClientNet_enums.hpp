#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ClientNet.EIMSDKPlatformType
enum class EIMSDKPlatformType : uint8 {
	kIMSDKPlatformTypeUnknow = 0,
	kIMSDKPlatformTypeIOS = 1,
	kIMSDKPlatformTypeAndroid = 2,
	EIMSDKPlatformType_MAX = 3
};

