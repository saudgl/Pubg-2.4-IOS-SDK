#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MediaAssets.MediaCaptureDevice
// Size: 0x28 // Inherited bytes: 0x00
struct FMediaCaptureDevice {
	// Fields
	struct FText DisplayName; // Offset: 0x00 // Size: 0x18
	struct FString URL; // Offset: 0x18 // Size: 0x10
};

