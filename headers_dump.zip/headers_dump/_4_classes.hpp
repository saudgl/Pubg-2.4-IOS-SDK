#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Avatar_All_UIBP.Common_Avatar_All_UIBP_C
// Size: 0x2b0 // Inherited bytes: 0x260
struct UCommon_Avatar_All_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Avatar; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Ban; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_Avatar; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_frame; // Offset: 0x280 // Size: 0x08
	struct UImage* Image_Icon_Default; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_medal; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_Reddot; // Offset: 0x298 // Size: 0x08
	struct UImage* Image_roleinfo_nation; // Offset: 0x2a0 // Size: 0x08
	struct UTextBlock* TextBlock_PlayerLevel; // Offset: 0x2a8 // Size: 0x08
};

