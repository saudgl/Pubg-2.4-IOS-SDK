#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PlaneBPTable_type.BP_STRUCT_PlaneBPTable_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_PlaneBPTable_type {
	// Fields
	int ID_0_59EBC34020F2CB575FD7DA4501D5C5E4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Path_1_6A746340179EA83F75000E8B05C45978; // Offset: 0x08 // Size: 0x10
	struct FString CName_2_5267910037561B4A1C0638D70C555B65; // Offset: 0x18 // Size: 0x10
	struct FString LobbyPath_3_11D881407290252D3B3DCF9705C20AE8; // Offset: 0x28 // Size: 0x10
};

