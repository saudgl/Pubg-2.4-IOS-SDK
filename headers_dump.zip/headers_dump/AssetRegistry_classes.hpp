#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AssetRegistry.AssetRegistryImpl
// Size: 0x6f8 // Inherited bytes: 0x28
struct UAssetRegistryImpl : UObject {
	// Fields
	char pad_0x28[0x6d0]; // Offset: 0x28 // Size: 0x6d0
};

// Object Name: Class AssetRegistry.AssetRegistryHelpers
// Size: 0x28 // Inherited bytes: 0x28
struct UAssetRegistryHelpers : UObject {
	// Functions

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FSoftObjectPath ToSoftObjectPath(struct FAssetData& InAssetData); // Offset: 0x1049abc98 // Return & Params: Num(2) Size(0x68)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FARFilter SetFilterTagsAndValues(struct FARFilter& InFilter, struct TArray<struct FTagAndValue>& InTagsAndValues); // Offset: 0x1049abb54 // Return & Params: Num(3) Size(0x1e0)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsValid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsValid(struct FAssetData& InAssetData); // Offset: 0x1049abaa0 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsUAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsUAsset(struct FAssetData& InAssetData); // Offset: 0x1049ab9ec // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsRedirector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsRedirector(struct FAssetData& InAssetData); // Offset: 0x1049ab938 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsAssetLoaded(struct FAssetData& InAssetData); // Offset: 0x1049ab884 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetTagValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetTagValue(struct FAssetData& InAssetData, struct FName& InTagName, struct FString& OutTagValue); // Offset: 0x1049ab70c // Return & Params: Num(4) Size(0x69)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetFullName(struct FAssetData& InAssetData); // Offset: 0x1049ab630 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetExportTextName(struct FAssetData& InAssetData); // Offset: 0x1049ab554 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetClass(struct FAssetData& InAssetData); // Offset: 0x1049ab4a0 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TScriptInterface<Class> GetAssetRegistry(); // Offset: 0x1049ab458 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetAsset(struct FAssetData& InAssetData); // Offset: 0x1049ab3a4 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FAssetData CreateAssetData(struct UObject* InAsset, bool bAllowBlueprintClass); // Offset: 0x1049ab2bc // Return & Params: Num(3) Size(0x60)
};

// Object Name: Class AssetRegistry.AssetRegistry
// Size: 0x28 // Inherited bytes: 0x28
struct UAssetRegistry : UInterface {
	// Functions

	// Object Name: Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void RunAssetsThroughFilter(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter); // Offset: 0x1049acc94 // Return & Params: Num(2) Size(0xf8)

	// Object Name: Function AssetRegistry.AssetRegistry.IsLoadingAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoadingAssets(); // Offset: 0x1049acc58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AssetRegistry.AssetRegistry.HasAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAssets(struct FName PackagePath, bool bRecursive); // Offset: 0x1049acb80 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function AssetRegistry.AssetRegistry.GetSubPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSubPaths(struct FString InBasePath, struct TArray<struct FString>& OutPathList, bool bInRecurse); // Offset: 0x1049aca28 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByPath
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetAssetsByPath(struct FName PackagePath, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets); // Offset: 0x1049ac890 // Return & Params: Num(5) Size(0x1b)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetAssetsByPackageName(struct FName PackageName, struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets); // Offset: 0x1049ac748 // Return & Params: Num(4) Size(0x1a)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetAssetsByClass(struct FName ClassName, struct TArray<struct FAssetData>& OutAssetData, bool bSearchSubClasses); // Offset: 0x1049ac600 // Return & Params: Num(4) Size(0x1a)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetAssets(struct FARFilter& Filter, struct TArray<struct FAssetData>& OutAssetData); // Offset: 0x1049ac4cc // Return & Params: Num(3) Size(0xf9)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAssetData GetAssetByObjectPath(struct FName ObjectPath, bool bIncludeOnlyOnDiskAssets); // Offset: 0x1049ac3cc // Return & Params: Num(3) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAllCachedPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetAllCachedPaths(struct TArray<struct FString>& OutPathList); // Offset: 0x1049ac31c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAllAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetAllAssets(struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets); // Offset: 0x1049ac210 // Return & Params: Num(3) Size(0x12)
};

