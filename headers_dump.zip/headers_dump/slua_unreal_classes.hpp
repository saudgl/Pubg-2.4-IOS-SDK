#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class slua_unreal.LatentDelegate
// Size: 0x30 // Inherited bytes: 0x28
struct ULatentDelegate : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LatentDelegate.OnLatentCallback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnLatentCallback(int threadRef); // Offset: 0x102189164 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaActor
// Size: 0x488 // Inherited bytes: 0x3c0
struct ALuaActor : AActor {
	// Fields
	char pad_0x3C0[0x60]; // Offset: 0x3c0 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x420 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x470 // Size: 0x10
	char pad_0x480[0x8]; // Offset: 0x480 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaActor.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x1021893a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaActor.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102189328 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaActorComponent
// Size: 0x1d8 // Inherited bytes: 0x110
struct ULuaActorComponent : UActorComponent {
	// Fields
	char pad_0x110[0x60]; // Offset: 0x110 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x170 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x1c0 // Size: 0x10
	char pad_0x1D0[0x8]; // Offset: 0x1d0 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x10218960c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102189590 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaDelegate
// Size: 0x38 // Inherited bytes: 0x28
struct ULuaDelegate : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function slua_unreal.LuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x1021897b4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class slua_unreal.LuaGameMode
// Size: 0x500 // Inherited bytes: 0x490
struct ALuaGameMode : AGameMode {
	// Fields
	char pad_0x490[0x60]; // Offset: 0x490 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x4f0 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaGameState
// Size: 0x4e0 // Inherited bytes: 0x420
struct ALuaGameState : AGameState {
	// Fields
	char pad_0x420[0x60]; // Offset: 0x420 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x480 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x4d0 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaInstancedActorComponent
// Size: 0x190 // Inherited bytes: 0x110
struct ULuaInstancedActorComponent : UActorComponent {
	// Fields
	char pad_0x110[0x68]; // Offset: 0x110 // Size: 0x68
	struct FString LuaFilePath; // Offset: 0x178 // Size: 0x10
	char pad_0x188[0x8]; // Offset: 0x188 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaInstancedActorComponent.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x102189b78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaInstancedActorComponent.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102189afc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaLevelScriptActor
// Size: 0x438 // Inherited bytes: 0x3c0
struct ALuaLevelScriptActor : ALevelScriptActor {
	// Fields
	char pad_0x3C0[0x60]; // Offset: 0x3c0 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x420 // Size: 0x10
	char pad_0x430[0x8]; // Offset: 0x430 // Size: 0x08

	// Functions

	// Object Name: Function slua_unreal.LuaLevelScriptActor.UnRegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistLuaTick(); // Offset: 0x102189da0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function slua_unreal.LuaLevelScriptActor.RegistLuaTick
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistLuaTick(float TickInterval); // Offset: 0x102189d24 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class slua_unreal.LuaOverrider
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaOverrider : UObject {
	// Functions

	// Object Name: Function slua_unreal.LuaOverrider.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	void TriggerAnimNotify(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class slua_unreal.InstancedLuaInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UInstancedLuaInterface : UInterface {
};

// Object Name: Class slua_unreal.LuaOverriderInterface
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaOverriderInterface : UInterface {
	// Functions

	// Object Name: Function slua_unreal.LuaOverriderInterface.GetLuaFilePath
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FString GetLuaFilePath(); // Offset: 0x10218a1f4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class slua_unreal.LuaPlayerController
// Size: 0x7e8 // Inherited bytes: 0x728
struct ALuaPlayerController : APlayerController {
	// Fields
	char pad_0x728[0x60]; // Offset: 0x728 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x788 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x7d8 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaPlayerState
// Size: 0x508 // Inherited bytes: 0x448
struct ALuaPlayerState : APlayerState {
	// Fields
	char pad_0x448[0x60]; // Offset: 0x448 // Size: 0x60
	struct FLuaNetSerialization LuaNetSerialization; // Offset: 0x4a8 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x4f8 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaObject
// Size: 0xa0 // Inherited bytes: 0x28
struct ULuaObject : UObject {
	// Fields
	char pad_0x28[0x68]; // Offset: 0x28 // Size: 0x68
	struct FString LuaFilePath; // Offset: 0x90 // Size: 0x10
};

// Object Name: Class slua_unreal.LuaUserWidget
// Size: 0x2d0 // Inherited bytes: 0x260
struct ULuaUserWidget : UUserWidget {
	// Fields
	char pad_0x260[0x60]; // Offset: 0x260 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x2c0 // Size: 0x10
};

// Object Name: Class slua_unreal.SluaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct USluaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetStringFromVar(struct FSluaBPVar Value, int Index); // Offset: 0x10218b3f4 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetObjectFromVar(struct FSluaBPVar Value, int Index); // Offset: 0x10218b2f4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetNumberFromVar(struct FSluaBPVar Value, int Index); // Offset: 0x10218b1f4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIntFromVar(struct FSluaBPVar Value, int Index); // Offset: 0x10218b0f4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBoolFromVar(struct FSluaBPVar Value, int Index); // Offset: 0x10218aff4 // Return & Params: Num(3) Size(0x25)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CreateVarFromString(struct FString Value); // Offset: 0x10218af20 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CreateVarFromObject(struct UObject* WorldContextObject, struct UObject* Value); // Offset: 0x10218ae54 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CreateVarFromNumber(float Value); // Offset: 0x10218adc4 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CreateVarFromInt(int Value); // Offset: 0x10218ad34 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CreateVarFromBool(bool Value); // Offset: 0x10218ac9c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FSluaBPVar CallToLuaWithArgs(struct UObject* WorldContextObject, struct FString FunctionName, struct TArray<struct FSluaBPVar>& Args, struct FString StateName); // Offset: 0x10218aaa0 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function slua_unreal.SluaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FSluaBPVar CallToLua(struct UObject* WorldContextObject, struct FString FunctionName, struct FString StateName); // Offset: 0x10218a914 // Return & Params: Num(4) Size(0x48)
};

