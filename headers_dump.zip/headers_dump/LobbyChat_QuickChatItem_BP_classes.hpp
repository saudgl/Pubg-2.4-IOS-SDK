#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Wifi_UIBP.Lobby_Main_Wifi_UIBP_C
// Size: 0x300 // Inherited bytes: 0x260
struct ULobby_Main_Wifi_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Animation_Battery; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_BanMatch; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_BanMatch; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Free; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_High; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Low; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_11; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_12; // Offset: 0x298 // Size: 0x08
	struct UImage* Image_13; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Image_37; // Offset: 0x2a8 // Size: 0x08
	struct UImage* Image_Charge; // Offset: 0x2b0 // Size: 0x08
	struct UImage* Image_xunyou; // Offset: 0x2b8 // Size: 0x08
	struct UProgressBar* ProgressBar_Battery; // Offset: 0x2c0 // Size: 0x08
	struct UTextBlock* TextBlock_CurTime; // Offset: 0x2c8 // Size: 0x08
	struct UTextBlock* TextBlock_FreeFlowTips; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TextBlock_Zone; // Offset: 0x2d8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Network; // Offset: 0x2e0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Quality; // Offset: 0x2e8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Signal; // Offset: 0x2f0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_WIFI; // Offset: 0x2f8 // Size: 0x08
};

