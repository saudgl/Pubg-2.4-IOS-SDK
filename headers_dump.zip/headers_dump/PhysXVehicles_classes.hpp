#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PhysXVehicles.WheeledVehicleMovementComponent
// Size: 0x300 // Inherited bytes: 0x190
struct UWheeledVehicleMovementComponent : UPawnMovementComponent {
	// Fields
	char pad_0x190[0x8]; // Offset: 0x190 // Size: 0x08
	char bDeprecatedSpringOffsetMode : 1; // Offset: 0x198 // Size: 0x01
	char pad_0x198_1 : 7; // Offset: 0x198 // Size: 0x01
	char pad_0x199[0x7]; // Offset: 0x199 // Size: 0x07
	struct TArray<struct FWheelSetup> WheelSetups; // Offset: 0x1a0 // Size: 0x10
	float Mass; // Offset: 0x1b0 // Size: 0x04
	float DragCoefficient; // Offset: 0x1b4 // Size: 0x04
	float ChassisWidth; // Offset: 0x1b8 // Size: 0x04
	float ChassisHeight; // Offset: 0x1bc // Size: 0x04
	bool bReverseAsBrake; // Offset: 0x1c0 // Size: 0x01
	bool bSuspensionSweep; // Offset: 0x1c1 // Size: 0x01
	char pad_0x1C2[0x2]; // Offset: 0x1c2 // Size: 0x02
	float DragArea; // Offset: 0x1c4 // Size: 0x04
	float EstimatedMaxEngineSpeed; // Offset: 0x1c8 // Size: 0x04
	float MaxEngineRPM; // Offset: 0x1cc // Size: 0x04
	float DebugDragMagnitude; // Offset: 0x1d0 // Size: 0x04
	struct FVector InertiaTensorScale; // Offset: 0x1d4 // Size: 0x0c
	float MinNormalizedTireLoad; // Offset: 0x1e0 // Size: 0x04
	float MinNormalizedTireLoadFiltered; // Offset: 0x1e4 // Size: 0x04
	float MaxNormalizedTireLoad; // Offset: 0x1e8 // Size: 0x04
	float MaxNormalizedTireLoadFiltered; // Offset: 0x1ec // Size: 0x04
	float ThresholdLongitudinalSpeed; // Offset: 0x1f0 // Size: 0x04
	int LowForwardSpeedSubStepCount; // Offset: 0x1f4 // Size: 0x04
	int HighForwardSpeedSubStepCount; // Offset: 0x1f8 // Size: 0x04
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
	struct TArray<struct UVehicleWheel*> Wheels; // Offset: 0x200 // Size: 0x10
	char pad_0x210[0x18]; // Offset: 0x210 // Size: 0x18
	char bUseRVOAvoidance : 1; // Offset: 0x228 // Size: 0x01
	char pad_0x228_1 : 7; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x3]; // Offset: 0x229 // Size: 0x03
	float RVOAvoidanceRadius; // Offset: 0x22c // Size: 0x04
	float RVOAvoidanceHeight; // Offset: 0x230 // Size: 0x04
	float AvoidanceConsiderationRadius; // Offset: 0x234 // Size: 0x04
	float RVOSteeringStep; // Offset: 0x238 // Size: 0x04
	float RVOThrottleStep; // Offset: 0x23c // Size: 0x04
	int AvoidanceUID; // Offset: 0x240 // Size: 0x04
	struct FNavAvoidanceMask AvoidanceGroup; // Offset: 0x244 // Size: 0x04
	struct FNavAvoidanceMask GroupsToAvoid; // Offset: 0x248 // Size: 0x04
	struct FNavAvoidanceMask GroupsToIgnore; // Offset: 0x24c // Size: 0x04
	float AvoidanceWeight; // Offset: 0x250 // Size: 0x04
	struct FVector PendingLaunchVelocity; // Offset: 0x254 // Size: 0x0c
	char pad_0x260[0x10]; // Offset: 0x260 // Size: 0x10
	struct FReplicatedVehicleState ReplicatedState; // Offset: 0x270 // Size: 0x14
	char pad_0x284[0x4]; // Offset: 0x284 // Size: 0x04
	float RawSteeringInput; // Offset: 0x288 // Size: 0x04
	float RawThrottleInput; // Offset: 0x28c // Size: 0x04
	float RawBrakeInput; // Offset: 0x290 // Size: 0x04
	char bRawHandbrakeInput : 1; // Offset: 0x294 // Size: 0x01
	char bRawGearUpInput : 1; // Offset: 0x294 // Size: 0x01
	char bRawGearDownInput : 1; // Offset: 0x294 // Size: 0x01
	char pad_0x294_3 : 5; // Offset: 0x294 // Size: 0x01
	char pad_0x295[0x3]; // Offset: 0x295 // Size: 0x03
	float SteeringInput; // Offset: 0x298 // Size: 0x04
	float ThrottleInput; // Offset: 0x29c // Size: 0x04
	float BrakeInput; // Offset: 0x2a0 // Size: 0x04
	float HandbrakeInput; // Offset: 0x2a4 // Size: 0x04
	float IdleBrakeInput; // Offset: 0x2a8 // Size: 0x04
	float StopThreshold; // Offset: 0x2ac // Size: 0x04
	float WrongDirectionThreshold; // Offset: 0x2b0 // Size: 0x04
	struct FVehicleInputRate ThrottleInputRate; // Offset: 0x2b4 // Size: 0x08
	struct FVehicleInputRate BrakeInputRate; // Offset: 0x2bc // Size: 0x08
	struct FVehicleInputRate HandbrakeInputRate; // Offset: 0x2c4 // Size: 0x08
	struct FVehicleInputRate SteeringInputRate; // Offset: 0x2cc // Size: 0x08
	char bWasAvoidanceUpdated : 1; // Offset: 0x2d4 // Size: 0x01
	char pad_0x2D4_1 : 7; // Offset: 0x2d4 // Size: 0x01
	char pad_0x2D5[0x2b]; // Offset: 0x2d5 // Size: 0x2b

	// Functions

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUseAutoGears(bool bUseAuto); // Offset: 0x10252eedc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetThrottleInput
	// Flags: [Native|Public|BlueprintCallable]
	void SetThrottleInput(float Throttle); // Offset: 0x10252ee58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTargetGear(int GearNum, bool bImmediate); // Offset: 0x10252ed9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetSteeringInput
	// Flags: [Native|Public|BlueprintCallable]
	void SetSteeringInput(float Steering); // Offset: 0x10252ed18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetPhysActive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPhysActive(bool bActive); // Offset: 0x10252ec94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetHandbrakeInput
	// Flags: [Native|Public|BlueprintCallable]
	void SetHandbrakeInput(bool bNewHandbrake); // Offset: 0x10252ec08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnoreMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x10252eb80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnore
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToIgnore(int GroupFlags); // Offset: 0x10252eb04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoidMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x10252ea7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoid
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToAvoid(int GroupFlags); // Offset: 0x10252ea00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGearUp(bool bNewGearUp); // Offset: 0x10252e97c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGearDown(bool bNewGearDown); // Offset: 0x10252e8f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetBrakeInput
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrakeInput(float Brake); // Offset: 0x10252e874 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroupMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x10252e7ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceGroup(int GroupFlags); // Offset: 0x10252e770 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceEnabled(bool bEnable); // Offset: 0x10252e6ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.ServerUpdateState
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int CurrentGear); // Offset: 0x10252e548 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetWheelShapeIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetWheelShapeIndices(struct TArray<int>& OutWheelShapeIndices); // Offset: 0x10252e4a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetUseAutoGears(); // Offset: 0x10252e46c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetTargetGear(); // Offset: 0x10252e438 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetForwardSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetForwardSpeed(); // Offset: 0x10252e404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEngineRotationSpeed(); // Offset: 0x10252e3d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineMaxRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEngineMaxRotationSpeed(); // Offset: 0x10252e39c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetCurrentGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetCurrentGear(); // Offset: 0x10252e368 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.EnableVehicleWheel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableVehicleWheel(int WheelIndex, bool InEnable); // Offset: 0x10252e2ac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.EnableVehicleSimulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableVehicleSimulation(bool InEnable); // Offset: 0x10252e228 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class PhysXVehicles.SimpleWheeledVehicleMovementComponent
// Size: 0x300 // Inherited bytes: 0x300
struct USimpleWheeledVehicleMovementComponent : UWheeledVehicleMovementComponent {
	// Functions

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSteerAngle(float SteerAngle, int WheelIndex); // Offset: 0x10252d430 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetDriveTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDriveTorque(float DriveTorque, int WheelIndex); // Offset: 0x10252d378 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetBrakeTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrakeTorque(float BrakeTorque, int WheelIndex); // Offset: 0x10252d2c0 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class PhysXVehicles.TireConfig
// Size: 0x50 // Inherited bytes: 0x30
struct UTireConfig : UDataAsset {
	// Fields
	float FrictionScale; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class PhysXVehicles.VehicleAnimInstance
// Size: 0x920 // Inherited bytes: 0x3c0
struct UVehicleAnimInstance : UAnimInstance {
	// Fields
	char pad_0x3C0[0x550]; // Offset: 0x3c0 // Size: 0x550
	struct UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // Offset: 0x910 // Size: 0x08
	char pad_0x918[0x8]; // Offset: 0x918 // Size: 0x08

	// Functions

	// Object Name: Function PhysXVehicles.VehicleAnimInstance.GetVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AWheeledVehicle* GetVehicle(); // Offset: 0x10252d978 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class PhysXVehicles.VehicleWheel
// Size: 0xf0 // Inherited bytes: 0x28
struct UVehicleWheel : UObject {
	// Fields
	struct UStaticMesh* CollisionMesh; // Offset: 0x28 // Size: 0x08
	bool bDontCreateShape; // Offset: 0x30 // Size: 0x01
	bool bAutoAdjustCollisionSize; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	struct FVector Offset; // Offset: 0x34 // Size: 0x0c
	float ShapeRadius; // Offset: 0x40 // Size: 0x04
	float ShapeWidth; // Offset: 0x44 // Size: 0x04
	float Mass; // Offset: 0x48 // Size: 0x04
	float DampingRate; // Offset: 0x4c // Size: 0x04
	float SteerAngle; // Offset: 0x50 // Size: 0x04
	bool bAffectedByHandbrake; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	struct UTireType* TireType; // Offset: 0x58 // Size: 0x08
	struct UTireConfig* TireConfig; // Offset: 0x60 // Size: 0x08
	float LatStiffMaxLoad; // Offset: 0x68 // Size: 0x04
	float LatStiffValue; // Offset: 0x6c // Size: 0x04
	float LongStiffValue; // Offset: 0x70 // Size: 0x04
	float SuspensionForceOffset; // Offset: 0x74 // Size: 0x04
	float SuspensionMaxRaise; // Offset: 0x78 // Size: 0x04
	float SuspensionMaxDrop; // Offset: 0x7c // Size: 0x04
	float SuspensionNaturalFrequency; // Offset: 0x80 // Size: 0x04
	float SuspensionDampingRatio; // Offset: 0x84 // Size: 0x04
	enum class EWheelSweepType SweepType; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	float MaxBrakeTorque; // Offset: 0x8c // Size: 0x04
	float MaxHandBrakeTorque; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct UWheeledVehicleMovementComponent* VehicleSim; // Offset: 0x98 // Size: 0x08
	int WheelIndex; // Offset: 0xa0 // Size: 0x04
	float DebugLongSlip; // Offset: 0xa4 // Size: 0x04
	float DebugLatSlip; // Offset: 0xa8 // Size: 0x04
	float DebugNormalizedTireLoad; // Offset: 0xac // Size: 0x04
	char pad_0xB0[0x4]; // Offset: 0xb0 // Size: 0x04
	float DebugWheelTorque; // Offset: 0xb4 // Size: 0x04
	float DebugLongForce; // Offset: 0xb8 // Size: 0x04
	float DebugLatForce; // Offset: 0xbc // Size: 0x04
	struct FVector Location; // Offset: 0xc0 // Size: 0x0c
	struct FVector OldLocation; // Offset: 0xcc // Size: 0x0c
	struct FVector Velocity; // Offset: 0xd8 // Size: 0x0c
	char pad_0xE4[0xc]; // Offset: 0xe4 // Size: 0x0c

	// Functions

	// Object Name: Function PhysXVehicles.VehicleWheel.IsInAir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInAir(); // Offset: 0x10252dc28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetSuspensionOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSuspensionOffset(); // Offset: 0x10252dbf4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSteerAngle(); // Offset: 0x10252dbc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetRotationAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRotationAngle(); // Offset: 0x10252db8c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class PhysXVehicles.WheeledVehicle
// Size: 0x430 // Inherited bytes: 0x420
struct AWheeledVehicle : APawn {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x420 // Size: 0x08
	struct UWheeledVehicleMovementComponent* VehicleMovement; // Offset: 0x428 // Size: 0x08
};

// Object Name: Class PhysXVehicles.WheeledVehicleMovementComponent4W
// Size: 0x460 // Inherited bytes: 0x300
struct UWheeledVehicleMovementComponent4W : UWheeledVehicleMovementComponent {
	// Fields
	struct FVehicleEngineData EngineSetup; // Offset: 0x300 // Size: 0x90
	struct FVehicleDifferential4WData DifferentialSetup; // Offset: 0x390 // Size: 0x1c
	char pad_0x3AC[0x4]; // Offset: 0x3ac // Size: 0x04
	struct FVehicleTransmissionData TransmissionSetup; // Offset: 0x3b0 // Size: 0x30
	struct FRuntimeFloatCurve SteeringCurve; // Offset: 0x3e0 // Size: 0x78
	float AckermannAccuracy; // Offset: 0x458 // Size: 0x04
	char pad_0x45C[0x4]; // Offset: 0x45c // Size: 0x04
};

