#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Tab_Item_UIBP.Lobby_Tab_Item_UIBP_C
// Size: 0x290 // Inherited bytes: 0x260
struct ULobby_Tab_Item_UIBP_C : UUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_tips; // Offset: 0x260 // Size: 0x08
	struct ULobby20_Tab_Item_UIBP_C* Lobby20_Tab_Item_UIBP; // Offset: 0x268 // Size: 0x08
	struct ULobby20_Tab_Item_UIBP_C* Lobby20_Tab_Item_UIBP_1; // Offset: 0x270 // Size: 0x08
	struct USizeBox* SizeBox_Diy01; // Offset: 0x278 // Size: 0x08
	struct USizeBox* SizeBox_Diy02; // Offset: 0x280 // Size: 0x08
	struct UUTRichTextBlock* UTRichTextBlock_3; // Offset: 0x288 // Size: 0x08
};

