#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LocalizationTextFixed_type.BP_STRUCT_LocalizationTextFixed_type
// Size: 0x130 // Inherited bytes: 0x00
struct FBP_STRUCT_LocalizationTextFixed_type {
	// Fields
	struct FString tr_0_2A65FE8050C91C9C71EC39C50EEE0B32; // Offset: 0x00 // Size: 0x10
	struct FString zhTW_1_623C684021A0C9232B2A96630E0C8377; // Offset: 0x10 // Size: 0x10
	struct FString fr_2_1821BB007577FA7E71ED46230EEE0A52; // Offset: 0x20 // Size: 0x10
	struct FString ja_3_542437C021D84D5171EC393D0EEE0B81; // Offset: 0x30 // Size: 0x10
	struct FString id_4_2522584076C0389B71EC395B0EEE0A74; // Offset: 0x40 // Size: 0x10
	struct FString vi_5_0866BCC026F9460571EC39880EEE0B49; // Offset: 0x50 // Size: 0x10
	struct FString en_6_6918D9C04A5FE5C171ED460E0EEE0A3E; // Offset: 0x60 // Size: 0x10
	struct FString zh_7_44793D80535998E871EC3B120EEE0C88; // Offset: 0x70 // Size: 0x10
	struct FString ru_8_4C5F3EC07A98F32D71EC3A1F0EEE0B15; // Offset: 0x80 // Size: 0x10
	struct FString zhHK_9_2DF5E2400824FCAB2B2A94FC0E0C822B; // Offset: 0x90 // Size: 0x10
	struct FString pt_10_6E547E002468C9BA71EC3A420EEE0BF4; // Offset: 0xa0 // Size: 0x10
	struct FString ko_11_03371B804CF0621871EC38E70EEE0B9F; // Offset: 0xb0 // Size: 0x10
	struct FString es_12_691DDB004A5FE5C671ED46030EEE0A43; // Offset: 0xc0 // Size: 0x10
	struct FString th_13_2A5BFC0050C91C9271EC39CB0EEE0B28; // Offset: 0xd0 // Size: 0x10
	struct FString de_14_3A0AF7401F47D0FF71ED46F20EEE0A25; // Offset: 0xe0 // Size: 0x10
	struct FString Key_15_4991AF400A82C50B0BCBD64F0EE09929; // Offset: 0xf0 // Size: 0x10
	struct FString ar_16_2D0959C01DFF92E171ED45870EEE0A02; // Offset: 0x100 // Size: 0x10
	struct FString hi_17_762279404BA823E771EC39470EEE0A69; // Offset: 0x110 // Size: 0x10
	struct FString ms_18_6144DD0023208B8E71EC38A90EEE0BC3; // Offset: 0x120 // Size: 0x10
};

