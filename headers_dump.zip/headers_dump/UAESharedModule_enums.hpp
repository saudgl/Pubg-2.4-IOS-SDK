#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UAESharedModule.EUAEBlackboardType
enum class EUAEBlackboardType : uint8 {
	EBT_Object = 0,
	EBT_WeakObjectPtr = 1,
	EBT_Class = 2,
	EBT_Enum = 3,
	EBT_Int = 4,
	EBT_UInt = 5,
	EBT_Float = 6,
	EBT_Bool = 7,
	EBT_String = 8,
	EBT_Name = 9,
	EBT_Vector = 10,
	EBT_Rotator = 11,
	EBT_MAX = 12
};

