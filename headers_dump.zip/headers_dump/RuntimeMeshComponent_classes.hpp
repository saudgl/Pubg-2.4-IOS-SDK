#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RuntimeMeshComponent.RuntimeMeshComponent
// Size: 0x890 // Inherited bytes: 0x790
struct URuntimeMeshComponent : UMeshComponent {
	// Fields
	struct FScriptMulticastDelegate CollisionUpdated; // Offset: 0x790 // Size: 0x10
	bool bUseComplexAsSimpleCollision; // Offset: 0x7a0 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x7a1 // Size: 0x01
	bool bShouldSerializeMeshData; // Offset: 0x7a2 // Size: 0x01
	enum class ERuntimeMeshCollisionCookingMode CollisionMode; // Offset: 0x7a3 // Size: 0x01
	char pad_0x7A4[0x4]; // Offset: 0x7a4 // Size: 0x04
	struct UBodySetup* BodySetup; // Offset: 0x7a8 // Size: 0x08
	char pad_0x7B0[0x30]; // Offset: 0x7b0 // Size: 0x30
	struct TArray<struct FRuntimeMeshCollisionSection> MeshCollisionSections; // Offset: 0x7e0 // Size: 0x10
	struct TArray<struct FRuntimeConvexCollisionSection> ConvexCollisionSections; // Offset: 0x7f0 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x800 // Size: 0x1c
	char pad_0x81C[0x4]; // Offset: 0x81c // Size: 0x04
	struct FRuntimeMeshComponentPrePhysicsTickFunction PrePhysicsTick; // Offset: 0x820 // Size: 0x58
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x878 // Size: 0x10
	char pad_0x888[0x8]; // Offset: 0x888 // Size: 0x08

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.UpdateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles); // Offset: 0x10226bb0c // Return & Params: Num(10) Size(0x7a)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetSectionTessellationTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSectionTessellationTriangles(int SectionIndex, struct TArray<int>& TessellationTriangles, bool bShouldMoveArray); // Offset: 0x10226b9d4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility); // Offset: 0x10226b918 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionCollisionEnabled(int SectionIndex, bool bNewCollisionEnabled); // Offset: 0x10226b85c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCastsShadow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionCastsShadow(int SectionIndex, bool bNewCastsShadow); // Offset: 0x10226b7a0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshCollisionSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMeshCollisionSection(int CollisionSectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles); // Offset: 0x10226b64c // Return & Params: Num(3) Size(0x28)

	// Object Name: DelegateFunction RuntimeMeshComponent.RuntimeMeshComponent.RuntimeMeshCollisionUpdatedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void RuntimeMeshCollisionUpdatedDelegate__DelegateSignature(); // Offset: 0x103e03170 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionVisible(int SectionIndex); // Offset: 0x10226b5c0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsMeshSectionCollisionEnabled(int SectionIndex); // Offset: 0x10226b534 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCastingShadows
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionCastingShadows(int SectionIndex); // Offset: 0x10226b4a8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumSections(); // Offset: 0x10226b474 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetLastSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetLastSectionIndex(); // Offset: 0x10226b440 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.FirstAvailableMeshSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int FirstAvailableMeshSectionIndex(); // Offset: 0x10226b40c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.EndBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndBatchUpdates(); // Offset: 0x10226b3f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.DoesSectionExist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool DoesSectionExist(int SectionIndex); // Offset: 0x10226b36c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.CreateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCreateCollision, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles, enum class EUpdateFrequency UpdateFrequency); // Offset: 0x10226aebc // Return & Params: Num(12) Size(0x7c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.CookCollisionNow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CookCollisionNow(); // Offset: 0x10226aea8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshSection(int SectionIndex); // Offset: 0x10226ae2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshCollisionSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshCollisionSection(int CollisionSectionIndex); // Offset: 0x10226adb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCollisionConvexMeshes(); // Offset: 0x10226ad9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshSections(); // Offset: 0x10226ad88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshCollisionSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshCollisionSections(); // Offset: 0x10226ad74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.BeginBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginBatchUpdates(); // Offset: 0x10226ad58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts); // Offset: 0x10226ac74 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct URuntimeMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int LODIndex, int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x10226d584 // Return & Params: Num(8) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.GenerateTessellationIndexBuffer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GenerateTessellationIndexBuffer(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<int>& OutTessTriangles); // Offset: 0x10226d2cc // Return & Params: Num(6) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, struct TArray<int>& Triangles); // Offset: 0x10226d170 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void CreateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x10226cee4 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CopyRuntimeMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CopyRuntimeMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComp, int LODIndex, struct URuntimeMeshComponent* RuntimeMeshComp, bool bShouldCreateCollision); // Offset: 0x10226cdb4 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConvertQuadToTriangles(struct TArray<int>& Triangles, int Vert0, int Vert1, int Vert2, int Vert3); // Offset: 0x10226cc18 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x10226c9c8 // Return & Params: Num(5) Size(0x50)
};

