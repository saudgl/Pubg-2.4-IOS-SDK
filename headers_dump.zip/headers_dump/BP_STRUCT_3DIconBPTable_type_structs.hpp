#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_3DIconBPTable_type.BP_STRUCT_3DIconBPTable_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_3DIconBPTable_type {
	// Fields
	struct FString CName_0_197F95006C7D41D02E19833803105905; // Offset: 0x00 // Size: 0x10
	int ID_1_6249C74062AE6BD53F17F69101F33054; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Path_2_064E67406FC200F32023304A0331E958; // Offset: 0x18 // Size: 0x10
};

